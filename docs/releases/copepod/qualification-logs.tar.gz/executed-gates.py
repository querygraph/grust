import datetime, json, os, pathlib, subprocess, time, hashlib
root = pathlib.Path('/Users/alexy/src/grust-arrow-pipeline')
os.chdir(root)
if subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip():
    raise SystemExit('Qualification requires clean source')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
receipt = pathlib.Path('/tmp/grust-copepod-release') / stamp
receipt.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env['PATH'] = '/opt/homebrew/bin:/usr/local/bin:' + env['PATH']
env['CARGO_BUILD_JOBS'] = '4'
steps = [
    ('fmt', ['cargo','fmt','--all','--','--check']),
    ('build', ['cargo','build','--locked','--workspace','--all-features']),
    ('tests', ['cargo','test','--locked','--workspace','--all-features']),
    ('clippy', ['cargo','clippy','--locked','--workspace','--all-features','--all-targets','--','-D','warnings']),
    ('rustdoc', ['cargo','doc','--locked','--workspace','--all-features','--no-deps']),
    ('package', ['cargo','package','--workspace','--allow-dirty']),
    ('attribution', ['bash','scripts/verify-package-attribution.sh']),
    ('integration-quick', ['bash','scripts/integration-test.sh','--profile','quick']),
]
state = {'source':source, 'version':'0.15.1', 'host':'capitola', 'started':stamp,
         'cargo_build_jobs':4, 'complete':False, 'steps':[],
         'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),
         'cargo':subprocess.check_output(['cargo','-V'],env=env,text=True),
         'boundary':'Quick integration covers local Ladybug/LanceDB/CocoIndex. No external service suite is claimed; unchanged Arrow/ADBC native paths retain Gooseneck evidence.'}
print('RECEIPT',receipt,flush=True)
for name, command in steps:
    started=time.monotonic()
    print('START',name,flush=True)
    step_env=env.copy()
    if name=='rustdoc': step_env['RUSTDOCFLAGS']='-D warnings'
    with (receipt/(name+'.log')).open('w') as out:
        code=subprocess.run(command,env=step_env,stdout=out,stderr=subprocess.STDOUT).returncode
    state['steps'].append({'name':name,'command':command,'exit_code':code,'seconds':time.monotonic()-started})
    (receipt/'status.json').write_text(json.dumps(state,indent=2)+'\n')
    print('DONE',name,code,flush=True)
    if code: raise SystemExit(code)
archives=[]
metadata=json.loads(subprocess.check_output(['cargo','metadata','--locked','--no-deps','--format-version','1'],env=env,text=True))
members=set(metadata['workspace_members'])
packages=[p for p in metadata['packages'] if p['id'] in members]
for package in sorted(packages,key=lambda p:p['name']):
    path=root/'target/package'/f"{package['name']}-{package['version']}.crate"
    with path.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
    archives.append({'name':path.name,'bytes':path.stat().st_size,'sha256':digest})
state['archives']=archives
state['complete']=True
(receipt/'status.json').write_text(json.dumps(state,indent=2)+'\n')
print('COMPLETE',len(archives),'archives',flush=True)
