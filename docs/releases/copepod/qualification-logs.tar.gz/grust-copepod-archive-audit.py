import pathlib, subprocess, json, tarfile, hashlib
root=pathlib.Path('/Users/alexy/src/grust-arrow-pipeline')
receipt=pathlib.Path('/tmp/grust-copepod-release/20260914T170408Z')
state=json.loads((receipt/'status.json').read_text())
assert all(s['exit_code']==0 for s in state['steps'])
assert {s['name'] for s in state['steps']}=={'fmt','build','tests','clippy','rustdoc','package','attribution','integration-quick'}
metadata=json.loads(subprocess.check_output(['/opt/homebrew/bin/cargo','metadata','--locked','--no-deps','--format-version','1'],cwd=root,text=True))
members=set(metadata['workspace_members']);rows=[]
for package in sorted((p for p in metadata['packages'] if p['id'] in members),key=lambda p:p['name']):
 filename=f"{package['name']}-{package['version']}.crate"
 qualified=[]
 for path in (root/'target/package').rglob(filename):
  with tarfile.open(path) as tar:
   vcs=json.load(tar.extractfile(f"{package['name']}-{package['version']}/.cargo_vcs_info.json"))
  if vcs['git']['sha1']==state['source'] and not vcs['git'].get('dirty',False):
   with path.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
   qualified.append((path,digest))
 assert qualified and len({h for _,h in qualified})==1,(filename,qualified)
 path,digest=qualified[0]
 rows.append({'crate':package['name'],'version':package['version'],'publish':package.get('publish')!=[], 'path':str(path),'sha256':digest,'bytes':path.stat().st_size})
assert len(rows)==24,len(rows)
(receipt/'archive-audit.json').write_text(json.dumps({'source':state['source'],'packages':rows,'complete':True},indent=2)+'\n')
print('VERIFIED',len(rows),'archives')
