#!/usr/bin/env python3
"""Receipt-only A2/A3 audit and shared-host ratio report; no payload reads."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

Json = dict[str, Any]
ENGINES = ("graphframes", "pecan")
ABBA = ["graphframes", "pecan", "pecan", "graphframes"]
GIB = 2**30


@dataclass(slots=True)
class Document:
    path: str
    sha256: str | None = None
    bytes: int | None = None
    data: Json | None = None
    error: str | None = None

    def evidence(self) -> Json:
        return {key: value for key, value in asdict(self).items() if key != "data"}


def read_json(path: Path) -> Document:
    item = Document(str(path))
    try:
        raw = path.read_bytes()
        item.sha256, item.bytes = hashlib.sha256(raw).hexdigest(), len(raw)
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError("JSON document must be an object")
        item.data = value
    except (OSError, ValueError) as error:
        item.error = str(error)
    return item


def mapping(value: Any) -> Json:
    return value if isinstance(value, dict) else {}


def positive(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def rounded(value: float) -> float:
    return float(f"{value:.3g}")


def integer(value: Any) -> int | None:
    try:
        return int(value) if value is not None else None
    except (ValueError, TypeError):
        return None


def fingerprint(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def closed(host: Json, record: Json, plan: Json) -> list[str]:
    errors: list[str] = []
    if host.get("certain_container_closure") is not True or host.get("lock_retained") is not False:
        errors.append("host closure or released-lock evidence missing")
    if not host.get("finished_utc") or host.get("error"):
        errors.append("host finalization missing or errored")
    inspect = mapping(record.get("inspect"))
    state = mapping(inspect.get("state"))
    created = mapping(record.get("create"))
    identifier = str(created.get("stdout", "")).strip()
    if len(identifier) != 64 or any(c not in "0123456789abcdef" for c in identifier) or inspect.get("id") != identifier:
        errors.append("container create/inspect identity mismatch or missing")
    if inspect.get("image") != plan.get("image"):
        errors.append("container image differs from plan")
    if created.get("returncode") != 0 or record.get("attach_returncode") != 0:
        errors.append("container create/attach did not succeed")
    if state.get("Running") is not False or state.get("ExitCode") != 0 or state.get("OOMKilled") is not False or state.get("Error"):
        errors.append("container final state did not pass")
    if mapping(record.get("remove")).get("returncode") != 0 or record.get("transport_errors"):
        errors.append("container removal or transport failed")
    if any(record.get(key) for key in ("outer_timeout", "operator_interrupted", "kill", "forced_cleanup_kill")):
        errors.append("container timeout, interruption or forced cleanup")
    if mapping(mapping(record.get("copied")).get("artifacts")).get("returncode") != 0:
        errors.append("artifact copy did not succeed")
    embedded = mapping(mapping(host.get("records")).get("container"))
    # The immutable matrix record is saved before the host adds its absence check.
    if {key: value for key, value in embedded.items() if key != "absence_verified"} != {key: value for key, value in record.items() if key != "absence_verified"}:
        errors.append("host embedded and separate matrix records differ")
    absence = mapping(embedded.get("absence_verified"))
    message = str(absence.get("stderr", "")).casefold()
    if absence.get("returncode") != 1 or not any(text in message for text in ("no such object", "no such container")):
        errors.append("post-removal container absence evidence missing")
    return errors


def numeric_memory(cell: Json) -> Json:
    cgroups = mapping(cell.get("cgroups"))
    return {
        "sampled_engine_pss_peak_bytes": cell.get("sampled_engine_pss_peak_bytes"),
        "sampled_engine_rows": cell.get("sampled_engine_rows"),
        "sampled_engine_pss_rows": cell.get("sampled_engine_pss_rows"),
        "sampled_container_execute_peaks": mapping(mapping(cell.get("memory")).get("phase_peaks")).get("execute"),
        "sample_coverage": cell.get("memory"),
        "after_engine_cgroup_peak_bytes": integer(mapping(cgroups.get("after_engine")).get("memory.peak")),
        "final_lifetime_cgroup_peak_bytes": integer(mapping(cgroups.get("final")).get("memory.peak")),
        "cgroup_snapshots": cgroups,
        "boundaries": cell.get("memory_boundaries"),
    }


def audit_cell(step: Json, base: Path, plan: Json) -> Json:
    directory = base / step["run_id"]
    documents = {"host": read_json(directory / "result.json"),
                 "cell": read_json(directory / "container/artifacts/receipt.json"),
                 "container": read_json(directory / "container-record.json"),
                 "bootstrap": read_json(directory / "container/artifacts/bootstrap-receipt.json"),
                 "configuration": read_json(directory / "configuration.json")}
    host, cell, record, bootstrap, configuration = (documents[key].data or {} for key in documents)
    row: Json = {"plan_step": step, "evidence": {key: item.evidence() for key, item in documents.items()},
                 "host_outcome": host.get("outcome"), "cell_outcome": cell.get("outcome"),
                 "engine_outcome": mapping(cell.get("engine_receipt")).get("outcome"),
                 "qualified": False, "reasons": [], "status": "missing" if not directory.exists() else "incomplete"}
    errors = row["reasons"]
    for key, item in documents.items():
        if item.error:
            errors.append(f"{key}: {item.error}")
    for name, data in (("host", host), ("cell", cell), ("bootstrap", bootstrap)):
        if data.get("outcome") != "passed":
            errors.append(f"{name} outcome is {data.get('outcome')!r}")
    if host.get("producer_outcome") != "passed" or host.get("run_id") != step["run_id"] or host.get("kind") != "cell":
        errors.append("host producer/run identity mismatch")
    if record:
        errors.extend(closed(host, record, plan))
    config = mapping(cell.get("config"))
    if any(config.get(key) != step.get(key) for key in ("engine", "algorithm", "mode")):
        errors.append("cell configuration differs from planned contrast")
    spec = mapping(configuration.get("specification"))
    try:
        expected_config = json.loads(spec.get("config_text", "null"))
    except (TypeError, ValueError):
        expected_config = None
    if expected_config != config or not config:
        errors.append("host exact configured cell differs or missing")
    if not cell.get("finished_utc") or cell.get("execution_verified") is not True or cell.get("engine_wait_completed") is not True or cell.get("engine_returncode") != 0:
        errors.append("completed verified engine exit missing")
    if not positive(cell.get("launch_to_exit_seconds")):
        errors.append("positive finite launch-to-exit time missing")
    if any(cell.get(key) for key in ("outer_timeout", "remaining_processes", "remaining_after_cleanup", "emergency_cleanup", "observer_error", "final_processes", "finalization_errors", "interruption_signals")):
        errors.append("cell observation/ownership/finalization failure")
    identities = mapping(cell.get("identities_before"))
    if not identities or identities != cell.get("identities_after"):
        errors.append("before/after source/input/helper identities differ or missing")
    if identities.get("controller") != plan.get("source") or identities.get("graphframes_binary") != plan.get("graphframes_binary_sha256"):
        errors.append("source or external binary differs from planned pin")
    reference = mapping(identities.get("reference_phase"))
    validation = mapping(reference.get("validation"))
    if reference.get("outcome") != "passed" or validation.get("isolated_vertex_count") != 0:
        errors.append("passed reference/zero-isolate scope missing")
    if plan.get("source_vertex") is not None and validation.get("source") != plan["source_vertex"]:
        errors.append("validated BFS source differs from declared plan source")
    oracle = mapping(cell.get("correctness"))
    vertices = validation.get("vertex_rows")
    mismatch_key = "distance_mismatches" if step["algorithm"] == "bfs" else "membership_mismatches"
    if not vertices or oracle.get("rows") != vertices or oracle.get("unique") != vertices or oracle.get(mismatch_key) != 0 or not oracle.get("result_files") or not oracle.get("physical_schemas"):
        errors.append("full physical output oracle pass evidence missing")
    if step["algorithm"] == "bfs" and (oracle.get("source") != validation.get("source") or oracle.get("directed") is not True):
        errors.append("directed BFS source differs from validated reference")
    method = ("unweighted-forward-hops" if step["algorithm"] == "bfs" else "randomized-contraction") if step["engine"] == "graphframes" else {"bfs": "frontier", "wcc-randomized": "randomized", "wcc-min-label": "min_label"}[step["algorithm"]]
    if cell.get("actual_engine_method") != method:
        errors.append("actual engine method missing or mislabelled")
    engine = mapping(cell.get("engine_receipt"))
    if step["engine"] == "pecan" and (engine.get("outcome") != "passed" or mapping(engine.get("result")).get("converged") is not True or engine.get("cleanup_errors") or engine.get("staging_payload_after_shutdown")):
        errors.append("Pecan convergence or engine cleanup did not pass")
    memory = mapping(cell.get("memory"))
    if memory.get("execution_sampled") is not True or not positive(cell.get("sampled_engine_pss_rows")) or not positive(cell.get("sampled_engine_pss_peak_bytes")):
        errors.append("complete execute-phase engine PSS observation missing")
    limits = mapping(mapping(cell.get("cgroups")).get("before"))
    expected_limits = {"cpu.max": "1600000 100000", "memory.max": str(32 * GIB), "memory.swap.max": "0"}
    if any(limits.get(key) != value for key, value in expected_limits.items()):
        errors.append("producer 16CPU/32GiB/no-swap envelope differs")
    retained_limits = mapping(mapping(record.get("inspect")).get("limits"))
    if any(retained_limits.get(key) != value for key, value in {"NanoCpus": 16 * 10**9, "CpusetCpus": "0-15", "Memory": 32 * GIB, "MemorySwap": 32 * GIB, "Init": True}.items()):
        errors.append("retained container limits differ")
    row.update(qualified=not errors, actual_engine_method=cell.get("actual_engine_method"),
               config=config, identity_fingerprint=fingerprint(identities) if identities else None,
               timing={"launch_to_exit_seconds": cell.get("launch_to_exit_seconds"),
                       "launch_until_interruption_seconds": cell.get("launch_until_interruption_seconds"),
                       "boundary": cell.get("measured_boundary"), "outside_boundary": cell.get("outside_boundary"),
                       "supervisor_phases": cell.get("phases"), "oracle_seconds": cell.get("oracle_seconds"),
                       "engine_phases": engine.get("phases"), "engine_phase_scope": engine.get("timing_scope"),
                       "engine_phases_overlap": "input_snapshot is nested in public_algorithm; durations are not additive and are not subtracted"},
               memory=numeric_memory(cell), correctness=cell.get("correctness"),
               iterations=mapping(engine.get("result")).get("iterations"), rounds=engine.get("rounds"),
               guest_steal_fraction=cell.get("guest_steal_fraction"),
               engine_guest_steal_fraction=engine.get("guest_steal_fraction"),
               host_observations=host.get("observations"), errors={"host": host.get("error"), "cell": cell.get("error"), "engine": engine.get("error")})
    if not errors:
        row["status"] = "passed"
    elif any(value in ("known_mismatch", "passed_with_known_mismatch") for value in (host.get("outcome"), cell.get("outcome"), engine.get("outcome"))):
        row["status"] = "known_mismatch"
    elif any(value and value not in ("checking", "running", "passed") for value in (host.get("outcome"), cell.get("outcome"), engine.get("outcome"))):
        row["status"] = "failed"
    return row


def ancillary(base: Path, planned: set[str], plan: Json) -> list[Json]:
    rows: list[Json] = []
    for path in sorted(base.glob("*/result.json")):
        if path.parent.name in planned:
            continue
        host_document = read_json(path)
        host = host_document.data or {}
        producer_path = "stage/stage-receipt.json" if host.get("action") == "stage" else "container/artifacts/receipt.json"
        producer_document = read_json(path.parent / producer_path)
        producer = producer_document.data or {}
        container_document = read_json(path.parent / "container-record.json")
        errors = closed(host, container_document.data or {}, plan) if host.get("kind") in ("validation", "compatibility") else []
        accepted = host.get("outcome") in ("passed", "passed_with_known_mismatch") and producer.get("outcome") == host.get("producer_outcome") and not errors
        rows.append({"run_id": host.get("run_id", path.parent.name), "kind": host.get("kind"), "action": host.get("action"),
                     "host_outcome": host.get("outcome"), "producer_outcome": producer.get("outcome"),
                     "accepted_phase_closure": accepted, "closure_errors": errors,
                     "error": host.get("error"), "producer_error": producer.get("error"),
                     "evidence": {"host": host_document.evidence(), "producer": producer_document.evidence(), "container": container_document.evidence()},
                     "known_mismatches": [control for control in producer.get("controls", []) if control.get("outcome") == "known_mismatch"],
                     "proceed_scope": producer.get("proceed_scope"), "validation": producer.get("validation"),
                     "certificate": producer.get("certificate"), "phase_timings": producer.get("timings"), "memory": producer.get("memory"),
                     "originals_before": producer.get("originals_before"), "originals_after": producer.get("originals_after"),
                     "references": producer.get("references")})
    return rows


def contrast(rows: list[Json], prerequisites: list[str]) -> Json:
    steps = [row["plan_step"] for row in rows]
    measured = sorted((row for row in rows if row["plan_step"]["role"] == "measured"), key=lambda row: row["plan_step"]["sequence_within_contrast"])
    warmups = [row for row in rows if row["plan_step"]["role"] == "warmup"]
    blockers = list(prerequisites)
    if len(warmups) != 2 or Counter(row["plan_step"]["engine"] for row in warmups) != Counter(ENGINES) or not all(row["qualified"] for row in warmups):
        blockers.append("both planned warmups must pass; excluded from ratios")
    if len(measured) != 8 or Counter(row["plan_step"]["engine"] for row in measured) != Counter({engine: 4 for engine in ENGINES}):
        blockers.append("requires exactly four measured samples per engine")
    if not all(row["qualified"] for row in measured):
        blockers.append("missing, incomplete or failed measured cell")
    if len({row.get("identity_fingerprint") for row in measured}) != 1 or any(not row.get("identity_fingerprint") for row in measured):
        blockers.append("measured source/helper/binary/input/reference identities do not match")
    blocks = {block: [row for row in measured if row["plan_step"]["measured_block"] == block] for block in (1, 2)}
    for number, block in blocks.items():
        if [row["plan_step"]["engine"] for row in block] != ABBA:
            blockers.append(f"block {number} is not the planned graphframes/Pecan/Pecan/graphframes sequence")
    summary: Json = {"item": steps[0]["item"], "mode": steps[0]["mode"], "algorithm": steps[0]["algorithm"],
                     "graphframes_execution": "single CLI process with 16 workers in both local and process-cluster contrasts",
                     "pecan_execution": "driver plus two workers inside one container on one host" if steps[0]["mode"] == "process-cluster" else "local runtime",
                     "ratio_status": "withheld" if blockers else "qualified_receipt_evidence", "blockers": blockers,
                     "measured_run_ids": [row["plan_step"]["run_id"] for row in measured],
                     "warmup_run_ids": [row["plan_step"]["run_id"] for row in warmups],
                     "median_pecan_over_graphframes": None, "block_geomean_paired_ratios": [],
                     "sample_limit": "n=4 per engine, two ordered ABBA blocks; shared host and cache effects; no multihost or absolute-performance inference"}
    if blockers:
        return summary
    times = {engine: [row["timing"]["launch_to_exit_seconds"] for row in measured if row["plan_step"]["engine"] == engine] for engine in ENGINES}
    medians = {engine: statistics.median(values) for engine, values in times.items()}
    summary["diagnostic_median_seconds"] = medians
    summary["median_pecan_over_graphframes"] = rounded(medians["pecan"] / medians["graphframes"])
    for number, block in blocks.items():
        pairs = []
        for a, b in ((block[0], block[1]), (block[2], block[3])):
            pecan, gf = (a, b) if a["plan_step"]["engine"] == "pecan" else (b, a)
            ratio = pecan["timing"]["launch_to_exit_seconds"] / gf["timing"]["launch_to_exit_seconds"]
            pairs.append({"pecan_run_id": pecan["plan_step"]["run_id"], "graphframes_run_id": gf["plan_step"]["run_id"], "pecan_over_graphframes": rounded(ratio), "unrounded_ratio": ratio})
        geometric = math.exp(statistics.mean(math.log(pair["unrounded_ratio"]) for pair in pairs))
        summary["block_geomean_paired_ratios"].append({"block": number, "pecan_over_graphframes": rounded(geometric), "adjacent_pairs": pairs})
    return summary


def summarize(plan_path: Path, base: Path, prior_bases: list[Path] | None = None) -> Json:
    plan_document = read_json(plan_path)
    if plan_document.data is None:
        raise ValueError(plan_document.error)
    plan = plan_document.data
    steps = plan["steps"]
    ids = [step["run_id"] for step in steps]
    if len(ids) != len(set(ids)) or any(Path(name).name != name or name in (".", "..") for name in ids):
        raise ValueError("planned IDs must be unique safe directory names")
    if any(step.get("engine") not in ENGINES or step.get("mode") not in ("local", "process-cluster") or step.get("algorithm") not in ("wcc-randomized", "wcc-min-label", "bfs") or step.get("role") not in ("warmup", "measured") for step in steps):
        raise ValueError("unsupported plan contrast, engine or role")
    cells = [audit_cell(step, base, plan) for step in steps]
    phases = ancillary(base, set(ids), plan)
    prerequisites = []
    for kind in ("validation", "compatibility"):
        if not any(row["kind"] == kind and row["accepted_phase_closure"] for row in phases):
            prerequisites.append(f"no accepted retained {kind} phase closure")
    groups: dict[tuple[str, str], list[Json]] = {}
    for cell in cells:
        step = cell["plan_step"]
        groups.setdefault((step["mode"], step["algorithm"]), []).append(cell)
    contrasts = [contrast(rows, prerequisites) for rows in groups.values()]
    return {"schema_version": 1, "observed_utc": datetime.now(timezone.utc).isoformat(),
            "status": "complete_receipt_evidence" if cells and all(cell["qualified"] for cell in cells) and not prerequisites else "incomplete",
            "audit_scope": "Retained host, bootstrap, container and cell JSON only; no Parquet/input reads, no independent rehash of payloads, no raw-sampler recomputation, no Docker or engine execution. Correctness is retained full-oracle receipt evidence, not a new physical-output audit.",
            "snapshot_scope": "Documents read individually while the queue may be active; only closed, finalized cells qualify. This is not an atomic snapshot of the whole queue.",
            "ratio_definition": "median of four Pecan launch-to-exit diagnostics / median of four graphframes diagnostics within each execution class and algorithm; each ABBA block also reports geometric mean of adjacent Pecan/GF ratios (positions 2/1 and 3/4). Warmups excluded; no ratio for missing/failed/known-mismatch or unmatched samples.",
            "performance_scope": "Ratios on Morrobay, a shared host. Raw seconds are diagnostics; no absolute-performance, multihost, generic signed-ID WCC, rebuilt-runtime, PageRank or larger-scale claim.",
            "plan_evidence": plan_document.evidence(), "plan_metadata": {key: value for key, value in plan.items() if key != "steps"},
            "archive_base": str(base), "summarizer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "cell_counts": dict(Counter(cell["status"] for cell in cells)), "prerequisite_blockers": prerequisites,
            "contrasts": contrasts, "cells": cells, "other_retained_attempts": phases,
            "prior_archive_attempts": [{"archive_base": str(previous), "attempts": ancillary(previous, set(), plan)} for previous in prior_bases or []]}


def markdown(report: Json) -> str:
    lines = ["# A2/A3 receipt comparison", "", f"Status: **{report['status']}**. Observed UTC: {report['observed_utc']}.", "", report["performance_scope"], "", report["audit_scope"], "", "## Shared-host ratios", "", "Pecan / graphframes; values have three significant digits. All raw seconds below are diagnostics. graphframes is always a single CLI process with 16 workers; A3 changes Pecan to driver + two workers on one host.", "", "| Execution class | Algorithm | Median ratio | ABBA block 1 | ABBA block 2 | Qualification |", "| --- | --- | ---: | ---: | ---: | --- |"]
    for contrast_row in report["contrasts"]:
        blocks = contrast_row["block_geomean_paired_ratios"]
        values = [str(row["pecan_over_graphframes"]) for row in blocks] if blocks else ["—", "—"]
        why = "; ".join(contrast_row["blockers"]) or "4 measured samples/engine; both ABBA blocks"
        lines.append(f"| {contrast_row['mode']} | {contrast_row['algorithm']} | {contrast_row['median_pecan_over_graphframes'] or '—'} | {values[0]} | {values[1]} | {why} |")
    lines.extend(["", "n=4 per engine and two ordered blocks limit inference. Warmups are retained and excluded from statistics; failed and known-mismatch cells cannot qualify. Input cache warming is retained in the boundary. No phases are subtracted.", "", "## Every planned cell", "", "| Run ID | Role / block | Host / cell | Diagnostic launch→exit seconds | Engine sampled PSS GiB | Final container lifetime peak GiB | Guest steal | Qualified |", "| --- | --- | --- | ---: | ---: | ---: | ---: | --- |"])
    for cell in report["cells"]:
        step, timing, memory = cell["plan_step"], cell["timing"], cell["memory"]
        def display(value: Any, divisor: float = 1) -> str:
            return f"{value / divisor:.6g}" if type(value) in (int, float) else "—"
        lines.append(f"| {step['run_id']} | {step['role']} / {step['measured_block'] or '—'} | {cell['host_outcome'] or 'missing'} / {cell['cell_outcome'] or 'missing'} | {display(timing['launch_to_exit_seconds'])} | {display(memory['sampled_engine_pss_peak_bytes'], GIB)} | {display(memory['final_lifetime_cgroup_peak_bytes'], GIB)} | {display(cell['guest_steal_fraction'])} | {cell['qualified']} |")
    lines.extend(["", "## Phase and memory boundaries", "", "The comparison timer spans engine launch through completed exit, including input, snapshots, algorithm, export and engine cleanup. Parent identity hashing, full oracle and final ownership checks are outside. JSON retains each cell's exact recorded boundary, supervisor phases, Pecan phases/rounds, coverage, steal and host admission observations. Pecan input_snapshot is nested inside public_algorithm: these durations are not additive. External phase breakdown and rounds are unavailable when the CLI emits no structured receipt; they are never inferred.", "", "Sampled engine PSS excludes supervisor/PID 1. Whole-container execute PSS includes them. Cgroup peaks include page cache and prior identity reads; the final lifetime peak also includes parent oracle/final observation. Peaks and sampling coverage remain separate.", "", "## Retained attempts and prerequisite phases", ""])
    for phase in report["other_retained_attempts"]:
        known = [row.get("id") for row in phase["known_mismatches"]]
        lines.append(f"- {phase['run_id']}: {phase['kind'] or phase['action']}; host {phase['host_outcome']}, producer {phase['producer_outcome']}; accepted closure {phase['accepted_phase_closure']}; known mismatches {known}.")
        if phase.get("error"):
            lines.append(f"  Error: {phase['error']}")
    for previous in report["prior_archive_attempts"]:
        lines.append(f"- Prior archive: {previous['archive_base']}")
        for phase in previous["attempts"]:
            lines.append(f"  - {phase['run_id']}: {phase['kind'] or phase['action']}; host {phase['host_outcome']}, producer {phase['producer_outcome']}. Phase failures are distinct from engine-cell failures.")
    lines.extend(["", "## Withheld cells", ""])
    for cell in report["cells"]:
        if not cell["qualified"]:
            lines.append(f"- {cell['plan_step']['run_id']}: {cell['status']}; " + "; ".join(cell["reasons"]))
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--prior-base", type=Path, action="append", default=[], help="retain earlier phase/cell attempt receipts; never qualifies current prerequisites")
    parser.add_argument("--json", type=Path, help="new report file; refuses overwrite; otherwise JSON to stdout")
    parser.add_argument("--markdown", type=Path, help="new Markdown file; refuses overwrite")
    options = parser.parse_args()
    report = summarize(options.plan, options.base, options.prior_base)
    serialized = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if options.json:
        with options.json.open("x") as stream:
            stream.write(serialized)
    else:
        print(serialized, end="")
    if options.markdown:
        with options.markdown.open("x") as stream:
            stream.write(markdown(report))


if __name__ == "__main__":
    main()
