"""Run one immutable A2/A3 item serially; retain every failure without retry."""
from __future__ import annotations

import argparse
import errno
import hashlib
import importlib.util
import json
import os
import signal
import subprocess
import sys
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType
from typing import Any, Literal, Protocol, cast

Json = dict[str, Any]
Item = Literal["A2", "A3"]
PYTHON = Path("/tmp/sem-output-oracle-venv/bin/python")
SUMMARIZER = Path("/tmp/sem-a2-summarize.py")
SUMMARIZER_SHA = "3594a71f826b56bdfe9456515876ef087cbe1254da0e678b460ec5c0bbee8df8"
SCOPE = {"dataset": "cit-Patents", "requires_zero_isolates": True,
         "per_cell_full_oracle": True, "generic_signed_wcc_qualified": False}
CONTROL_IDS = ["wcc-graphframes", "wcc-pecan-randomized", "wcc-pecan-min-label",
               "bfs-graphframes", "bfs-pecan", "b9-signed-isolate"]


class Auditor(Protocol):
    def audit_cell(self, step: Json, base: Path, plan: Json) -> Json: ...
    def closed(self, host: Json, record: Json, plan: Json) -> list[str]: ...


class Child(Protocol):
    pid: int
    def wait(self) -> int: ...
    def poll(self) -> int | None: ...


class Spawner(Protocol):
    def __call__(self, command: list[str], log: Path) -> Child: ...


@dataclass(frozen=True, slots=True)
class Options:
    base: Path
    item: Item
    start_after: str | None = None


@dataclass(frozen=True, slots=True)
class FilePin:
    path: str
    sha256: str
    bytes: int


@dataclass(slots=True)
class CellProgress:
    run_id: str
    command: list[str]
    log: str
    outcome: str = "pending"
    started_utc: str | None = None
    finished_utc: str | None = None
    child_pid: int | None = None
    returncode: int | None = None
    audit: Json | None = None


@dataclass(slots=True)
class Receipt:
    base: str
    item: Item
    owner_pid: int
    token: str
    started_utc: str
    observed_utc: str
    schema_version: int = 1
    outcome: str = "preparing"
    finished_utc: str | None = None
    active_child_pid: int | None = None
    lock_retained: bool = True
    pins: list[FilePin] = field(default_factory=list)
    prerequisites: Json = field(default_factory=dict)
    prior_qualified: list[Json] = field(default_factory=list)
    cells: list[CellProgress] = field(default_factory=list)
    interruption_signals: list[int] = field(default_factory=list)
    error: str | None = None
    durability_scope: str = ("file fsync, atomic replace and requested directory fsync; "
        "macOS EINVAL/ENOTSUP tolerated without host power-loss durability qualification")
    ownership_scope: str = ("serial queue lock coordinates queue runners; host driver owns global gate.lock "
        "and engine/container lifecycle; queue never sends cleanup signals or retries IDs")


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def read(path: Path) -> Json:
    require(not path.is_symlink(), "refuse symbolic link: " + str(path))
    data: Any = json.loads(path.read_bytes())
    require(isinstance(data, dict), "JSON object required: " + str(path))
    return cast(Json, data)


def pin(path: Path) -> FilePin:
    require(path.is_file() and not path.is_symlink(), "regular pinned file required: " + str(path))
    data = path.read_bytes()
    return FilePin(str(path), hashlib.sha256(data).hexdigest(), len(data))


def directory_fsync(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        try:
            os.fsync(descriptor)
        except OSError as error:
            if sys.platform != "darwin" or error.errno not in (errno.EINVAL, errno.ENOTSUP):
                raise
    finally:
        os.close(descriptor)


def save(path: Path, receipt: Receipt) -> None:
    receipt.observed_utc = utc()
    temporary = path.with_suffix(".json.tmp")
    with temporary.open("w") as stream:
        stream.write(json.dumps(asdict(receipt), indent=2, sort_keys=True, allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    directory_fsync(path.parent)


def load_auditor() -> Auditor:
    require(pin(SUMMARIZER).sha256 == SUMMARIZER_SHA, "frozen summarizer changed")
    spec = importlib.util.spec_from_file_location("sem_a2_queue_auditor", SUMMARIZER)
    require(spec is not None and spec.loader is not None, "summarizer import unavailable")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    require(callable(getattr(module, "audit_cell", None)) and callable(getattr(module, "closed", None)), "summarizer API unavailable")
    return cast(Auditor, module)


def prerequisites(base: Path, plan: Json, auditor: Auditor) -> Json:
    result: Json = {}
    for run_id, kind in (("validation04", "validation"), ("compatibility04", "compatibility")):
        root = base / run_id
        host = read(root / "result.json")
        producer = read(root / "container/artifacts/receipt.json")
        require(host.get("run_id") == run_id and host.get("kind") == kind and host.get("action") == "run", "prerequisite identity: " + run_id)
        require(host.get("outcome") in ("passed", "passed_with_known_mismatch") and host.get("producer_outcome") == producer.get("outcome"), "prerequisite outcome: " + run_id)
        require(not auditor.closed(host, read(root / "container-record.json"), plan), "prerequisite closure: " + run_id)
        require(bool(producer.get("finished_utc")) and not producer.get("error"), "prerequisite finalization: " + run_id)
        if kind == "validation":
            validation = producer.get("validation") or {}
            require(producer.get("outcome") == "passed" and producer.get("originals_before") == producer.get("originals_after") and bool(producer.get("originals_before")), "validation identities/outcome")
            require(validation.get("isolated_vertex_count") == 0 and validation.get("source") == plan.get("source_vertex") and validation.get("vertex_rows") == validation.get("unique_vertices") and bool(producer.get("certificate")) and bool(producer.get("references")), "validated zero-isolate/source/reference scope")
        else:
            require(producer.get("proceed_scope") == SCOPE and host.get("proceed_scope") == SCOPE and producer.get("generic_signed_id_qualification") is False, "exact compatibility proceed scope")
            require(bool(producer.get("before")) and producer.get("before") == producer.get("after"), "compatibility source identities")
            controls = producer.get("controls") or []
            require([control.get("id") for control in controls] == CONTROL_IDS, "compatibility control set")
            require(all(control.get("outcome") == "passed" for control in controls[:-1]), "ordinary compatibility controls must pass")
            for control in controls:
                require(control.get("returncode") == 0 and control.get("closure_observed") is True and bool(control.get("result_files")) and not any(control.get(key) for key in ("remaining_processes", "remaining_after_cleanup", "emergency_cleanup", "error")), "compatibility control ownership: " + str(control.get("id")))
            witness = controls[-1]
            known = producer.get("outcome") == "passed_with_known_mismatch"
            require(witness.get("outcome") == ("known_mismatch" if known else "passed"), "signed witness classification")
            isolate = -7694170072594669674
            expected = [{"id": isolate, "value": isolate}, {"id": 1, "value": 1}, {"id": 2, "value": 1}]
            actual = [{"id": isolate, "value": isolate}, {"id": 1, "value": isolate}, {"id": 2, "value": isolate}] if known else expected
            require(witness.get("raw_rows") == actual and witness.get("expected_rows") == expected, "signed witness must preserve exact observed/expected rows")
            result["signed_witness"] = witness
        result[run_id] = {"host_outcome": host["outcome"], "producer_outcome": producer["outcome"], "finished_utc": host["finished_utc"]}
    return result


def unoccupied(base: Path, run_id: str) -> None:
    require(not (base / run_id).exists() and not (base / run_id).is_symlink(), "existing run directory; no retry: " + run_id)
    require(not list(base.glob(run_id + "*.log")) and not list(base.glob(run_id + "*.launch.json")), "existing run log/launch record; no retry: " + run_id)


def qualified(step: Json, base: Path, plan: Json, auditor: Auditor) -> Json:
    audit = auditor.audit_cell(step, base, plan)
    require(audit.get("qualified") is True, "cell did not qualify: " + step["run_id"] + " " + str(audit.get("reasons")))
    return audit


def prepare(options: Options, receipt: Receipt, auditor: Auditor) -> tuple[Json, list[Json]]:
    base, driver = options.base, options.base / "controller-profile/run_host.py"
    plan = read(base / "plan.json")
    steps = plan["steps"]
    require(isinstance(steps, list) and bool(steps), "nonempty immutable plan required")
    ids = [step["run_id"] for step in steps]
    require(len(ids) == len(set(ids)) and all(isinstance(name, str) and Path(name).name == name and name not in (".", "..") for name in ids), "unique safe planned IDs")
    selected = [step for step in steps if step.get("item") == options.item]
    require(bool(selected), "item absent from plan")
    require(all(step.get("mode") == ("local" if options.item == "A2" else "process-cluster") for step in selected), "item execution class differs")
    manifest_path = base / "cell-configs-manifest.json"
    manifest, driver_index = read(manifest_path), read(base / "controller-profile/index.json")
    require(pin(driver).sha256 == driver_index.get("driver_sha256"), "declared driver identity differs")
    require(pin(base / "plan.json").sha256 == manifest.get("plan_sha256"), "declared plan identity differs")
    receipt.prerequisites = prerequisites(base, plan, auditor)
    paths = [Path(__file__), SUMMARIZER, driver, base / "plan.json", manifest_path, base / "controller-profile/index.json", base / "support/support-manifest.json"]
    for run_id in ("validation04", "compatibility04"):
        paths.extend(base / run_id / name for name in ("result.json", "container-record.json", "container/artifacts/receipt.json"))
    reference_sha = pin(base / "validation04/container/artifacts/receipt.json").sha256
    require(manifest.get("reference_receipt_sha256") == reference_sha and manifest.get("support_manifest_sha256") == pin(base / "support/support-manifest.json").sha256, "manifest reference/support binding")
    require(set(manifest.get("files", {})) == {name + ".json" for name in ids}, "exact config manifest coverage")
    for step in steps:
        path = base / "configs" / (step["run_id"] + ".json")
        identity, config = pin(path), read(path)
        require(manifest["files"][path.name] == {"sha256": identity.sha256, "bytes": identity.bytes}, "config identity differs: " + path.name)
        require(all(config.get(key) == step.get(key) for key in ("engine", "algorithm", "mode")) and config.get("reference_receipt_sha256") == reference_sha, "config contrast/reference differs: " + path.name)
        paths.append(path)
    receipt.pins = [pin(path) for path in paths]
    prefix: list[Json] = []
    if options.start_after is not None:
        matches = [index for index, step in enumerate(selected) if step["run_id"] == options.start_after]
        require(len(matches) == 1 and selected[matches[0]].get("role") == "warmup", "start-after must name an exact completed warmup of this item")
        prefix, selected = selected[:matches[0] + 1], selected[matches[0] + 1:]
    allowed = {step["run_id"] for step in prefix}
    for step in steps:
        root = base / step["run_id"]
        exists = root.exists() or root.is_symlink() or bool(list(base.glob(step["run_id"] + "*.log"))) or bool(list(base.glob(step["run_id"] + "*.launch.json")))
        if step["run_id"] in allowed or (options.item == "A3" and step.get("item") == "A2"):
            receipt.prior_qualified.append(qualified(step, base, plan, auditor))
        elif exists:
            raise ValueError("existing cell outside explicit completed prefix; no resume/retry: " + step["run_id"])
    require(bool(selected), "no pending cells after explicit warmup")
    for step in selected:
        unoccupied(base, step["run_id"])
        command = [str(PYTHON), "-B", str(driver), "run", "--run-id", step["run_id"], "--kind", "cell", "--cell-config", str(base / "configs" / (step["run_id"] + ".json"))]
        receipt.cells.append(CellProgress(step["run_id"], command, str(base / (step["run_id"] + ".host.log"))))
    return plan, selected


def verify_pins(receipt: Receipt) -> None:
    for expected in receipt.pins:
        require(pin(Path(expected.path)) == expected, "immutable file changed: " + expected.path)


def spawn(command: list[str], log: Path) -> Child:
    with log.open("xb") as stream:
        directory_fsync(log.parent)
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    return process


def run(options: Options, auditor: Auditor | None = None, spawner: Spawner = spawn) -> int:
    base = options.base.resolve()
    options = Options(base, options.item, options.start_after)
    global_lock, queue_lock = base.parent / "gate.lock", base.parent / "serial-queue.lock"
    output = base / ("queue-" + options.item)
    require(base.is_dir() and not output.exists(), "new existing-base queue directory required; automatic resume forbidden")
    require(not global_lock.exists() and not global_lock.is_symlink(), "global gate.lock present; phase overlap refused")
    receipt = Receipt(str(base), options.item, os.getpid(), uuid.uuid4().hex, utc(), utc())
    receipt_path = output / "receipt.json"
    owner_path = queue_lock / "owner.json"
    queue_lock.mkdir(exist_ok=False)
    child: Child | None = None
    previous: dict[int, Any] = {}
    closing = False

    def interrupted(signum: int, _frame: FrameType | None) -> None:
        receipt.interruption_signals.append(signum)
        if not closing:
            raise InterruptedError("queue interrupted; child/container cleanup remains host driver's responsibility")

    try:
        for signum in (signal.SIGTERM, signal.SIGINT):
            previous[signum] = signal.signal(signum, interrupted)
        save(owner_path, receipt)
        directory_fsync(queue_lock.parent)
        output.mkdir(exist_ok=False)
        directory_fsync(output.parent)
        save(receipt_path, receipt)
        actual_auditor = auditor if auditor is not None else load_auditor()
        plan, steps = prepare(options, receipt, actual_auditor)
        receipt.outcome = "running"
        save(receipt_path, receipt)
        for step, progress in zip(steps, receipt.cells, strict=True):
            require(child is None, "queue child overlap")
            verify_pins(receipt)
            require(not global_lock.exists() and not global_lock.is_symlink(), "global gate.lock appeared before next cell")
            unoccupied(base, progress.run_id)
            progress.started_utc, progress.outcome = utc(), "launch_intent"
            save(receipt_path, receipt)
            child = spawner(progress.command, Path(progress.log))
            progress.child_pid, receipt.active_child_pid, progress.outcome = child.pid, child.pid, "running"
            save(receipt_path, receipt)
            progress.returncode = child.wait()
            receipt.active_child_pid = None
            progress.finished_utc = utc()
            progress.outcome = "child_exited"
            save(receipt_path, receipt)
            require(progress.returncode == 0, "host child exit failed: " + progress.run_id)
            require(not global_lock.exists() and not global_lock.is_symlink(), "global gate.lock retained after cell")
            host = read(base / progress.run_id / "result.json")
            require(host.get("run_id") == progress.run_id and host.get("outcome") == "passed" and bool(host.get("finished_utc")) and host.get("certain_container_closure") is True and host.get("lock_retained") is False, "host finalized closure did not pass: " + progress.run_id)
            progress.audit = qualified(step, base, plan, actual_auditor)
            verify_pins(receipt)
            progress.outcome = "passed"
            child = None
            save(receipt_path, receipt)
        receipt.outcome, receipt.finished_utc = "passed", utc()
        save(receipt_path, receipt)
        owner = read(owner_path)
        require(owner.get("token") == receipt.token and owner.get("owner_pid") == os.getpid() and {path.name for path in queue_lock.iterdir()} == {"owner.json"}, "queue lock ownership changed")
        require(not global_lock.exists() and not global_lock.is_symlink(), "global gate.lock appeared at queue close")
        owner_path.unlink()
        queue_lock.rmdir()
        directory_fsync(queue_lock.parent)
        receipt.lock_retained = False
        save(receipt_path, receipt)
        return 0
    except BaseException as error:  # noqa: BLE001 - all interrupted/uncertain orchestration is retained.
        closing = True
        receipt.outcome = "interrupted" if isinstance(error, (InterruptedError, KeyboardInterrupt)) else "error"
        receipt.error, receipt.finished_utc = repr(error), utc()
        receipt.lock_retained = queue_lock.exists()
        if child is not None:
            try:
                observed_code = child.poll()
                receipt.active_child_pid = child.pid if observed_code is None else None
                for progress in receipt.cells:
                    if progress.child_pid == child.pid:
                        progress.returncode = observed_code
                        progress.outcome = "active_child_uncertain" if observed_code is None else "failed_or_unqualified"
            except BaseException as observation_error:  # noqa: BLE001 - preserve original failure and uncertain child identity.
                receipt.error += "; child observation: " + repr(observation_error)
        save(receipt_path if output.is_dir() else owner_path, receipt)
        return 1
    finally:
        for restored_signal, handler in previous.items():
            signal.signal(restored_signal, handler)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--item", choices=("A2", "A3"), required=True)
    parser.add_argument("--start-after", help="exact completed warmup ID; all preceding item cells must qualify")
    args = parser.parse_args()
    try:
        return run(Options(args.base, cast(Item, args.item), args.start_after))
    except (OSError, ValueError) as error:
        print(json.dumps({"outcome": "queue_refusal_or_persistence_error", "error": str(error), "observed_utc": utc(), "inspect": "base/queue-ITEM/receipt.json and parent/serial-queue.lock"}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
