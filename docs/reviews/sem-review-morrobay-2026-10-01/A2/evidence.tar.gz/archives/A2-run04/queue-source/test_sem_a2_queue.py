"""Offline serial queue controls: fake children and temporary receipt trees only."""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any

SPEC = importlib.util.spec_from_file_location("sem_a2_queue", "/tmp/sem-a2-queue.py")
assert SPEC is not None and SPEC.loader is not None
queue = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = queue
SPEC.loader.exec_module(queue)
REAL = Path("/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04")


def write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + "\n")


class FakeAuditor:
    def closed(self, _host: dict[str, Any], _record: dict[str, Any], _plan: dict[str, Any]) -> list[str]:
        return []

    def audit_cell(self, step: dict[str, Any], base: Path, _plan: dict[str, Any]) -> dict[str, Any]:
        path = base / step["run_id"] / "result.json"
        okay = path.exists() and json.loads(path.read_text()).get("outcome") == "passed"
        return {"qualified": okay, "reasons": [] if okay else ["fake failed receipt"], "run_id": step["run_id"]}


class FakeChild:
    pid = 900001

    def __init__(self, test: QueueControls, run_id: str) -> None:
        self.test, self.run_id = test, run_id
        self.code: int | None = None

    def wait(self) -> int:
        if self.test.interrupt:
            raise KeyboardInterrupt
        self.code = self.test.returncode
        write(self.test.base / self.run_id / "result.json", {"run_id": self.run_id,
            "outcome": "passed" if self.code == 0 else "error", "finished_utc": "control",
            "certain_container_closure": True, "lock_retained": False})
        if self.test.retain_global:
            (self.test.base.parent / "gate.lock").mkdir()
        if self.test.mutate_config:
            path = self.test.base / "configs" / (self.test.steps[-1]["run_id"] + ".json")
            path.write_text(path.read_text() + " ")
        return self.code

    def poll(self) -> int | None:
        return self.code


class QueueControls(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name) / "A2-run04"
        self.base.mkdir()
        self.returncode, self.interrupt, self.retain_global, self.mutate_config = 0, False, False, False
        self.calls: list[str] = []
        plan = queue.read(REAL / "plan.json")
        self.steps = plan["steps"][:4]
        plan["steps"] = self.steps
        write(self.base / "plan.json", plan)
        for run_id in ("validation04", "compatibility04"):
            for name in ("result.json", "container-record.json", "container/artifacts/receipt.json"):
                write(self.base / run_id / name, queue.read(REAL / run_id / name))
        write(self.base / "support/support-manifest.json", queue.read(REAL / "support/support-manifest.json"))
        driver = self.base / "controller-profile/run_host.py"
        driver.parent.mkdir()
        driver.write_text("# Fake driver never executed.\n")
        write(driver.parent / "index.json", {"driver_sha256": queue.pin(driver).sha256})
        reference = queue.pin(self.base / "validation04/container/artifacts/receipt.json").sha256
        files: dict[str, Any] = {}
        for step in self.steps:
            config = queue.read(REAL / "configs" / (step["run_id"] + ".json"))
            config["reference_receipt_sha256"] = reference
            path = self.base / "configs" / (step["run_id"] + ".json")
            write(path, config)
            pinned = queue.pin(path)
            files[path.name] = {"sha256": pinned.sha256, "bytes": pinned.bytes}
        write(self.base / "cell-configs-manifest.json", {"files": files,
            "plan_sha256": queue.pin(self.base / "plan.json").sha256,
            "reference_receipt_sha256": reference,
            "support_manifest_sha256": queue.pin(self.base / "support/support-manifest.json").sha256})
        for step in self.steps[:2]:
            write(self.base / step["run_id"] / "result.json", {"outcome": "passed"})
        self.options = queue.Options(self.base, "A2", self.steps[1]["run_id"])

    def spawn(self, command: list[str], log: Path) -> FakeChild:
        self.assertEqual(command[:2], [str(queue.PYTHON), "-B"])
        run_id = command[command.index("--run-id") + 1]
        receipt = queue.read(self.base / "queue-A2/receipt.json")
        self.assertIsNone(receipt["active_child_pid"])
        self.assertFalse((self.base / run_id).exists())
        log.write_text("fake child only\n")
        self.calls.append(run_id)
        return FakeChild(self, run_id)

    def execute(self) -> int:
        return int(queue.run(self.options, FakeAuditor(), self.spawn))

    def test_serial_success_requires_both_prior_warmups(self) -> None:
        self.assertEqual(self.execute(), 0)
        receipt = queue.read(self.base / "queue-A2/receipt.json")
        self.assertEqual(self.calls, [step["run_id"] for step in self.steps[2:]])
        self.assertEqual([cell["returncode"] for cell in receipt["cells"]], [0, 0])
        self.assertEqual(receipt["outcome"], "passed")
        self.assertFalse(receipt["lock_retained"])
        self.assertEqual(len(receipt["prior_qualified"]), 2)
        self.assertEqual(receipt["prerequisites"]["signed_witness"]["outcome"], "known_mismatch")
        self.assertFalse((self.base.parent / "serial-queue.lock").exists())

    def test_failed_child_blocks_next_and_retains_queue_lock(self) -> None:
        self.returncode = 1
        self.assertEqual(self.execute(), 1)
        self.assertEqual(len(self.calls), 1)
        self.assertTrue((self.base.parent / "serial-queue.lock").exists())
        self.assertEqual(queue.read(self.base / "queue-A2/receipt.json")["cells"][0]["returncode"], 1)

    def test_interruption_retains_live_child_without_cleanup_signal(self) -> None:
        self.interrupt = True
        self.assertEqual(self.execute(), 1)
        receipt = queue.read(self.base / "queue-A2/receipt.json")
        self.assertEqual(receipt["outcome"], "interrupted")
        self.assertEqual(receipt["active_child_pid"], FakeChild.pid)
        self.assertIsNone(receipt["cells"][0]["returncode"])
        self.assertEqual(len(self.calls), 1)

    def test_global_lock_left_by_child_blocks_next(self) -> None:
        self.retain_global = True
        self.assertEqual(self.execute(), 1)
        self.assertEqual(len(self.calls), 1)

    def test_changed_config_after_cell_blocks_next(self) -> None:
        self.mutate_config = True
        self.assertEqual(self.execute(), 1)
        self.assertEqual(len(self.calls), 1)

    def test_failed_existing_warmup_never_retries(self) -> None:
        write(self.base / self.steps[0]["run_id"] / "result.json", {"outcome": "error"})
        self.assertEqual(self.execute(), 1)
        self.assertEqual(self.calls, [])

    def test_existing_next_log_never_retries(self) -> None:
        (self.base / (self.steps[2]["run_id"] + ".host.log")).write_text("prior failure")
        self.assertEqual(self.execute(), 1)
        self.assertEqual(self.calls, [])


if __name__ == "__main__":
    unittest.main()
