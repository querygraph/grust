"""Offline failure/receipt controls; module doubles cannot launch an engine."""
import importlib.util
import json
import pathlib
import sys
import tempfile
import types


def module(name):
    value = types.ModuleType(name)
    value.__path__ = []
    sys.modules[name] = value
    return value


for name in ('pyspark', 'pyspark.sql', 'pyspark.sql.connect', 'pyspark.sql.connect.client',
             'pyspark.sql.connect.client.retries', 'pyspark.sql.connect.session', 'pyspark_pecan'):
    module(name)
sys.modules['pyspark.sql'].DataFrame = object
sys.modules['pyspark.sql.connect.client.retries'].DefaultPolicy = object
sys.modules['pyspark.sql.connect.session'].SparkSession = object
alg = module('pyspark_pecan.algorithms')
alg.ConvergenceError = type('ConvergenceError', (RuntimeError,), {})
alg._snapshot = lambda *a, **kw: (a[1], a[2], None)
module('pyspark_pecan.lifecycle').GraphResult = object
module('pyspark_pecan.staging').StagingRun = object
base = pathlib.Path('/Volumes/Apo/graph-tests/workspaces/sem-review-20261001/pecan-f3b3ef8fc')
spec = importlib.util.spec_from_file_location('pyspark_pecan.types',
    base / 'examples/extensions/graph-algorithms/src/pyspark_pecan/types.py')
events = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = events
spec.loader.exec_module(events)
measurement = module('measurement')
measurement.cgroup_snapshot = lambda: {key: '0' for key in (
    'memory.current', 'memory.peak', 'memory.max', 'memory.swap.max', 'memory.events',
    'memory.stat', 'cpu.max', 'cpu.stat', 'cpuset.cpus.effective')}
runtime = module('runtime')


def no_server(*args, **kwargs):
    raise AssertionError('an offline control attempted to launch a server')


runtime.server = no_server
path = pathlib.Path('/private/tmp/grust-sem-a2-code-b22f02497a56/docs/reviews/sem-review-morrobay-2026-10-01/A2/engine_pecan.py')
spec = importlib.util.spec_from_file_location('engine_pecan', path)
engine = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = engine
spec.loader.exec_module(engine)
checks = []
with tempfile.TemporaryDirectory(prefix='pecan-engine-offline-') as directory:
    root = pathlib.Path(directory)
    config = dict(repo=str(root / 'repo'), harness_repo=str(root / 'harness'), output=str(root / 'output'),
                  vertices=str(root / 'v.parquet'), edges=str(root / 'e.parquet'), binary=str(root / 'binary'),
                  mode='local', algorithm='wcc-randomized', source=750000, partitions=16,
                  pool_bytes=30 * engine.GIB, native_quota=256 * 2**20)
    engine.EngineConfig.model_validate_json(json.dumps(config))
    checks.append('accepted exact local envelope')
    cluster = {**config, 'mode': 'process-cluster', 'pool_bytes': 10 * engine.GIB}
    engine.EngineConfig.model_validate_json(json.dumps(cluster))
    checks.append('accepted exact three-process envelope')
    for wrong in ({**config, 'pool_bytes': 24 * engine.GIB}, {**cluster, 'pool_bytes': 30 * engine.GIB},
                  {**config, 'source': True}, {**config, 'extra': 1}):
        try:
            engine.EngineConfig.model_validate_json(json.dumps(wrong))
        except ValueError:
            checks.append('rejected malformed free config')
        else:
            raise AssertionError('invalid config was accepted')
    alg.__file__ = str(root / 'repo/examples/extensions/graph-algorithms/src/pyspark_pecan/algorithms.py')
    runtime.__file__ = str(root / 'harness/examples/extensions/benchmarks/runtime.py')
    measurement.__file__ = str(root / 'harness/examples/extensions/benchmarks/measurement.py')
    original_execute = engine.execute
    for name, expected in [('empty_dirs', 'passed'), ('payload', 'cleanup_error'),
                           ('timeout', 'timeout'), ('interrupt', 'interrupted'), ('nonconverged', 'nonconverged')]:
        cell = {**config, 'output': str(root / name)}
        config_path = root / (name + '.json')
        config_path.write_text(json.dumps(cell))

        def mocked_execute(c, journal, sink):
            staging = c.output / 'staging'
            (staging / 'retained-directory').mkdir(parents=True)
            journal.observe(events.IterationEvent(kind='iteration_start', algorithm='wcc-randomized-contraction',
                                                  iteration=1, run_path=str(staging)))
            if name in ('timeout', 'interrupt', 'nonconverged'):
                (staging / 'partial.parquet').write_bytes(b'failed-write-payload')
                if name == 'timeout':
                    raise TimeoutError('offline timeout')
                if name == 'interrupt':
                    raise InterruptedError('offline cancellation')
                raise alg.ConvergenceError('offline cap')
            journal.observe(events.IterationEvent(kind='iteration_end', algorithm='wcc-randomized-contraction',
                                                  iteration=1, run_path=str(staging)))
            if name == 'payload':
                (staging / 'partial.parquet').write_bytes(b'nonempty')
            journal.receipt.result = engine.ResultMetadata(algorithm='wcc-randomized-contraction', method='randomized',
                                                           seed=42, iterations=1, converged=True)

        engine.execute = mocked_execute
        sys.argv = ['engine_pecan.py', '--config', str(config_path)]
        code = engine.main()
        receipt = json.loads((pathlib.Path(cell['output']) / 'engine-receipt.json').read_text())
        assert receipt['outcome'] == expected
        assert code == (0 if expected == 'passed' else 1)
        assert bool(receipt['error']) == (name in ('timeout', 'interrupt', 'nonconverged'))
        if name in ('payload', 'timeout', 'interrupt', 'nonconverged'):
            assert receipt['staging_payload_after_shutdown'] == ['partial.parquet']
        if name in ('timeout', 'interrupt', 'nonconverged'):
            assert receipt['incomplete_rounds'] == [1]
        checks.append(name + ' durable outcome/receipt')
    engine.execute = original_execute
    output = root / 'snapshot_control'
    output.mkdir()
    cfg = engine.EngineConfig.model_validate_json(json.dumps({**config, 'output': str(output)}))
    receipt = engine.EngineReceipt(config=cfg, started_utc=engine.utc(), max_iterations=100, worker_count=0)
    journal = engine.Journal(receipt, engine.time.perf_counter())
    calls = []

    def failing_snapshot(*args, **kwargs):
        calls.append((args, kwargs))
        raise RuntimeError('offline snapshot failure')

    alg._snapshot = failing_snapshot
    try:
        with engine.snapshot_phase(journal):
            alg._snapshot(None, 'v', 'e', ('src', 'dst'), count_vertices=False)
    except RuntimeError:
        pass
    assert alg._snapshot is failing_snapshot
    assert calls == [((None, 'v', 'e', ('src', 'dst')), {'count_vertices': False})]
    assert receipt.phases[-1].status == 'error'
    checks.append('snapshot delegates exactly once and restores on exception')
    sink = engine.CleanupSink()
    sink.append({'operation': 'stop_server_group', 'error': 'offline runtime cleanup error'})
    assert sink.records[0].operation == 'stop_server_group'
    checks.append('frozen-runtime cleanup adapter preserves error')
    original_mark = engine.Journal.mark
    close_calls = []

    def broken_mark(self, event):
        raise OSError('offline diagnostic write failure')

    engine.Journal.mark = broken_mark
    engine.cleanup(journal, sink, 'resource_close', lambda: close_calls.append('closed'))
    engine.Journal.mark = original_mark
    assert close_calls == ['closed']
    assert sink.records[-1].operation == 'resource_close'
    checks.append('cleanup runs exactly once after journal start failure')
    lifecycle = []

    class FakeServer:
        def __enter__(self):
            lifecycle.append('enter')
            return 'sc://offline', 1

        def __exit__(self, *args):
            lifecycle.append('exit')
            return False

    runtime.server = lambda *args, **kwargs: FakeServer()
    measurement.cpu_ticks = lambda: [1] * 10
    measurement.steal_fraction = lambda *args: 0.0

    def broken_startup_end(self, event):
        if event.name == 'server_startup' and event.status == 'end':
            raise OSError('offline post-enter journal failure')
        return original_mark(self, event)

    engine.Journal.mark = broken_startup_end
    try:
        engine.execute(cfg, journal, engine.CleanupSink())
    except OSError:
        pass
    else:
        raise AssertionError('journal failure was swallowed')
    finally:
        engine.Journal.mark = original_mark
        runtime.server = no_server
    assert lifecycle == ['enter', 'exit']
    checks.append('successful server enter is closed after phase-end journal failure')
print(json.dumps({'offline_controls': len(checks), 'checks': checks, 'server_calls': 0,
                  'engine_launches': 0, 'outcome': 'PASS'}, indent=2))
