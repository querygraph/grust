from __future__ import annotations
import ast
import copy
import importlib.util
import json
import os
import pathlib
import sys
import tempfile
import unittest
from typing import Any
from unittest import mock

FILE = pathlib.Path('/private/tmp/grust-sem-a2-code-b22f02497a56/docs/reviews/sem-review-morrobay-2026-10-01/A2/run_host.py')
SPEC = importlib.util.spec_from_file_location('tested_run_host', FILE)
assert SPEC is not None and SPEC.loader is not None
HOST = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = HOST
SPEC.loader.exec_module(HOST)
IDENTIFIER = 'a' * 64

class Controls(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.base = pathlib.Path(self.temporary.name) / 'A2-run01'
        self.base.mkdir()
        self.lock = self.base.parent / 'gate.lock'
        self.patches = [mock.patch.object(HOST, 'BASE', self.base), mock.patch.object(HOST, 'LOCK', self.lock),
                        mock.patch.object(HOST.subprocess, 'run', side_effect=AssertionError('UNMOCKED subprocess forbidden'))]
        for patch in self.patches:
            patch.start()
    def tearDown(self) -> None:
        for patch in reversed(self.patches):
            patch.stop()
        self.temporary.cleanup()
    def record(self) -> dict[str, Any]:
        return {'create': {'returncode': 0, 'stdout': IDENTIFIER}, 'attach_returncode': 0,
                'inspect': {'id': IDENTIFIER, 'image': HOST.IMAGE,
                    'state': {'Running': False, 'ExitCode': 0, 'OOMKilled': False},
                    'limits': {'NanoCpus': 16 * 10**9, 'CpusetCpus': '0-15', 'Memory': 32 * 2**30,
                               'MemorySwap': 32 * 2**30, 'PidsLimit': 1024, 'Init': True, 'PidMode': ''}},
                'remove': {'returncode': 0}, 'transport_errors': [], 'copied': {'artifacts': {'returncode': 0}}}
    def test_all_scripts_compile_typed_no_local_imports(self) -> None:
        for code in (FILE.read_text(), HOST.STAGE, HOST.PROBE, HOST.BOOT):
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    self.assertIsNotNone(node.returns, node.name)
                    for arg in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs):
                        self.assertIsNotNone(arg.annotation, node.name + ':' + arg.arg)
                    self.assertFalse(any(isinstance(child, (ast.Import, ast.ImportFrom)) for child in ast.walk(node)))
    def test_atomic_save_fsync(self) -> None:
        target = self.base / 'receipt.json'
        with mock.patch.object(HOST.os, 'fsync', wraps=os.fsync) as fsync:
            HOST.save(target, {'outcome': 'checking'})
        self.assertEqual(fsync.call_count, 1)
        self.assertEqual(json.loads(target.read_text()), {'outcome': 'checking'})
        self.assertFalse(target.with_suffix('.json.tmp').exists())
    def test_existing_lock_refused_without_docker(self) -> None:
        self.lock.mkdir()
        owner = self.lock / 'owner.json'
        owner.write_text('{"token":"other"}')
        with mock.patch.object(HOST, 'capture', side_effect=AssertionError('Docker must not run')):
            self.assertEqual(HOST.execute(HOST.Options('stage', 'locked')), 1)
        self.assertEqual(owner.read_text(), '{"token":"other"}')
        receipt = json.loads((self.base / 'locked/result.json').read_text())
        self.assertEqual(receipt['outcome'], 'error')
        self.assertTrue(receipt['lock_retained'])
    def test_reused_id_refused(self) -> None:
        (self.base / 'used').mkdir()
        with self.assertRaises(FileExistsError):
            HOST.execute(HOST.Options('stage', 'used'))
        self.assertFalse(self.lock.exists())
    def test_wrong_lock_owner_retained(self) -> None:
        self.lock.mkdir()
        HOST.save(self.lock / 'owner.json', {'token': 'other', 'pid': os.getpid()})
        with self.assertRaises(ValueError):
            HOST.release_lock('ours')
        self.assertTrue((self.lock / 'owner.json').exists())
    def test_full_closed_envelope_acceptance(self) -> None:
        with mock.patch.object(HOST, 'absent', return_value=HOST.CommandResult(returncode=1)), mock.patch.object(HOST, 'idle'):
            HOST.check_matrix_record(self.record(), 'owned', True)
    def test_every_closure_guard_rejects(self) -> None:
        mutations = [('transport_errors', ['copy failed']), ('outer_timeout', True), ('operator_interrupted', True),
                     ('forced_cleanup_kill', {'returncode': 0}), ('remove', {'returncode': 1}), ('attach_returncode', 1),
                     ('copied', {'artifacts': {'returncode': 1}}), ('create', {'returncode': 0, 'stdout': 'b' * 64})]
        with mock.patch.object(HOST, 'absent', return_value=HOST.CommandResult(returncode=1)), mock.patch.object(HOST, 'idle'):
            for key, value in mutations:
                record = self.record(); record[key] = value
                with self.subTest(key=key), self.assertRaises(ValueError):
                    HOST.check_matrix_record(record, 'owned', True)
            for key, value in [('Running', True), ('ExitCode', 1), ('OOMKilled', True)]:
                record = self.record(); record['inspect']['state'][key] = value
                with self.subTest(state=key), self.assertRaises(ValueError):
                    HOST.check_matrix_record(record, 'owned', True)
            for key, value in [('MemorySwap', -1), ('Memory', 16 * 2**30), ('NanoCpus', 4 * 10**9), ('Init', False), ('PidMode', 'host')]:
                record = self.record(); record['inspect']['limits'][key] = value
                with self.subTest(limit=key), self.assertRaises(ValueError):
                    HOST.check_matrix_record(record, 'owned', True)
    def small(self, change: str = '') -> tuple[dict[str, Any], list[str]]:
        directory = self.base / ('small-' + (change or 'pass')); directory.mkdir()
        spec = {'test': 1}; name = 'owned'; calls: list[str] = []
        item = {'Id': IDENTIFIER, 'Image': HOST.IMAGE, 'Config': {'Entrypoint': [HOST.PYTHON],
                    'Cmd': ['-I', '-B', '-c', 'SCRIPT', json.dumps(spec)]},
                'Mounts': [{'Name': 'sail-extension-targets', 'Destination': '/targets', 'RW': False}],
                'State': {'Running': False, 'ExitCode': 0, 'OOMKilled': False}}
        if change == 'foreign': item['Id'] = 'b' * 64
        if change == 'running': item['State']['Running'] = True
        def capture(command: list[str], timeout: int = 30, stdin: Any = None) -> Any:
            operation = command[3]; calls.append(operation)
            if operation == 'create': return HOST.CommandResult(returncode=1 if change == 'create' else 0, stdout=IDENTIFIER)
            if operation == 'start': return HOST.CommandResult(returncode=None if change == 'attach' else 0, stdout='{}')
            if operation == 'inspect': return HOST.CommandResult(returncode=0, stdout=json.dumps([item]))
            if operation == 'kill': item['State']['Running'] = False; return HOST.CommandResult(returncode=0)
            if operation == 'rm': return HOST.CommandResult(returncode=1 if change == 'remove' else 0)
            raise AssertionError(command)
        with mock.patch.object(HOST, 'capture', side_effect=capture), mock.patch.object(HOST, 'absent', return_value=HOST.CommandResult(returncode=1)), mock.patch.object(HOST, 'idle'):
            if change:
                with self.assertRaises(ValueError):
                    HOST.owned_small(directory, name, 'SCRIPT', spec, None, None)
                record = json.loads((directory / 'orchestration.json').read_text())
            else:
                record = HOST.owned_small(directory, name, 'SCRIPT', spec, None, None)
        return record, calls
    def test_small_owned_container_closed(self) -> None:
        record, calls = self.small()
        self.assertTrue(record['certain_closure'])
        self.assertEqual(calls, ['create', 'start', 'inspect', 'rm'])
    def test_foreign_container_never_killed_or_removed(self) -> None:
        record, calls = self.small('foreign')
        self.assertFalse(record['certain_closure'])
        self.assertNotIn('kill', calls); self.assertNotIn('rm', calls)
    def test_create_failure_not_removed(self) -> None:
        record, calls = self.small('create')
        self.assertFalse(record['certain_closure'])
        self.assertEqual(calls, ['create'])
    def test_attach_failure_is_retained(self) -> None:
        record, calls = self.small('attach')
        self.assertTrue(record['certain_closure'])
        self.assertIn('rm', calls)
        self.assertIsNone(record['attach']['returncode'])
    def test_remove_failure_uncertain(self) -> None:
        record, _ = self.small('remove')
        self.assertFalse(record['certain_closure'])
    def test_owned_running_cleanup_retained_as_failure(self) -> None:
        record, calls = self.small('running')
        self.assertTrue(record['certain_closure'])
        self.assertIn('kill', calls)
        self.assertIn('rm', calls)
        self.assertIn('kill', record)
    def stage(self, error: str = '') -> dict[str, Any]:
        pins = {'support_sha256': 's' * 64, 'payload_sha256': 'p' * 64}
        def small(host: pathlib.Path, *args: Any) -> dict[str, Any]:
            HOST.save(host / 'stage-receipt.json', {'outcome': 'error' if error == 'producer' else 'passed'})
            return {'certain_closure': True}
        with mock.patch.object(HOST, 'idle'), mock.patch.object(HOST, 'snapshot', side_effect=[{}, ValueError('final observation')] if error == 'observation' else [{}, {}]), mock.patch.object(HOST, 'host_pins', side_effect=[pins, {'changed': True}] if error == 'pins' else [pins, pins]), mock.patch.object(HOST, 'capture', return_value=HOST.CommandResult(returncode=0, stdout=HOST.IMAGE)), mock.patch.object(HOST, 'owned_small', side_effect=small):
            code = HOST.execute(HOST.Options('stage', 'stage-' + (error or 'pass')))
        receipt = json.loads((self.base / ('stage-' + (error or 'pass')) / 'result.json').read_text())
        self.assertEqual(code, 0 if not error else 1)
        return receipt
    def test_only_full_pass_releases_lock(self) -> None:
        receipt = self.stage()
        self.assertEqual(receipt['outcome'], 'passed')
        self.assertFalse(receipt['lock_retained']); self.assertFalse(self.lock.exists())
    def test_producer_failure_retains_lock(self) -> None:
        receipt = self.stage('producer')
        self.assertEqual(receipt['outcome'], 'error'); self.assertTrue(self.lock.exists())
    def test_final_observation_failure_retains_lock(self) -> None:
        receipt = self.stage('observation')
        self.assertEqual(receipt['outcome'], 'error'); self.assertTrue(self.lock.exists())
    def test_final_support_drift_retains_lock(self) -> None:
        receipt = self.stage('pins')
        self.assertEqual(receipt['outcome'], 'error'); self.assertTrue(self.lock.exists())
    def test_scope_exact(self) -> None:
        scope = {'dataset': 'cit-Patents', 'requires_zero_isolates': True, 'per_cell_full_oracle': True,
                 'generic_signed_wcc_qualified': False}
        HOST.ProceedScope.model_validate(scope)
        for key, value in [('dataset', 'generic'), ('requires_zero_isolates', False), ('per_cell_full_oracle', False), ('generic_signed_wcc_qualified', True)]:
            invalid = copy.copy(scope); invalid[key] = value
            with self.subTest(key=key), self.assertRaises(Exception): HOST.ProceedScope.model_validate(invalid)
    def test_cell_exact_bytes_and_scope(self) -> None:
        config = {'engine': 'pecan', 'algorithm': 'wcc-randomized', 'mode': 'local', 'repo': HOST.ROOT + '/repo',
                  'harness_repo': HOST.HARNESS_REPO, 'support': HOST.ROOT + '/support', 'output': HOST.ROOT + '/cells/config-cell',
                  'inputs': '/targets/sail-stream-experiments-20260930/sem-wcc-pilot-inputs', 'references': HOST.ROOT + '/references',
                  'sail_binary': HOST.SAIL, 'graphframes_binary': HOST.GF, 'timeout_seconds': 1500,
                  'reference_receipt_sha256': 'a' * 64, 'support_sha256': 'b' * 64}
        path = self.base / 'config.json'; raw = (json.dumps(config, indent=3) + '\n').encode(); path.write_bytes(raw)
        host = self.base / 'config-cell'; host.mkdir()
        result = HOST.config_for(HOST.Options('run', 'config-cell', 'cell', path), {'support_sha256': 'b' * 64}, host)
        self.assertEqual((host / 'cell-config.json').read_bytes(), raw)
        self.assertEqual(result['config_text'].encode(), raw)
        self.assertEqual(result['config_path'], HOST.ROOT + '/configs/config-cell.json')
        invalid = config.copy(); invalid['output'] = HOST.ROOT + '/references'; path.write_text(json.dumps(invalid))
        with self.assertRaises(ValueError): HOST.config_for(HOST.Options('run', 'config-cell', 'cell', path), {'support_sha256': 'b' * 64}, host)
    def test_no_special_artifacts(self) -> None:
        directory = self.base / 'artifacts'; directory.mkdir(); (directory / 'good').write_text('data')
        self.assertIn('good', HOST.collected_inventory(directory))
        (directory / 'bad').symlink_to(directory / 'good')
        with self.assertRaises(ValueError): HOST.collected_inventory(directory)

if __name__ == '__main__':
    unittest.main(verbosity=2)
