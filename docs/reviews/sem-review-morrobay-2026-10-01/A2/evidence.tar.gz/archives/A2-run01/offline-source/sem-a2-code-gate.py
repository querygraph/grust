from __future__ import annotations
import ast
import hashlib
import importlib.metadata
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

repo = Path(sys.argv[1]).resolve()
expected = sys.argv[2]
out = Path(sys.argv[3]).resolve()
plan = json.loads(Path('/tmp/sem-a2-code-plan.json').read_text())
out.mkdir(parents=True, exist_ok=False)
def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert git('rev-parse','HEAD') == expected
assert subprocess.run(['git','-C',str(repo),'symbolic-ref','-q','HEAD'], check=False,
                      stdout=subprocess.DEVNULL).returncode == 1
assert Path(os.environ['CARGO_TARGET_DIR']).resolve().is_relative_to(repo)
assert git('rev-parse','HEAD^{tree}') == plan['tree']
assert not git('status','--porcelain','--untracked-files=no')
changed = set(git('diff','--name-only',plan['parent'],expected).splitlines())
assert changed == set(plan['files_sha256'])
for name, digest in plan['files_sha256'].items():
    assert sha(repo/name) == digest, name
    if name.endswith('.py'):
        tree=ast.parse((repo/name).read_text())
        for node in ast.walk(tree):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                assert node.returns is not None, (name,node.name,'return')
                for argument in [*node.args.posonlyargs,*node.args.args,*node.args.kwonlyargs]:
                    assert argument.arg in ('self','cls') or argument.annotation is not None,(name,node.name,argument.arg)
                for argument in (node.args.vararg,node.args.kwarg):
                    assert argument is None or argument.annotation is not None,(name,node.name,'variadic')
                assert not any(isinstance(child,(ast.Import,ast.ImportFrom)) for child in ast.walk(node)),(name,node.name,'local import')
assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)( |$)',(repo/'codex-to-codex.md').read_text(),re.M)
support=repo/'docs/reviews/sem-review-morrobay-2026-10-01/A2'
source=Path('/Volumes/Apo/graph-tests/workspaces/sem-review-20261001/pecan-f3b3ef8fc')
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
venv=Path('/tmp/sem-output-oracle-venv/bin')
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1',
     'MYPY_CACHE_DIR':str(repo/'gate-target/mypy')}
records=[]
def run(label: str, command: list[str]) -> None:
    result=subprocess.run(command,cwd=repo,env=env,text=True,capture_output=True,check=False)
    (out/(label+'.log')).write_text(result.stdout+result.stderr)
    records.append({'label':label,'command':command,'exit_code':result.returncode})
    if result.returncode:
        print((result.stdout+result.stderr)[-12000:])
        raise RuntimeError(label+' failed')
run('ruff',[str(venv/'ruff'),'check',str(support)])
run('mypy',[str(venv/'mypy'),'--strict','--follow-imports=silent','--ignore-missing-imports',str(support)])
run('controls',[str(venv/'python'),'-B','-m','unittest','discover','-v','-s',str(support),'-p','test_*.py'])
original=Path('/tmp/pecan-engine-offline-controls-20261001.py')
old="pathlib.Path('/Users/alexy/src/grust/docs/reviews/sem-review-morrobay-2026-10-01/A2/engine_pecan.py')"
text=original.read_text()
assert text.count(old)==1
adapted=out/'engine-controls-for-detached-tree.py'
adapted.write_text(text.replace(old,'pathlib.Path('+repr(str(support/'engine_pecan.py'))+')'))
run('engine-controls',[str(venv/'python'),'-B',str(adapted)])
host_original=Path('/tmp/sem-host-wrapper-offline-controls-20261001.py')
host_old="pathlib.Path('/Users/alexy/src/grust/docs/reviews/sem-review-morrobay-2026-10-01/A2/run_host.py')"
host_text=host_original.read_text()
assert host_text.count(host_old)==1
host_adapted=out/'host-controls-for-detached-tree.py'
host_adapted.write_text(host_text.replace(host_old,'pathlib.Path('+repr(str(support/'run_host.py'))+')'))
run('host-controls',[str(venv/'python'),'-B',str(host_adapted)])
assert git('rev-parse','HEAD')==expected and git('rev-parse','HEAD^{tree}')==plan['tree']
assert not git('status','--porcelain','--untracked-files=no')
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
for name,digest in plan['files_sha256'].items():
    assert sha(repo/name)==digest,name
receipt={'observed_utc':datetime.now(timezone.utc).isoformat(),'outcome':'passed','commit':expected,
 'tree':plan['tree'],'scope':'exact detached Grust experiment-helper tree; offline controls only; no benchmark qualification',
 'files_sha256':plan['files_sha256'],'commands':records,
 'engine_controls_original_sha256':sha(original),'engine_controls_adapted_sha256':sha(adapted),
 'host_controls_original_sha256':sha(host_original),'host_controls_adapted_sha256':sha(host_adapted),
 'versions':{n:importlib.metadata.version(n) for n in ('ruff','mypy','numpy','pyarrow','pydantic')},
 'cargo_gates':'not applicable: only staged Python experiment helpers and reports, no Rust or publishable crate changes'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS A2 helper gate commit='+expected+' tree='+plan['tree'])
