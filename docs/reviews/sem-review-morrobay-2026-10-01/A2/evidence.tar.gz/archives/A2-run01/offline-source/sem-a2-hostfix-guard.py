import hashlib
import json
import subprocess
from pathlib import Path
repo=Path('/Users/alexy/src/grust')
plan=json.loads(Path('/tmp/sem-a2-hostfix-plan.json').read_text())
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==plan['parent']
for name,digest in plan['files_sha256'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
print('PASS host fix root guard')
