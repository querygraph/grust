from __future__ import annotations
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path

repo=Path('/Users/alexy/src/grust')
base=Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run01')
support=base/'support'
root='/targets/sem-review-20261001/A2-run01'
plan=json.loads(Path('/tmp/sem-a2-code-plan.json').read_text())
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD^{tree}'],text=True).strip()
assert head==sys.argv[1] and tree==plan['tree']
assert json.loads(Path(sys.argv[2]).read_text())['commit']==head
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path: Path, value: dict[str, object]) -> None:
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2)+'\n')
helpers={}
prefix='docs/reviews/sem-review-morrobay-2026-10-01/A2/'
for name,digest in plan['files_sha256'].items():
    assert sha(repo/name)==digest,name
    if name.startswith(prefix) and name.endswith('.py'):
        target=support/Path(name).name
        assert not target.exists(),target
        shutil.copyfile(repo/name,target)
        assert sha(target)==digest
        helpers[target.name]=digest
bundle=support/'delta.bundle'
assert sha(bundle)=='b53951c1242e56b6fd1b9a59e204469846c2043eee1f47e7855db351e2e64454'
manifest={'schema_version':1,'files_sha256':helpers,'delta_bundle_sha256':sha(bundle),
 'controller_sha':'f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a',
 'harness_sha':'6ae2e43a903c2cee02da170465c922c72b76198e',
 'helper_repository_commit':head,'helper_repository_tree':tree}
write(support/'support-manifest.json',manifest)
write(support/'prepare-config.json',{'inputs':'/targets/sail-stream-experiments-20260930/sem-wcc-pilot-inputs',
 'output':root+'/references','source':750000})
write(support/'compatibility-config.json',{'repo':root+'/repo',
 'harness_repo':'/targets/pecan-typed-tests-20261001/candidate','support':root+'/support',
 'output':root+'/compatibility',
 'binary':'/targets/sail-compact-host-56194b170155/sail-linux-x86_64-56194b170155-release',
 'graphframes_binary':'/targets/sem-review-20261001/A1-run02/target/release/graphframes',
 'fixtures_root':'/targets/pecan-ldbc-semantics-20261001-run02/inputs'})
files={**{f'support/{name}':support/name for name in helpers},
 'support/support-manifest.json':support/'support-manifest.json','delta.bundle':bundle,
 'prepare-config.json':support/'prepare-config.json','compatibility-config.json':support/'compatibility-config.json'}
payload={**{key:value for key,value in manifest.items() if key!='files_sha256'},
 'files_sha256':{name:sha(path) for name,path in files.items()}}
write(support/'payload-manifest.json',payload)
files['payload-manifest.json']=support/'payload-manifest.json'
with tarfile.open(support/'payload.tar','x') as archive:
    for name,path in sorted(files.items()):
        archive.add(path,arcname=name,recursive=False)
write(base/'payload-preparation.json',{'observed_utc':datetime.now(timezone.utc).isoformat(),
 'outcome':'prepared','helper_commit':head,'helper_tree':tree,
 'support_manifest_sha256':sha(support/'support-manifest.json'),
 'payload_manifest_sha256':sha(support/'payload-manifest.json'),
 'payload_tar_sha256':sha(support/'payload.tar'),'payload_tar_bytes':(support/'payload.tar').stat().st_size,
 'files_sha256':payload['files_sha256']})
print(json.dumps({'outcome':'prepared','helper_commit':head,'payload_bytes':(support/'payload.tar').stat().st_size}))
