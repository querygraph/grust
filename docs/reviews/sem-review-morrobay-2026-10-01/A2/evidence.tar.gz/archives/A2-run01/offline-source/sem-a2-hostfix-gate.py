from __future__ import annotations
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

repo=Path(sys.argv[1]).resolve()
head=sys.argv[2]
out=Path(sys.argv[3])
out.mkdir(exist_ok=False)
plan=json.loads(Path('/tmp/sem-a2-hostfix-plan.json').read_text())
def git(*args: str) -> str:
    return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==plan['tree']
assert subprocess.run(['git','-C',str(repo),'symbolic-ref','-q','HEAD'],check=False,stdout=subprocess.DEVNULL).returncode==1
assert Path(os.environ['CARGO_TARGET_DIR']).resolve().is_relative_to(repo)
assert not git('status','--porcelain','--untracked-files=no')
assert set(git('diff','--name-only',plan['parent'],head).splitlines())==set(plan['files_sha256'])
for name,digest in plan['files_sha256'].items():
    assert sha(repo/name)==digest
path=repo/'docs/reviews/sem-review-morrobay-2026-10-01/A2/run_host.py'
original=Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run01/offline-source/sem-host-wrapper-offline-controls-20261001-v2.py')
old="pathlib.Path('/Users/alexy/src/grust/docs/reviews/sem-review-morrobay-2026-10-01/A2/run_host.py')"
text=original.read_text()
assert text.count(old)==1
control=out/'host-controls-exact.py'
control.write_text(text.replace(old,'pathlib.Path('+repr(str(path))+')'))
venv=Path('/tmp/sem-output-oracle-venv/bin')
records=[]
for label,command in [('ruff',[str(venv/'ruff'),'check',str(path)]),
 ('mypy',[str(venv/'mypy'),'--strict',str(path)]),('controls',[str(venv/'python'),'-B',str(control)])]:
    result=subprocess.run(command,cwd=repo,env={**os.environ,'MYPY_CACHE_DIR':str(repo/'gate-target-hostfix/mypy'),'PYTHONDONTWRITEBYTECODE':'1'},text=True,capture_output=True,check=False)
    (out/(label+'.log')).write_text(result.stdout+result.stderr)
    records.append({'label':label,'command':command,'exit_code':result.returncode})
    assert result.returncode==0,(label,(result.stdout+result.stderr)[-8000:])
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==plan['tree']
assert not git('status','--porcelain','--untracked-files=no')
for name,digest in plan['files_sha256'].items():
    assert sha(repo/name)==digest
(out/'receipt.json').write_text(json.dumps({'observed_utc':datetime.now(timezone.utc).isoformat(),'outcome':'passed','commit':head,'tree':plan['tree'],'scope':'exact detached tree; host absence parser fix and staged closure documentation; no algorithm evidence','commands':records,'files_sha256':plan['files_sha256'],'controls_original_sha256':sha(original),'controls_adapted_sha256':sha(control)},indent=2)+'\n')
print('PASS A2 host parser fix commit='+head)
