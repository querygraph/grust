import hashlib
import json
import subprocess
from pathlib import Path
plan=json.loads(Path('/tmp/sem-a2-code-plan.json').read_text())
repo=Path('/Users/alexy/src/grust')
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==plan['parent']
for name,expected in plan['files_sha256'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name
assert subprocess.check_output(['git','-C',str(repo),'diff','--name-only'],text=True).strip()=='docs/reviews/sem-review-morrobay-2026-10-01/README.md'
print('PASS A2 root source guard')
