"""Publication controls use synthetic receipts and metadata only, no jobs."""
from __future__ import annotations

import copy
import importlib.util
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path
from typing import Any

SPEC = importlib.util.spec_from_file_location("sem_a2_publication", "/tmp/sem-a2-publish-report.py")
assert SPEC is not None and SPEC.loader is not None
publication = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = publication
SPEC.loader.exec_module(publication)


def report() -> dict[str, Any]:
    cells: list[dict[str, Any]] = []
    contrasts: list[dict[str, Any]] = []
    for algorithm in ("wcc-randomized", "wcc-min-label", "bfs"):
        for sequence, engine in enumerate(("graphframes", "pecan", "graphframes", "pecan", "pecan", "graphframes", "graphframes", "pecan", "pecan", "graphframes"), 1):
            cells.append({"plan_step": {"item": "A2", "algorithm": algorithm, "engine": engine,
                "run_id": algorithm + str(sequence), "role": "warmup" if sequence <= 2 else "measured"},
                "qualified": True, "status": "passed", "correctness": {"result_files": {}},
                "timing": {"engine_phases": [{"name": "public_algorithm", "status": "end", "duration_seconds": 20},
                    {"name": "input_snapshot", "status": "end", "duration_seconds": 4},
                    {"name": "input_snapshot", "status": "end", "duration_seconds": 6}] if engine == "pecan" else None},
                "memory": {"sampled_engine_pss_peak_bytes": 1, "final_lifetime_cgroup_peak_bytes": 2, "boundaries": {}},
                "guest_steal_fraction": 0})
        contrasts.append({"item": "A2", "algorithm": algorithm, "ratio_status": "qualified_receipt_evidence", "blockers": []})
    return {"cells": cells, "contrasts": contrasts, "prerequisite_blockers": [], "status": "incomplete", "archive_base": "/offline/base"}


class PublicationControls(unittest.TestCase):
    def test_complete_item_accepts_other_item_incomplete(self) -> None:
        result = publication.complete_item(report(), "A2")
        self.assertEqual(result["status"], "complete_item_receipt_evidence")
        self.assertEqual(result["full_plan_status_at_observation"], "incomplete")
        self.assertEqual(len(result["cells"]), 30)

    def test_missing_failed_or_known_mismatch_cell_rejects(self) -> None:
        for kind in ("missing", "failed", "known_mismatch"):
            fixture = report()
            if kind == "missing":
                fixture["cells"].pop()
            else:
                fixture["cells"][3]["qualified"] = False
                fixture["cells"][3]["status"] = kind
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                publication.complete_item(fixture, "A2")

    def test_method_labels_and_overlapping_phase_costs(self) -> None:
        result = publication.complete_item(report(), "A2")
        witness = {"id": "b9-signed-isolate", "outcome": "known_mismatch"}
        publication.enrich(result, {"prerequisites": {"signed_witness": witness}})
        self.assertEqual(result["known_signed_isolate_mismatch"], witness)
        phase = result["phase_diagnostics"][1]
        self.assertEqual(phase["pecan_phase_median_seconds"], {"public_algorithm": 20, "input_snapshot": 10})
        self.assertIsNone(phase["graphframes_phases"])
        self.assertIn("Pecan min_label", phase["comparison_label"])
        self.assertIn("graphframes randomized contraction", phase["comparison_label"])
        self.assertIn("not additive", phase["overlap"])
        self.assertEqual(result["dataset_qualification"], publication.SCOPE)

    def test_unqualified_contrast_rejects_ratio_publication(self) -> None:
        fixture = copy.deepcopy(report())
        fixture["contrasts"][1]["ratio_status"] = "withheld"
        with self.assertRaises(ValueError):
            publication.complete_item(fixture, "A2")

    def test_metadata_archive_excludes_physical_arrays_and_parquet(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "archive"
            root.mkdir()
            (root / "plan.json").write_text("{}")
            (root / "ids.i64le").write_bytes(b"payload not read")
            output = root / "cell/container/artifacts/result"
            output.mkdir(parents=True)
            (output / "part.parquet").write_bytes(b"payload not read")
            files = publication.source_files(root, set(), "A2", False)
            self.assertEqual(files, [root / "plan.json"])
            dest = Path(temporary) / "dest"
            dest.mkdir()
            index = publication.pack(dest, [("archives/test/plan.json", files[0])])
            self.assertEqual(index["members"][0]["bytes"], 2)
            with tarfile.open(dest / "evidence.tar.gz", "r:gz") as archive:
                self.assertEqual(archive.getnames(), ["archives/test/plan.json"])


if __name__ == "__main__":
    unittest.main()
