"""Publish a completed A2/A3 receipt report to a fresh explicit directory."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import json
import os
import statistics
import sys
import tarfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Protocol, cast

Json = dict[str, Any]
Item = Literal["A2", "A3"]
SUMMARIZER = Path("/tmp/sem-a2-summarize.py")
SUMMARIZER_SHA = "3594a71f826b56bdfe9456515876ef087cbe1254da0e678b460ec5c0bbee8df8"
QUEUE = Path("/tmp/sem-a2-queue.py")
QUEUE_SHA = "a26558a1cc5532f092b757cc0546239e033047bc47976850aa7fae6932753dfe"
GIB = 2**30
SCOPE = {"dataset": "cit-Patents", "requires_zero_isolates": True,
         "per_cell_full_oracle": True, "generic_signed_wcc_qualified": False}
ALLOWED = {".json", ".jsonl", ".log", ".py", ".md", ".sha256", ".txt"}


class Summarizer(Protocol):
    def summarize(self, plan_path: Path, base: Path, prior_bases: list[Path] | None = None) -> Json: ...
    def markdown(self, report: Json) -> str: ...


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def raw(path: Path) -> bytes:
    require(path.is_file() and not path.is_symlink(), "regular evidence file required: " + str(path))
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    require((before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino), "evidence changed during read: " + str(path))
    return data


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read(path: Path) -> Json:
    value: Any = json.loads(raw(path))
    require(isinstance(value, dict), "JSON object required: " + str(path))
    return cast(Json, value)


def load_summarizer() -> Summarizer:
    require(sha(raw(SUMMARIZER)) == SUMMARIZER_SHA, "frozen summarizer changed")
    require(sha(raw(QUEUE)) == QUEUE_SHA, "frozen queue changed")
    spec = importlib.util.spec_from_file_location("sem_a2_publication_summarizer", SUMMARIZER)
    require(spec is not None and spec.loader is not None, "summarizer import unavailable")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return cast(Summarizer, module)


def idle_receipts(base: Path, item: Item) -> Json:
    for lock in (base.parent / "gate.lock", base.parent / "serial-queue.lock"):
        require(not lock.exists() and not lock.is_symlink(), "active or uncertain gate/queue; publication refused: " + str(lock))
    queue = read(base / ("queue-" + item) / "receipt.json")
    require(queue.get("item") == item and queue.get("base") == str(base) and queue.get("outcome") == "passed" and bool(queue.get("finished_utc")) and queue.get("lock_retained") is False and queue.get("active_child_pid") is None and not queue.get("error") and not queue.get("interruption_signals"), "item queue is not finalized and closed")
    require(all(cell.get("outcome") == "passed" and cell.get("returncode") == 0 and cell.get("audit", {}).get("qualified") is True for cell in queue.get("cells", [])), "queued cell failure or incomplete audit")
    require(bool(queue.get("pins")), "queue immutable evidence pins missing")
    for pinned in queue["pins"]:
        path = Path(pinned["path"])
        require(path.suffix in (".py", ".json"), "queue pin is not helper/JSON evidence")
        data = raw(path)
        require(sha(data) == pinned["sha256"] and len(data) == pinned["bytes"], "immutable queue evidence changed: " + str(path))
    compatibility = read(base / "compatibility04/container/artifacts/receipt.json")
    require(compatibility.get("outcome") == "passed_with_known_mismatch" and compatibility.get("proceed_scope") == SCOPE and compatibility.get("generic_signed_id_qualification") is False, "exact restricted known-mismatch compatibility scope required")
    return queue


def complete_item(full: Json, item: Item) -> Json:
    cells = [cell for cell in full["cells"] if cell["plan_step"]["item"] == item]
    require(len(cells) == 30 and len({cell["plan_step"]["run_id"] for cell in cells}) == 30, "requires all 30 unique item cells")
    require(all(cell.get("qualified") is True for cell in cells), "missing, failed, known-mismatch or unqualified item cell")
    require(Counter(cell["plan_step"]["role"] for cell in cells) == Counter({"warmup": 6, "measured": 24}), "requires six retained warmups and 24 measured cells")
    contrasts = [contrast for contrast in full["contrasts"] if contrast["item"] == item]
    require(len(contrasts) == 3 and all(contrast["ratio_status"] == "qualified_receipt_evidence" and not contrast["blockers"] for contrast in contrasts), "all three matched ABBA contrasts must qualify")
    require(not full["prerequisite_blockers"], "reference/compatibility prerequisites did not qualify")
    report = dict(full)
    report.update(status="complete_item_receipt_evidence", published_item=item,
                  full_plan_status_at_observation=full["status"],
                  other_item_counts=dict(Counter(cell["status"] for cell in full["cells"] if cell["plan_step"]["item"] != item)),
                  cells=cells, contrasts=contrasts, cell_counts={"passed": 30},
                  archive="evidence.tar.gz", evidence_index="evidence-index.json")
    return report


def contrast_label(algorithm: str) -> str:
    return {"wcc-randomized": "Pecan randomized WCC / graphframes randomized contraction WCC",
            "wcc-min-label": "Pecan min_label WCC / graphframes randomized contraction WCC",
            "bfs": "Pecan frontier BFS / graphframes directed unweighted shortest-path hops"}[algorithm]


def enrich(report: Json, queue: Json) -> None:
    known = queue.get("prerequisites", {}).get("signed_witness") or {}
    require(known.get("outcome") == "known_mismatch" and known.get("id") == "b9-signed-isolate", "known signed/isolate mismatch must be preserved separately")
    report["known_signed_isolate_mismatch"] = known
    report["dataset_qualification"] = dict(SCOPE)
    report["phase_diagnostics"] = []
    report["memory_and_steal_diagnostics"] = []
    for contrast in report["contrasts"]:
        contrast["comparison_label"] = contrast_label(contrast["algorithm"])
        cells = [cell for cell in report["cells"] if cell["plan_step"]["algorithm"] == contrast["algorithm"] and cell["plan_step"]["role"] == "measured"]
        phases: dict[str, list[float]] = {}
        for cell in cells:
            if cell["plan_step"]["engine"] != "pecan":
                continue
            totals: dict[str, float] = {}
            for phase in cell["timing"].get("engine_phases") or []:
                if phase.get("status") == "end":
                    duration = phase.get("duration_seconds")
                    require(type(duration) in (int, float) and duration >= 0, "invalid retained phase duration")
                    totals[phase["name"]] = totals.get(phase["name"], 0) + duration
            for name, duration in totals.items():
                phases.setdefault(name, []).append(duration)
        report["phase_diagnostics"].append({"algorithm": contrast["algorithm"], "comparison_label": contrast["comparison_label"],
            "pecan_phase_median_seconds": {name: statistics.median(values) for name, values in phases.items()},
            "phase_sample_counts": {name: len(values) for name, values in phases.items()},
            "boundary": "child phase offsets begin after config parsing; launch-to-exit includes process startup/imports and full cleanup",
            "overlap": "input_snapshot is nested in public_algorithm; phases are not additive; no snapshot subtraction or adjusted performance ratio",
            "graphframes_phases": None, "graphframes_phase_reason": "single CLI has no corresponding structured phase receipt; no inferred decomposition"})
        for engine in ("graphframes", "pecan"):
            engine_cells = [cell for cell in cells if cell["plan_step"]["engine"] == engine]
            ps = [cell["memory"]["sampled_engine_pss_peak_bytes"] for cell in engine_cells]
            lifetime = [cell["memory"]["final_lifetime_cgroup_peak_bytes"] for cell in engine_cells]
            steal = [cell["guest_steal_fraction"] for cell in engine_cells if cell["guest_steal_fraction"] is not None]
            require(all(type(value) is int and value > 0 for value in ps + lifetime), "memory observations missing")
            report["memory_and_steal_diagnostics"].append({"algorithm": contrast["algorithm"], "engine": engine,
                "sampled_engine_pss_peak_bytes_range": [min(ps), max(ps)],
                "final_lifetime_cgroup_peak_bytes_range": [min(lifetime), max(lifetime)],
                "observed_minimum_cgroup_headroom_bytes": 32 * GIB - max(lifetime),
                "guest_steal_fraction_range": [min(steal), max(steal)] if steal else None,
                "guest_steal_observed_cells": len(steal), "measured_cells": 4,
                "boundaries": engine_cells[0]["memory"].get("boundaries"),
                "scope": "sampled and lifetime observations for four measured cells; no guarantee for other graphs or later runs"})
    report["physical_payloads"] = [{"run_id": cell["plan_step"]["run_id"],
        "apo_collected_manifest": str(Path(report["archive_base"]) / cell["plan_step"]["run_id"] / "collected-manifest.json"),
        "apo_output_tree": str(Path(report["archive_base"]) / cell["plan_step"]["run_id"] / "container/artifacts"),
        "declared_physical_result_files": cell["correctness"]["result_files"],
        "scope": "retained host manifest/producer oracle evidence; payload bytes are not rehashed or embedded by this generator"}
        for cell in report["cells"]]


def allowed(path: Path, relative: Path) -> bool:
    return not any(part in ("result", "staging", "gf_workdir", "__pycache__", ".git") for part in relative.parts) and (path.suffix in ALLOWED or path.name in ("SHA256SUMS", "ARTIFACTS.sha256"))


def source_files(root: Path, selected_ids: set[str], item: Item, current: bool) -> list[Path]:
    require(root.is_dir() and not root.is_symlink(), "retained archive unavailable: " + str(root))
    files: list[Path] = []
    for top in sorted(root.iterdir()):
        require(not top.is_symlink(), "archive symbolic link refused: " + str(top))
        if current and (top.name.startswith(("a2-", "a3-")) or top.name.startswith("queue-A")) and not any(top.name == run_id or top.name.startswith(run_id + ".") for run_id in selected_ids) and not (top.name == "queue-" + item or top.name.startswith("queue-" + item + ".")):
            continue
        if top.is_dir() and (top / "result.json").is_file():
            host = read(top / "result.json")
            require(bool(host.get("finished_utc")) and host.get("outcome") not in ("running", "checking"), "unfinished host attempt refused: " + str(top))
        candidates = [top] if top.is_file() else sorted(top.rglob("*"))
        for path in candidates:
            relative = path.relative_to(root)
            if allowed(path, relative):
                require(not path.is_symlink(), "evidence symbolic link refused: " + str(path))
                if path.is_file():
                    files.append(path)
    return files


def pack(dest: Path, origins: list[tuple[str, Path]]) -> Json:
    require(len({name for name, _path in origins}) == len(origins), "duplicate archive member")
    members: list[Json] = []
    with tarfile.open(dest / "evidence.tar.gz", "x:gz", compresslevel=3) as archive:
        for name, source in origins:
            require(not Path(name).is_absolute() and ".." not in Path(name).parts, "unsafe archive member")
            data = raw(source)
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            archive.addfile(info, io.BytesIO(data))
            members.append({"member": name, "bytes": len(data), "sha256": sha(data), "retained_source": str(source)})
    # Recheck the metadata copied into the archive; no physical payload reads.
    for member in members:
        require(sha(raw(Path(member["retained_source"]))) == member["sha256"], "evidence changed during archive creation")
    archive_bytes = raw(dest / "evidence.tar.gz")
    return {"schema_version": 1, "observed_utc": utc(), "archive": "evidence.tar.gz",
            "archive_bytes": len(archive_bytes), "archive_sha256": sha(archive_bytes), "members": members,
            "member_paths": "exact names inside evidence.tar.gz; archives/<Apo archive basename>/... preserves relative paths",
            "payload_scope": "JSON/JSONL/log/plan/helper/gate evidence only; Parquet, i64 arrays, binaries, bundles and payload tar files excluded; original collected manifests link the unchanged payloads on Apo"}


def write(path: Path, value: Json | str) -> None:
    text = value if isinstance(value, str) else json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    with path.open("x") as stream:
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())


def readme(report: Json) -> str:
    item = report["published_item"]
    mode = "Pecan local runtime" if item == "A2" else "Pecan driver plus two workers in one container on one host"
    lines = [f"# {item}: cit-Patents shared-host comparison", "", f"All 30 {item} cells qualified by retained host/producer/full-oracle receipts: 24 measured cells and six warmups. Warmups remain in the evidence and are excluded from ratios. This is a receipt audit, not a new physical payload comparison.", "", f"Execution: {mode}; graphframes remains one CLI process with 16 workers. Morrobay is a shared host. Only within-class ratios are reported; raw seconds in the [detailed report](REPORT.md) are diagnostics.", "", "## Ratios", "", "Pecan / graphframes, three significant digits; four measured samples per engine per contrast, in two ABBA blocks.", "", "| Comparison | Median ratio | Paired geometric mean, block 1 | Block 2 |", "| --- | ---: | ---: | ---: |"]
    for contrast in report["contrasts"]:
        blocks = contrast["block_geomean_paired_ratios"]
        lines.append(f"| {contrast['comparison_label']} | {contrast['median_pecan_over_graphframes']} | {blocks[0]['pecan_over_graphframes']} | {blocks[1]['pecan_over_graphframes']} |")
    lines.extend(["", "The median ratio compares the four-sample medians. Each block pairs adjacent runs (Pecan position 2 / graphframes position 1, Pecan position 3 / graphframes position 4). n=4, ordered blocks, filesystem cache warming and shared-host activity limit inference. No absolute-performance or multihost claim follows.", "", "## Contract and resources", "", "Each fresh engine container has 16 CPUs, cpuset 0–15, 32 GiB memory and no swap. graphframes has a 30 GiB FairSpillPool with SnMalloc. Pecan local has a 30 GiB greedy pool with mimalloc; in A3, driver and two workers each have 10 GiB, summing to 30 GiB. Each Pecan process prepays its 256 MiB native quota from its pool. Pool sums do not guarantee a physical memory bound.", "", "The timer spans engine process launch through completed exit, including startup, input reads, Pecan snapshots, algorithm, full Parquet export, cleanup and shutdown. Hashing, input/reference construction, full physical oracle and parent final observations are outside. Pecan input_snapshot is nested in public_algorithm: raw phase medians below overlap and must not be added or subtracted from the launch-to-exit ratio. graphframes has no corresponding structured phase breakdown.", "", "Sampled engine PSS excludes the supervisor and PID 1; sampled container PSS includes them. Cgroup lifetime peaks include page cache and earlier identity reads, and final peaks also include the parent oracle. Per-cell observations, sampling coverage and guest steal are preserved in [report.json](report.json).", "", "Original cit-Patents inputs remain pinned. Validation observed zero isolated vertices. The former source 750000 was absent; its failed validation is retained. The explicit common BFS source is **5795784**, chosen before timing by maximum outgoing edge-row count (770), ties by minimum raw vertex ID. This does not reproduce the historical landmark.", "", "The signed/isolate B9 control remains **known_mismatch**, with exact observed and expected rows retained. Dataset qualification is restricted to zero-isolate cit-Patents with a full oracle in every cell; generic signed-ID WCC is not qualified. PageRank remains **not comparable pending B11**; no PR timing is included.", "", "Controller source is f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a, on retained runtime 56194b170155301ba91077f0ba3df31fe2c78b6b and native source ffcfbd5690e3f3681ef9ac18ba959bc231cf9f73; this does not claim a runtime rebuilt from the controller pin. graphframes source is b4da56dabe20bba8e29563e06acc5179b2113ce3. Exact byte pins are retained in the plan and JSON report.", "", "## Phase diagnostics", "", "Pecan measured phase medians in seconds, for explanation only; input_snapshot overlaps public_algorithm. Each named phase sums its own completed occurrences within a cell before taking its median.", "", "| Pecan method | Input snapshot | Public algorithm (includes snapshot) | Result export | Server startup | Server shutdown |", "| --- | ---: | ---: | ---: | ---: | ---: |"])
    for diagnostic in report["phase_diagnostics"]:
        phases = diagnostic["pecan_phase_median_seconds"]
        values = [f"{phases[name]:.4g}" if name in phases else "unavailable" for name in ("input_snapshot", "public_algorithm", "result_export", "server_startup", "server_shutdown")]
        lines.append("| " + diagnostic["comparison_label"].split(" / ")[0] + " | " + " | ".join(values) + " |")
    lines.extend(["", "## Memory and steal diagnostics", "", "Ranges cover the four measured cells per engine and contrast. Peaks are observations within their labelled boundaries, not future capacity guarantees.", "", "| Contrast / engine | Sampled engine PSS GiB range | Final container lifetime peak GiB range | Guest steal % range |", "| --- | ---: | ---: | ---: |"])
    for observation in report["memory_and_steal_diagnostics"]:
        pss = "–".join(f"{value / GIB:.3g}" for value in observation["sampled_engine_pss_peak_bytes_range"])
        peak = "–".join(f"{value / GIB:.3g}" for value in observation["final_lifetime_cgroup_peak_bytes_range"])
        steal = observation["guest_steal_fraction_range"]
        steal_text = "–".join(f"{value * 100:.3g}" for value in steal) if steal else "unavailable"
        lines.append(f"| {observation['algorithm']} / {observation['engine']} | {pss} | {peak} | {steal_text} ({observation['guest_steal_observed_cells']}/4 observed) |")
    lines.extend(["", "## Retained evidence", "", "[evidence.tar.gz](evidence.tar.gz) contains finalized JSON/JSONL, logs, plans, helpers and offline controls. [evidence-index.json](evidence-index.json) records every archive member's exact name, byte count, SHA-256 and original path. Historical run01–03 failed preflights and phase attempts remain distinct; they are not counted as algorithm results.", "", "Full Parquet outputs, binary references and other physical payloads remain on Apo. Their unchanged collected manifests are linked by `physical_payloads` in [report.json](report.json), with copies indexed in the archive. This generator does not read or rehash those payloads.", ""])
    return "\n".join(lines)


def publish(base: Path, item: Item, dest: Path, offline: list[Path]) -> Json:
    base, dest = base.resolve(), dest.resolve()
    require(not dest.exists() and not dest.is_symlink(), "destination must be new; existing outputs refused")
    queue = idle_receipts(base, item)
    plan = read(base / "plan.json")
    prior = [Path(path).resolve() for path in plan.get("prior_archives", [])]
    require(len(prior) == 3 and len(set(prior)) == 3 and all(path.name == f"A2-run{number:02d}" for number, path in enumerate(prior, 1)), "all three declared prior archives required")
    summarizer = load_summarizer()
    report = complete_item(summarizer.summarize(base / "plan.json", base, prior), item)
    enrich(report, queue)
    ids = {cell["plan_step"]["run_id"] for cell in report["cells"]}
    completed_ids = {cell["run_id"] for cell in queue["cells"]} | {cell["plan_step"]["run_id"] for cell in queue.get("prior_qualified", []) if cell["plan_step"]["item"] == item}
    require(completed_ids == ids, "queue plus explicit prior prefix does not cover every item cell")
    for payload in report["physical_payloads"]:
        manifest = Path(payload["apo_collected_manifest"])
        payload["collected_manifest_sha256"] = sha(raw(manifest))
        payload["evidence_member"] = "archives/" + base.name + "/" + str(manifest.relative_to(base))
    origins: list[tuple[str, Path]] = []
    for root in [base, *prior]:
        origins.extend(("archives/" + root.name + "/" + str(path.relative_to(root)), path) for path in source_files(root, ids, item, root == base))
    origins.extend(("tools/" + path.name, path) for path in (Path(__file__), SUMMARIZER, QUEUE, Path("/tmp/test_sem_a2_queue.py"), Path("/tmp/test_sem_a2_publish_report.py")))
    for root in offline:
        require(read(root / "receipt.json").get("outcome") == "passed", "offline gate evidence must pass")
        origins.extend(("offline/" + root.name + "/" + str(path.relative_to(root)), path) for path in source_files(root, set(), item, False))
    report["publication_generator_sha256"] = sha(raw(Path(__file__)))
    report["publication_observed_utc"] = utc()
    idle_receipts(base, item)
    dest.mkdir(parents=True, exist_ok=False)
    try:
        write(dest / "report.json", report)
        detailed = summarizer.markdown(report).replace("# A2/A3 receipt comparison", "# " + item + " completed receipt comparison", 1)
        detailed += "\n## Explicit method labels and phase observations\n\n" + readme(report).split("## Ratios", 1)[1]
        write(dest / "REPORT.md", detailed)
        write(dest / "README.md", readme(report))
        index = pack(dest, origins)
        idle_receipts(base, item)
        write(dest / "evidence-index.json", index)
        receipt = {"outcome": "passed", "observed_utc": utc(), "item": item, "dest": str(dest),
                   "generator_sha256": report["publication_generator_sha256"], "archive_sha256": index["archive_sha256"],
                   "evidence_members": len(index["members"]), "qualified_cells": 30,
                   "scope": "receipt report and metadata evidence only; no Docker, engine or physical payload reads"}
        write(dest / "generation-receipt.json", receipt)
        files = [path for path in sorted(dest.iterdir()) if path.is_file()]
        write(dest / "ARTIFACTS.sha256", "".join(sha(raw(path)) + "  " + path.name + "\n" for path in files))
        return receipt
    except BaseException as error:
        write(dest / "generation-error.json", {"outcome": "error", "observed_utc": utc(), "error": repr(error)})
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--item", choices=("A2", "A3"), required=True)
    parser.add_argument("--dest", type=Path, required=True)
    parser.add_argument("--offline", type=Path, action="append", default=[], help="closed offline gate directory with passed receipt.json")
    args = parser.parse_args()
    print(json.dumps(publish(args.base, cast(Item, args.item), args.dest, args.offline), sort_keys=True))


if __name__ == "__main__":
    main()
