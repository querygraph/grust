"""Serial B8 continuation; root launches it after review. No retries or cleanup."""
from __future__ import annotations

import argparse
import errno
import hashlib
import json
import math
import os
import shlex
import signal
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType
from typing import Any, Protocol, cast

Json = dict[str, Any]
BASE = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01')
PYTHON = Path('/tmp/sem-output-oracle-venv/bin/python')
REFERENCE_PID = 76098
REFERENCE_START = 'Thu Oct 1 17:49:59 2026'
FROZEN = {
    'graph500-reference01.launch.json': 'bb59acbede44468ffbab9d25b10ffc1c5d28d934ca439316512cd18aaf88be5f',
    'operations/sem-b8-configs.py': '504c0127e4897c9f5d74c7d89680b0a25ecc5680a1cdb40976def8fcfcb50ce9',
    'controller-profile/run_pair_queue.py': 'abe3842e4d5ae77122c42857ff1cb0298e3d42ccba7030e99c9a902967b05a94',
    'controller-profile/run_shapes_host.py': 'ab2c33497e31df9b1f0010be78446df4eb936f09af4235264b6bb421e2f28e98',
    'support/support-manifest.json': '02837080b86cae0ffcd63c8873fc88ba00bdbf87c63ab618fe97618a0f4120bd',
}


class Child(Protocol):
    pid: int
    def poll(self) -> int | None: ...


class Spawner(Protocol):
    def __call__(self, command: list[str], log: Path) -> Child: ...


@dataclass(frozen=True, slots=True)
class Options:
    base: Path
    output: Path
    reference_deadline_seconds: float = 14400
    prepare_deadline_seconds: float = 1800
    queue_deadline_seconds: float = 172800
    poll_seconds: float = 5


@dataclass(slots=True)
class Progress:
    name: str
    command: list[str]
    log: str
    outcome: str = 'launch_intent'
    started_utc: str | None = None
    finished_utc: str | None = None
    pid: int | None = None
    returncode: int | None = None


@dataclass(slots=True)
class Receipt:
    options: Json
    owner_pid: int
    started_utc: str
    observed_utc: str
    outcome: str = 'preparing'
    finished_utc: str | None = None
    active_child_pid: int | None = None
    pins: list[Json] = field(default_factory=list)
    reference_observations: list[Json] = field(default_factory=list)
    phases: list[Progress] = field(default_factory=list)
    interruption_signals: list[int] = field(default_factory=list)
    error: str | None = None
    scope: str = 'Root-owned serial metadata/configgen/queue orchestration; no forced cleanup, retry, resume or competing lock. Child timeout may leave its process alive and ownership uncertain.'
    durability_scope: str = 'file fsync/atomic replace/directory fsync; macOS EINVAL/ENOTSUP tolerated without host power-loss qualification'


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def read(path: Path) -> Json:
    require(path.is_file() and not path.is_symlink(), 'regular JSON required: ' + str(path))
    value: Any = json.loads(path.read_bytes())
    require(isinstance(value, dict), 'JSON object required')
    return cast(Json, value)


def pin(path: Path) -> Json:
    require(path.is_file() and not path.is_symlink(), 'regular pinned file required: ' + str(path))
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def verify_pins(receipt: Receipt) -> None:
    for expected in receipt.pins:
        require(pin(Path(expected['path'])) == expected, 'immutable metadata changed: ' + expected['path'])


def directory_fsync(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        try:
            os.fsync(descriptor)
        except OSError as error:
            if sys.platform != 'darwin' or error.errno not in (errno.EINVAL, errno.ENOTSUP):
                raise
    finally:
        os.close(descriptor)


def save(path: Path, receipt: Receipt) -> None:
    receipt.observed_utc = utc()
    temporary = path.with_suffix('.tmp')
    with temporary.open('x') as stream:
        stream.write(json.dumps(asdict(receipt), indent=2, sort_keys=True, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    directory_fsync(path.parent)


def idle(base: Path) -> None:
    for name in ('gate.lock', 'serial-queue.lock'):
        path = base.parent / name
        require(not path.exists() and not path.is_symlink(), 'phase overlap/retained lock: ' + str(path))


def process_snapshot(pid: int) -> Json | None:
    result = subprocess.run(['/bin/ps', '-p', str(pid), '-o', 'lstart=', '-o', 'command='],
                            capture_output=True, text=True, check=False)
    if result.returncode == 1 and not result.stdout.strip():
        return None
    require(result.returncode == 0, 'reference PID observation failed')
    fields = result.stdout.strip().split(maxsplit=5)
    require(len(fields) == 6, 'reference process start/command observation malformed')
    return {'pid': pid, 'start': ' '.join(fields[:5]), 'argv': shlex.split(fields[5])}


def same_argv(observed: list[str], expected: list[str]) -> bool:
    def canonical(value: str) -> str:
        return str(Path(value).resolve()) if value.startswith('/') else value
    return [canonical(v) for v in observed] == [canonical(v) for v in expected]


def wait_reference(base: Path, launch: Json, receipt: Receipt, path: Path, seconds: float,
                   observe: Callable[[int], Json | None] = process_snapshot,
                   clock: Callable[[], float] = time.monotonic,
                   sleeper: Callable[[float], None] = time.sleep) -> None:
    deadline = clock() + seconds
    last: Json | None = None
    while True:
        current = observe(REFERENCE_PID)
        if current is None:
            receipt.reference_observations.append({'observed_utc': utc(), 'pid': REFERENCE_PID, 'state': 'not_present'})
            save(path, receipt)
            return
        require(current.get('start') == REFERENCE_START and same_argv(current['argv'], launch['command']),
                'reference PID reused/wrong start or command; ownership uncertain')
        if last != current:
            receipt.reference_observations.append({'observed_utc': utc(), 'state': 'running', **current})
            save(path, receipt)
            last = current
        result_path = base / 'graph500-reference01/result.json'
        if result_path.is_file():
            host = read(result_path)
            require(not host.get('finished_utc') or host.get('outcome') == 'passed', 'reference failed; no continuation')
        verify_pins(receipt)
        require(clock() < deadline, 'reference wait deadline; no cleanup/next phase')
        sleeper(min(5.0, max(0.0, deadline - clock())))


def reference_closed(base: Path, receipt: Receipt) -> None:
    directory = base / 'graph500-reference01'
    host = read(directory / 'result.json')
    producer = read(directory / 'container/artifacts/receipt.json')
    record = read(directory / 'container-record.json')
    require(host.get('run_id') == 'graph500-reference01' and host.get('action') == 'run'
            and host.get('kind') == 'reference' and host.get('outcome') == host.get('producer_outcome') == 'passed'
            and bool(host.get('finished_utc')) and host.get('certain_container_closure') is True
            and host.get('archive_verified') is True and host.get('lock_retained') is False and not host.get('error'),
            'full reference host pass/archive/certain closure required')
    embedded = host['records']['container']
    require({k: v for k, v in embedded.items() if k != 'absence_verified'} == record,
            'embedded/separate reference container metadata differ')
    state = record['inspect']['state']
    limits = record['inspect']['limits']
    require(record['inspect']['id'] == record['create']['stdout'].strip()
            and record['inspect']['image'] == 'sha256:f3518d652fbea8b9b9f9ebf9849277ca3bd39d0c21bb2c6e36fbaeaa2dc2678e'
            and limits.get('Memory') == limits.get('MemorySwap') == 32 * 2**30
            and limits.get('NanoCpus') == 16 * 10**9 and limits.get('Init') is True
            and record['create']['returncode'] == record['attach_returncode'] == record['remove']['returncode'] == 0
            and record['copied']['artifacts']['returncode'] == 0 and state.get('Running') is False
            and state.get('ExitCode') == 0 and state.get('OOMKilled') is False and not state.get('Error')
            and not any(record.get(k) for k in ('outer_timeout', 'transport_errors', 'kill', 'forced_cleanup_kill', 'operator_interrupted')),
            'reference stopped/removed/transport closure failed')
    absence = embedded['absence_verified']
    require(absence.get('returncode') == 1 and any(word in absence.get('stderr', '').lower()
            for word in ('no such object', 'no such container')), 'reference absence proof missing')
    require(producer.get('outcome') == 'passed' and bool(producer.get('finished_utc')) and not producer.get('error')
            and producer.get('controller_semantics') == 'f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a'
            and producer.get('inputs_before') == producer.get('inputs_after') and bool(producer.get('inputs_before'))
            and producer.get('vertex_rows') == 8870942 and producer.get('edge_rows') == 260379520
            and set(producer.get('artifacts', {})) == {'adjacency', 'representatives', 'min-label-initial-round'},
            'full selected Graph500 reference source/input/artifacts missing')
    require(producer['config'] == read(directory / 'helper-config.json'), 'reference configured producer differs')
    inventory = read(directory / 'collected-manifest.json')
    require(inventory == host.get('artifacts') and inventory.get('receipt.json') ==
            {k: v for k, v in pin(directory / 'container/artifacts/receipt.json').items() if k != 'path'},
            'reference host archive inventory/receipt identity differs')
    for name in ('result.json', 'container-record.json', 'helper-config.json', 'collected-manifest.json', 'container/artifacts/receipt.json'):
        receipt.pins.append(pin(directory / name))
    idle(base)


def spawn(command: list[str], log: Path) -> Child:
    with log.open('xb') as stream:
        directory_fsync(log.parent)
        return subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
                                start_new_session=True)


def phase(command: list[str], name: str, receipt: Receipt, path: Path, seconds: float,
          spawner: Spawner = spawn, clock: Callable[[], float] = time.monotonic,
          sleeper: Callable[[float], None] = time.sleep) -> None:
    require(receipt.active_child_pid is None, 'continuation child overlap')
    log = path.parent / (name + '.log')
    require(not log.exists() and not log.is_symlink(), 'fresh phase log required')
    verify_pins(receipt)
    progress = Progress(name=name, command=command, log=str(log), started_utc=utc())
    receipt.phases.append(progress)
    save(path, receipt)
    child = spawner(command, log)
    progress.pid, progress.outcome, receipt.active_child_pid = child.pid, 'running', child.pid
    save(path, receipt)
    deadline = clock() + seconds
    while (code := child.poll()) is None:
        require(clock() < deadline, 'phase deadline exceeded; child remains owner responsibility: ' + name)
        sleeper(min(5.0, max(0.0, deadline - clock())))
    progress.returncode, progress.finished_utc, progress.outcome = code, utc(), 'child_exited'
    receipt.active_child_pid = None
    save(path, receipt)
    require(code == 0, 'phase returncode failed: ' + name)
    verify_pins(receipt)


def prepared(base: Path, generated: Path, receipt: Receipt) -> Json:
    value = read(generated / 'preparation.json')
    require(value.get('outcome') == 'prepared' and bool(value.get('finished_utc')) and not value.get('error')
            and value.get('source_sha256') == FROZEN['operations/sem-b8-configs.py'], 'configuration preparation failed')
    options = value['options']
    require(options.get('action') == 'queues' and Path(options['output']).resolve() == generated.resolve()
            and options.get('driver_sha256') == FROZEN['controller-profile/run_shapes_host.py']
            and options.get('queue_sha256') == FROZEN['controller-profile/run_pair_queue.py'], 'prepared config source/paths differ')
    for name, expected in value['artifacts'].items():
        require('/' not in name and name not in ('.', '..'), 'unsafe prepared member')
        observed = pin(generated / name)
        require(observed == expected, 'prepared metadata artifact differs: ' + name)
        receipt.pins.append(observed)
    plan = read(generated / 'plan.json')
    require(len(plan['steps']) == 60 and len({s['run_id'] for s in plan['steps']}) == 60, 'complete immutable sixty-step plan required')
    for dataset in ('cit-Patents', 'graph500-24'):
        config = read(generated / ('queue-' + dataset.lower() + '.json'))
        require(Path(config['host_root']).resolve() == base.resolve()
                and Path(config['output']).resolve() == (base / ('queue-' + dataset.lower())).resolve(), 'queue campaign/output identity differs')
    idle(base)
    return plan


def queue_closed(base: Path, dataset: str, plan: Json, config: Json) -> None:
    value = read(base / ('queue-' + dataset.lower()) / 'receipt.json')
    selected = [step for step in plan['steps'] if step['dataset'] == dataset]
    require(len(selected) == 30 and value.get('dataset') == dataset and value.get('config') == config
            and value.get('outcome') == 'passed' and bool(value.get('finished_utc'))
            and value.get('active_child_pid') is None and value.get('lock_retained') is False
            and not value.get('error') and not value.get('interruption_signals'), 'dataset queue final closure failed')
    cells = value.get('cells') or []
    require([cell.get('step') for cell in cells] == selected
            and all(cell.get('outcome') == 'passed' and cell.get('returncode') == 0 and bool(cell.get('finished_utc'))
                    and (cell.get('audit') or {}).get('qualified') is True for cell in cells), 'all thirty queue outcomes/audits must qualify')
    idle(base)


def run(options: Options) -> int:
    require(options.base.resolve() == BASE.resolve(), 'frozen B8-run01 namespace required')
    require(all(math.isfinite(value) and value > 0 for value in (options.reference_deadline_seconds, options.prepare_deadline_seconds,
            options.queue_deadline_seconds, options.poll_seconds)) and options.prepare_deadline_seconds <= 1800,
            'positive finite phase deadlines; preparation at most1800seconds')
    out = options.output.resolve()
    require(not out.exists() and not out.is_symlink(), 'fresh continuation receipt namespace; no resume')
    out.mkdir(parents=True)
    directory_fsync(out.parent)
    path = out / 'receipt.json'
    receipt = Receipt(options={**asdict(options), 'base': str(options.base), 'output': str(out)},
                      owner_pid=os.getpid(), started_utc=utc(), observed_utc=utc())
    receipt.pins.append(pin(Path(__file__)))
    previous: dict[int, Any] = {}

    def interrupted(signum: int, _frame: FrameType | None) -> None:
        receipt.interruption_signals.append(signum)
        raise InterruptedError('continuation interrupted; children remain root ownership')

    try:
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous[signum] = signal.signal(signum, interrupted)
        save(path, receipt)
        for name, expected in FROZEN.items():
            observed = pin(options.base / name)
            require(observed['sha256'] == expected, 'frozen continuation dependency differs: ' + name)
            receipt.pins.append(observed)
        launch = read(options.base / 'graph500-reference01.launch.json')
        require(launch.get('pid') == REFERENCE_PID and launch.get('driver_sha256') == FROZEN['controller-profile/run_shapes_host.py'],
                'exact original reference PID/driver required')
        receipt.pins.append(pin(options.base / 'campaign.json'))
        config_path = options.base / 'generated-graph500-reference01/graph500-24-reference.json'
        config_pin = pin(config_path)
        require(config_pin['sha256'] == launch.get('config_sha256'), 'reference launch config differs')
        receipt.pins.append(config_pin)
        receipt.outcome = 'waiting_reference'
        save(path, receipt)
        wait_reference(options.base, launch, receipt, path, options.reference_deadline_seconds)
        reference_closed(options.base, receipt)
        generated = options.base / 'generated-queues01'
        require(not generated.exists() and not generated.is_symlink(), 'existing generated queue config namespace; no retry')
        command = [str(PYTHON), '-B', str(options.base / 'operations/sem-b8-configs.py'), 'queues', '--output', str(generated),
                   '--driver-sha256', FROZEN['controller-profile/run_shapes_host.py'], '--queue-sha256', FROZEN['controller-profile/run_pair_queue.py']]
        phase(command, 'prepare-queues', receipt, path, options.prepare_deadline_seconds)
        plan = prepared(options.base, generated, receipt)
        receipt.phases[-1].outcome = 'passed'
        save(path, receipt)
        for dataset in ('cit-Patents', 'graph500-24'):
            idle(options.base)
            config_path = generated / ('queue-' + dataset.lower() + '.json')
            config = read(config_path)
            queue_output = Path(config['output'])
            require(not queue_output.exists() and not queue_output.is_symlink(), 'existing queue namespace; no resume/retry')
            command = [str(PYTHON), '-B', str(options.base / 'controller-profile/run_pair_queue.py'),
                       '--config', str(config_path), '--dataset', dataset]
            phase(command, 'queue-' + dataset.lower(), receipt, path, options.queue_deadline_seconds)
            queue_closed(options.base, dataset, plan, config)
            receipt.pins.append(pin(queue_output / 'receipt.json'))
            receipt.phases[-1].outcome = 'passed'
            save(path, receipt)
        verify_pins(receipt)
        idle(options.base)
        receipt.outcome = 'passed'
    except BaseException as error:  # noqa: BLE001 - retain all failures/interruption without touching child ownership.
        receipt.outcome = 'interrupted' if isinstance(error, (KeyboardInterrupt, InterruptedError)) else 'error'
        receipt.error = type(error).__name__ + ': ' + str(error)
        if receipt.active_child_pid is not None and receipt.phases:
            receipt.phases[-1].outcome = 'active_child_uncertain'
    finally:
        receipt.finished_utc = utc()
        save(path, receipt)
        for restored_signal, handler in previous.items():
            signal.signal(restored_signal, handler)
    return 0 if receipt.outcome == 'passed' else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=BASE)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reference-deadline-seconds', type=float, default=14400)
    parser.add_argument('--prepare-deadline-seconds', type=float, default=1800)
    parser.add_argument('--queue-deadline-seconds', type=float, default=172800)
    args = parser.parse_args()
    return run(Options(**vars(args)))


if __name__ == '__main__':
    raise SystemExit(main())
