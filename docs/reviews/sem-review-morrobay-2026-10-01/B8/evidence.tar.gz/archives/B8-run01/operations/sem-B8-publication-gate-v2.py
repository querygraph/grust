"""Exact B8 publication gate plus explicit host adapter/configuration provenance."""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import sys
from collections.abc import Callable
from pathlib import Path
from types import ModuleType
from typing import Any, TypeAlias, cast

Json: TypeAlias = dict[str, Any]
FROZEN_GATE_SHA = '703a3832648b538ea67cc170c145ca69a2ccbd9aedc7b1e6a8a96f7cbc216fa7'
WRAPPER_SHA = '6420a71cdd971cc42d09ba5be6be4d98e4ad8c6b4d0a713985e2205376f10408'
PUBLISHER_SHA = '6a5e76f1e549cbbf7e5b19e680059d2f1c960808a0c86ce9011409043ae30937'
QUEUE_SHA = 'abe3842e4d5ae77122c42857ff1cb0298e3d42ccba7030e99c9a902967b05a94'
ADAPTER_SHA = '99c53056d946d16c705e041769acccd5034c321093c7706d261c1174ae6038f2'
CONFIG_WRAPPER_SHA = 'a6e8e1d446e1e081a3515c32bf5633be1ad93b432bf1d1c1ea89331d4129d33f'
CONFIG_SHA = '504c0127e4897c9f5d74c7d89680b0a25ecc5680a1cdb40976def8fcfcb50ce9'
FUNCTION_SHA = '7dd9fefe0888f46705c883a61787a91a2809057b4324f1fbadbf4faeb8457201'
REFERENCE_GATE_SHA = '4de6b53ea46d43e579613e3404582dd3cdd98887338becf88af5a2171e6557a6'
LIMIT = 64 * 2**20


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def raw(path: Path) -> bytes:
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= LIMIT, 'bounded regular gate source')
    before = path.stat(); data = path.read_bytes(); after = path.stat()
    require((before.st_ino,before.st_size,before.st_mtime_ns) == (after.st_ino,after.st_size,after.st_mtime_ns), 'gate source changed during read')
    return data


def load(path: Path, expected: str, name: str) -> ModuleType:
    before = raw(path); require(sha(before) == expected, 'exact frozen source before import: '+name)
    spec = importlib.util.spec_from_file_location(name,path)
    require(spec is not None and spec.loader is not None, 'exact gate loader')
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module; spec.loader.exec_module(module)
    require(raw(path) == before, 'frozen source changed during import')
    return module


def archive_pin(identity: Json, contents: dict[str,bytes], expected: str | None = None) -> bytes:
    require(set(identity) == {'path','bytes','sha256'}, 'exact archived FilePin schema')
    path = Path(identity['path'])
    require(path.is_absolute() and '..' not in path.parts and str(path) in contents, 'host provenance source unindexed')
    data = contents[str(path)]
    require(len(data) == identity['bytes'] and sha(data) == identity['sha256']
            and (expected is None or identity['sha256'] == expected), 'host provenance indexed bytes/SHA differ')
    return data


class RemoveFrozenPrefix(ast.NodeTransformer):
    def visit_Attribute(self,node: ast.Attribute) -> ast.AST:
        result = self.generic_visit(node)
        assert isinstance(result,ast.Attribute)
        if isinstance(result.value,ast.Name) and result.value.id == 'frozen':
            return ast.copy_location(ast.Name(id=result.attr,ctx=result.ctx),result)
        return result


def function(source: bytes,name: str) -> tuple[ast.FunctionDef,bytes]:
    text = source.decode(); nodes = ast.parse(text).body
    matched = [n for n in nodes if isinstance(n,ast.FunctionDef) and n.name == name]
    require(len(matched) == 1,'unique archived predicate function')
    node = matched[0]; require(node.end_lineno is not None,'archived predicate extent')
    lines = text.splitlines(keepends=True)
    return node,''.join(lines[node.lineno-1:node.end_lineno]).encode()


def predicate_guard(queue: bytes,adapter: bytes,record: Json) -> None:
    left,text = function(queue,'audited_archive'); right,_ = function(adapter,'audited_archive_v2')
    right_ = RemoveFrozenPrefix().visit(right)
    require(isinstance(right_,ast.FunctionDef),'archived adapter predicate AST')
    assert isinstance(right_,ast.FunctionDef)
    require(sha(text) == record['original_function_sha256'] == FUNCTION_SHA
            and len(text) == record['original_function_bytes']
            and len(left.body) == len(right_.body) == record['statement_count'],'original predicate source guard differs')
    unchanged = [i for i in range(len(left.body)) if i not in {3,4}]
    require(record['changed_statement_indices'] == [3,4] and record['unchanged_statement_indices'] == unchanged,'authorized predicate statement roster differs')
    for i in unchanged:
        require(ast.dump(left.body[i],include_attributes=False) == ast.dump(right_.body[i],include_attributes=False), 'retained predicate changed outside closure binding')


def provenance_gate(report: Json,contents: dict[str,bytes],wrapper: ModuleType) -> Json:
    value = report['host_closure_provenance']
    model = wrapper.Provenance.model_validate(value)
    require(model.model_dump(mode='json') == value,'structured publication provenance differs')
    require(value['version'] == 'b8-publication-host-provenance-v3'
            and value['guest_change'] is False and value['timer_change'] is False
            and value['raw_archive_rewrite'] is False,'host-only derivation scope differs')
    archive_pin(value['publisher_wrapper'],contents,WRAPPER_SHA)
    archive_pin(value['frozen_publisher'],contents,PUBLISHER_SHA)
    archive_pin(value['frozen_publication_gate'],contents,FROZEN_GATE_SHA)
    adapter = value['closure_adapter']
    require(set(adapter) == {'version','adapter','frozen_queue','original_function_sha256','predicate_change','guest_change','timer_change','raw_archive_rewrite'}
            and adapter['version'] == 'b8-host-embedded-absence-v2'
            and adapter['original_function_sha256'] == FUNCTION_SHA
            and adapter['predicate_change'] == 'Compare only absence_verified separately; require embedded absence; all other archived predicates unchanged.'
            and all(adapter[k] is False for k in ('guest_change','timer_change','raw_archive_rewrite')),'executed host adapter provenance differs')
    adapter_bytes = archive_pin(adapter['adapter'],contents,ADAPTER_SHA)
    queue_bytes = archive_pin(adapter['frozen_queue'],contents,QUEUE_SHA)
    predicate_guard(queue_bytes,adapter_bytes,value['predicate_guard'])
    archive_pin(value['config_wrapper'],contents,CONFIG_WRAPPER_SHA)
    archive_pin(value['frozen_config_generator'],contents,CONFIG_SHA)
    preparation = cast(Json,json.loads(archive_pin(value['preparation'],contents)))
    require(preparation['outcome'] == 'prepared' and bool(preparation['finished_utc'])
            and not preparation['error'] and not preparation['traceback'] and preparation['source_sha256'] == CONFIG_SHA
            and preparation['generator_wrapper_version'] == 'b8-metadata-generator-host-closure-v2'
            and preparation['closure_adapter'] == adapter and preparation['generator_wrapper'] == value['config_wrapper'], 'actual prepared configuration provenance differs')
    directory = Path(value['preparation']['path']).parent
    require(preparation['options']['action'] == 'queues' and Path(preparation['options']['output']) == directory
            and preparation['options']['queue_sha256'] == QUEUE_SHA, 'prepared source/namespace differs')
    for name,identity in preparation['artifacts'].items():
        require(Path(identity['path']) == directory/name,'prepared artifact escapes namespace')
        archive_pin(identity,contents)
    require(preparation['artifacts']['sem-b8-configs.py'] == value['frozen_config_generator'], 'retained config generator snapshot differs')
    require(preparation['artifacts']['plan.json'] == {k:report['plan_evidence'][k] for k in ('path','bytes','sha256')}, 'report/prepared plan bytes differ')
    expected_queues = [{k:q['evidence'][k] for k in ('path','bytes','sha256')} for q in report['queues']]
    require(value['queue_receipts'] == expected_queues and bool(expected_queues),'actual queue receipt roster differs')
    for identity in expected_queues:
        queue = cast(Json,json.loads(archive_pin(identity,contents)))
        require(queue['closure_adapter'] == adapter and adapter['adapter'] in queue['pins']
                and adapter['frozen_queue'] in queue['pins'],'queue executed an unbound closure adapter')
        for field,name in (('plan','plan.json'),('config_index','config-index.json'),('prerequisites','prerequisites.json')):
            require(queue['config'][field] == preparation['artifacts'][name],'queue/preparation source tuple differs')
    reference = cast(Json,json.loads(archive_pin(value['reference_closure_gate'],contents)))
    require(reference['outcome'] == 'passed' and reference['finished_utc'] and not reference['error']
            and not reference['traceback'] and reference['engine_executed'] is False
            and reference['adapter'] == adapter['adapter']
            and set(reference['references']) == {'cit-reference01','graph500-reference01'}, 'complete prior full-reference gate differs')
    archive_pin(reference['helper'],contents,REFERENCE_GATE_SHA)
    for observation in reference['references'].values():
        require(observation['outcome'] == 'passed' and observation['full_physical_archive_hashed_before_after'] is True
                and bool(observation['archive']) and bool(observation['reference_artifacts']),'prior full-archive reference observation absent')
    required = value['required_retained_evidence']
    require(len({p['path'] for p in required}) == len(required),'duplicate required retained evidence')
    for identity in required:
        archive_pin(identity,contents)
    for path in (Path(report['base'])/'continuation01/receipt.json',Path(report['base'])/'generated-queues01/preparation.json'):
        identity = next((p for p in required if p['path'] == str(path)),None)
        require(identity is not None,'genuine first preparation/continuation failure absent')
        assert identity is not None
        failed = cast(Json,json.loads(archive_pin(identity,contents)))
        require(failed['outcome'] == 'error' and failed['finished_utc'] and failed['error'],'retained failed attempt misclassified')
    return {'version':value['version'],'adapter_sha256':ADAPTER_SHA,'frozen_queue_sha256':QUEUE_SHA,
            'config_wrapper_sha256':CONFIG_WRAPPER_SHA,'original_predicate_sha256':FUNCTION_SHA,
            'prepared_configuration':value['preparation'],'runtime_source_or_timer_changed':False}


def install(gate: ModuleType,wrapper: ModuleType,gate_path: Path,wrapper_path: Path) -> None:
    old_report = cast(Callable[[Json,Any,dict[str,bytes]],Json],gate.report_gate)
    old_execute = cast(Callable[[Path,str,Any,list[Json],Path],Json],gate.execute)

    def report_gate(report: Json,plan: Any,contents: dict[str,bytes]) -> Json:
        summary = old_report(report,plan,contents)
        summary['host_closure_provenance'] = provenance_gate(report,contents,wrapper)
        require(any(sha(data) == sha(raw(Path(__file__).resolve())) for data in contents.values()), 'actual publication gate source unarchived')
        return summary

    def execute(worktree: Path,commit: str,plan: Any,commands: list[Json],output: Path) -> Json:
        result = old_execute(worktree,commit,plan,commands,output)
        report = cast(Json,json.loads(raw(worktree/gate.DOC/'report.json')))
        receipt = cast(Json,json.loads(raw(worktree/gate.DOC/'generation-receipt.json')))
        require(receipt['host_closure_provenance'] == report['host_closure_provenance'],'generation/report host provenance differs')
        for name in ('README.md','REPORT.md'):
            require(wrapper.DISCLOSURE in raw(worktree/gate.DOC/name).decode(),'generated host adapter disclosure absent')
        require(sha(raw(gate_path)) == FROZEN_GATE_SHA and sha(raw(wrapper_path)) == WRAPPER_SHA,'publication gate source changed')
        result['derivation'] = {'version':'b8-publication-explicit-host-provenance-v2','frozen_gate_sha256':FROZEN_GATE_SHA,
                                'publisher_wrapper_sha256':WRAPPER_SHA,'scope':'additional metadata/source provenance checks; original exact candidate/oracle/ratio/closure gates retained'}
        return result

    gate.__dict__['report_gate'] = report_gate; gate.__dict__['execute'] = execute
    # The original main records the actual derived gate SHA, not the imported predecessor.
    gate.__dict__['__file__'] = str(Path(__file__).resolve())


def main() -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--frozen-gate',type=Path,required=True)
    parser.add_argument('--publisher-wrapper',type=Path,required=True)
    options,remaining = parser.parse_known_args()
    gate = load(options.frozen_gate,FROZEN_GATE_SHA,'b8_frozen_metadata_gate')
    wrapper = load(options.publisher_wrapper,WRAPPER_SHA,'b8_frozen_publication_provenance_wrapper')
    install(gate,wrapper,options.frozen_gate,options.publisher_wrapper)
    sys.argv = [sys.argv[0],*remaining]
    return cast(int,gate.main())


if __name__ == '__main__':
    raise SystemExit(main())
