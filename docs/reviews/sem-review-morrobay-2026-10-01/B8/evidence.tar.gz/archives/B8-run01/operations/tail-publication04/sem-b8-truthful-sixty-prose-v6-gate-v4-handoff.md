# B8 truthful 60/60 disclosure: wrapper v6 and gate v4

Source preparation only; root owns generation04, candidate03, exact gates, commit and push. All previous wrappers/gates/failed candidates and generation artifacts are preserved.

Use the same publication command with colocated `sem-b8-publish-tail-v6.py`, `--publication-gate sem-B8-tail-publication-gate-v4.py`, a fresh destination and namespace, and all prior generation bases retained. The actual gate CLI is unchanged. Keep adapter-v2, models, core and the frozen original publisher/gates/host wrapper colocated.

The sole wrapper subject change replaces the completion sentence with: “60/60 qualification is false; 60/60 attempted calls are false; the protocol completed_with_failures with closed failures and explicit skips retained. B8 DONE denotes protocol completion with failures. The all60_qualified and all60_attempted fields are false.” All JSON, qualification, ratio and archival code stays unchanged.

Gate v4 changes only the wrapper SHA, wrapper basename and own receipt version from v3. Its disclosure predicates, original positive cell/ratio delegation and closed OOM negative checks are unchanged. The original disclosure requirement for the literal `60/60` stays intact.

Repo Ruff, strict mypy and 25 bounded controls passed. The prior 24 test methods remain AST-identical. The new control renders both README and detailed report through the actual frozen publisher, host wrapper and v5/v6 wrapper install paths from pinned finalized JSON metadata. It demonstrates v5 lacks the required marker; v6 changes only the single truthful sentence, keeps every original scope keyword, retains false machine qualification fields, and does not mutate report JSON. No actual publication, package, Git, candidate gate, VM, Docker, engine or payload reads occurred; existing tiny fake package controls remain offline evidence.
