"""Root's short-lived durable launcher; the frozen host owns all execution."""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01')


def main() -> None:
    run, previous = sys.argv[1:]
    assert re.fullmatch(r'tiny-(adjacency|representatives|min-label-initial-round)-(union|array-explode)01', run)
    prior = json.loads((BASE / previous / 'result.json').read_text())
    assert prior['outcome'] == prior['producer_outcome'] == 'passed'
    assert prior['certain_container_closure'] and not prior['lock_retained'] and not prior['error']
    assert not (BASE.parent / 'gate.lock').exists() and not (BASE.parent / 'serial-queue.lock').exists()
    assert not (BASE / run).exists()
    driver = BASE / 'controller-profile/run_shapes_host.py'
    assert hashlib.sha256(driver.read_bytes()).hexdigest() == 'ab2c33497e31df9b1f0010be78446df4eb936f09af4235264b6bb421e2f28e98'
    config = BASE / 'generated-tiny01' / (run + '.json')
    command = [sys.executable, '-B', str(driver), 'run', '--campaign', str(BASE / 'campaign.json'),
               '--run-id', run, '--kind', 'cell', '--config', str(config)]
    with (BASE / (run + '.host.log')).open('xb') as log:
        child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    receipt = {'observed_utc': datetime.now(timezone.utc).isoformat(), 'pid': child.pid,
               'command': command, 'previous_closed_host': previous,
               'config_sha256': hashlib.sha256(config.read_bytes()).hexdigest()}
    with (BASE / (run + '.launch.json')).open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
