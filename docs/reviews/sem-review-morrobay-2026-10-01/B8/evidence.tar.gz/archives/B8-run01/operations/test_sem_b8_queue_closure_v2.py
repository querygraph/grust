"""Actual small-metadata and bounded archive controls; no engine/config generation."""
from __future__ import annotations

import copy
import importlib.util
import json
import pathlib
import sys
import tempfile
import unittest
from types import ModuleType
from typing import Any
from unittest import mock


def load(path: str, name: str) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


ADAPTER = load('/tmp/sem-b8-queue-closure-adapter-v2.py', 'b8_closure_v2_controls')
WRAPPER = load('/tmp/sem-b8-configs-closure-v2.py', 'b8_generator_v2_controls')
FROZEN: ModuleType = ADAPTER.frozen
ORIGINAL_RECEIPT = ADAPTER.AdapterReceipt.__bases__[0]
BASE: pathlib.Path = ADAPTER.BASE
Json = dict[str, Any]


def configuration() -> Any:
    generated = BASE / 'generated-queues01'
    return FROZEN.QueueConfig(
        host_root=BASE, output=BASE/'offline-control-not-executed', python=pathlib.Path(sys.executable),
        driver=FROZEN.pin(BASE/'controller-profile/run_shapes_host.py'), campaign=FROZEN.pin(BASE/'campaign.json'),
        plan=FROZEN.pin(generated/'plan.json'), config_index=FROZEN.pin(generated/'config-index.json'),
        prerequisites=FROZEN.pin(generated/'prerequisites.json'), support_manifest=FROZEN.pin(BASE/'support/support-manifest.json'))


def campaign() -> Any:
    return ADAPTER.host_contract.Campaign.model_validate(FROZEN.read(BASE/'campaign.json'))


def pair(name: str = 'cit-reference01') -> tuple[Json, Json]:
    directory = BASE/name
    return FROZEN.read(directory/'result.json'), FROZEN.read(directory/'container-record.json')


class Controls(unittest.TestCase):
    def setUp(self) -> None:
        ADAPTER.__dict__['AUTHORIZED'] = None
        FROZEN.__dict__['audited_archive'] = ADAPTER.ORIGINAL_ARCHIVE
        FROZEN.__dict__['Receipt'] = ORIGINAL_RECEIPT

    def tearDown(self) -> None:
        self.setUp()

    def test_original_refuses_actual_both_reference_records(self) -> None:
        for name in ('cit-reference01', 'graph500-reference01'):
            with self.subTest(name=name), mock.patch.object(FROZEN, 'physical_archive') as physical:
                with self.assertRaisesRegex(ValueError, 'embedded/separate container records differ'):
                    ADAPTER.ORIGINAL_ARCHIVE(BASE/name, name, 'reference', configuration(), campaign())
                physical.assert_not_called()

    def test_new_accepts_actual_reference_metadata_and_delegates_archive(self) -> None:
        ADAPTER.copied_predicate_guard()
        for name in ('cit-reference01', 'graph500-reference01'):
            directory = BASE/name
            host, _record = pair(name)
            archive = FROZEN.read(directory/'collected-manifest.json')
            with self.subTest(name=name), mock.patch.object(FROZEN, 'physical_archive', return_value=archive) as physical:
                observed, full, _spec = ADAPTER.audited_archive_v2(directory, name, 'reference', configuration(), campaign())
                self.assertEqual(observed, host)
                self.assertEqual(full, archive)
                physical.assert_called_once_with(directory, host)

    def test_authoritative_embedded_absence_required_and_exact(self) -> None:
        host, separate = pair()
        self.assertNotIn('absence_verified', separate)
        ADAPTER.record_binding(host, separate)
        for failure in ('missing', 'returncode', 'stderr'):
            bad = copy.deepcopy(host)
            embedded = bad['records']['container']
            if failure == 'missing':
                del embedded['absence_verified']
            elif failure == 'returncode':
                embedded['absence_verified']['returncode'] = 0
            else:
                embedded['absence_verified']['stderr'] = 'some unrelated no such file'
            with self.subTest(failure=failure), self.assertRaises(ValueError):
                ADAPTER.record_binding(bad, separate)
        included = {**separate, 'absence_verified': host['records']['container']['absence_verified']}
        ADAPTER.record_binding(host, included)
        included['absence_verified'] = {'returncode': 1, 'stderr': 'no such object: wrong', 'stdout': ''}
        with self.assertRaisesRegex(ValueError, 'separate absence differs'):
            ADAPTER.record_binding(host, included)

    def test_changed_other_record_or_failed_both_remove_refused(self) -> None:
        host, separate = pair()
        for field in ('remove', 'inspect'):
            bad = copy.deepcopy(host)
            if field == 'remove':
                bad['records']['container']['remove']['returncode'] = 1
            else:
                bad['records']['container']['inspect']['state']['OOMKilled'] = True
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, 'outside absence_verified'):
                ADAPTER.record_binding(bad, separate)
        bad, record = copy.deepcopy(host), copy.deepcopy(separate)
        bad['records']['container']['remove']['returncode'] = record['remove']['returncode'] = 1
        embedded = ADAPTER.record_binding(bad, record)
        with self.assertRaises(ValueError):
            FROZEN.closed_container(embedded)

    def test_complete_physical_archive_hashing_and_changes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = pathlib.Path(temporary)
            artifacts = directory/'container/artifacts'
            artifacts.mkdir(parents=True)
            payload = artifacts/'tiny.i64le'
            payload.write_bytes(bytes(range(16)))
            guest = {'schema_version': 1, 'files': ADAPTER.host_contract.collected_inventory(artifacts)}
            (artifacts/'archive-manifest.json').write_text(json.dumps(guest))
            inventory = ADAPTER.host_contract.collected_inventory(artifacts)
            (directory/'collected-manifest.json').write_text(json.dumps(inventory))
            host = {'artifacts': inventory}
            self.assertEqual(FROZEN.physical_archive(directory, host), inventory)
            payload.write_bytes(b'x'*16)
            with self.assertRaisesRegex(ValueError, 'complete raw archive hash/set binding'):
                FROZEN.physical_archive(directory, host)
            payload.write_bytes(bytes(range(16)))
            (artifacts/'unexpected').write_bytes(b'x')
            with self.assertRaises(ValueError):
                FROZEN.physical_archive(directory, host)

    def test_receipt_pins_adapter_and_original_queue(self) -> None:
        pin = FROZEN.pin(pathlib.Path(str(ADAPTER.__file__)).resolve())
        ADAPTER.install(FROZEN, pin.sha256)
        receipt = FROZEN.Receipt(config=configuration(), dataset='cit-Patents', owner_pid=1, token='offline',
                                 started_utc=FROZEN.utc(), observed_utc=FROZEN.utc())
        self.assertIn(pin, receipt.pins)
        self.assertIn(FROZEN.pin(pathlib.Path(str(FROZEN.__file__)).resolve()), receipt.pins)
        self.assertEqual(receipt.closure_adapter.version, ADAPTER.VERSION)
        FROZEN.verify_pins(receipt)
        receipt.pins[0] = pin.model_copy(update={'sha256': '0'*64})
        with self.assertRaises(ValueError):
            FROZEN.verify_pins(receipt)

    def test_wrong_adapter_pin_and_preserved_predicates(self) -> None:
        with self.assertRaisesRegex(ValueError, 'authorized host closure adapter SHA'):
            ADAPTER.install(FROZEN, '0'*64)
        ADAPTER.copied_predicate_guard()
        with mock.patch.object(ADAPTER.inspect, 'getsource', return_value='def changed():\n    pass\n'), self.assertRaisesRegex(ValueError, 'original archived validator function SHA'):
            ADAPTER.copied_predicate_guard()

    def test_generator_delegates_loader_and_records_adapter(self) -> None:
        original = WRAPPER.module(pathlib.Path('/tmp/sem-b8-configs.py'), 'frozen_generator_offline_control', WRAPPER.GENERATOR_SHA)
        adapter_path = pathlib.Path(str(ADAPTER.__file__)).resolve()
        options = WRAPPER.Options(frozen_generator=pathlib.Path('/tmp/sem-b8-configs.py'), adapter=adapter_path,
                                  adapter_sha256=FROZEN.pin(adapter_path).sha256)
        with mock.patch.object(original, 'load_queue', return_value=FROZEN) as delegated:
            WRAPPER.install_generator(original, options)
            argument = object()
            queue = original.load_queue(argument)
            delegated.assert_called_once_with(argument)
        self.assertIs(queue, FROZEN)
        input_options = original.Options(action='queues', output=BASE/'offline-no-output',
            driver_sha256=FROZEN.DRIVER_SHA, queue_sha256=ADAPTER.QUEUE_SHA)
        receipt = original.Preparation(options=input_options, started_utc=FROZEN.utc(), source_sha256=WRAPPER.GENERATOR_SHA)
        self.assertEqual(receipt.closure_adapter.version, ADAPTER.VERSION)
        self.assertEqual(receipt.generator_wrapper.sha256, WRAPPER.pin(pathlib.Path(str(WRAPPER.__file__)).resolve()).sha256)


if __name__ == '__main__':
    unittest.main()
