# Post-receipt B8 config generator

`/tmp/sem-b8-configs.py` is preparation source only. It has not generated
configs, inspected a guest, executed Docker/engines, or changed the profile.
Root invokes it only after the exact committed profile and required receipts
exist. Static gates cover this source, not an actual prerequisite run.

Every invocation requires `--driver-sha256` and `--queue-sha256`. Before importing
the queue's actual Pydantic models/API, it checks every staged support helper,
both exact host driver/queue copies, and their manifest bindings. Module
origins must resolve to that profile's support. No working-tree helper is used.

All actions require `--output <BASE>/generated-<fresh-id>` directly under
`BASE=/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01`. Reuse is
refused. `preparation.json` and the source bytes are retained, including failure;
there is no retry, cleanup, gate-lock manipulation or queue execution.

## Actions

| Action | Inputs required | Files prepared |
|---|---|---|
| `reference --dataset cit-Patents` | Retained A2-run04 exact original v/e pins | Cit reference config, borrowing historical guest Parquet |
| `reference --dataset graph500-24` | Actual completed download plus closed owned data-stage receipts | Graph500 reference config pinned to actual bodies |
| `tiny` | Closed `tiny-reference01` and original tiny host FilePins | Six shape/variant cell configs |
| `queues` | Stage, both closed full references, six closed tiny controls, independent dataset evidence | All60 configs, plan, config index, prerequisites, two queue configs and metadata-only prerequisite audits |

Default prerequisite IDs are `stage01`, `cit-reference01`,
`graph500-reference01`, `tiny-reference01`, and `data-stage01`; CLI flags allow
explicit alternative IDs. Tiny controls have exact generated IDs
`tiny-<shape>-<variant>01`. The host driver still enforces fresh guest config and
output names. References and every cell must use the original profile tuple.

Cit borrows `/targets/sail-stream-experiments-20260930/sem-wcc-pilot-inputs/`
`cit-Patents-v.parquet` and `cit-Patents-e.parquet`. The contract retains the
A2-run04 validation04 producer receipt as a FilePin and checks known original
SHA256/bytes plus actual recorded counts V=3,774,768/E=16,518,947. It does not
copy, re-read or infer those originals. Graph500's evidence is the completed
`downloads/graph500-24/download-receipt.json`: official URL map, actual body
SHA256/bytes and footer V/E/R. HEAD metadata cannot satisfy that contract.

Tiny cell configs use the actual closed tiny reference receipt SHA256, retain
the `tiny-signed-highbit` dataset label, and require exact original host file
identities/counts. The queue's own bounded inspection records the signed/highbit
IDs, duplicate edges, loops and isolate from those small original files only.

The generator uses the queue's actual `build_plan()`, `HostProof`, `TinyProof`,
`DatasetContract`, `Prerequisites`, `ConfigIndex` and `QueueConfig` models.
It constructs both independent dataset contracts and pins all60 configs before
either dataset queue launches. It invokes only `prerequisite_audits()`, which
reads and checks already closed metadata/evidence; no `prepare()`/`execute()` or
spawn API is called. Both full references and all six tiny controls must pass
these audits before preparation is marked complete.

Per-cell engine timeout is explicitly 1500 s, the existing declared default;
whole host cell deadline is the campaign's 3600 s. Reference deadline7200 s and
copy deadline1800 s stay in the campaign. Every cell declares64GiB guest free;
the campaign declares120GiB Apo free. These are bounds to admit/refuse, not
observed runtime or memory claims.

Root must review the actual helper/profile/source hashes and generated pins,
then launch the queue from the committed profile with `PYTHONPATH=<BASE>/support`
and the exact generated queue JSON: cit-Patents first, Graph500-24 next.
Actual generation and integrated prerequisites remain unqualified until then.
