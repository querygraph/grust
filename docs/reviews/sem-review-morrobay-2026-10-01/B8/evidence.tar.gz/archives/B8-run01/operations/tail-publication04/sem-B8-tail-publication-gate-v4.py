"""Exact detached publication gate for a finalized B8 tail with retained failures."""
from __future__ import annotations

import ast
import copy
import gzip
import hashlib
import re
import subprocess
import tarfile
from collections.abc import Callable
from dataclasses import dataclass
from io import BufferedIOBase
from pathlib import Path, PurePosixPath
from types import ModuleType, SimpleNamespace
from typing import Any, cast

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_publication_models_v2 as schema
import sem_b8_tail_publication_v2 as adapter

WRAPPER_SHA = 'f9c85a8b262d1dd645b1f9547b6a7da7b7a3c8893fc32c6328fa43a5c8b4f390'
ADAPTER_SHA = 'c66b8f3a226459e659327585a279f8e48ba08a44e8476597d76d04425b5cbf03'


@dataclass(slots=True)
class TarInput:
    stream: gzip.GzipFile
    deadline: core.Deadline

    def read(self, size: int) -> bytes:
        self.deadline.check()
        core.require(0 <= size <= adapter.LIMIT, 'bounded tar metadata/header read required')
        data = self.stream.read(size)
        self.deadline.check()
        return data

    def tell(self) -> int:
        return self.stream.tell()

    def seek(self, offset: int, whence: int = 0) -> int:
        self.deadline.check()
        core.require(offset >= 0 and whence == 0, 'absolute forward metadata tar position required')
        position = self.stream.seek(offset,whence)
        self.deadline.check()
        return position


class ArchivedIO:
    def __init__(self, contents: dict[str,bytes], deadline: core.Deadline) -> None:
        self.contents = contents
        self.deadline = deadline

    def read(self, path: Path) -> bytes:
        self.deadline.check()
        core.require(path.is_absolute() and path.suffix in adapter.ALLOWED and str(path) in self.contents,
                     'indexed archived metadata path required')
        data = self.contents[str(path)]
        core.require(len(data) <= adapter.LIMIT, 'indexed metadata file too large')
        return data

    def pin(self, path: Path) -> models.FilePin:
        data = self.read(path)
        return models.FilePin(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

    def exists(self, path: Path) -> bool:
        self.deadline.check()
        prefix = str(path)
        return prefix in self.contents or any(p.startswith(prefix+'/') for p in self.contents)


def archive_gate(doc: Path, index: models.Json, io_state: adapter.IO) -> tuple[dict[str,bytes],dict[str,models.Json]]:
    outer = io_state.archive_pin(doc/'evidence.tar.gz')
    core.require(outer.bytes == index['archive_bytes'] and outer.sha256 == index['archive_sha256'], 'outer archive differs')
    expected: dict[str,models.Json] = {}
    for row in index['members']:
        io_state.deadline.check()
        name = PurePosixPath(row['member'])
        core.require(bool(str(name)) and not name.is_absolute() and str(name) == row['member']
                     and all(p not in ('.','..') for p in name.parts) and str(name) not in expected,
                     'unsafe/duplicate indexed metadata member')
        expected[str(name)] = row
    core.require(0 < len(expected) <= 100000, 'bounded indexed metadata member count')
    contents: dict[str,bytes] = {}
    sources: dict[str,models.Json] = {}
    seen: set[str] = set()
    with gzip.GzipFile(filename=str(doc/'evidence.tar.gz'),mode='rb') as compressed, \
            tarfile.open(fileobj=cast(BufferedIOBase,TarInput(compressed,io_state.deadline)),mode='r:') as archive:
        for info in archive:
            io_state.deadline.check()
            name = PurePosixPath(info.name)
            core.require(info.isfile() and info.name in expected and info.name not in seen
                         and not name.is_absolute() and '..' not in name.parts
                         and (name.suffix in adapter.ALLOWED or name.name in {'ARTIFACTS.sha256','SHA256SUMS'})
                         and not any(p in adapter.EXCLUDED for p in name.parts)
                         and info.size <= adapter.LIMIT, 'unsafe/unindexed/physical archive member')
            row = expected[info.name]
            stream = archive.extractfile(info)
            core.require(stream is not None, 'unreadable metadata member')
            assert stream is not None
            chunks: list[bytes] = []
            total = 0
            with stream:
                while part := stream.read(adapter.CHUNK):
                    io_state.deadline.check()
                    total += len(part)
                    core.require(total <= adapter.LIMIT, 'member decompressed past metadata limit')
                    chunks.append(part)
            data = b''.join(chunks)
            core.require(len(data) == info.size == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'],
                         'indexed member bytes/SHA differ')
            source = row['retained_source']
            core.require(source not in sources and Path(source).is_absolute(), 'duplicate/relative retained source')
            contents[source],sources[source] = data,row
            seen.add(info.name)
    core.require(seen == set(expected) and any(r['member'].startswith('tools/') and r['sha256'] == adapter.PUBLISHER
                     for r in sources.values()), 'archive roster or original frozen publisher differs')
    report = adapter.decode(io_state.read(doc/'report.json'))
    value = schema.TailProvenance.model_validate(report['tail_publication_provenance'])
    declared: dict[Path,models.FilePin] = {}
    for pin in value.immutable_helper_sources:
        if pin.path.suffix not in adapter.ALLOWED:
            core.require(pin.path not in declared or declared[pin.path] == pin,
                         'inconsistent declared physical source identity')
            declared[pin.path] = pin
    core.require(index['declared_physical_tools_not_read'] == [declared[p].model_dump(mode='json') for p in sorted(declared)]
                 and not any(str(p) in contents for p in declared),
                 'declared physical tool pins were omitted, changed or packaged')
    io_state.deadline.check()
    return contents,sources


def tail_evidence(report: models.Json, contents: dict[str,bytes], wrapper: ModuleType,
                  deadline: core.Deadline) -> schema.TailProvenance:
    value = schema.TailProvenance.model_validate(report['tail_publication_provenance'])
    archived = ArchivedIO(contents,deadline)
    read = archived.read
    source_fields = ((value.frozen_publisher,adapter.PUBLISHER),(value.frozen_host_wrapper,adapter.HOST_WRAPPER),
        (value.frozen_gate,adapter.GATE),(value.frozen_host_gate,adapter.HOST_GATE),
        (value.publication_models,adapter.PUB_MODELS),(value.publisher_wrapper,WRAPPER_SHA),
        (value.publication_adapter,ADAPTER_SHA))
    for pin,expected in source_fields:
        core.require(pin.sha256 == expected, 'publication source identity differs')
        adapter.checked(pin,read)
    own = Path(__file__).resolve()
    core.require(value.publication_gate.sha256 == hashlib.sha256(adapter.IO(deadline).read(own)).hexdigest(),
                 'actual tail publication gate source differs')
    adapter.checked(value.publication_gate,read)
    prepared,tail,projection,cells = adapter.project_tail(value.prepared,value.authorization,value.tail_queue,read,
        Path(report['base']),archived.exists)
    core.require(value.queue_projection == projection and value.cell_projection == cells
                 and value.original_plan == prepared.original_plan and value.derived_plan == prepared.derived_plan
                 and value.original_cit_receipt == prepared.original_cit_queue_receipt
                 and value.original_graph_receipt == prepared.original_graph_queue_receipt
                 and value.original_continuation_receipt == prepared.original_continuation_receipt
                 and value.original_oom_closure == prepared.original_oom_closure,
                 'declared projection or preserved original evidence differs')
    # This reconstructs exact recorded metadata bindings using archive bytes only.
    options = wrapper.Options(base=Path(report['base']),dest=Path('/metadata-only-gate-no-output'),
        frozen_publisher=value.frozen_publisher.path,frozen_host_wrapper=value.frozen_host_wrapper.path,
        frozen_gate=value.frozen_gate.path,frozen_host_gate=value.frozen_host_gate.path,
        publication_gate=value.publication_gate.path,host_preparation=Path(report['host_closure_provenance']['preparation']['path']),
        reference_closure_gate=Path(report['host_closure_provenance']['reference_closure_gate']['path']),
        prepared=value.prepared.path,preparation_attempt=value.preparation_attempt.path,authorization=value.authorization.path,
        root_review=value.root_authorization_review.path,tail_receipt=value.tail_queue.path,preservation=value.original_lock_preservation.path)
    owner = wrapper.root_proof(options,prepared,tail,archived)
    core.require(owner == value.preserved_serial_owner, 'final owned serial archive bytes differ')
    for identity in value.immutable_helper_sources:
        if identity.path.suffix in adapter.ALLOWED:
            adapter.checked(identity,read)
    expected_functions = [('qualify_cell',value.frozen_publisher),('contrast',value.frozen_publisher),
                          ('cell',value.frozen_gate),('ratios',value.frozen_gate),('report_gate',value.frozen_gate),('execute',value.frozen_gate)]
    functions = [adapter.function_pin(source,name,read) for name,source in expected_functions]
    core.require(value.frozen_predicates == functions, 'original positive predicate function body pins differ')
    core.require(report['all60_qualified'] is report['all60_attempted'] is False
                 and report['protocol_finished_terminal_evidence'] is True
                 and report['protocol_outcome'] == 'completed_with_failures'
                 and report['eligible_final_DONE'] is False and report['attempted_cells']+report['skipped_cells'] == 60,
                 'protocol completion conflated with successful qualification/attempts')
    rows = report['cells']
    skipped = sum(isinstance(c,schema.SkippedProjection) for c in cells)
    core.require(report['attempted_cells'] == 60-skipped and report['skipped_cells'] == skipped
                 and skipped >= 8 and len(rows) == 60 and rows[30]['qualified'] is False and rows[30]['status'] == 'failed',
                 'original OOM/actual attempt/skip counts differ')
    for row,mapping in zip(rows[31:],cells,strict=True):
        core.require(row['step'] == mapping.mapping.actual.model_dump(mode='json')
                     and row['original_step'] == mapping.mapping.original.model_dump(mode='json')
                     and row['tail_projection'] == mapping.model_dump(mode='json'), 'row projection or original ID differs')
        if isinstance(mapping,schema.SkippedProjection):
            core.require(row == wrapper.skipped_row(row['step'],mapping), 'skip fabricated diagnostic/launch fields')
            core.require(not archived.exists(Path(report['base'])/mapping.mapping.actual.run_id)
                         and not archived.exists(Path(report['base'])/(mapping.mapping.actual.run_id+'.host.log')),
                         'skipped alias has archived host/log evidence')
        else:
            core.require(row['qualified'] == mapping.qualified
                         and row['evidence']['host'] == {**mapping.raw_host_receipt.model_dump(mode='json'),'error':None},
                         'attempted actual host evidence or qualification differs')
    for row,payload in zip(rows,report['physical_payloads'],strict=True):
        if row['status'] == 'not_started_due_to_failed_warmup':
            core.require(payload['apo_collected_manifest'] is None and payload['declared_result_files'] is None
                         and payload['scope'] == 'Warmup-policy skip: no process, physical payload or collected manifest was created.',
                         'skip fabricated a physical payload/manifest link')
    core.require(report['native_quota_observation'] == {'configured_bytes':268435456,'actual_reservation_observed':False,
        'actual_prepayment_observed':False,'scope':'Configured quota only; actual reservation/prepayment events unobserved.'},
        'native configured quota incorrectly claimed observed')
    return value


def completion_log(report: models.Json, append: bytes) -> None:
    matches = list(re.finditer(rb'\b(?:DONE\s+B8|B8\s+DONE)\b',append))
    if not matches:
        return
    core.require(report['protocol_finished_terminal_evidence'] is True and report['protocol_outcome'] == 'completed_with_failures'
                 and report['all60_qualified'] is report['all60_attempted'] is False, 'unqualified completion log scope')
    for match in matches:
        core.require(append[match.end():].startswith(b' (protocol completed with failures)'), 'unscoped B8 DONE claim')
    text = append.decode()
    withheld = sum(c['ratio_status'] == 'withheld' for c in report['contrasts'])
    for scope in (f"{report['qualified_cells']}/60 qualified",f"{report['attempted_cells']}/60 attempted",
                  f"{report['skipped_cells']} skipped",f'{withheld} ratios withheld'):
        core.require(scope in text, 'completion log missing exact count/withheld ratio scope: '+scope)


class CompletionGuard(ast.NodeTransformer):
    def __init__(self) -> None:
        self.changed = 0

    def visit_If(self, node: ast.If) -> ast.AST:
        if ast.unparse(node.test) == "not report['eligible_final_DONE']":
            core.require(len(node.body) == 1 and not node.orelse
                         and 'partial evidence claims final DONE' in ast.unparse(node.body[0]), 'original log guard changed')
            self.changed += 1
            node.body = ast.parse('tail_completion_log(report, current[len(parent):])').body
            return node
        return self.generic_visit(node)


def nullable_oracle_outcome(docs: models.Json) -> Any:
    oracle = docs.get('producer',{}).get('correctness')
    core.require(oracle is None or isinstance(oracle,dict), 'unknown raw nullable oracle shape')
    return None if oracle is None else oracle.get('outcome')


def frozen_negative_cell(gate: ModuleType, source: bytes) -> Callable[[models.Json,list[models.Json],dict[str,bytes]],None]:
    """Retain every original negative predicate; handle exactly the nullable oracle expression."""
    parsed = ast.parse(source)
    nodes = [n for n in parsed.body if isinstance(n,ast.FunctionDef) and n.name == 'cell']
    core.require(len(nodes) == 1, 'unique frozen cell body required')
    node = copy.deepcopy(nodes[0])
    guards = [(i,n) for i,n in enumerate(node.body) if isinstance(n,ast.If)
              and ast.unparse(n.test) == "not row['qualified']"]
    core.require(len(guards) == 1 and not guards[0][1].orelse
                 and isinstance(guards[0][1].body[-1],ast.Return), 'original negative cell guard changed')
    # The positive body is never compiled into this negative-only delegate.
    node.body = node.body[:guards[0][0]+1]
    outcomes = [n for n in node.body if isinstance(n,ast.Assign)
                and len(n.targets) == 1 and isinstance(n.targets[0],ast.Name)
                and n.targets[0].id == 'expected_outcomes']
    core.require(len(outcomes) == 1 and isinstance(outcomes[0].value,ast.Dict),
                 'original raw outcome declaration changed')
    original = outcomes[0].value
    assert isinstance(original,ast.Dict)
    oracle_slots = [i for i,k in enumerate(original.keys) if isinstance(k,ast.Constant) and k.value == 'oracle']
    core.require(len(oracle_slots) == 1 and ast.unparse(original.values[oracle_slots[0]])
                 == "docs.get('producer', {}).get('correctness', {}).get('outcome')",
                 'original nullable oracle expression changed')
    original.values[oracle_slots[0]] = ast.parse('nullable_oracle_outcome(docs)',mode='eval').body
    node.name = 'frozen_closed_oom_negative_cell'
    tree = ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]))
    gate.__dict__['nullable_oracle_outcome'] = nullable_oracle_outcome
    exec(compile(tree,'<frozen-B8-negative-cell-with-nullable-oracle>','exec'),gate.__dict__)  # noqa: S102
    return cast(Callable[[models.Json,list[models.Json],dict[str,bytes]],None],
                gate.__dict__['frozen_closed_oom_negative_cell'])


@dataclass(frozen=True,slots=True)
class ClosedOOMBinding:
    closure: models.FilePin
    configuration: models.FilePin
    gate_archive: Path | None


def closed_oom_binding(row: models.Json, value: schema.TailProvenance, read: adapter.Reader) -> ClosedOOMBinding:
    prepared = models.Prepared.model_validate(adapter.json_pin(value.prepared,read))
    step = row['step']
    if step == prepared.original_failed_step.model_dump(mode='json'):
        config = schema.NativeQueueConfig.model_validate(adapter.json_pin(prepared.original_queue_config,read))
        pin = models.FilePin.model_validate(adapter.json_pin(config.config_index,read)['files'][step['run_id']])
        core.require(prepared.original_oom_closure == value.original_oom_closure,
                     'original named OOM closure differs')
        return ClosedOOMBinding(value.original_oom_closure,pin,None)
    selected = [p for p in value.cell_projection if isinstance(p,schema.AttemptedProjection)
                and p.mapping.actual.model_dump(mode='json') == step]
    core.require(len(selected) == 1 and selected[0].disposition == 'closed_oom'
                 and selected[0].qualified is False, 'unreviewed failure outside exact named closed OOM scope')
    projection = selected[0]
    core.require(projection.failure_closure is not None and projection.archived_failure_gate_owner is not None
                 and row['tail_projection'] == projection.model_dump(mode='json'), 'failed tail closure projection differs')
    assert projection.failure_closure is not None and projection.archived_failure_gate_owner is not None
    return ClosedOOMBinding(projection.failure_closure,projection.mapping.actual_config,
                            projection.archived_failure_gate_owner.path.parent)


def closed_oom_cell(row: models.Json, queues: list[models.Json], contents: dict[str,bytes],
                    value: schema.TailProvenance, deadline: core.Deadline,
                    negative: Callable[[models.Json,list[models.Json],dict[str,bytes]],None]) -> None:
    core.require(row['qualified'] is False and row['status'] == 'failed'
                 and row['step']['dataset'] == 'graph500-24' and row['step']['role'] == 'warmup',
                 'only named unqualified Graph warmup OOM may use nullable negative branch')
    read = ArchivedIO(contents,deadline).read
    binding = closed_oom_binding(row,value,read)
    # All original raw evidence/outcome/status/reason/live-host predicates run first.
    negative(row,queues,contents)
    core.require(set(row['evidence']) == {'host','producer','container','configuration','bootstrap','engine',
                                        'guest_manifest','collected_manifest'}, 'closed OOM raw evidence roster differs')
    docs = {name:adapter.json_pin(models.FilePin.model_validate({k:ev[k] for k in ('path','bytes','sha256')}),read)
            for name,ev in row['evidence'].items()}
    core.require(row['outcomes'] == {'host':'error','producer':'oom','engine':'error','oracle':None}
                 and docs['producer']['correctness'] is None and row['correctness'] is None,
                 'closed OOM raw oracle/outcomes misclassified')
    config = adapter.json_pin(binding.configuration,read)
    configured = adapter.decode(docs['configuration']['specification']['config_text'].encode())
    for record in (config,configured):
        record.setdefault('timeout_seconds',1500)
        record.setdefault('minimum_free_bytes',24*2**30)
    core.require(config == configured == docs['producer']['config']
                 and all(config[k] == row['step'][k] for k in ('dataset','shape','variant'))
                 and docs['configuration']['specification']['config_sha256'] == binding.configuration.sha256
                 and docs['bootstrap']['config_sha256'] == binding.configuration.sha256,
                 'closed OOM exact dataset/configuration binding differs')
    adapter.closure_evidence(binding.closure,read,value.tail_queue.path.parent.parent,
        row['step']['run_id'],binding.configuration,binding.gate_archive)
    producer = docs['producer']; collected = docs['collected_manifest']; guest = docs['guest_manifest']
    core.require(producer['identities_before'] == producer['identities_after']
                 and producer['identities_before']['controller'] == 'f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a'
                 and docs['engine']['controller_pin'] == 'f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a'
                 and docs['engine']['runtime_pin'] == '56194b170155301ba91077f0ba3df31fe2c78b6b'
                 and docs['engine']['native_pin'] == 'ffcfbd5690e3f3681ef9ac18ba959bc231cf9f73'
                 and collected == docs['host']['artifacts']
                 and {k:v for k,v in collected.items() if k != 'archive-manifest.json'} == guest['files']
                 and collected['archive-manifest.json'] == {k:row['evidence']['guest_manifest'][k] for k in ('bytes','sha256')},
                 'closed OOM source/raw collection manifest binding differs')


def install(gate: ModuleType, host_gate: ModuleType, old_host: ModuleType, wrapper: ModuleType,
            io_state: adapter.IO) -> None:
    original_evidence = cast(Callable[[models.Json,dict[str,bytes],bool],models.Json | None],gate.evidence)
    original_cell = cast(Callable[[models.Json,list[models.Json],dict[str,bytes]],None],gate.cell)
    original_report = cast(Callable[[models.Json,Any,dict[str,bytes]],models.Json],gate.report_gate)
    source = io_state.read(Path(cast(str,gate.__file__)))
    negative = frozen_negative_cell(gate,source)
    context: dict[str,Any] = {}

    def evidence(row: models.Json, contents: dict[str,bytes], optional: bool = False) -> models.Json | None:
        actual = original_evidence(row,contents,optional)
        value: schema.TailProvenance | None = context.get('value')
        if value is not None and row['path'] == str(value.tail_queue.path):
            core.require(actual == adapter.json_pin(value.tail_queue,ArchivedIO(contents,io_state.deadline).read),
                         'raw tail receipt evidence differs before projection')
            return value.queue_projection.model_dump(mode='json')
        return actual

    def cell(row: models.Json, queues: list[models.Json], contents: dict[str,bytes]) -> None:
        if row['status'] == 'not_started_due_to_failed_warmup':
            # The entire exact skip row and alias absence were checked above.
            core.require(not row['qualified'] and not row['evidence'], 'skip qualified or fabricated raw evidence')
            return
        if not row['qualified']:
            value: schema.TailProvenance | None = context.get('value')
            core.require(value is not None, 'closed OOM lacks finalized tail provenance')
            assert value is not None
            closed_oom_cell(row,queues,contents,value,io_state.deadline,negative)
            return
        # Preserve the original failed Graph queue as evidence. Its historical
        # reference is excluded only when selecting the one actual tail queue
        # for a qualified Graph cell. The positive cell body remains unchanged.
        selected = queues
        if row['qualified'] and row['step']['dataset'] == 'graph500-24':
            selected = [q for q in queues if q['dataset'] != 'graph500-24' or q.get('version') == 'b8-tail-in-memory-qualification-view-v1']
        original_cell(row,selected,contents)

    def report_gate(report: models.Json, plan: Any, contents: dict[str,bytes]) -> models.Json:
        value = tail_evidence(report,contents,wrapper,io_state.deadline)
        context['value'] = value
        core.require(plan.require_complete is False, 'tail gate must explicitly allow nonqualified evidence')
        summary = original_report(report,plan,contents)
        historical = copy.deepcopy(report)
        historical['plan_evidence'] = {**value.original_plan.model_dump(mode='json'),'error':None}
        originals = {str(value.original_cit_receipt.path),str(value.original_graph_receipt.path)}
        historical['queues'] = [q for q in report['queues'] if q['evidence']['path'] in originals]
        core.require(len(historical['queues']) == 2 and len(report['queues']) == 3,
                     'original plus tail raw queue roster differs')
        summary['host_closure_provenance'] = host_gate.provenance_gate(historical,contents,old_host)
        summary['tail_protocol'] = {'outcome':'completed_with_failures','protocol_finished_terminal_evidence':True,
            'all60_qualified':False,'all60_attempted':False,'attempted':report['attempted_cells'],'skipped':report['skipped_cells']}
        context['report'] = report
        return summary

    parsed = ast.parse(source)
    nodes = [n for n in parsed.body if isinstance(n,ast.FunctionDef) and n.name == 'execute']
    core.require(len(nodes) == 1, 'unique original execute body required')
    before = copy.deepcopy(nodes[0])
    transformer = CompletionGuard()
    changed = transformer.visit(copy.deepcopy(before))
    core.require(transformer.changed == 1, 'exactly one scoped coordination completion guard change')
    tree = ast.fix_missing_locations(ast.Module(body=[cast(ast.stmt,changed)],type_ignores=[]))
    gate.__dict__.update(tail_completion_log=completion_log,raw=io_state.read,
        pin_file=lambda path:gate.Pin(bytes=(p:=io_state.archive_pin(path)).bytes,sha256=p.sha256),
        archive_gate=lambda doc,index:archive_gate(doc,index,io_state),evidence=evidence,cell=cell,report_gate=report_gate)
    # Bound subprocess lookups without changing command/result/return-code semantics.
    def bounded_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[Any]:
        checked = kwargs.pop('check',False)
        return subprocess.run(*args,check=checked,**{**kwargs,'timeout':io_state.deadline.remaining()})

    gate.__dict__['subprocess'] = SimpleNamespace(run=bounded_run,SubprocessError=subprocess.SubprocessError)
    # Compile only the exact hash-pinned original function with the one guarded
    # log statement replaced; no untrusted archive string is executed.
    exec(compile(tree,'<frozen-B8-execute-with-scoped-completion-guard>','exec'),gate.__dict__)  # noqa: S102
    derived_execute = cast(Callable[[Path,str,Any,list[models.Json],Path],models.Json],gate.execute)

    def execute(worktree: Path, commit: str, plan: Any, commands: list[models.Json], output: Path) -> models.Json:
        result = derived_execute(worktree,commit,plan,commands,output)
        report = cast(models.Json,context['report'])
        receipt = adapter.decode(io_state.read(worktree/gate.DOC/'generation-receipt.json'))
        for field in ('host_closure_provenance','tail_publication_provenance','all60_qualified','all60_attempted',
                      'protocol_finished_terminal_evidence','protocol_outcome'):
            core.require(receipt[field] == report[field], 'generation/report tail scope differs')
        for name in ('README.md','REPORT.md'):
            text = io_state.read(worktree/gate.DOC/name).decode()
            core.require(adapter.DISCLOSURE in text and old_host.DISCLOSURE in text
                         and 'actual reservation and prepayment events are unobserved' in text,
                         'generated tail/host/native scope disclosure absent')
        result['derivation'] = {'version':'b8-finalized-tail-publication-gate-v4',
            'frozen_positive_cell_and_ratio_bodies_unchanged':True,
            'negative_branch_change':'Only exact pinned closed natural OOM warmups use the frozen negative prefix with a nullable raw oracle outcome; all original negative predicates retained.',
            'coordination_guard_change':'Only explicit protocol completed with failures plus exact counts/withheld ratios may say B8 DONE.',
            'scope':'Metadata/source/archive/candidate validation only; no physical arrays, engine or Docker.'}
        return result

    gate.__dict__['execute'] = execute
    gate.__dict__['__file__'] = str(Path(__file__).resolve())


def main() -> int:
    io_state = adapter.IO(core.Deadline.after(3600))
    own_dir = Path(__file__).resolve().parent
    for module,expected in ((core,adapter.CORE),(models,adapter.MODELS),(schema,adapter.PUB_MODELS),(adapter,ADAPTER_SHA)):
        core.require(io_state.pin(Path(cast(str,module.__file__)).resolve()).sha256 == expected,
                     'actual gate dependency source differs')
    gate = adapter.source_module(own_dir/'sem-B8-publication-gate.py',adapter.GATE,'b8_final_tail_original_gate',io_state)
    host_gate = adapter.source_module(own_dir/'sem-B8-publication-gate-v2.py',adapter.HOST_GATE,'b8_final_tail_original_host_gate',io_state)
    host = adapter.source_module(own_dir/'sem-b8-publish-host-provenance-v3.py',adapter.HOST_WRAPPER,'b8_final_tail_original_host_wrapper',io_state)
    wrapper = adapter.source_module(own_dir/'sem-b8-publish-tail-v6.py',WRAPPER_SHA,'b8_final_tail_wrapper',io_state)
    install(gate,host_gate,host,wrapper,io_state)
    return cast(int,gate.main())


if __name__ == '__main__':
    raise SystemExit(main())
