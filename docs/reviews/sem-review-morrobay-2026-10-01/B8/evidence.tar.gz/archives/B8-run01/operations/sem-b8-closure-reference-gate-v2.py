"""Full retained reference archive closure gate; root runs explicitly, no engines."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import pathlib
import sys
import traceback
from types import ModuleType
from typing import Any, Literal

import pydantic

BASE = pathlib.Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01')


class FilePin(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra='forbid', frozen=True)
    path: pathlib.Path
    bytes: int
    sha256: str


class Report(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra='forbid')
    outcome: Literal['checking', 'passed', 'error'] = 'checking'
    started_utc: str
    finished_utc: str | None = None
    helper: FilePin
    adapter: FilePin
    references: dict[str, dict[str, Any]] = pydantic.Field(default_factory=dict)
    error: str | None = None
    traceback: str | None = None
    engine_executed: Literal[False] = False
    scope: str = 'Exact frozen reference predicates plus complete retained physical archive hashing; read-only, no config generation or guest execution.'


def utc() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()


def pin(path: pathlib.Path) -> FilePin:
    if not path.is_absolute() or not path.is_file() or path.is_symlink():
        raise ValueError('absolute regular pinned source required')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return FilePin(path=path, bytes=path.stat().st_size, sha256=digest)


def load(path: pathlib.Path, expected: str) -> ModuleType:
    if pin(path).sha256 != expected:
        raise ValueError('adapter source pin differs')
    spec = importlib.util.spec_from_file_location('b8_actual_reference_closure_v2', path)
    if spec is None or spec.loader is None:
        raise ValueError('adapter import loader')
    result = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = result
    spec.loader.exec_module(result)
    return result


def save(path: pathlib.Path, report: Report) -> None:
    temporary = path.with_suffix('.writing')
    temporary.write_text(report.model_dump_json(indent=2)+'\n')
    temporary.replace(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--adapter', type=pathlib.Path, required=True)
    parser.add_argument('--adapter-sha256', required=True)
    parser.add_argument('--out', type=pathlib.Path, required=True)
    options = parser.parse_args()
    if not options.out.is_absolute() or options.out.exists() or options.out.is_symlink():
        raise ValueError('fresh absolute gate receipt required')
    report = Report(started_utc=utc(), helper=pin(pathlib.Path(__file__).resolve()), adapter=pin(options.adapter))
    save(options.out, report)
    try:
        adapter = load(options.adapter, options.adapter_sha256)
        frozen = adapter.install(adapter.frozen, options.adapter_sha256)
        generated = BASE/'generated-queues01'
        config = frozen.QueueConfig(host_root=BASE, output=BASE/'reference-closure-gate-only', python=pathlib.Path(sys.executable),
            driver=frozen.pin(BASE/'controller-profile/run_shapes_host.py'), campaign=frozen.pin(BASE/'campaign.json'),
            plan=frozen.pin(generated/'plan.json'), config_index=frozen.pin(generated/'config-index.json'),
            prerequisites=frozen.pin(generated/'prerequisites.json'), support_manifest=frozen.pin(BASE/'support/support-manifest.json'))
        campaign = adapter.host_contract.Campaign.model_validate(frozen.read(BASE/'campaign.json'))
        receipt = frozen.Receipt(config=config, dataset='cit-Patents', owner_pid=0, token='read-only-reference-gate',
                                 started_utc=utc(), observed_utc=utc())
        for name in ('cit-reference01', 'graph500-reference01'):
            for lock in (BASE.parent/'gate.lock', BASE.parent/'serial-queue.lock'):
                if lock.exists() or lock.is_symlink():
                    raise ValueError('read-only full archive gate refuses active global lock')
            proof = frozen.host_proof(BASE/name, 'reference')
            frozen.proof_files(proof, config, receipt, 'reference')
            before = frozen.read(BASE/name/'collected-manifest.json')
            raw = frozen.audit_reference(proof, config, campaign)
            frozen.verify_pins(receipt)
            after = frozen.physical_archive(BASE/name, frozen.read(BASE/name/'result.json'))
            if before != after:
                raise ValueError('full reference archive changed during gate')
            report.references[name] = {'outcome': 'passed', 'full_physical_archive_hashed_before_after': True,
                'archive': after, 'vertex_rows': raw['vertex_rows'], 'edge_rows': raw['edge_rows'],
                'reference_artifacts': raw['artifacts'], 'metadata_files': proof.model_dump(mode='json')}
            save(options.out, report)
        if pin(options.adapter) != report.adapter or pin(pathlib.Path(__file__).resolve()) != report.helper:
            raise ValueError('gate/adapter source changed')
        report.outcome = 'passed'
    except (OSError, ValueError, KeyError, TypeError) as error:
        report.outcome, report.error, report.traceback = 'error', repr(error), traceback.format_exc()
    report.finished_utc = utc()
    save(options.out, report)
    print(json.dumps({'outcome': report.outcome, 'receipt': str(options.out)}))
    return 0 if report.outcome == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
