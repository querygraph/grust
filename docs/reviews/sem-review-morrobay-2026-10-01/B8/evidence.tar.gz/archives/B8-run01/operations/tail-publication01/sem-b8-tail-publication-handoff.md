# Finalized B8 tail publication handoff

Observed UTC: 2026-10-02T06:39:26.312844+00:00

## Frozen source and offline gate

- Wrapper `sem-b8-publish-tail-v4.py`: 868df938fa27015d164b07c34dbb4a3ffa25bf4c1c2460610eebe2a349289d53.
- Adapter `sem_b8_tail_publication.py`: a88aed82c386add97509a4a03ef659c07eab456318dca1e03c4cc3262f05eae5.
- Gate `sem-B8-tail-publication-gate.py`: 6a0a68be5a2703a7c09efdb0f4d977ed27378cff93fb1221aa99c855ad73ffb9.
- Models `sem_b8_tail_publication_models_v2.py`: c3ee1875f8e80f351a41e425a82e9dd21c6988b8afc4633475187a6ceb6b0e77.
- Tests `test_sem_b8_tail_publication.py`: bd89282e0e715ddb93b138572bf321984cf73c698d28a6e5d29d0e3ad3c3760b.
- Actual metadata control `sem-b8-tail-metadata-readonly.py`: 3cacf15f3748575b039253b8ad4ab430d4fb59715b622042306fd116a4ec9039.
- Offline gate `/tmp/sem-b8-tail-publication-offline01/receipt.json`: 4bcb7ddd72eda970abe58083d8a0128f4bd05c69eba3fdcb3779f1fe3d897d97. Repo Ruff, strict mypy and 15 bounded controls passed; actual read-only metadata control accepts 40 qualified, four genuine OOM warmups and 16 policy skips. No physical payload reads, engines or actual publication/package generation.

Preserve design01/models01. Design02/models_v2 clarify task completion separately from qualification. The raw tail remains `completed_with_failures`; `all60_qualified=false`, `all60_attempted=false`, `protocol_finished_terminal_evidence=true`. Legacy `eligible_final_DONE=false` still means failure of all60 qualification, not unfinished protocol.

## Colocated runtime source copies

Root should copy the six files above plus the following frozen dependencies into a fresh `BASE/operations/tail-publication01` directory. Preserve basenames. Gate imports its four predecessors from its own directory:

- `sem_b8_tail_core.py` d2a6586df48fc4f00e0afb8a427db375f41f1ea773cf16d76adf4e1108822277.
- `sem_b8_tail_models.py` 5b984d9d5c5c51999b2943fdd316216b29aea11d4e8c658fa07c5f8947d0c44b.
- `sem-b8-publish-report-v2.py` 6a5e76f1e549cbbf7e5b19e680059d2f1c960808a0c86ce9011409043ae30937.
- `sem-b8-publish-host-provenance-v3.py` 6420a71cdd971cc42d09ba5be6be4d98e4ad8c6b4d0a713985e2205376f10408.
- `sem-B8-publication-gate.py` 703a3832648b538ea67cc170c145ca69a2ccbd9aedc7b1e6a8a96f7cbc216fa7.
- `sem-B8-publication-gate-v2.py` 1f51104259f5cfb27f0dbba588d481cd9ea441560e64b25aae3e95fc6e0f413d.

Copy the offline receipt/log directory and immutable design02 files there too. New sources are explicitly indexed, including externally archived lock-owner metadata. Physical Parquet/array/binary/bundle contents are not packaged or hashed. Metadata files and the final compressed metadata archive have a 64 MiB admission limit; each chunk/header read and hash propagates a finite deadline. Any refusal preserves fresh partial output for review, with no automatic retry.

## Root invocation after source review

Set the explicit destination to a fresh directory outside BASE. This command is an example only; the agent has not invoked it.

```sh
B8_BASE=/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01
B8_PUB=$B8_BASE/operations/tail-publication01
/tmp/sem-output-oracle-venv/bin/python -B "$B8_PUB/sem-b8-publish-tail-v4.py" \
  --base "$B8_BASE" --dest /private/tmp/sem-b8-final-tail-publication01 \
  --frozen-publisher "$B8_PUB/sem-b8-publish-report-v2.py" \
  --frozen-host-wrapper "$B8_PUB/sem-b8-publish-host-provenance-v3.py" \
  --frozen-gate "$B8_PUB/sem-B8-publication-gate.py" \
  --frozen-host-gate "$B8_PUB/sem-B8-publication-gate-v2.py" \
  --publication-gate "$B8_PUB/sem-B8-tail-publication-gate.py" \
  --host-preparation "$B8_BASE/generated-queues02/preparation.json" \
  --reference-closure-gate "$B8_BASE/reference-closure-gate02.json" \
  --prepared "$B8_BASE/tail-preparation01/prepared.json" \
  --preparation-attempt "$B8_BASE/tail-preparation01/preparation-receipt.json" \
  --authorization "$B8_BASE/tail-preparation01/root-authorization01.json" \
  --root-review "$B8_BASE/tail-preparation01/root-review01.json" \
  --tail-receipt "$B8_BASE/queue-graph500-tail01/receipt.json" \
  --preservation "$B8_BASE/original-failed-locks-preserved01.json" \
  --retained-evidence "$B8_BASE/continuation01/receipt.json" \
  --retained-evidence "$B8_BASE/generated-queues01/preparation.json" \
  --retained-evidence "$B8_BASE/terminal-root-review03.json" \
  --timeout-seconds 1800
```

Gate CLI stays `--worktree PATH --expected-commit FULL_SHA --plan EXACT_PLAN --out FRESH_RECEIPT`. It has a 3600 second metadata deadline. The exact detached plan must bind the DERIVED 60-row benchmark plan and set `require_complete=false`; retain all old failures/sources in `required_retained_sources`. Every positive cell/ratio predicate remains unchanged. A raw source-checked in-memory tail view supplies the actual fresh queue progress; the old failed Graph queue is excluded only from choosing the one qualified fresh Graph reference, while its raw bytes remain indexed. No raw receipt/config rewriting occurs.

If the append declares completion, accepted explicit wording is:

`B8 DONE (protocol completed with failures): 40/60 qualified; 44/60 attempted; 16 skipped; 2 ratios withheld.`

The prefix and append byte hashes remain mandatory. Bare DONE, all60 success/attempt claims, wrong counts, uncertain closure, any skipped launch fields or failed ratios are refused. Root owns actual archive generation, detached/actual-commit gates, Git and publication. No independent review of this final implementation has yet been claimed.
