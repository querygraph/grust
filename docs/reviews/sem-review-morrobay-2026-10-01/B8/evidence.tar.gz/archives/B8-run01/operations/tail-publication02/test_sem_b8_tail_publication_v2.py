"""Bounded fake metadata controls; no engines or real artifact publication."""
from __future__ import annotations

import ast
import copy
import gzip
import hashlib
import importlib.util
import sys
import tempfile
import unittest
from io import BytesIO
from pathlib import Path
from types import ModuleType
from unittest.mock import patch

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_publication_models_v2 as schema
import sem_b8_tail_publication_v2 as adapter


def load(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name,path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


WRAPPER = load('b8_tail_control_wrapper',Path('/tmp/sem-b8-publish-tail-v5.py'))
GATE = load('b8_tail_control_gate',Path('/tmp/sem-B8-tail-publication-gate-v2.py'))
ORIGINAL_ADAPTER = load('b8_tail_original_refusal_control',Path('/tmp/sem_b8_tail_publication.py'))


def mapping() -> models.Mapping:
    old = models.Step(dataset='graph500-24',shape='adjacency',variant='union',
        run_id='b8-graph500-24-adjacency-03-union',role='measured',sequence_within_contrast=3,measured_block=1)
    new = old.model_copy(update={'run_id':'b8-tail01-graph500-24-adjacency-03-union'})
    pin = models.FilePin(path=Path('/fake/config.json'),bytes=2,sha256=hashlib.sha256(b'{}').hexdigest())
    return models.Mapping(original=old,actual=new,original_config=pin,actual_config=pin)


def completion() -> models.Json:
    return {'protocol_finished_terminal_evidence':True,'protocol_outcome':'completed_with_failures',
        'all60_qualified':False,'all60_attempted':False,'qualified_cells':40,'attempted_cells':44,'skipped_cells':16,
        'contrasts':[{'ratio_status':'qualified_receipt_evidence'}]*4+[{'ratio_status':'withheld'}]*2}


class PublicationControls(unittest.TestCase):
    def test_skip_rejects_any_pid(self) -> None:
        with self.assertRaises(ValueError):
            schema.SkippedProjection.model_validate({'mapping':mapping().model_dump(),
                'failed_warmup_ids':['b8-graph500-24-adjacency-01-union'],'child_pid':123})

    def test_closed_oom_never_qualified(self) -> None:
        with self.assertRaises(ValueError):
            schema.AttemptedProjection(mapping=mapping(),disposition='closed_oom',qualified=True,
                raw_host_receipt=mapping().original_config)

    def test_pass_requires_rc_zero_and_actual_audit(self) -> None:
        with self.assertRaises(ValueError):
            schema.ProgressProjection(step=mapping().actual,outcome='passed',qualified=True,command=['fake'],
                log=None,started_utc=None,finished_utc=None,child_pid=123,returncode=1,audit={'qualified':True})

    def test_skip_row_diagnostic_fields_are_null(self) -> None:
        projection = schema.SkippedProjection(mapping=mapping(),failed_warmup_ids=['b8-graph500-24-adjacency-01-union'])
        row = WRAPPER.skipped_row(mapping().actual.model_dump(mode='json'),projection)
        self.assertFalse(row['qualified'])
        self.assertEqual(row['evidence'],{})
        self.assertTrue(all(v is None for v in row['timing_diagnostics'].values()))
        self.assertTrue(all(v is None for v in row['memory_diagnostics'].values()))
        self.assertFalse(row['tail_projection']['engine_call_started'])

    def test_scoped_protocol_done(self) -> None:
        GATE.completion_log(completion(),b'B8 DONE (protocol completed with failures): 40/60 qualified; 44/60 attempted; 16 skipped; 2 ratios withheld.')

    def test_unscoped_done_refused(self) -> None:
        with self.assertRaises(ValueError):
            GATE.completion_log(completion(),b'B8 DONE: all passed')

    def test_wrong_counts_refused(self) -> None:
        with self.assertRaises(ValueError):
            GATE.completion_log(completion(),b'B8 DONE (protocol completed with failures): 60/60 qualified; 44/60 attempted; 16 skipped; 2 ratios withheld.')

    def test_all60_claim_refused(self) -> None:
        report = completion(); report['all60_qualified'] = True
        with self.assertRaises(ValueError):
            GATE.completion_log(report,b'B8 DONE (protocol completed with failures): 40/60 qualified; 44/60 attempted; 16 skipped; 2 ratios withheld.')

    def test_execute_only_log_guard_changed(self) -> None:
        source = Path('/tmp/sem-B8-publication-gate.py').read_text()
        original = next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name == 'execute')
        changed = GATE.CompletionGuard(); actual = changed.visit(copy.deepcopy(original))
        expected = copy.deepcopy(original)
        guards = [n for n in ast.walk(expected) if isinstance(n,ast.If) and ast.unparse(n.test) == "not report['eligible_final_DONE']"]
        self.assertEqual(len(guards),1)
        guards[0].body = ast.parse('tail_completion_log(report, current[len(parent):])').body
        self.assertEqual(changed.changed,1)
        self.assertEqual(ast.dump(actual),ast.dump(expected))

    def test_physical_file_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            file = Path(temp)/'result.parquet'; file.write_bytes(b'not-read')
            with self.assertRaises(ValueError):
                adapter.IO(core.Deadline.after(10)).read(file)

    def test_deadline_checked_after_chunk(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            file = Path(temp)/'fake.log'; file.write_bytes(b'x'*(adapter.CHUNK+1))
            with patch('sem_b8_tail_core.time.monotonic',side_effect=[0,2]), self.assertRaises(TimeoutError):
                adapter.IO(core.Deadline(1)).read(file)

    def test_fake_package_deduplicates_source_and_excludes_payload(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)/'archive'; root.mkdir()
            source = root/'helper.py'; source.write_text('# fake helper\n')
            payload = root/'result'; payload.mkdir(); (payload/'x.parquet').write_bytes(b'never-read')
            dest = Path(temp)/'fake-output'; dest.mkdir()
            io_state = adapter.IO(core.Deadline.after(10))
            index = adapter.package(dest,[root],[io_state.pin(source)],io_state)
            self.assertEqual(len(index['members']),1)
            self.assertEqual(index['members'][0]['retained_source'],str(source))

    def test_archive_tamper_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)/'archive'; root.mkdir()
            (root/'fake.json').write_text('{}\n')
            dest = Path(temp)/'fake-output'; dest.mkdir()
            io_state = adapter.IO(core.Deadline.after(10))
            index = adapter.package(dest,[root],[],io_state)
            index['archive_sha256'] = '0'*64
            with self.assertRaises(ValueError):
                GATE.archive_gate(dest,index,io_state)

    def test_archived_skip_absence_detects_nested_receipt(self) -> None:
        io_state = GATE.ArchivedIO({'/fake/run/result.json':b'{}'},core.Deadline.after(10))
        self.assertTrue(io_state.exists(Path('/fake/run')))
        self.assertFalse(io_state.exists(Path('/fake/unused')))

    def test_oversized_tar_extension_header_refused_before_read(self) -> None:
        with gzip.GzipFile(fileobj=BytesIO(gzip.compress(b'{}')),mode='rb') as stream:
            reader = GATE.TarInput(stream,core.Deadline.after(10))
            with self.assertRaises(ValueError):
                reader.read(adapter.LIMIT+1)

    def test_declared_physical_tool_pins_are_never_opened_or_packaged(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)/'archive'; root.mkdir()
            source = root/'helper.py'; source.write_text('# metadata helper\n')
            payload = root/'vertices.parquet'; payload.write_bytes(b'physical-control')
            array = root/'labels.i64'; array.write_bytes(b'array-control')
            physical = [models.FilePin(path=p,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                        for p in (payload,array)]
            old_dest = Path(temp)/'preserved-original-refusal'; old_dest.mkdir()
            self.assertEqual(hashlib.sha256(Path('/tmp/sem_b8_tail_publication.py').read_bytes()).hexdigest(),
                'a88aed82c386add97509a4a03ef659c07eab456318dca1e03c4cc3262f05eae5')
            with self.assertRaises(ValueError):
                ORIGINAL_ADAPTER.package(old_dest,[root],physical,ORIGINAL_ADAPTER.IO(core.Deadline.after(10)))
            self.assertFalse((old_dest/'evidence.tar.gz').exists())
            dest = Path(temp)/'fake-output'; dest.mkdir()
            io_state = adapter.IO(core.Deadline.after(10))
            original = io_state.read
            read_paths: list[Path] = []

            def tracked(path: Path) -> bytes:
                read_paths.append(path)
                return original(path)

            with patch.object(adapter.IO,'read',side_effect=tracked):
                index = adapter.package(dest,[root],[*physical,io_state.pin(source)],io_state)
            self.assertEqual([m['retained_source'] for m in index['members']],[str(source)])
            self.assertEqual(index['declared_physical_tools_not_read'],[p.model_dump(mode='json') for p in sorted(physical,key=lambda p:p.path)])
            self.assertNotIn(payload,read_paths)
            self.assertNotIn(array,read_paths)


if __name__ == '__main__':
    unittest.main()
