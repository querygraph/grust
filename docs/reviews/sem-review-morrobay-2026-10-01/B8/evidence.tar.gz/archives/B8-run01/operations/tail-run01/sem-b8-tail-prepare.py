#!/usr/bin/env python3
"""Prepare fresh B8 tail config bytes only; no engine launches or lock changes."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import sem_b8_tail_core as core
import sem_b8_tail_prepare as preparation

PREPARATION_SHA = 'a48805d3cb0c9ed0917cedf3496e29018b63674ce1cdbb8c62f6e491e4ca000b'


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('original-queue-config', 'closure', 'preservation'):
        parser.add_argument('--'+name, type=Path, required=True)
        parser.add_argument('--'+name+'-sha256', required=True)
    parser.add_argument('--dest', type=Path, required=True)
    parser.add_argument('--queue-run-id', default='queue-graph500-tail01')
    parser.add_argument('--helper-sha256', required=True)
    parser.add_argument('--timeout-seconds', type=float, default=1800)
    args = parser.parse_args()
    deadline = core.Deadline.after(args.timeout_seconds)
    own = core.pin(Path(__file__).resolve(), deadline)
    core.require(own.sha256 == args.helper_sha256, 'preparation helper SHA admission')
    source = core.pin(Path(preparation.__file__).resolve(), deadline)
    core.require(source.sha256 == PREPARATION_SHA, 'exact preparation implementation SHA')
    pins = preparation.own_sources(deadline)
    original = core.pin(args.original_queue_config, deadline)
    closure = core.pin(args.closure, deadline)
    preserved = core.pin(args.preservation, deadline)
    core.require(original.sha256 == args.original_queue_config_sha256 and closure.sha256 == args.closure_sha256
                 and preserved.sha256 == args.preservation_sha256, 'root-selected input receipt identities')
    frozen = core.load(deadline)
    result = preparation.prepare(frozen, original, closure, preserved, args.dest, args.queue_run_id, [*pins, own])
    print(json.dumps({'outcome': result.outcome, 'prepared': str(args.dest/'prepared.json'),
        'prepared_sha256': core.pin(args.dest/'prepared.json', deadline).sha256,
        'authorization_for_root_review': str(args.dest/'authorization-for-root-review.json'),
        'engine_launched': False, 'locks_changed': False, 'fresh_configs': len(result.mappings)}))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, TimeoutError) as error:
        print(json.dumps({'outcome': 'preparation_refused', 'error': repr(error), 'observed_utc': core.utc(),
                          'engine_launched': False, 'locks_changed': False}), file=sys.stderr)
        raise SystemExit(1) from error
