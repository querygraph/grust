# B8 tail publication adapter, source preparation

This is a new metadata adapter and gate. The frozen publishers `6a5e76f1` and
`6420a71c`, gates `703a3832` and `1f511042`, queue `abe3842e`, closure adapter
`99c53056`, and all guest sources remain unchanged. Root owns publication,
candidate gates and execution. This preparation does not read physical
Parquet/reference arrays, start engines, change locks, or modify Grust.

## Plans, original evidence and the projected queue

The report's execution plan is the exact retained derived sixty-step plan.
Its first thirty-one entries must equal the original plan, including all
thirty citation runs and the original Graph500 adjacency union OOM. The
remaining twenty-nine steps map one-to-one to previously unused original
Graph500 IDs. Only each mapped `run_id` and its config `output` change;
every other step/config field is equal. The original plan, index, sixty
configs, original citation/Graph queue receipts, continuation failure,
closed-OOM audit and root-preserved original lock owners remain indexed
with their original bytes and SHA256. Each mapped report row records
`original_step` as well as its actual step; raw receipts are not rewritten.

The new typed `QueueProjection` is an explicitly declared, in-memory view
used only to call frozen qualification functions. Its `config` comes from
the actual derived queue-config file. Its finished/outcome/owner/active-child
fields come from the actual tail receipt. `mapping.actual` supplies `step`,
`disposition` supplies the progress outcome, `pass_audit` supplies `audit`,
and the actual stored `original_full_prerequisites` supplies the reference
view. It records its raw tail-receipt pin and every field mapping. It never
claims the tail ran the bare frozen queue, substitutes a fake raw config,
turns a failed outcome into pass, or overwrites a raw document. The original
citation receipt and its original config/plan pins are checked directly.

For every attempted mapped pass, the frozen publisher `qualify_cell` and
gate `cell` execute unchanged against actual alias directories and the
declared queue projection. Their source/function hashes, the old absence
adapter's copied-predicate AST guard, and the unchanged ratio functions are
rechecked from indexed source. The new adapter adds mapping, provenance,
failure and skip checks; it does not relax a qualification predicate.

## Failure, skip and completion

The first implementation accepts only a finalized tail with
`outcome=completed_with_failures`, no active child, its exact owned serial
lock preserved by rename, and all twenty-nine rows terminal. Root-approved
named OOMs require indexed immutable closure audits, full-collection
declarations, raw failed host/producer/bootstrap/engine receipts, unchanged
source/config pins, and matching preserved future gate-owner bytes. These
checks qualify closure only; every failed row remains `qualified=false`.
Uncertain/interrupted ownership is refused until separately reviewed.

An explicit `not_started_due_to_failed_warmup` row must name an actual
unqualified warmup in that contrast. Both warmups must have terminal
pass/closed-OOM evidence before a block is either admitted or skipped.
A skipped row has no PID, command, return code, launch/finish time, engine
directory/log, oracle, measured seconds, memory sample, or ratio. It is
retained as a planned outcome. Failed and skipped rows withhold the entire
contrast. A contrast qualifies only with both warmups and both exact U A A U
blocks, four measured samples per form and matching identities. Ratios
remain array-explode/union medians and adjacent-pair block geometric means
on the shared host; raw seconds are diagnostics. The original OOM makes
sixty-of-sixty qualification and attempt completion impossible under the warmup policy. The B8 protocol can finish with every planned row terminal, including closed failures and policy skips. Root may record B8 DONE (protocol completed with failures) with the actual counts and withheld ratios.

## Finite metadata packaging and gates

Each invocation takes an explicit finite wall deadline, propagated through
metadata enumeration, reads, chunked SHA256, tar member reads/writes and
final archive hashing. Checks occur between one-MiB chunks and directory
entries. Metadata retains the frozen sixty-four-MiB per-file limit and a
bounded entry count. No unbounded `file_digest` is used. A bounded I/O adapter
returns the same bytes/identities to frozen metadata predicates; the new
package implementation retains the old allowed-file/excluded-directory,
safe unique member, complete set and before/after SHA rules and discloses
its source. Physical inputs, reference arrays, Parquet outputs, binaries,
bundles and payload archives are linked by unchanged physical manifests.

The new detached gate retains exact HEAD/tree/parent/cleanliness, exact
changed paths, artifact hashes, safe unique indexed tar bytes, append-only
coordination, all sixty outcomes, and recomputed rounded ratios. It validates
the declared projection against archived raw bytes before delegation.
Original host provenance is checked with its original two queue receipts
and original preparation plan; tail provenance independently binds the
derived plan/configs/controller/authorization/closure/lock evidence. The new provenance records all60_qualified=false, all60_attempted=false, and protocol_finished_terminal_evidence=true only when all planned rows have terminal evidence and closure. The frozen legacy eligible_final_DONE field continues to mean all-sixty qualification, not task completion. The new gate versions only the coordination-log completion wording check to permit an explicitly scoped protocol-completed-with-failures entry; exact append bytes, positive qualification, skips, closure and ratio checks remain unchanged.
