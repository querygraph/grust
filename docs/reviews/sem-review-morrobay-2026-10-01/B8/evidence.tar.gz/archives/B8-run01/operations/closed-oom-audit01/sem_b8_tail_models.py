"""Typed host-only B8 continuation evidence; failure closure is never correctness."""
from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

Digest = Annotated[str, Field(pattern=r'^[a-f0-9]{64}$')]
RunId = Annotated[str, Field(pattern=r'^[a-z0-9][a-z0-9-]{0,63}$')]
Json = dict[str, Any]


class Record(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)


class Identity(Record):
    bytes: int = Field(ge=0)
    sha256: Digest


class FilePin(Identity):
    path: Path

    @model_validator(mode='after')
    def canonical(self) -> Self:
        if not self.path.is_absolute() or '..' in self.path.parts:
            raise ValueError('absolute clean pinned path')
        return self

    def identity(self) -> Identity:
        return Identity(bytes=self.bytes, sha256=self.sha256)


class GateOwner(Record):
    action: Literal['run']
    host: str
    pid: int = Field(gt=0)
    run_id: RunId
    started_utc: str
    token: Annotated[str, Field(pattern=r'^[a-f0-9]{32}$')]


class Probe(Record):
    argv: list[str]
    observed_utc: str
    returncode: int
    stdout: str
    stderr: str


class FailureClosure(Record):
    schema_version: Literal[1] = 1
    outcome: Literal['closed_natural_oom'] = 'closed_natural_oom'
    qualified: Literal[False] = False
    run_id: RunId
    observed_utc: str
    host_child_pid: int
    gate_owner: GateOwner
    gate_owner_pin: FilePin
    serial_owner_pin: FilePin
    source_pins: list[FilePin]
    evidence_pins: list[FilePin]
    physical_inventory: dict[str, Identity]
    native_package_manifest: Json
    raw_outcomes: dict[str, str | int | bool | None]
    oom_events: dict[str, dict[str, int]]
    probes: list[Probe]
    host_child_absent: Literal[True] = True
    certain_closure: Literal[True] = True
    full_collection_rehashed: Literal[True] = True
    original_receipts_rewritten: Literal[False] = False
    io_adapter_scope: str = 'Bounded chunk IO replaces only queue pin/read and host sha/collected_inventory; identical records, unchanged source predicates.'
    scope: str = 'Natural OOM process/container/archive/source closure only; no oracle or timing qualification.'


class Step(Record):
    dataset: Literal['graph500-24', 'cit-Patents']
    shape: Literal['adjacency', 'representatives', 'min-label-initial-round']
    variant: Literal['union', 'array-explode']
    run_id: RunId
    role: Literal['warmup', 'measured']
    sequence_within_contrast: int = Field(ge=1, le=10)
    measured_block: Literal[1, 2] | None


class Mapping(Record):
    original: Step
    actual: Step
    original_config: FilePin
    actual_config: FilePin
    only_changed_field: Literal['output'] = 'output'


class Authorization(Record):
    schema_version: Literal[1] = 1
    policy: Literal['b8-tail-warmups-before-two-UAAU-blocks-v1']
    approved_by: Literal['root']
    original_queue_config: FilePin
    named_failures: dict[str, Digest]
    allowed_classification: Literal['oom'] = 'oom'
    release_future_gate_by_owned_rename: Literal[True] = True
    change_guest_algorithms: Literal[False] = False
    change_resources: Literal[False] = False


class Prepared(Record):
    schema_version: Literal[1] = 1
    outcome: Literal['prepared'] = 'prepared'
    observed_utc: str
    original_queue_config: FilePin
    queue_config: FilePin
    original_cit_queue_receipt: FilePin
    original_graph_queue_receipt: FilePin
    original_continuation_receipt: FilePin
    original_oom_closure: FilePin
    original31_evidence: list[FilePin]
    sources: list[FilePin]
    mappings: list[Mapping]
    original_plan: FilePin
    derived_plan: FilePin
    original_failed_step: Step
    original_failure_qualified: Literal[False] = False
    policy: Literal['b8-tail-warmups-before-two-UAAU-blocks-v1'] = 'b8-tail-warmups-before-two-UAAU-blocks-v1'
    derivation: str = 'Only29 previously unused Graph IDs and their output path change; all original31 artifacts and configs are retained.'


class Cell(Record):
    mapping: Mapping
    disposition: Literal['pending', 'running', 'child_exited', 'passed', 'closed_oom', 'not_started_due_to_failed_warmup', 'uncertain'] = 'pending'
    qualified: bool = False
    command: list[str] = Field(default_factory=list)
    log: Path | None = None
    child_pid: int | None = None
    returncode: int | None = None
    started_utc: str | None = None
    finished_utc: str | None = None
    pass_audit: Json | None = None
    failure_closure: FilePin | None = None
    failure_gate_retained: Path | None = None
    cause_warmup_ids: list[str] = Field(default_factory=list)
    raw_receipts: Json = Field(default_factory=dict)
    error: str | None = None


class TailReceipt(Record):
    schema_version: Literal[1] = 1
    observed_utc: str
    started_utc: str
    finished_utc: str | None = None
    outcome: Literal['preparing', 'running', 'passed', 'completed_with_failures', 'uncertain', 'interrupted'] = 'preparing'
    owner_pid: int
    token: str
    prepared: FilePin
    authorization: FilePin
    sources: list[FilePin]
    original31: list[FilePin]
    original_failed_step: Step
    cells: list[Cell]
    active_child_pid: int | None = None
    serial_lock_retained: bool = True
    serial_lock_archived: Path | None = None
    interruption_signals: list[int] = Field(default_factory=list)
    prerequisite_observations: Json = Field(default_factory=dict)
    error: str | None = None
    scope: str = 'Warmup-qualified serial tail; failed/skipped cells never enter ratios; no failed-ID retry or engine cleanup.'
    io_adapter_scope: str = 'Bounded chunk hash/read adapters only; original99c archive normalization and all pass-audit predicates unchanged.'
