"""Add B8 host adapter provenance before frozen publisher manifests are formed."""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import sys
from collections.abc import Callable
from pathlib import Path
from types import ModuleType
from typing import Any, Literal, TypeAlias, cast

import pydantic

Json: TypeAlias = dict[str, Any]
PUBLISHER_SHA = '6a5e76f1e549cbbf7e5b19e680059d2f1c960808a0c86ce9011409043ae30937'
QUEUE_SHA = 'abe3842e4d5ae77122c42857ff1cb0298e3d42ccba7030e99c9a902967b05a94'
ADAPTER_SHA = '99c53056d946d16c705e041769acccd5034c321093c7706d261c1174ae6038f2'
CONFIG_WRAPPER_SHA = 'a6e8e1d446e1e081a3515c32bf5633be1ad93b432bf1d1c1ea89331d4129d33f'
CONFIG_SHA = '504c0127e4897c9f5d74c7d89680b0a25ecc5680a1cdb40976def8fcfcb50ce9'
GATE_SHA = '703a3832648b538ea67cc170c145ca69a2ccbd9aedc7b1e6a8a96f7cbc216fa7'
FUNCTION_SHA = '7dd9fefe0888f46705c883a61787a91a2809057b4324f1fbadbf4faeb8457201'
REFERENCE_GATE_SHA = '4de6b53ea46d43e579613e3404582dd3cdd98887338becf88af5a2171e6557a6'
SHA = r'^[0-9a-f]{64}$'
LIMIT = 64 * 2**20
DISCLOSURE = (
    'Host orchestration used the unchanged frozen queue abe3842e with the explicit '
    'b8-host-embedded-absence-v2 adapter 99c53056. '
    'Configuration preparation used the unchanged generator 504c0127 through wrapper a6e8e1d4. '
    'The only archived predicate correction requires embedded absence_verified and compares '
    'separate records excluding only that field; all other archived predicates remain unchanged. '
    'The original function SHA 7dd9fefe and its copied predicate guard are rechecked from retained '
    'source. Guest algorithms, source matrix, inputs and engine timers are unchanged. '
    'Structured host_closure_provenance in report.json pins these sources, prepared configuration, '
    'complete reference closure gate and the failed continuation01/generated-queues01 receipts.'
)


class Model(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra='forbid', frozen=True)


class FilePin(Model):
    path: Path
    bytes: int = pydantic.Field(strict=True, ge=0, le=LIMIT)
    sha256: str = pydantic.Field(pattern=SHA)


class ClosureAdapter(Model):
    version: Literal['b8-host-embedded-absence-v2']
    adapter: FilePin
    frozen_queue: FilePin
    original_function_sha256: Literal['7dd9fefe0888f46705c883a61787a91a2809057b4324f1fbadbf4faeb8457201']
    predicate_change: str
    guest_change: Literal[False]
    timer_change: Literal[False]
    raw_archive_rewrite: Literal[False]


class Provenance(Model):
    version: Literal['b8-publication-host-provenance-v3'] = 'b8-publication-host-provenance-v3'
    publisher_wrapper: FilePin
    frozen_publisher: FilePin
    frozen_publication_gate: FilePin
    closure_adapter: ClosureAdapter
    preparation: FilePin
    config_wrapper: FilePin
    frozen_config_generator: FilePin
    reference_closure_gate: FilePin
    required_retained_evidence: list[FilePin]
    queue_receipts: list[FilePin]
    predicate_guard: Json
    guest_change: Literal[False] = False
    timer_change: Literal[False] = False
    raw_archive_rewrite: Literal[False] = False


class Options(Model):
    frozen_publisher: Path
    frozen_publication_gate: Path
    base: Path
    dest: Path
    preparation: Path
    reference_closure_gate: Path
    queue_receipt: list[Path]
    retained_evidence: list[Path]
    prior_base: list[Path]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def raw(path: Path) -> bytes:
    require(path.is_absolute() and path.is_file() and not path.is_symlink()
            and '..' not in path.parts and path.stat().st_size <= LIMIT, 'bounded absolute regular metadata')
    before = path.stat(); data = path.read_bytes(); after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_ino, after.st_size, after.st_mtime_ns), 'metadata changed during read')
    return data


def pin(path: Path) -> FilePin:
    data = raw(path)
    return FilePin(path=path, bytes=len(data), sha256=digest(data))


def decode(data: bytes) -> Json:
    value: Any = json.loads(data)
    require(isinstance(value, dict), 'metadata JSON object')
    return cast(Json, value)


def check_pin(expected: FilePin, read: Callable[[Path], bytes]) -> bytes:
    data = read(expected.path)
    require(len(data) == expected.bytes and digest(data) == expected.sha256, 'retained metadata pin differs')
    return data


def original_function(data: bytes, name: str) -> tuple[ast.FunctionDef, bytes]:
    source = data.decode(); tree = ast.parse(source)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name]
    require(len(functions) == 1, 'unique retained function required')
    function = functions[0]
    require(function.end_lineno is not None, 'retained function boundaries')
    lines = source.splitlines(keepends=True)
    return function, ''.join(lines[function.lineno-1:function.end_lineno]).encode()


class StripFrozen(ast.NodeTransformer):
    def visit_Attribute(self, node: ast.Attribute) -> ast.AST:
        updated = self.generic_visit(node)
        assert isinstance(updated, ast.Attribute)
        if isinstance(updated.value, ast.Name) and updated.value.id == 'frozen':
            return ast.copy_location(ast.Name(id=updated.attr, ctx=updated.ctx), updated)
        return updated


def predicate_guard(queue: bytes, adapter: bytes) -> Json:
    require(digest(queue) == QUEUE_SHA and digest(adapter) == ADAPTER_SHA, 'frozen queue/adapter source differs')
    old, text = original_function(queue, 'audited_archive')
    new, _ = original_function(adapter, 'audited_archive_v2')
    stripped = StripFrozen().visit(new)
    require(isinstance(stripped, ast.FunctionDef) and digest(text) == FUNCTION_SHA, 'original copied predicate identity differs')
    assert isinstance(stripped, ast.FunctionDef)
    require(len(old.body) == len(stripped.body), 'copied predicate statement count differs')
    unchanged = [i for i in range(len(old.body)) if i not in {3, 4}]
    for index in unchanged:
        require(ast.dump(old.body[index], include_attributes=False) == ast.dump(stripped.body[index], include_attributes=False),
                'archived predicate changed outside authorized two statements')
    return {'original_function_sha256': digest(text), 'original_function_bytes': len(text),
            'statement_count': len(old.body), 'changed_statement_indices': [3, 4],
            'unchanged_statement_indices': unchanged, 'source_check': 'retained exact source plus AST comparison; no adapter import'}


def adapter_check(value: ClosureAdapter, read: Callable[[Path], bytes]) -> Json:
    require(value.adapter.sha256 == ADAPTER_SHA and value.frozen_queue.sha256 == QUEUE_SHA
            and value.original_function_sha256 == FUNCTION_SHA
            and value.predicate_change == 'Compare only absence_verified separately; require embedded absence; all other archived predicates unchanged.',
            'host adapter/frozen queue/predicate pins differ')
    return predicate_guard(check_pin(value.frozen_queue, read), check_pin(value.adapter, read))


def preparation_check(value: Json, evidence_pin: FilePin, adapter: ClosureAdapter,
                      read: Callable[[Path], bytes]) -> FilePin:
    require(value['outcome'] == 'prepared' and bool(value['finished_utc']) and not value['error']
            and not value['traceback'] and value['source_sha256'] == CONFIG_SHA, 'prepared configuration closure differs')
    require(ClosureAdapter.model_validate(value['closure_adapter']) == adapter
            and value['generator_wrapper_version'] == 'b8-metadata-generator-host-closure-v2', 'prepared host adapter provenance differs')
    wrapper = FilePin.model_validate(value['generator_wrapper'])
    require(wrapper.sha256 == CONFIG_WRAPPER_SHA, 'config wrapper source differs')
    check_pin(wrapper, read)
    options = value['options']
    require(options['action'] == 'queues' and Path(options['output']) == evidence_pin.path.parent
            and options['queue_sha256'] == QUEUE_SHA, 'prepared config namespace/source differs')
    artifacts = value['artifacts']
    require({'plan.json','config-index.json','prerequisites.json','queue-cit-patents.json','queue-graph500-24.json','sem-b8-configs.py'} <= set(artifacts), 'complete prepared metadata artifacts absent')
    for name, identity in artifacts.items():
        selected = FilePin.model_validate(identity)
        require(selected.path == evidence_pin.path.parent/name, 'prepared artifact namespace differs')
        check_pin(selected, read)
    return wrapper


def queue_check(queue: Json, adapter: ClosureAdapter, preparation: Json) -> None:
    require(queue['finished_utc'] and queue['active_child_pid'] is None
            and queue['outcome'] not in {'running','checking','preparing'}, 'unfinished queue publication refused')
    require(ClosureAdapter.model_validate(queue['closure_adapter']) == adapter, 'executed queue adapter provenance differs')
    pins = [FilePin.model_validate(v) for v in queue['pins']]
    require(adapter.adapter in pins and adapter.frozen_queue in pins, 'queue must verify both adapter and frozen source')
    config = queue['config']; artifacts = preparation['artifacts']
    for name in ('plan','config_index','prerequisites'):
        filename = {'plan':'plan.json','config_index':'config-index.json','prerequisites':'prerequisites.json'}[name]
        require(FilePin.model_validate(config[name]) == FilePin.model_validate(artifacts[filename]), 'queue/prepared metadata binding differs')


def reference_gate_check(value: Json, adapter: ClosureAdapter, read: Callable[[Path], bytes]) -> None:
    require(value['outcome'] == 'passed' and bool(value['finished_utc']) and not value['error']
            and not value['traceback'] and value['engine_executed'] is False, 'full reference closure gate did not pass')
    require(FilePin.model_validate(value['adapter']) == adapter.adapter
            and set(value['references']) == {'cit-reference01','graph500-reference01'}, 'full reference gate scope/adapter differs')
    helper = FilePin.model_validate(value['helper'])
    require(helper.sha256 == REFERENCE_GATE_SHA, 'complete reference closure gate source differs')
    check_pin(helper, read)
    for row in value['references'].values():
        require(row['outcome'] == 'passed' and row['full_physical_archive_hashed_before_after'] is True
                and bool(row['reference_artifacts']) and bool(row['archive']), 'complete physical reference gate observation absent')


def build_provenance(options: Options) -> Provenance:
    publisher, gate = pin(options.frozen_publisher), pin(options.frozen_publication_gate)
    require(publisher.sha256 == PUBLISHER_SHA and gate.sha256 == GATE_SHA, 'frozen publication source differs')
    preparation_pin = pin(options.preparation); preparation = decode(raw(options.preparation))
    adapter = ClosureAdapter.model_validate(preparation['closure_adapter']); guard = adapter_check(adapter, raw)
    config_wrapper = preparation_check(preparation, preparation_pin, adapter, raw)
    config = FilePin.model_validate(preparation['artifacts']['sem-b8-configs.py'])
    require(config.sha256 == CONFIG_SHA, 'frozen config generator identity differs')
    reference = pin(options.reference_closure_gate); reference_gate_check(decode(raw(reference.path)), adapter, raw)
    required = [pin(p) for p in options.retained_evidence]
    failures = [options.base/'continuation01/receipt.json', options.base/'generated-queues01/preparation.json']
    for path in failures:
        identity = pin(path); value = decode(raw(path))
        require(identity in required and value['outcome'] == 'error' and bool(value['finished_utc']) and value['error'], 'first failed continuation/preparation must remain retained')
    queues = [pin(p) for p in options.queue_receipt]
    require(bool(queues) and len({p.path for p in queues}) == len(queues), 'explicit unique finalized queue receipts required')
    for q in queues:
        queue_check(decode(raw(q.path)), adapter, preparation)
    own = pin(Path(__file__).resolve())
    result = Provenance(publisher_wrapper=own, frozen_publisher=publisher, frozen_publication_gate=gate,
                        closure_adapter=adapter, preparation=preparation_pin, config_wrapper=config_wrapper,
                        frozen_config_generator=config, reference_closure_gate=reference,
                        required_retained_evidence=required, queue_receipts=queues, predicate_guard=guard)
    roots = [options.base, *options.prior_base]
    all_pins = [own,publisher,gate,adapter.adapter,adapter.frozen_queue,preparation_pin,config_wrapper,config,
                reference,*required,*queues,FilePin.model_validate(decode(raw(reference.path))['helper'])]
    require(all(any(p.path.is_relative_to(root) for root in roots) for p in all_pins), 'publication source/evidence must be within packaged archives')
    return result


def load_publisher(path: Path) -> ModuleType:
    before = pin(path); require(before.sha256 == PUBLISHER_SHA, 'frozen publisher before import')
    spec = importlib.util.spec_from_file_location('b8_frozen_publication_host_provenance', path)
    require(spec is not None and spec.loader is not None, 'publisher source loader')
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
    require(pin(path) == before, 'publisher changed during import')
    return module


def install(module: ModuleType, provenance: Provenance) -> None:
    write_original = cast(Callable[[Path, Json | str], None], module.write)
    markdown_original = cast(Callable[[Json, bool], str], module.markdown)
    structured = provenance.model_dump(mode='json')

    def write(path: Path, value: Json | str) -> None:
        if path.name in {'report.json','generation-receipt.json'}:
            require(isinstance(value, dict), 'structured generated report required')
            assert isinstance(value, dict)
            value['host_closure_provenance'] = structured
            if path.name == 'report.json':
                value['scope'] = value['scope'].replace('retained frozen queue', 'retained frozen queue plus declared host closure adapter')
        write_original(path, value)

    def markdown(report: Json, detailed: bool) -> str:
        require(report['host_closure_provenance'] == structured, 'provenance must precede generated prose/hash')
        text = markdown_original(report,detailed).replace('retained frozen queue, host', 'retained frozen queue plus declared host closure adapter, host')
        return text+'\n## Host closure provenance\n\n'+DISCLOSURE+'\n'

    module.__dict__['write'] = write
    module.__dict__['markdown'] = markdown


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('frozen-publisher','frozen-publication-gate','base','dest','preparation','reference-closure-gate'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('queue-receipt','retained-evidence','prior-base'):
        parser.add_argument('--'+name,type=Path,action='append',default=[])
    options = Options.model_validate(vars(parser.parse_args()))
    require(not options.dest.exists(), 'fresh publication destination required')
    provenance = build_provenance(options); module = load_publisher(options.frozen_publisher); install(module,provenance)
    publish = cast(Callable[[Path,Path,list[Path],list[Path],Path],Json],module.publish)
    result = publish(options.base,options.preparation.parent/'plan.json',options.queue_receipt,options.prior_base,options.dest)
    require(build_provenance(options) == provenance,
            'publication provenance changed during packaging')
    print(json.dumps(result)); return 0


if __name__ == '__main__':
    raise SystemExit(main())
