"""Explicit host provenance gate controls on bounded synthetic receipt fixtures."""
from __future__ import annotations

import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType
from typing import Any


def module(name: str,path: str) -> ModuleType:
    spec=importlib.util.spec_from_file_location(name,path)
    assert spec is not None and spec.loader is not None
    value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value)
    return value


GATE=module('b8_v2_provenance_gate_controls','/tmp/sem-B8-publication-gate-v2.py')
FIXTURE=module('b8_v3_provenance_fixtures','/tmp/test_sem_b8_publish_host_provenance_v3.py')
WRAP: ModuleType=FIXTURE.WRAP
Json=dict[str,Any]


def make(directory: Path) -> tuple[Json,dict[str,bytes]]:
    generated=directory/'generated-queues02';generated.mkdir()
    preparation=FIXTURE.preparation(generated);prepared=generated/'preparation.json'
    prepared.write_text(json.dumps(preparation))
    adapter=WRAP.ClosureAdapter.model_validate(preparation['closure_adapter'])
    queue: Json={'outcome':'passed','finished_utc':'synthetic-not-observed','active_child_pid':None,
                 'closure_adapter':preparation['closure_adapter'],
                 'pins':[adapter.adapter.model_dump(mode='json'),adapter.frozen_queue.model_dump(mode='json')],
                 'config':{k:preparation['artifacts'][n] for k,n in (('plan','plan.json'),('config_index','config-index.json'),('prerequisites','prerequisites.json'))}}
    queue_path=directory/'queue-receipt.json';queue_path.write_text(json.dumps(queue))
    reference: Json={'outcome':'passed','finished_utc':'synthetic-not-observed','error':None,'traceback':None,'engine_executed':False,
                     'adapter':preparation['closure_adapter']['adapter'],
                     'helper':WRAP.pin(Path('/tmp/sem-b8-closure-reference-gate-v2.py')).model_dump(mode='json'),
                     'references':{name:{'outcome':'passed','full_physical_archive_hashed_before_after':True,
                                         'archive':{'synthetic':True},'reference_artifacts':{'synthetic':True}}
                                   for name in ('cit-reference01','graph500-reference01')}}
    reference_path=directory/'reference-closure-gate02.json';reference_path.write_text(json.dumps(reference))
    failures=[]
    for relative in ('continuation01/receipt.json','generated-queues01/preparation.json'):
        p=directory/relative;p.parent.mkdir();p.write_text(json.dumps({'outcome':'error','finished_utc':'synthetic-not-observed','error':'retained fixture failure'}))
        failures.append(WRAP.pin(p))
    wrapper=WRAP.pin(Path('/tmp/sem-b8-publish-host-provenance-v3.py'))
    publisher=WRAP.pin(Path('/tmp/sem-b8-publish-report-v2.py'))
    predecessor=WRAP.pin(Path('/tmp/sem-B8-publication-gate.py'))
    config_wrapper=WRAP.pin(Path('/tmp/sem-b8-configs-closure-v2.py'))
    generator=WRAP.FilePin.model_validate(preparation['artifacts']['sem-b8-configs.py'])
    queue_pin=WRAP.pin(queue_path);prepared_pin=WRAP.pin(prepared);reference_pin=WRAP.pin(reference_path)
    provenance=WRAP.Provenance(publisher_wrapper=wrapper,frozen_publisher=publisher,frozen_publication_gate=predecessor,
        closure_adapter=adapter,preparation=prepared_pin,config_wrapper=config_wrapper,frozen_config_generator=generator,
        reference_closure_gate=reference_pin,required_retained_evidence=failures,queue_receipts=[queue_pin],
        predicate_guard=WRAP.adapter_check(adapter,WRAP.raw))
    pins=[wrapper,publisher,predecessor,adapter.adapter,adapter.frozen_queue,config_wrapper,generator,queue_pin,prepared_pin,reference_pin,
          *failures,WRAP.FilePin.model_validate(reference['helper']),
          *[WRAP.FilePin.model_validate(p) for p in preparation['artifacts'].values()]]
    contents={str(p.path):p.path.read_bytes() for p in pins}
    report: Json={'base':str(directory),'host_closure_provenance':provenance.model_dump(mode='json'),
                 'plan_evidence':preparation['artifacts']['plan.json'],
                 'queues':[{'evidence':queue_pin.model_dump(mode='json')}]}
    return report,contents


def change_json(identity: Json,contents: dict[str,bytes],change: Any) -> None:
    value=json.loads(contents[identity['path']]);change(value)
    data=json.dumps(value).encode();contents[identity['path']]=data
    identity.update(bytes=len(data),sha256=GATE.sha(data))


class Controls(unittest.TestCase):
    def test_complete_declared_source_and_copied_predicate_schema(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report,contents=make(Path(temporary))
            result=GATE.provenance_gate(report,contents,WRAP)
            self.assertEqual(result['adapter_sha256'],WRAP.ADAPTER_SHA)
            self.assertFalse(result['runtime_source_or_timer_changed'])

    def test_queue_missing_or_unbound_adapter_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report,contents=make(Path(temporary))
            for case in ('missing','bare-queue'):
                selected=copy.deepcopy(report);evidence=copy.deepcopy(contents)
                identity=selected['host_closure_provenance']['queue_receipts'][0]
                if case=='missing':
                    change_json(identity,evidence,lambda v:v.pop('closure_adapter'))
                else:
                    change_json(identity,evidence,lambda v:v.update(pins=v['pins'][1:]))
                selected['queues'][0]['evidence']=copy.deepcopy(identity)
                with self.subTest(case=case),self.assertRaises((ValueError,KeyError)):
                    GATE.provenance_gate(selected,evidence,WRAP)

    def test_preparation_source_or_provenance_tamper_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report,contents=make(Path(temporary))
            selected=copy.deepcopy(report);evidence=copy.deepcopy(contents)
            identity=selected['host_closure_provenance']['preparation']
            change_json(identity,evidence,lambda v:v.update(source_sha256='0'*64))
            with self.assertRaisesRegex(ValueError,'prepared configuration'):
                GATE.provenance_gate(selected,evidence,WRAP)

    def test_failed_attempt_erasure_and_reference_scope_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report,contents=make(Path(temporary))
            selected=copy.deepcopy(report);selected['host_closure_provenance']['required_retained_evidence']=[]
            with self.assertRaisesRegex(ValueError,'failure absent'):
                GATE.provenance_gate(selected,contents,WRAP)
            selected=copy.deepcopy(report);evidence=copy.deepcopy(contents)
            identity=selected['host_closure_provenance']['reference_closure_gate']
            change_json(identity,evidence,lambda v:v['references'].pop('graph500-reference01'))
            with self.assertRaisesRegex(ValueError,'full-reference gate'):
                GATE.provenance_gate(selected,evidence,WRAP)

    def test_original_predicate_function_pin_and_statement_roster(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report,contents=make(Path(temporary))
            for field,value in (('original_function_sha256','0'*64),('changed_statement_indices',[3,4,5])):
                selected=copy.deepcopy(report);selected['host_closure_provenance']['predicate_guard'][field]=value
                with self.subTest(field=field),self.assertRaises(ValueError):
                    GATE.provenance_gate(selected,contents,WRAP)


if __name__ == '__main__':
    unittest.main()
