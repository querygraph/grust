#!/usr/bin/env python3
"""Publish finalized B8 metadata, including explicit partial and failed outcomes."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import os
import statistics
import tarfile
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, TypeAlias, cast

Json: TypeAlias = dict[str, Any]
DATASETS = ("cit-Patents", "graph500-24")
SHAPES = ("adjacency", "representatives", "min-label-initial-round")
FORMS = ("union", "array-explode")
ORDER = ("union", "array-explode", "union", "array-explode", "array-explode", "union",
         "union", "array-explode", "array-explode", "union")
SOURCE = "f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a"
GIB = 2**30
ALLOWED = {".json", ".jsonl", ".log", ".py", ".md", ".sha256", ".txt"}


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def raw(path: Path) -> bytes:
    require(path.is_file() and not path.is_symlink(), "regular metadata required: " + str(path))
    before = path.stat()
    value = path.read_bytes()
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_ino, after.st_size, after.st_mtime_ns), "metadata changed during read: " + str(path))
    return value


@dataclass(frozen=True, slots=True)
class Document:
    path: Path
    value: Json
    bytes: int | None
    sha256: str | None
    error: str | None

    def evidence(self) -> Json:
        return {"path": str(self.path), "bytes": self.bytes, "sha256": self.sha256, "error": self.error}


def document(path: Path) -> Document:
    try:
        data = raw(path)
        value: Any = json.loads(data)
        require(isinstance(value, dict), "JSON object required: " + str(path))
        return Document(path, cast(Json, value), len(data), digest(data), None)
    except (OSError, ValueError) as error:
        return Document(path, {}, None, None, str(error))


def exact(path: Path) -> Json:
    loaded = document(path)
    require(loaded.error is None, "required JSON unavailable: " + str(loaded.error))
    return loaded.value


def rounded(value: float) -> float:
    return float(f"{value:.3g}")


def positive(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0


def classification(outcomes: Json, missing: bool) -> str:
    if missing:
        return "missing"
    if any(v in ("mismatch", "known_mismatch", "passed_with_known_mismatch") for v in outcomes.values()):
        return "mismatch"
    if any(v and v not in ("passed", "checking", "running") for v in outcomes.values()):
        return "failed"
    return "unqualified"


def method(shape: str, form: str) -> str:
    if shape == "min-label-initial-round":
        return "min-label-whole-update-left-join-array-explode" if form == "array-explode" else "min-label-labels-union-messages"
    return shape + "-" + form


def container_binding(host: Json, container: Json) -> bool:
    embedded = host.get("records", {}).get("container") or {}
    return ({k: v for k, v in embedded.items() if k != "absence_verified"}
            == {k: v for k, v in container.items() if k != "absence_verified"}
            and ("absence_verified" not in container or container["absence_verified"] == embedded.get("absence_verified")))


def absence_proved(host: Json) -> bool:
    absence = host.get("records", {}).get("container", {}).get("absence_verified") or {}
    return absence.get("returncode") == 1 and any(
        s in absence.get("stderr", "").lower() for s in ("no such object", "no such container"))


def plan_gate(plan: Json) -> None:
    require(plan.get("source") == SOURCE, "pinned B8 controller required")
    expected = [(dataset, shape, form, index + 1, "warmup" if index < 2 else "measured",
                 None if index < 2 else 1 if index < 6 else 2)
                for dataset in DATASETS for shape in SHAPES for index, form in enumerate(ORDER)]
    actual = [(s["dataset"], s["shape"], s["variant"], s["sequence_within_contrast"], s["role"], s["measured_block"])
              for s in plan["steps"]]
    require(actual == expected and len({s["run_id"] for s in plan["steps"]}) == 60, "exact unique60-step paired plan required")


def queue_documents(base: Path, paths: list[Path]) -> list[Document]:
    selected = paths or sorted(base.glob("queue*/receipt.json"))
    result: list[Document] = []
    for path in selected:
        require(path.resolve().is_relative_to(base.resolve()), "queue evidence must belong to base")
        loaded = document(path)
        if not loaded.error:
            queue = loaded.value
            require(bool(queue.get("finished_utc")) and queue.get("outcome") not in ("running", "preparing", "checking")
                    and queue.get("active_child_pid") is None, "queue is not finalized; no live publication")
            pin_errors: list[str] = []
            for pinned in queue.get("pins") or []:
                source = Path(pinned["path"])
                # Full/tiny Parquet and reference arrays remain receipt-only evidence.
                if source.suffix in {".json", ".py", ".md", ".txt"}:
                    try:
                        content = raw(source)
                        require(len(content) == pinned["bytes"] and digest(content) == pinned["sha256"], "immutable metadata pin differs")
                    except (OSError, ValueError) as error:
                        pin_errors.append(str(source) + ": " + str(error))
            if pin_errors:
                loaded = Document(loaded.path, loaded.value, loaded.bytes, loaded.sha256, "; ".join(pin_errors))
        result.append(loaded)
    return result


def audit_cell(step: Json, base: Path, queues: list[Document]) -> Json:
    directory = base / step["run_id"]
    docs = {"host": document(directory / "result.json"),
            "producer": document(directory / "container/artifacts/receipt.json"),
            "container": document(directory / "container-record.json"),
            "configuration": document(directory / "configuration.json"),
            "bootstrap": document(directory / "container/artifacts/bootstrap-receipt.json"),
            "engine": document(directory / "container/artifacts/engine/engine-receipt.json"),
            "guest_manifest": document(directory / "container/artifacts/archive-manifest.json"),
            "collected_manifest": document(directory / "collected-manifest.json")}
    host, producer, engine = (docs[name].value for name in ("host", "producer", "engine"))
    row: Json = {"step": step, "qualified": False, "status": "missing" if not directory.exists() else "unqualified",
                 "outcomes": {"host": host.get("outcome"), "producer": producer.get("outcome"), "engine": engine.get("outcome"),
                              "oracle": (producer.get("correctness") or {}).get("outcome")},
                 "evidence": {name: d.evidence() for name, d in docs.items()},
                 "reasons": [], "raw_plans": producer.get("plans"), "correctness": producer.get("correctness"),
                 "timing_diagnostics": {"launch_to_exit_seconds": producer.get("launch_to_exit_seconds"),
                    "launch_until_interruption_seconds": producer.get("launch_until_interruption_seconds"),
                    "boundary": producer.get("measured_boundary"), "outside_boundary": producer.get("outside_boundary"),
                    "engine_phases": engine.get("phases"), "engine_scope": engine.get("timing_scope"),
                    "oracle_seconds": producer.get("oracle_seconds"), "supervisor_phases": producer.get("phases")},
                 "memory_diagnostics": {"sampled_engine_pss_peak_bytes": producer.get("sampled_engine_pss_peak_bytes"),
                    "sampled_engine_rows": producer.get("sampled_engine_rows"), "sampled_engine_pss_rows": producer.get("sampled_engine_pss_rows"),
                    "sampling": producer.get("memory"), "boundaries": producer.get("memory_boundaries"), "cgroups": producer.get("cgroups")},
                 "guest_steal_fraction": producer.get("guest_steal_fraction"), "errors": {"host": host.get("error"),
                    "producer": producer.get("error"), "engine": engine.get("error")}}
    errors: list[str] = row["reasons"]
    row["status"] = classification(row["outcomes"], not directory.exists())

    def check(value: bool, message: str) -> None:
        if not value:
            errors.append(message)

    for name, doc in docs.items():
        check(doc.error is None, name + ": " + str(doc.error))
    if docs["host"].error is None:
        require(bool(host.get("finished_utc")) and host.get("outcome") not in ("running", "checking"), "unfinished host refused: " + step["run_id"])
    if any(d.error for d in docs.values()):
        return row
    if row["status"] in ("failed", "mismatch"):
        errors.append("actual failed/mismatched outcome retained; ratio withheld")
        return row
    try:
        return qualify_cell(step, directory, queues, docs, row)
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        errors.append("inconsistent finalized qualification metadata: " + str(error))
        return row


def qualify_cell(step: Json, directory: Path, queues: list[Document], docs: dict[str, Document], row: Json) -> Json:
    host, producer, container, configuration, bootstrap, engine, guest, collected = (d.value for d in docs.values())
    errors: list[str] = row["reasons"]

    def check(value: bool, message: str) -> None:
        if not value:
            errors.append(message)

    matching_queues = [queue for queue in queues if not queue.error
                       and any(cell.get("step", {}).get("run_id") == step["run_id"] for cell in queue.value.get("cells", []))]
    progress = [cell for queue in matching_queues for cell in queue.value.get("cells", []) if cell.get("step", {}).get("run_id") == step["run_id"]]
    check(len(progress) == 1 and progress[0].get("returncode") == 0 and progress[0].get("outcome") == "passed"
          and (progress[0].get("audit") or {}).get("qualified") is True, "final frozen queue audit did not qualify")
    check(host.get("run_id") == step["run_id"] and host.get("kind") == "cell" and host.get("action") == "run"
          and host.get("outcome") == host.get("producer_outcome") == "passed" and host.get("certain_container_closure") is True
          and host.get("lock_retained") is False and host.get("archive_verified") is True and host.get("payload_removed") is True
          and not host.get("error"), "host run/archive/payload closure failed")
    check(container_binding(host, container), "embedded/separate container records differ")
    inspection, state = container.get("inspect") or {}, (container.get("inspect") or {}).get("state") or {}
    check(inspection.get("id") == container.get("create", {}).get("stdout", "").strip()
          and container.get("create", {}).get("returncode") == container.get("attach_returncode") == container.get("remove", {}).get("returncode") == 0
          and container.get("copied", {}).get("artifacts", {}).get("returncode") == 0
          and state.get("Running") is False and state.get("ExitCode") == 0 and state.get("OOMKilled") is False and not state.get("Error")
          and not any(container.get(k) for k in ("transport_errors", "outer_timeout", "kill", "forced_cleanup_kill", "operator_interrupted")), "container lifecycle failed")
    check(absence_proved(host), "container absence missing")
    spec = configuration["specification"]
    configured = json.loads(spec["config_text"])
    configured.setdefault("timeout_seconds", 1500)
    configured.setdefault("minimum_free_bytes", 24 * GIB)
    conf = producer.get("config") or {}
    check(conf == configured and all(conf.get(k) == step[k] for k in ("dataset", "shape", "variant")), "exact configured shape/dataset differs")
    check(bootstrap.get("outcome") == "passed" and bootstrap.get("producer_returncode") == 0
          and bootstrap.get("config_sha256") == spec.get("config_sha256")
          and bootstrap.get("identities_before") == bootstrap.get("identities_after"), "bootstrap config/source guard failed")
    check(producer.get("outcome") == engine.get("outcome") == "passed" and producer.get("engine_receipt") == engine
          and producer.get("engine_wait_completed") is True and producer.get("engine_returncode") == 0
          and producer.get("execution_verified") is True and producer.get("ownership_admitted") is True
          and not any(producer.get(k) for k in ("outer_timeout", "remaining_processes", "remaining_after_cleanup", "emergency_cleanup", "observer_error",
              "final_processes", "finalization_errors", "interruption_signals", "preexisting_processes", "error"))
          and engine.get("result_exported") is True and not any(engine.get(k) for k in ("cleanup_errors", "staging_payload_after_shutdown", "error")), "engine/oracle/owned process closure failed")
    check(producer.get("actual_engine_method") == engine.get("actual_method") == method(step["shape"], step["variant"]), "actual method differs")
    identities = producer.get("identities_before") or {}
    check(bool(identities) and identities == producer.get("identities_after") and identities.get("controller") == SOURCE, "source/input/helper closure differs")
    row["identity_fingerprint"] = digest(json.dumps(identities, sort_keys=True, allow_nan=False).encode()) if identities else None
    reference = identities.get("reference_phase") or {}
    check(len(matching_queues) == 1 and matching_queues[0].value.get("prerequisite_observations", {}).get("references", {}).get(step["dataset"]) == reference,
          "selected dataset reference differs from final queue prerequisite proof")
    artifact = reference.get("artifacts", {}).get(step["shape"]) or {}
    correctness = producer.get("correctness") or {}
    check(reference.get("outcome") == "passed" and reference.get("inputs_before") == reference.get("inputs_after")
          and correctness.get("outcome") == "passed" and correctness.get("full_oracle") is True
          and correctness.get("shape") == step["shape"] and correctness.get("reference_artifact") == artifact
          and correctness.get("rows") == correctness.get("unique") == correctness.get("expected_rows") == artifact.get("rows")
          and correctness.get("mismatches") == correctness.get("duplicate_rows") == 0
          and correctness.get("reference_receipt", {}).get("sha256") == conf.get("reference_receipt_sha256"), "complete exact shape oracle/reference missing")
    inventory = collected
    check(inventory == host.get("artifacts") and {k: v for k, v in inventory.items() if k != "archive-manifest.json"} == guest.get("files")
          and inventory.get("archive-manifest.json") == {"bytes": docs["guest_manifest"].bytes, "sha256": docs["guest_manifest"].sha256}, "guest/host archive metadata binding differs")
    files = correctness.get("result_files") or {}
    check(bool(files) and files == correctness.get("result_files_after")
          and all(inventory.get("engine/result/" + name) == value for name, value in files.items()), "declared raw result identities differ")
    plans = producer.get("plans") or {}
    check(bool(plans) and all({"bytes": p["bytes"], "sha256": p["sha256"]} == inventory.get(name) for name, p in plans.items()), "raw plan archive identities differ")
    for name, pin in plans.items():
        relative = PurePosixPath(name)
        check(not relative.is_absolute() and ".." not in relative.parts and name.startswith("engine/plan-") and name.endswith(".txt"), "raw plan path scope")
        if relative.is_absolute() or ".." in relative.parts:
            continue
        content = raw(directory / "container/artifacts" / name)
        check(len(content) == pin["bytes"] and digest(content) == pin["sha256"], "actual raw plan bytes differ")
    elapsed = producer.get("launch_to_exit_seconds")
    check(positive(elapsed), "finite positive timer missing")
    if len(progress) == 1:
        audit = progress[0].get("audit") or {}
        check(all(audit.get(k) == step[k] for k in ("run_id", "dataset", "shape", "variant", "role"))
              and audit.get("launch_to_exit_seconds") == elapsed and audit.get("result_files") == files
              and audit.get("plans") == plans and audit.get("actual_method") == method(step["shape"], step["variant"]),
              "frozen queue audit/source receipt binding differs")
    check(producer.get("memory", {}).get("execution_sampled") is True and producer.get("sampled_engine_pss_rows", 0) > 0
          and producer.get("sampled_engine_pss_peak_bytes", 0) > 0, "engine PSS samples missing")
    cgroups = producer.get("cgroups") or {}
    check(set(cgroups) >= {"before", "after_engine", "after_oracle", "final"}, "complete memory observation boundaries missing")
    for snapshot in cgroups.values():
        check(snapshot.get("cpu.max") == "1600000 100000" and snapshot.get("memory.max") == str(32 * GIB)
              and snapshot.get("memory.swap.max") == "0", "resource envelope differs")
        events = dict(line.split() for line in snapshot.get("memory.events", "").splitlines())
        check(events.get("oom") == events.get("oom_kill") == "0", "OOM observation failed")
    if not errors:
        row.update(qualified=True, status="passed")
    return row


def contrast(rows: list[Json]) -> Json:
    warmups = sorted((r for r in rows if r["step"]["role"] == "warmup"), key=lambda r: r["step"]["sequence_within_contrast"])
    measured = sorted((r for r in rows if r["step"]["role"] == "measured"), key=lambda r: r["step"]["sequence_within_contrast"])
    blockers: list[str] = []
    if len(warmups) != 2 or [r["step"]["variant"] for r in warmups] != list(FORMS) or not all(r["qualified"] for r in warmups):
        blockers.append("both retained warmups must qualify; excluded from ratios")
    if len(measured) != 8 or Counter(r["step"]["variant"] for r in measured) != Counter({form: 4 for form in FORMS}) or not all(r["qualified"] for r in measured):
        blockers.append("four qualified measured samples per form required")
    if len({r.get("identity_fingerprint") for r in measured}) != 1 or any(not r.get("identity_fingerprint") for r in measured):
        blockers.append("matched original input/reference/source/helper/binary identities required")
    blocks = [[r for r in measured if r["step"]["measured_block"] == b] for b in (1, 2)]
    if any([r["step"]["variant"] for r in b] != ["union", "array-explode", "array-explode", "union"] for b in blocks):
        blockers.append("both exact U A A U blocks required")
    first = rows[0]["step"]
    result: Json = {"dataset": first["dataset"], "shape": first["shape"], "ratio_status": "withheld" if blockers else "qualified_receipt_evidence",
                   "blockers": blockers, "median_array_over_union": None, "blocks": [],
                   "measured_run_ids": [r["step"]["run_id"] for r in measured], "warmup_run_ids": [r["step"]["run_id"] for r in warmups],
                   "n_per_form": 4, "scope": "isolated relational shape; shared-host ratio; not full WCC or multihost performance"}
    if blockers:
        return result
    medians = {form: statistics.median(r["timing_diagnostics"]["launch_to_exit_seconds"] for r in measured if r["step"]["variant"] == form) for form in FORMS}
    result.update(diagnostic_median_seconds=medians, median_array_over_union=rounded(medians["array-explode"] / medians["union"]))
    for index, block in enumerate(blocks, 1):
        pairs = [(block[1], block[0]), (block[2], block[3])]
        values = [a["timing_diagnostics"]["launch_to_exit_seconds"] / u["timing_diagnostics"]["launch_to_exit_seconds"] for a, u in pairs]
        result["blocks"].append({"block": index, "array_over_union": rounded(math.sqrt(values[0] * values[1])),
            "pairs": [{"array_run_id": a["step"]["run_id"], "union_run_id": u["step"]["run_id"], "unrounded_ratio": value}
                      for (a, u), value in zip(pairs, values, strict=True)]})
    return result


def phase_totals(row: Json) -> Json:
    totals: dict[str, float] = {}
    for phase in row["timing_diagnostics"].get("engine_phases") or []:
        if phase.get("status") == "end" and type(phase.get("duration_seconds")) in (int, float):
            totals[phase["name"]] = totals.get(phase["name"], 0.0) + phase["duration_seconds"]
    return totals


def diagnostics(cells: list[Json]) -> list[Json]:
    result: list[Json] = []
    for dataset in DATASETS:
        for shape in SHAPES:
            for form in FORMS:
                selected = [r for r in cells if r["qualified"] and r["step"]["role"] == "measured"
                            and (r["step"]["dataset"], r["step"]["shape"], r["step"]["variant"]) == (dataset, shape, form)]
                phases: dict[str, list[float]] = {}
                for row in selected:
                    for name, value in phase_totals(row).items():
                        phases.setdefault(name, []).append(value)
                pss = [r["memory_diagnostics"]["sampled_engine_pss_peak_bytes"] for r in selected]
                peaks = [int(r["memory_diagnostics"]["cgroups"]["final"]["memory.peak"]) for r in selected]
                steal = [r["guest_steal_fraction"] for r in selected if r["guest_steal_fraction"] is not None]
                result.append({"dataset": dataset, "shape": shape, "variant": form, "qualified_measured_samples": len(selected),
                    "phase_median_seconds_diagnostic": {name: statistics.median(values) for name, values in phases.items()},
                    "phase_sample_counts": {name: len(values) for name, values in phases.items()},
                    "sampled_engine_pss_peak_bytes_range": [min(pss), max(pss)] if pss else None,
                    "final_lifetime_cgroup_peak_bytes_range": [min(peaks), max(peaks)] if peaks else None,
                    "guest_steal_fraction_range": [min(steal), max(steal)] if steal else None,
                    "scope": "observed qualified measured cells only; raw phases may nest; not a future memory guarantee"})
    return result


def prerequisites(queues: list[Document]) -> list[Json]:
    rows: list[Json] = []
    seen: set[str] = set()
    for queue in queues:
        observation = queue.value.get("prerequisite_observations") or {}
        stage = observation.get("stage") or {}
        candidates: list[Json] = [{"kind": "stage", "id": "stage", "outcome": stage.get("outcome"),
                                  "scope": "retained queue prerequisite/source staging evidence"}]
        for dataset, reference in (observation.get("references") or {}).items():
            candidates.append({"kind": "full-reference", "id": dataset, "outcome": reference.get("outcome"),
                "vertex_rows": reference.get("vertex_rows"), "edge_rows": reference.get("edge_rows"),
                "isolated_vertices": reference.get("isolated_vertices"), "inputs": reference.get("inputs_before"),
                "artifacts": reference.get("artifacts"), "scope": "sealed separate reference phase; outside child timer"})
        for control in observation.get("tiny_controls") or []:
            candidates.append({"kind": "tiny-control", "id": control.get("run_id"), "shape": control.get("shape"),
                "variant": control.get("variant"), "outcome": "passed" if control.get("qualified") is True else "unqualified",
                "rows": control.get("rows"), "plans": control.get("plans"),
                "scope": "bounded signed/high-magnitude/duplicate/loop/isolate shape control; not full dataset or WCC qualification"})
        for row in candidates:
            fingerprint = digest(json.dumps(row, sort_keys=True, allow_nan=False).encode())
            if fingerprint not in seen:
                seen.add(fingerprint)
                rows.append(row)
    return rows


def write(path: Path, value: Json | str) -> None:
    content = value if isinstance(value, str) else json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    with path.open("x") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())


def package(dest: Path, roots: list[Path]) -> Json:
    origins: list[tuple[str, Path]] = [("tools/" + Path(__file__).name, Path(__file__))]
    require(len({root.name for root in roots}) == len(roots), "unique archive base names required")
    for root in roots:
        for path in sorted(root.rglob("*")):
            relative = path.relative_to(root)
            if any(p in ("result", "staging", "__pycache__", ".git", ".mypy_cache", ".ruff_cache") for p in relative.parts):
                continue
            if path.suffix not in ALLOWED and path.name not in ("ARTIFACTS.sha256", "SHA256SUMS"):
                continue
            require(not path.is_symlink(), "metadata symlink refused: " + str(path))
            if path.is_file():
                origins.append(("archives/" + root.name + "/" + relative.as_posix(), path))
    require(len({name for name, _ in origins}) == len(origins), "duplicate metadata archive member")
    members: list[Json] = []
    with tarfile.open(dest / "evidence.tar.gz", "x:gz", compresslevel=3) as archive:
        for name, path in origins:
            pure = PurePosixPath(name)
            require(not pure.is_absolute() and ".." not in pure.parts, "unsafe metadata archive member")
            data = raw(path)
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
            members.append({"member": name, "bytes": len(data), "sha256": digest(data), "retained_source": str(path)})
    for member in members:
        require(digest(raw(Path(member["retained_source"]))) == member["sha256"], "metadata changed during packaging")
    archive_bytes = raw(dest / "evidence.tar.gz")
    return {"schema_version": 1, "observed_utc": utc(), "archive": "evidence.tar.gz", "archive_bytes": len(archive_bytes),
            "archive_sha256": digest(archive_bytes), "members": members,
            "scope": "metadata/raw plans/logs/helpers only; no Parquet, reference arrays, binaries, bundles or physical payload tar reads"}


def markdown(report: Json, detailed: bool) -> str:
    lines = ["# B8: isolated relational shape comparison", "", "Status: **" + report["status"] + "**. " + str(report["qualified_cells"]) + "/60 cells qualify by retained frozen queue, host, producer and full physical-oracle receipts. This is a metadata audit, not a new physical-payload comparison.", "",
        "Ratios are **array-explode / union**, within each dataset and shape on shared Morrobay. Four measured samples per form, in two U A A U blocks; warmups remain in evidence and are excluded. Raw seconds are diagnostics. No absolute-performance, multihost or full-WCC performance claim follows.", "",
        "| Dataset | Isolated shape | Median ratio | Block 1 | Block 2 | Status |", "| --- | --- | ---: | ---: | ---: | --- |"]
    for c in report["contrasts"]:
        blocks = c["blocks"]
        lines.append(f"| {c['dataset']} | {c['shape']} | {c['median_array_over_union'] if blocks else 'withheld'} | {blocks[0]['array_over_union'] if blocks else '—'} | {blocks[1]['array_over_union'] if blocks else '—'} | {c['ratio_status']} |")
    lines.extend(["", "## Boundaries and semantics", "", "One fresh local Pecan engine per cell; 16 CPUs, 32 GiB, no swap; 30 GiB greedy pool with mimalloc and native_quota configured to 256 MiB. Pool/native reservation counters are not measured by this report. Pool budgets do not guarantee a physical memory bound. Source pins and every observed memory boundary/guest steal value remain in report.json.", "",
        "The earlier A2/A3 statement that every Pecan process prepays this quota was corrected in [C3-NATIVE-QUOTA-CORRECTION.md](../C3-NATIVE-QUOTA-CORRECTION.md). Exact source review supports quota admission when the corresponding extension owner is bound, including lazy worker-native admission. These are source contracts; actual reservation events are unmeasured here. The correction preserves the original timings, cells, archived plans and generation receipts.", "",
        "The timer spans child process launch through completed exit: startup, original reads, snapshots, shape preparation, explain recording before staging writes, materialization, result export and cleanup. Source/input/reference hashes, full physical output oracle and host archival are outside. Plans describe the relation immediately before its staging sink; they exclude the Parquet sink wrapper. The raw plan files are indexed artifacts, and recording them remains inside the child timer.", "",
        "Adjacency is the distinct original/reverse pair set. Representatives cover active endpoints in the first contraction round after self-loop exclusion; they are not a full WCC partition. The initial min-label update includes isolated vertices and compares the whole labels/propagation update; it is not a complete WCC loop. Every qualifying oracle compares all raw signed64 pairs/IDs/values, schema, multiplicity and coverage against the selected sealed reference.", "",
        "n=4, ordered blocks, shared-host activity and filesystem cache warming limit inference. Child phases may nest/overlap; phase totals sum only occurrences of the same name, and their medians are explanatory diagnostics. No phase subtraction or adjusted performance ratio is reported. Sampled engine PSS excludes the supervisor/PID1; whole-container and lifetime cgroup observations include broader costs and page cache, and final peaks include the parent oracle.", "",
        "Both original dataset contracts, full reference phases, six tiny signed/high-magnitude/duplicate/loop/isolate controls and all prior attempts remain separately recorded. Missing, failed, mismatched or unqualified cells withhold that contrast. Only a 60/60 qualified report with finalized passed queues is eligible for final DONE.", "",
        "See [report.json](report.json), [REPORT.md](REPORT.md), [evidence-index.json](evidence-index.json) and [evidence.tar.gz](evidence.tar.gz). Full physical payloads stay on Apo, linked through unchanged collected and guest archive manifests; this generator never reads or rehashes them."])
    lines.extend(["", "## Retained prerequisite outcomes", "", "| Kind | Reference or control | Outcome |", "| --- | --- | --- |"])
    for prerequisite in report["prerequisite_outcomes"]:
        lines.append(f"| {prerequisite['kind']} | {prerequisite['id']} | {prerequisite['outcome']} |")
    if detailed:
        lines.extend(["", "## All planned outcomes", "", "Seconds below are retained launch-to-exit diagnostics, including warmups.", "",
            "| Run | Role / block | Host / producer / engine / oracle | Seconds | Qualified |", "| --- | --- | --- | ---: | --- |"])
        for row in report["cells"]:
            s = row["step"]
            lines.append(f"| {s['run_id']} | {s['role']} / {s['measured_block'] or '—'} | {' / '.join(str(v) for v in row['outcomes'].values())} | {row['timing_diagnostics']['launch_to_exit_seconds']} | {row['qualified']} |")
        lines.extend(["", "## Withheld comparisons and cell failures", ""])
        for row in report["cells"]:
            if row["reasons"]:
                lines.append("- " + row["step"]["run_id"] + ": " + "; ".join(row["reasons"]))
        lines.extend(["", "## Other retained attempts and gates", ""])
        for attempt in report["other_retained_attempts"]:
            lines.append("- `" + attempt["evidence"]["path"] + "`: " + str(attempt["host"].get("outcome"))
                         + "; excluded from shape performance samples.")
        lines.extend(["", "## Exact raw plans", "", "Each listed relative member is inside evidence.tar.gz; its recorded SHA binds the raw file to the producer and physical archive manifests.", ""])
        for row in report["cells"]:
            for name, pin in (row["raw_plans"] or {}).items():
                member = "archives/" + Path(report["base"]).name + "/" + row["step"]["run_id"] + "/container/artifacts/" + name
                lines.append(f"- `{member}`: {pin['bytes']} bytes, SHA-256 `{pin['sha256']}`; {pin['scope']}.")
    return "\n".join(lines) + "\n"


def publish(base: Path, plan_path: Path, queue_paths: list[Path], prior_bases: list[Path], dest: Path) -> Json:
    require(not dest.exists() and not dest.is_symlink(), "fresh publication destination required")
    require(all(not dest.is_relative_to(root) for root in [base, *prior_bases]), "destination must be outside source archives")
    plan = exact(plan_path)
    plan_gate(plan)
    queues = queue_documents(base, queue_paths)
    cells = [audit_cell(step, base, queues) for step in plan["steps"]]
    contrasts = [contrast([r for r in cells if r["step"]["dataset"] == dataset and r["step"]["shape"] == shape]) for dataset in DATASETS for shape in SHAPES]
    qualified = sum(row["qualified"] for row in cells)
    passed_queues = {q.value.get("dataset") for q in queues if not q.error and q.value.get("outcome") == "passed"
                     and q.value.get("lock_retained") is False and not q.value.get("error")}
    complete = qualified == 60 and passed_queues == set(DATASETS)
    attempts: list[Json] = []
    planned = {step["run_id"] for step in plan["steps"]}
    for root in [base, *prior_bases]:
        for path in sorted(root.glob("*/result.json")):
            if root == base and path.parent.name in planned:
                continue
            doc = document(path)
            require(doc.error is not None or (bool(doc.value.get("finished_utc")) and doc.value.get("outcome") not in ("running", "checking")), "live ancillary host refused")
            attempts.append({"evidence": doc.evidence(), "host": doc.value, "counted_as_algorithm_cell": False})
        gate_receipt = root / "receipt.json"
        if root != base and gate_receipt.is_file():
            doc = document(gate_receipt)
            require(doc.error is not None or doc.value.get("outcome") not in ("running", "checking"), "live prior gate refused")
            attempts.append({"evidence": doc.evidence(), "host": doc.value, "kind": "external_gate", "counted_as_algorithm_cell": False})
    report: Json = {"schema_version": 1, "observed_utc": utc(), "status": "complete_60_receipt_evidence" if complete else "incomplete_receipt_evidence",
        "eligible_final_DONE": complete, "base": str(base), "plan": plan, "plan_evidence": document(plan_path).evidence(), "cells": cells,
        "qualified_cells": qualified, "cell_counts": dict(Counter(row["status"] for row in cells)), "contrasts": contrasts,
        "queues": [{"evidence": q.evidence(), "outcome": q.value.get("outcome"), "error": q.value.get("error"),
                    "prerequisites": q.value.get("prerequisite_observations"), "pins": q.value.get("pins")} for q in queues],
        "other_retained_attempts": attempts, "phase_cost_diagnostics": [{"run_id": row["step"]["run_id"], "role": row["step"]["role"],
            "completed_same_name_totals_seconds": phase_totals(row), "scope": "raw possibly nested phases, not additive across names"} for row in cells],
        "phase_memory_steal_summaries": diagnostics(cells),
        "prerequisite_outcomes": prerequisites(queues),
        "scope": "metadata/retained frozen queue full-oracle evidence only; no engine, Docker, input, Parquet or reference-array reads; no raw sampler recomputation",
        "ratio_direction": "array-explode / union; ratio of four-sample medians plus per-block adjacent-pair geometric means",
        "physical_payloads": [{"run_id": row["step"]["run_id"], "apo_collected_manifest": str(base/row["step"]["run_id"]/"collected-manifest.json"),
            "declared_result_files": (row["correctness"] or {}).get("result_files"), "scope": "unchanged retained declared identities; payload bytes not rehashed here"} for row in cells],
        "generator_sha256": digest(raw(Path(__file__)))}
    dest.mkdir(parents=True)
    write(dest / "report.json", report)
    write(dest / "README.md", markdown(report, False))
    write(dest / "REPORT.md", markdown(report, True))
    index = package(dest, [base, *prior_bases])
    write(dest / "evidence-index.json", index)
    receipt: Json = {"outcome": "passed", "observed_utc": utc(), "report_status": report["status"],
        "eligible_final_DONE": complete, "qualified_cells": qualified, "generator_sha256": report["generator_sha256"],
        "archive_sha256": index["archive_sha256"], "evidence_members": len(index["members"]), "dest": str(dest)}
    write(dest / "generation-receipt.json", receipt)
    names = ("README.md", "REPORT.md", "report.json", "evidence-index.json", "evidence.tar.gz", "generation-receipt.json")
    write(dest / "ARTIFACTS.sha256", "".join(digest(raw(dest/name)) + "  " + name + "\n" for name in names))
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--dest", type=Path, required=True)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--queue-receipt", type=Path, action="append", default=[])
    parser.add_argument("--prior-base", type=Path, action="append", default=[])
    args = parser.parse_args()
    base = args.base.resolve()
    receipt = publish(base, (args.plan or base/"plan.json").resolve(), [p.resolve() for p in args.queue_receipt],
                      [p.resolve() for p in args.prior_base], args.dest.resolve())
    print(json.dumps(receipt))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
