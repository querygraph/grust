# B8 nullable oracle gate v3

Source preparation only. Original gate-v2, publisher-v5, adapter-v2, generation02 and failed candidate641269f1 remain unchanged. Root owns fresh generation03/candidate02/exact gates/commit/push.

Use the same publisher-v5 command with `--publication-gate` naming the colocated `sem-B8-tail-publication-gate-v3.py` and a fresh destination; then invoke the new gate with the existing gate CLI and a fresh candidate plan/output. Keep the same models, core, adapter-v2, publisher-v5 and four frozen original gate/publisher modules colocated. No publisher or adapter patch is required.

Only exact original or mapped, unqualified, failed Graph500 warmup natural OOM rows use the new negative branch. It compiles the frozen original negative prefix, preserving raw evidence, outcomes, status/reasons, and live-host predicates, replacing only the nullable oracle outcome expression. Qualified cells and ratios delegate the unchanged original function objects. Failed and skipped rows remain unqualified, ratios withheld. No producer object is rewritten or replaced with `{}`.

The new branch additionally rechecks original/mapped closure pins through unchanged `closure_evidence`, exact configuration/dataset/method, source/native/runtime, complete collected/guest manifest bindings, and recorded oracle null. These checks use indexed metadata only. Skipped rows retain the prior exact no-launch branch.

Offline evidence: repo Ruff, strict mypy and24 tests passed. Original16 controls retained;8 new controls include all four actual closed-OOM null-oracle regressions (original cell AttributeError/v3 accepts unchanged failure), wrong outcomes, live hosts, unknown IDs/dataset/measured failures, reason/status/promotion/false oracle, config/source/manifest/owned-cleanup tampering and unchanged original positive function objects. Fixture is a3.3MB pinned retained metadata snapshot, with no physical Parquet or i64 bytes.

No actual publication, package, candidate gate, Git, Docker, engine, VM or payload reads were performed. Tiny fake package tests are retained offline controls. The proof does not qualify physical payload or numerical output again.
