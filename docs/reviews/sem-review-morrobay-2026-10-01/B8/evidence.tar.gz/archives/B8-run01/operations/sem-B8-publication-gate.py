#!/usr/bin/env python3
"""Exact detached B8 publication metadata gate; no engines or physical payload reads."""
from __future__ import annotations

import argparse
import errno
import hashlib
import json
import math
import os
import re
import statistics
import subprocess
import sys
import tarfile
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Any, TypeAlias, cast

import pydantic

Json: TypeAlias = dict[str, Any]
DOC = Path('docs/reviews/sem-review-morrobay-2026-10-01/B8')
FILES = {'README.md', 'REPORT.md', 'report.json', 'evidence-index.json',
         'evidence.tar.gz', 'generation-receipt.json', 'ARTIFACTS.sha256'}
ALLOWED = {'.json', '.jsonl', '.log', '.py', '.md', '.sha256', '.txt'}
SOURCE = 'f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a'
RUNTIME = '56194b170155301ba91077f0ba3df31fe2c78b6b'
NATIVE = 'ffcfbd5690e3f3681ef9ac18ba959bc231cf9f73'
HARNESS = '6ae2e43a903c2cee02da170465c922c72b76198e'
GENERATOR = '6a5e76f1e549cbbf7e5b19e680059d2f1c960808a0c86ce9011409043ae30937'
IMAGE = 'sha256:f3518d652fbea8b9b9f9ebf9849277ca3bd39d0c21bb2c6e36fbaeaa2dc2678e'
DATASETS = ('cit-Patents', 'graph500-24')
SHAPES = ('adjacency', 'representatives', 'min-label-initial-round')
FORMS = ('union', 'array-explode')
ORDER = ('union', 'array-explode', 'union', 'array-explode', 'array-explode', 'union',
         'union', 'array-explode', 'array-explode', 'union')
GIB = 2**30
MAX_METADATA = 64 * 2**20
SHA = r'^[0-9a-f]{64}$'
COMMIT = r'^[0-9a-f]{40}$'


class Model(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra='forbid', frozen=True)


class Pin(Model):
    bytes: int = pydantic.Field(strict=True, ge=0)
    sha256: str = pydantic.Field(pattern=SHA)


class Plan(Model):
    tree: str = pydantic.Field(pattern=COMMIT)
    parent: str = pydantic.Field(pattern=COMMIT)
    files: dict[str, Pin]
    base: Path
    benchmark_plan: Pin
    required_retained_sources: dict[str, Pin]
    codex_parent_sha256: str = pydantic.Field(pattern=SHA)
    codex_append_sha256: str = pydantic.Field(pattern=SHA)
    require_complete: bool = True


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe(name: str) -> bool:
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and str(path) == name and all(p not in ('.', '..') for p in path.parts)


def raw(path: Path) -> bytes:
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_METADATA, f'bounded metadata required: {path}')
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), f'changed metadata: {path}')
    return data


def pin_file(path: Path) -> Pin:
    require(path.is_file() and not path.is_symlink(), f'regular artifact required: {path}')
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(2**20), b''):
            digest.update(part)
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), f'changed artifact: {path}')
    return Pin(bytes=before.st_size, sha256=digest.hexdigest())


def pairs(values: list[tuple[str, Any]]) -> Json:
    result: Json = {}
    for key, value in values:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def decode(data: bytes) -> Json:
    value: Any = json.loads(data, object_pairs_hook=pairs,
                            parse_constant=lambda _value: (_ for _ in ()).throw(ValueError('nonfinite JSON value')))
    require(isinstance(value, dict), 'JSON object required')
    return cast(Json, value)


def git(worktree: Path, argv: list[str], commands: list[Json], codes: tuple[int, ...] = (0,)) -> str:
    result = subprocess.run(['git', '-C', str(worktree), *argv], capture_output=True, text=True, timeout=30,
                            env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}, check=False)
    commands.append({'argv': argv, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    require(result.returncode in codes, f'Git command failed: {argv}')
    return result.stdout.strip()


def state(worktree: Path, commit: str, plan: Plan, commands: list[Json]) -> Json:
    head = git(worktree, ['rev-parse', 'HEAD'], commands)
    tree = git(worktree, ['rev-parse', 'HEAD^{tree}'], commands)
    parents = git(worktree, ['rev-list', '--parents', '-n', '1', 'HEAD'], commands).split()
    branch = git(worktree, ['symbolic-ref', '-q', 'HEAD'], commands, (0, 1))
    detached = not branch and commands[-1]['returncode'] == 1
    status = git(worktree, ['status', '--porcelain=v1', '--untracked-files=all'], commands)
    top = git(worktree, ['rev-parse', '--show-toplevel'], commands)
    changed = git(worktree, ['diff', '--no-renames', '--name-only', plan.parent, commit], commands).splitlines()
    require(head == commit and tree == plan.tree and parents == [commit, plan.parent], 'exact HEAD/tree/parent mismatch')
    require(detached and not status and Path(top).resolve() == worktree, 'candidate must be exact detached clean worktree')
    require(set(changed) == set(plan.files), 'changed paths differ from immutable plan')
    return {'head': head, 'tree': tree, 'parent': plan.parent, 'detached': detached, 'status': status, 'changed_paths': changed}


def candidate_files(worktree: Path, plan: Plan) -> dict[str, Pin]:
    required = {str(DOC/name) for name in FILES} | {'codex-to-codex.md'}
    require(required <= set(plan.files) <= required | {str(DOC/'PREPARATION.md')}, 'publication changed-file scope differs')
    result: dict[str, Pin] = {}
    for name, expected in plan.files.items():
        require(safe(name) and (worktree/name).resolve().is_relative_to(worktree), 'candidate path escapes worktree')
        actual = pin_file(worktree/name)
        require(actual == expected, f'candidate file differs: {name}')
        if name.endswith(('.md', '.json', '.sha256')):
            require(not re.search(rb'^(<<<<<<<|=======|>>>>>>>)( |$)', raw(worktree/name), re.MULTILINE), 'conflict marker')
        result[name] = actual
    return result


def archive_gate(doc: Path, index: Json) -> tuple[dict[str, bytes], dict[str, Json]]:
    require(pin_file(doc/'evidence.tar.gz') == Pin(bytes=index['archive_bytes'], sha256=index['archive_sha256']), 'outer archive differs')
    expected: dict[str, Json] = {}
    for record in index['members']:
        require(safe(record['member']) and record['member'] not in expected, 'unsafe/duplicate indexed member')
        expected[record['member']] = record
    contents: dict[str, bytes] = {}
    sources: dict[str, Json] = {}
    seen: set[str] = set()
    with tarfile.open(doc/'evidence.tar.gz', 'r:gz') as archive:
        for info in archive:
            require(info.isfile() and safe(info.name) and info.name not in seen and info.name in expected, 'unsafe/unindexed archive member')
            path = PurePosixPath(info.name)
            require(path.suffix in ALLOWED or path.name in {'ARTIFACTS.sha256', 'SHA256SUMS'}, 'physical payload member refused')
            require(not any(p in {'result', 'staging', '.git', '__pycache__', '.mypy_cache', '.ruff_cache'} for p in path.parts), 'physical payload directory')
            require(info.size <= MAX_METADATA, 'archive member metadata limit')
            entry = expected[info.name]
            stream = archive.extractfile(info)
            require(stream is not None, 'unreadable member')
            assert stream is not None
            data = stream.read(MAX_METADATA+1)
            require(len(data) == info.size == entry['bytes'] and sha(data) == entry['sha256'], 'indexed archive bytes/SHA differ')
            source = entry['retained_source']
            require(source not in sources, 'duplicate retained source')
            contents[source], sources[source] = data, entry
            seen.add(info.name)
    require(seen == set(expected) and bool(seen), 'archive file set differs')
    require(any(entry['member'].startswith('tools/') and entry['sha256'] == GENERATOR for entry in sources.values()), 'frozen publisher missing from archive')
    return contents, sources


def evidence(value: Json, contents: dict[str, bytes], optional: bool = False) -> Json | None:
    if value.get('error') is not None:
        require(optional, 'required evidence records an error')
        return None
    require(value['path'] in contents, f'unindexed evidence: {value["path"]}')
    data = contents[value['path']]
    require(len(data) == value['bytes'] and sha(data) == value['sha256'], 'report/evidence identity differs')
    return decode(data)


def method(shape: str, form: str) -> str:
    if shape == 'min-label-initial-round':
        return 'min-label-whole-update-left-join-array-explode' if form == 'array-explode' else 'min-label-labels-union-messages'
    return shape+'-'+form


def closure(host: Json, container: Json, step: Json, kind: str = 'cell', payload_removal: bool = True) -> None:
    require(host['run_id'] == step['run_id'] and host['kind'] == kind and host['action'] == 'run'
            and host['outcome'] == host['producer_outcome'] == 'passed' and host['finished_utc']
            and host['certain_container_closure'] is True and host['lock_retained'] is False
            and host['archive_verified'] is True and (not payload_removal or host['payload_removed'] is True) and not host.get('error'), 'host closure failed')
    embedded = host['records']['container']
    require({k:v for k,v in embedded.items() if k != 'absence_verified'} == {k:v for k,v in container.items() if k != 'absence_verified'}, 'container binding differs')
    require('absence_verified' not in container or container['absence_verified'] == embedded.get('absence_verified'), 'separate absence differs')
    absence = embedded['absence_verified']
    require(absence['returncode'] == 1 and any(s in absence['stderr'].casefold() for s in ('no such object', 'no such container')), 'embedded absence unproven')
    inspect = container['inspect']; status = inspect['state']; identifier = container['create']['stdout'].strip()
    require(bool(re.fullmatch(SHA, identifier)) and inspect['id'] == identifier and inspect['image'] == IMAGE, 'container identity differs')
    require(container['create']['returncode'] == container['attach_returncode'] == container['remove']['returncode']
            == container['copied']['artifacts']['returncode'] == 0 and status['Running'] is False
            and status['ExitCode'] == 0 and status['OOMKilled'] is False and not status['Error'], 'container execution/removal failure')
    require(not any(container.get(k) for k in ('transport_errors', 'outer_timeout', 'kill', 'forced_cleanup_kill', 'operator_interrupted')), 'transport/forced cleanup failure')


def positive(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def reference_proofs(queue: Json, contents: dict[str, bytes]) -> None:
    path = queue['config']['prerequisites']['path']
    require(path in contents, 'reference prerequisite document unindexed')
    prerequisites = decode(contents[path])
    require(set(prerequisites['references']) == set(DATASETS), 'both full reference proofs required')
    require(len(prerequisites['tiny_controls']) == 6, 'six tiny controls required')
    observed = queue['prerequisite_observations']
    for proof in [*prerequisites['references'].values(), *prerequisites['tiny_controls']]:
        for name, pin in proof['files'].items():
            source = str(Path(proof['directory'])/name)
            require(safe(name) and source in contents and len(contents[source]) == pin['bytes']
                    and sha(contents[source]) == pin['sha256'], 'prerequisite raw metadata pin differs')
    for dataset, proof in prerequisites['references'].items():
        directory = Path(proof['directory'])
        paths = {k:str(directory/name) for k,name in {'host':'result.json','container':'container-record.json',
                 'producer':'container/artifacts/receipt.json','collected':'collected-manifest.json'}.items()}
        require(all(p in contents for p in paths.values()), 'full reference raw receipts absent')
        host,container,producer,collected = (decode(contents[paths[k]]) for k in ('host','container','producer','collected'))
        closure(host,container,{'run_id':proof['run_id']},kind='reference',payload_removal=False)
        require(producer == observed['references'][dataset] and producer['outcome'] == 'passed' and producer['finished_utc']
                and producer['inputs_before'] == producer['inputs_after'] and set(producer['artifacts']) == set(SHAPES), 'sealed original reference receipt differs')
        for shape, artifact in producer['artifacts'].items():
            require(artifact['file'] == shape+'.i64le' and artifact['identity']['bytes'] == 16*artifact['rows']
                    and collected[artifact['file']] == artifact['identity'], 'reference declared physical identity differs')
    tiny = observed['tiny_controls']
    require(len(tiny) == 6 and {(c['shape'],c['variant']) for c in tiny} == {(s,v) for s in SHAPES for v in FORMS}
            and all(c['qualified'] is True for c in tiny), 'complete signed/isolate/duplicate tiny controls absent')
    for proof in prerequisites['tiny_controls']:
        directory = Path(proof['directory'])
        host = decode(contents[str(directory/'result.json')])
        record = decode(contents[str(directory/'container-record.json')])
        producer = decode(contents[str(directory/'container/artifacts/receipt.json')])
        closure(host,record,{'run_id':proof['run_id']})
        oracle = producer['correctness']
        require(producer['outcome'] == 'passed' and producer['finished_utc'] and not producer['error']
                and producer['actual_engine_method'] == method(proof['shape'],proof['variant'])
                and oracle['outcome'] == 'passed' and oracle['full_oracle'] is True
                and oracle['mismatches'] == oracle['duplicate_rows'] == 0
                and oracle['rows'] == oracle['unique'] == oracle['expected_rows'], 'tiny raw full-oracle control failed')


def cell(row: Json, queues: list[Json], contents: dict[str, bytes]) -> None:
    step = row['step']
    docs: dict[str, Json] = {}
    for name, ev in row['evidence'].items():
        value = evidence(ev, contents, optional=not row['qualified'])
        if value is not None:
            docs[name] = value
    expected_outcomes = {'host':docs.get('host',{}).get('outcome'), 'producer':docs.get('producer',{}).get('outcome'),
                         'engine':docs.get('engine',{}).get('outcome'), 'oracle':docs.get('producer',{}).get('correctness',{}).get('outcome')}
    require(row['outcomes'] == expected_outcomes, 'reported raw outcomes differ')
    if not row['qualified']:
        require(row['status'] in {'missing', 'failed', 'mismatch', 'unqualified'} and bool(row['reasons']), 'unqualified outcome misclassified')
        require(not docs.get('host') or (bool(docs['host'].get('finished_utc')) and docs['host'].get('outcome') not in {'running', 'checking'}), 'live host evidence')
        return
    require(row['status'] == 'passed' and not row['reasons'] and set(docs) == {'host','producer','container','configuration','bootstrap','engine','guest_manifest','collected_manifest'}, 'qualified cell lacks complete evidence')
    host, producer, container, conf, bootstrap, engine, guest, collected = (docs[k] for k in ('host','producer','container','configuration','bootstrap','engine','guest_manifest','collected_manifest'))
    closure(host, container, step)
    require(producer['outcome'] == engine['outcome'] == 'passed' and producer['finished_utc'] and engine['finished_utc']
            and producer['engine_receipt'] == engine and producer['engine_wait_completed'] is True
            and producer['engine_returncode'] == 0 and producer['execution_verified'] is True and producer['ownership_admitted'] is True, 'engine/producer outcome failed')
    require(not any(producer.get(k) for k in ('outer_timeout','remaining_processes','remaining_after_cleanup','emergency_cleanup','observer_error','final_processes','finalization_errors','interruption_signals','preexisting_processes','error'))
            and not any(engine.get(k) for k in ('cleanup_errors','staging_payload_after_shutdown','error')) and engine['result_exported'] is True, 'producer lifecycle failure')
    configured = json.loads(conf['specification']['config_text']); configured.setdefault('timeout_seconds',1500); configured.setdefault('minimum_free_bytes',24*GIB)
    require(configured == producer['config'] and all(configured[k] == step[k] for k in ('dataset','shape','variant')), 'configured cell differs')
    require(bootstrap['outcome'] == 'passed' and bootstrap['producer_returncode'] == 0 and bootstrap['config_sha256'] == conf['specification']['config_sha256']
            and bootstrap['identities_before'] == bootstrap['identities_after'], 'bootstrap source/config guard failed')
    ids = producer['identities_before']
    require(ids == producer['identities_after'] and ids['controller'] == SOURCE and sha(json.dumps(ids,sort_keys=True,allow_nan=False).encode()) == row['identity_fingerprint'], 'input/source identity closure differs')
    require(engine['controller_pin'] == SOURCE and engine['runtime_pin'] == RUNTIME and engine['native_pin'] == NATIVE
            and engine['actual_method'] == producer['actual_engine_method'] == method(step['shape'],step['variant']), 'actual engine method/pins differ')
    require(engine['threads_per_process'] == 16 and engine['pool_type'] == 'greedy' and engine['snapshots_in_engine_boundary'] is True
            and engine['preparation_in_engine_boundary'] is True and engine['planning_in_engine_boundary'] is True, 'engine profile/timing boundary differs')
    progress = [c for q in queues for c in q.get('cells',[]) if c['step']['run_id'] == step['run_id']]
    require(len(progress) == 1 and progress[0]['step'] == step and progress[0]['returncode'] == 0 and progress[0]['outcome'] == 'passed'
            and progress[0]['audit']['qualified'] is True, 'final queue did not qualify cell')
    reference = ids['reference_phase']; oracle = producer['correctness']; artifact = reference['artifacts'][step['shape']]
    selected_refs = [q['prerequisite_observations']['references'][step['dataset']] for q in queues if q['dataset'] == step['dataset']]
    require(len(selected_refs) == 1 and selected_refs[0] == reference and reference['outcome'] == 'passed'
            and reference['inputs_before'] == reference['inputs_after'], 'selected full reference differs')
    require(row['correctness'] == oracle and oracle['outcome'] == 'passed' and oracle['full_oracle'] is True and oracle['shape'] == step['shape']
            and oracle['reference_artifact'] == artifact and oracle['rows'] == oracle['unique'] == oracle['expected_rows'] == artifact['rows']
            and oracle['mismatches'] == oracle['duplicate_rows'] == 0 and oracle['reference_receipt']['sha256'] == configured['reference_receipt_sha256'], 'complete exact physical oracle receipt missing')
    require(bool(oracle['physical_schemas']) and all(f['arrow_type'] == 'int64' for s in oracle['physical_schemas'] for f in s['fields']), 'signed64 physical schema receipt missing')
    require(collected == host['artifacts'] and {k:v for k,v in collected.items() if k != 'archive-manifest.json'} == guest['files'], 'guest/collected manifest binding differs')
    require(collected['archive-manifest.json'] == {'bytes':row['evidence']['guest_manifest']['bytes'],'sha256':row['evidence']['guest_manifest']['sha256']}, 'guest manifest byte binding differs')
    files = oracle['result_files']
    require(files and files == oracle['result_files_after'] and all(collected['engine/result/'+k] == v for k,v in files.items()), 'declared physical payload binding differs')
    require(row['raw_plans'] == producer['plans'] and bool(producer['plans']), 'raw plans missing')
    for name, identity in producer['plans'].items():
        require(safe(name) and name.startswith('engine/plan-') and name.endswith('.txt'), 'plan path scope differs')
        path = str(Path(row['evidence']['producer']['path']).parent/name)
        require(path in contents and collected[name] == {'bytes':identity['bytes'],'sha256':identity['sha256']}
                and len(contents[path]) == identity['bytes'] and sha(contents[path]) == identity['sha256'], 'actual recorded plan bytes differ')
    require(row['timing_diagnostics']['launch_to_exit_seconds'] == producer['launch_to_exit_seconds'] and positive(producer['launch_to_exit_seconds'])
            and row['timing_diagnostics']['engine_phases'] == engine['phases'], 'raw timer differs')
    require(row['guest_steal_fraction'] == producer['guest_steal_fraction']
            and row['memory_diagnostics']['cgroups'] == producer['cgroups']
            and row['memory_diagnostics']['boundaries'] == producer['memory_boundaries']
            and row['memory_diagnostics']['sampled_engine_pss_peak_bytes'] == producer['sampled_engine_pss_peak_bytes'], 'memory/steal report differs')
    audit = progress[0]['audit']
    require(all(audit[k] == step[k] for k in ('run_id','dataset','shape','variant','role')) and audit['launch_to_exit_seconds'] == producer['launch_to_exit_seconds']
            and audit['result_files'] == files and audit['plans'] == producer['plans'] and audit['actual_method'] == method(step['shape'],step['variant']), 'queue raw output/time/method binding differs')
    require(producer['memory']['execution_sampled'] is True and producer['sampled_engine_pss_rows'] > 0 and producer['sampled_engine_pss_peak_bytes'] > 0, 'PSS coverage missing')
    require(set(producer['cgroups']) >= {'before','after_engine','after_oracle','final'}, 'resource observation boundaries missing')
    for snapshot in producer['cgroups'].values():
        events = dict(line.split() for line in snapshot['memory.events'].splitlines())
        require(snapshot['cpu.max'] == '1600000 100000' and snapshot['memory.max'] == str(32*GIB) and snapshot['memory.swap.max'] == '0'
                and events['oom'] == events['oom_kill'] == '0', 'resource envelope/OOM observation failed')


def ratios(rows: list[Json], record: Json) -> None:
    warm = rows[:2]; measured = rows[2:]
    qualified = all(r['qualified'] for r in rows) and len({r.get('identity_fingerprint') for r in measured}) == 1 and all(r.get('identity_fingerprint') for r in measured)
    require(record['warmup_run_ids'] == [r['step']['run_id'] for r in warm] and record['measured_run_ids'] == [r['step']['run_id'] for r in measured]
            and record['n_per_form'] == 4, 'ratio sample roster differs')
    if not qualified:
        require(record['ratio_status'] == 'withheld' and record['median_array_over_union'] is None and record['blocks'] == [] and record['blockers'], 'failed/missing/unmatched contrast retained ratio')
        return
    require(record['ratio_status'] == 'qualified_receipt_evidence' and not record['blockers'], 'qualified contrast withheld')
    medians = {form:statistics.median(r['timing_diagnostics']['launch_to_exit_seconds'] for r in measured if r['step']['variant'] == form) for form in FORMS}
    require(record['diagnostic_median_seconds'] == medians and record['median_array_over_union'] == float(f'{medians["array-explode"]/medians["union"]:.3g}'), 'median ratio differs')
    require(len(record['blocks']) == 2, 'both blocks required')
    for number, block in enumerate(record['blocks'],1):
        selected = [r for r in measured if r['step']['measured_block'] == number]
        pairs_ = [(selected[1],selected[0]),(selected[2],selected[3])]
        values = [a['timing_diagnostics']['launch_to_exit_seconds']/u['timing_diagnostics']['launch_to_exit_seconds'] for a,u in pairs_]
        expected = [{'array_run_id':a['step']['run_id'],'union_run_id':u['step']['run_id'],'unrounded_ratio':v} for (a,u),v in zip(pairs_,values,strict=True)]
        require(block['block'] == number and block['pairs'] == expected and block['array_over_union'] == float(f'{math.sqrt(values[0]*values[1]):.3g}'), 'paired block ratios differ')


def report_gate(report: Json, plan: Plan, contents: dict[str,bytes]) -> Json:
    benchmark = report['plan']; ev = report['plan_evidence']
    require(Pin(bytes=ev['bytes'],sha256=ev['sha256']) == plan.benchmark_plan and evidence(ev,contents) == benchmark, 'benchmark plan byte identity differs')
    require(report['base'] == str(plan.base) and benchmark['source'] == SOURCE and benchmark['harness'] == HARNESS and benchmark['runtime'] == RUNTIME
            and benchmark['native'] == NATIVE and benchmark['image'] == IMAGE and benchmark['cpus'] == 16 and benchmark['memory_bytes'] == 32*GIB and benchmark['swap_bytes'] == 0, 'pinned input/execution profile differs')
    expected = [(d,s,v,n+1,'warmup' if n<2 else 'measured',None if n<2 else 1 if n<6 else 2) for d in DATASETS for s in SHAPES for n,v in enumerate(ORDER)]
    actual = [(s['dataset'],s['shape'],s['variant'],s['sequence_within_contrast'],s['role'],s['measured_block']) for s in benchmark['steps']]
    require(actual == expected and len({s['run_id'] for s in benchmark['steps']}) == 60 and [r['step'] for r in report['cells']] == benchmark['steps'], 'exact60 outcomes/paired schedule differ')
    require(report['generator_sha256'] == GENERATOR and report['ratio_direction'].startswith('array-explode / union'), 'publisher/ratio direction differs')
    queues: list[Json] = []
    for row in report['queues']:
        queue = evidence(row['evidence'],contents,optional=True)
        if queue is not None:
            require(queue['finished_utc'] and queue['active_child_pid'] is None and queue['outcome'] not in {'running','preparing','checking'}, 'live queue publication')
            require(row['outcome'] == queue['outcome'] and row['error'] == queue['error'] and row['prerequisites'] == queue['prerequisite_observations'] and row['pins'] == queue['pins'], 'queue summary differs')
            for identity in queue['pins']:
                source = Path(identity['path'])
                if source.suffix in {'.json','.py','.md','.txt'}:
                    require(str(source) in contents and len(contents[str(source)]) == identity['bytes'] and sha(contents[str(source)]) == identity['sha256'], 'archived queue metadata pin differs')
            if queue['outcome'] == 'passed':
                reference_proofs(queue,contents)
            queues.append(queue)
    for row in report['cells']:
        cell(row,queues,contents)
    qualified = sum(row['qualified'] for row in report['cells'])
    completed = qualified == 60 and {q['dataset'] for q in queues if q['outcome'] == 'passed' and q['lock_retained'] is False and not q['error']} == set(DATASETS)
    require(report['qualified_cells'] == qualified and report['cell_counts'] == dict(Counter(row['status'] for row in report['cells']))
            and report['eligible_final_DONE'] is completed and report['status'] == ('complete_60_receipt_evidence' if completed else 'incomplete_receipt_evidence'), 'completion/count claims differ')
    require(not plan.require_complete or completed, 'final DONE requires60/60 and both finalized passed queues')
    require(len(report['contrasts']) == 6 and [(c['dataset'],c['shape']) for c in report['contrasts']] == [(d,s) for d in DATASETS for s in SHAPES], 'six contrast roster differs')
    for record in report['contrasts']:
        ratios([r for r in report['cells'] if (r['step']['dataset'],r['step']['shape']) == (record['dataset'],record['shape'])],record)
    require(len(report['physical_payloads']) == len(report['phase_cost_diagnostics']) == 60, 'all planned diagnostics/payload links required')
    for row, phases, payload in zip(report['cells'],report['phase_cost_diagnostics'],report['physical_payloads'],strict=True):
        totals: dict[str,float] = {}
        for phase in row['timing_diagnostics']['engine_phases'] or []:
            if phase.get('status') == 'end' and type(phase.get('duration_seconds')) in (int,float):
                totals[phase['name']] = totals.get(phase['name'],0.0)+phase['duration_seconds']
        require(phases['run_id'] == payload['run_id'] == row['step']['run_id'] and phases['role'] == row['step']['role']
                and phases['completed_same_name_totals_seconds'] == totals
                and payload['declared_result_files'] == (row['correctness'] or {}).get('result_files'), 'phase/payload diagnostic differs')
    for attempt in report['other_retained_attempts']:
        retained = evidence(attempt['evidence'],contents,optional=True)
        require(attempt['counted_as_algorithm_cell'] is False and (retained is None or retained == attempt['host']), 'prior attempt erased or counted as benchmark')
    return {'qualified_cells':qualified,'complete':completed,'ratios':[{'dataset':c['dataset'],'shape':c['shape'],'status':c['ratio_status'],'array_over_union':c['median_array_over_union']} for c in report['contrasts']]}


def execute(worktree: Path, commit: str, plan: Plan, commands: list[Json], output: Path) -> Json:
    before = state(worktree,commit,plan,commands)
    files_before = candidate_files(worktree,plan)
    parent = subprocess.run(['git','-C',str(worktree),'show',plan.parent+':codex-to-codex.md'],capture_output=True,check=True).stdout
    current = raw(worktree/'codex-to-codex.md'); require(sha(parent) == plan.codex_parent_sha256 and current.startswith(parent) and len(current)>len(parent)
                and sha(current[len(parent):]) == plan.codex_append_sha256,'coordination append/prefix differs')
    target = worktree/'target'/('sem-b8-publication-'+commit[:12]+'-'+sha(str(output).encode())[:12])
    require(not target.exists() and bool(git(worktree,['check-ignore',str(target)],commands)), 'own fresh ignored target required')
    target.mkdir(parents=True)
    doc = worktree/DOC
    lines = raw(doc/'ARTIFACTS.sha256').decode().splitlines()
    require(len(lines) == 6, 'six publication artifact hashes required')
    for line in lines:
        digest,name = line.split('  '); require(name in FILES-{'ARTIFACTS.sha256'} and pin_file(doc/name).sha256 == digest,'artifact SHA differs')
    require({line.split('  ')[1] for line in lines} == FILES-{'ARTIFACTS.sha256'},'artifact index file set differs')
    index = decode(raw(doc/'evidence-index.json')); contents,sources = archive_gate(doc,index)
    require(bool(plan.required_retained_sources), 'explicit prior-failure/source retention pins required')
    for name,pin in plan.required_retained_sources.items():
        require(name in sources and sources[name]['bytes'] == pin.bytes and sources[name]['sha256'] == pin.sha256,'required historical source/receipt absent or changed')
    report = decode(raw(doc/'report.json')); summary = report_gate(report,plan,contents)
    receipt = decode(raw(doc/'generation-receipt.json'))
    require(receipt['outcome'] == 'passed' and receipt['generator_sha256'] == GENERATOR and receipt['report_status'] == report['status']
            and receipt['qualified_cells'] == report['qualified_cells'] and receipt['eligible_final_DONE'] == report['eligible_final_DONE']
            and receipt['archive_sha256'] == index['archive_sha256'] and receipt['evidence_members'] == len(sources),'generation receipt differs')
    for name in ('README.md','REPORT.md'):
        text = raw(doc/name).decode()
        require('array-explode / union' in text and 'shared Morrobay' in text
                and 'No absolute-performance, multihost or full-WCC performance claim' in text
                and 'lifetime cgroup' in text and 'n=4' in text and 'overlap' in text and '60/60' in text, 'publication scope disclosure absent')
        for contrast in report['contrasts']:
            blocks = contrast['blocks']
            line = f"| {contrast['dataset']} | {contrast['shape']} | {contrast['median_array_over_union'] if blocks else 'withheld'} | {blocks[0]['array_over_union'] if blocks else '—'} | {blocks[1]['array_over_union'] if blocks else '—'} | {contrast['ratio_status']} |"
            require(text.count(line) == 1,'published ratio table differs from recomputed report')
        if name == 'REPORT.md':
            for row in report['cells']:
                step = row['step']
                line = f"| {step['run_id']} | {step['role']} / {step['measured_block'] or '—'} | {' / '.join(str(v) for v in row['outcomes'].values())} | {row['timing_diagnostics']['launch_to_exit_seconds']} | {row['qualified']} |"
                require(text.count(line) == 1,'published planned outcome differs')
        if not report['eligible_final_DONE']:
            require(not re.search(rb'\b(?:DONE\s+B8|B8\s+DONE)\b',current[len(parent):]), 'partial evidence claims final DONE')
    require(not list(target.iterdir()),'metadata gate target is not empty')
    after = state(worktree,commit,plan,commands); files_after = candidate_files(worktree,plan)
    require(before == after and files_before == files_after,'candidate changed during gate')
    return {'outcome':'passed_exact_detached_B8_publication_metadata_gate','before':before,'after':after,
            'files':{n:p.model_dump() for n,p in files_after.items()},'archive_members':len(sources),
            'archive_sha256':index['archive_sha256'],'target':str(target),'scope':'retained receipt/metadata audit only; no physical payload, oracle rerun, engine or Docker','summary':summary}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worktree',type=Path,required=True); parser.add_argument('--expected-commit',required=True)
    parser.add_argument('--plan',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args(); worktree = args.worktree.resolve(); output = args.out.resolve()
    record: Json = {'started_utc':datetime.now(UTC).isoformat(),'outcome':'error','commands':[]}
    code = 1
    try:
        require(not output.exists() and not output.is_relative_to(worktree) and re.fullmatch(COMMIT,args.expected_commit) is not None,'fresh external receipt/full commit required')
        initial = raw(args.plan); plan = Plan.model_validate(decode(initial))
        record.update(helper=pin_file(Path(__file__)).model_dump(),plan_sha256=sha(initial),expected_commit=args.expected_commit)
        record.update(execute(worktree,args.expected_commit,plan,record['commands'],output))
        require(raw(args.plan) == initial,'gate plan changed'); code = 0
    except (ValueError,TypeError,KeyError,IndexError,OSError,subprocess.SubprocessError,tarfile.TarError) as error:
        record.update(outcome='error',error=f'{type(error).__name__}: {error}')
    record['finished_utc'] = datetime.now(UTC).isoformat()
    if output.exists() or output.is_relative_to(worktree):
        print(json.dumps(record),file=sys.stderr); return 1
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x') as stream:
        json.dump(record,stream,indent=2,sort_keys=True,allow_nan=False); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    descriptor = os.open(output.parent,os.O_RDONLY)
    try:
        try:
            os.fsync(descriptor)
        except OSError as error:
            if error.errno not in {errno.EINVAL,errno.ENOTSUP}:
                raise
    finally:
        os.close(descriptor)
    print(f'B8_PUBLICATION_GATE {record["outcome"]} receipt={output}')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
