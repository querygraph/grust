"""Bounded config-only controls; no Parquet data, Docker, engines or real locks."""
from __future__ import annotations

import importlib
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any
from unittest.mock import patch

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_prepare as preparation

SUPPORT = core.BASE/'support'
sys.path.insert(0, str(SUPPORT))
QUEUE: Any = importlib.import_module('run_pair_queue')
HOST: Any = importlib.import_module('run_shapes_host')
BASE = core.BASE


class DerivationFixture:
    def __init__(self, root: Path) -> None:
        self.deadline = core.Deadline.after(60)
        self.config: Any = QUEUE.QueueConfig.model_validate(core.read(BASE/'generated-queues02/queue-graph500-24.json', self.deadline))
        self.campaign: Any = HOST.Campaign.model_validate(core.read(self.config.campaign.path, self.deadline))
        self.plan: Any = QUEUE.Plan.model_validate(core.read(self.config.plan.path, self.deadline))
        old_index = QUEUE.ConfigIndex.model_validate(core.read(self.config.config_index.path, self.deadline))
        self.base = root/'base'
        self.base.mkdir()
        self.config = self.config.model_copy(update={'host_root': self.base, 'output': self.base/'queue-original'})
        self.dest = self.base/'preparation'
        self.dest.mkdir()
        originals = root/'original-configs'
        originals.mkdir()
        files: dict[str, Any] = {}
        self.original_pins: list[models.FilePin] = []
        self.references: dict[str, models.Json] = {}
        for step in self.plan.steps:
            p = originals/(step.run_id+'.json')
            values = core.read(old_index.files[step.run_id].path, self.deadline)
            core.write(p, values, fresh=True)
            actual = core.pin(p, self.deadline)
            self.original_pins.append(actual)
            files[step.run_id] = QUEUE.FilePin.model_validate(actual.model_dump())
            self.references[step.dataset] = {'config': {'output': values['references'], 'vertices': values['vertices'], 'edges': values['edges']}}
        self.index: Any = QUEUE.ConfigIndex.model_validate({**old_index.model_dump(mode='json'),
            'files': {k: v.model_dump(mode='json') for k, v in files.items()}})
        self.frozen = core.Frozen(QUEUE, HOST, None, self.deadline, [])

    def derive(self) -> tuple[Any, list[models.Mapping]]:
        with patch.object(core, 'BASE', self.base):
            return preparation.derive(self.frozen, self.config, self.campaign, self.plan, self.index,
                self.references, self.dest, 'queue-graph500-tail01')


class DerivationControls(unittest.TestCase):
    def test_exact29_output_only_configs_and_original31_entries_unchanged(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = DerivationFixture(Path(directory))
            config, mappings = f.derive()
            self.assertEqual(len(mappings), 29)
            new_plan = QUEUE.Plan.model_validate(core.read(config.plan.path, f.deadline))
            self.assertEqual(new_plan.steps[:31], f.plan.steps[:31])
            self.assertEqual(len(new_plan.steps), 60)
            for mapping in mappings:
                before = core.read(mapping.original_config.path, f.deadline)
                after = core.read(mapping.actual_config.path, f.deadline)
                self.assertEqual({k:v for k,v in before.items() if k != 'output'}, {k:v for k,v in after.items() if k != 'output'})
                self.assertEqual(after['output'], f.campaign.guest_root+'/cells/'+mapping.actual.run_id)
                self.assertEqual(mapping.actual.run_id, 'b8-tail01-'+mapping.original.run_id.removeprefix('b8-'))
            for pin in f.original_pins:
                core.verify(pin, f.deadline)

    def test_already_attempted_original_id_refused(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = DerivationFixture(Path(directory))
            (f.base/f.plan.steps[31].run_id).mkdir()
            with self.assertRaisesRegex(ValueError, 'existing run directory'):
                f.derive()
            self.assertFalse((f.dest/'plan.json').exists())

    def test_already_attempted_actual_id_refused(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = DerivationFixture(Path(directory))
            (f.base/('b8-tail01-'+f.plan.steps[31].run_id.removeprefix('b8-')+'.host.log')).write_text('prior')
            with self.assertRaisesRegex(ValueError, 'existing run log'):
                f.derive()

    def test_changed_original_config_pin_refused(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = DerivationFixture(Path(directory))
            f.index.files[f.plan.steps[31].run_id].path.write_text('{}')
            with self.assertRaisesRegex(ValueError, 'immutable pin'):
                f.derive()

    def test_repeat_derivation_refuses_existing_files(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = DerivationFixture(Path(directory))
            f.derive()
            original = (f.dest/'plan.json').read_bytes()
            with self.assertRaisesRegex(ValueError, 'existing output'):
                f.derive()
            self.assertEqual((f.dest/'plan.json').read_bytes(), original)

    def test_existing_global_gate_or_serial_refuses_admission(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base = root/'base'
            base.mkdir()
            for name in ('gate.lock', 'serial-queue.lock'):
                lock = root/name
                lock.mkdir()
                with patch.object(core, 'BASE', base), self.assertRaisesRegex(ValueError, 'still present'):
                    preparation.assert_no_locks()
                lock.rmdir()

    def test_source_dependency_pins_are_original_frozen_bytes(self) -> None:
        values = preparation.own_sources(core.Deadline.after(10))
        self.assertEqual(values[0].sha256, preparation.CORE_SHA)
        self.assertEqual(values[1].sha256, preparation.MODELS_SHA)


if __name__ == '__main__':
    unittest.main()
