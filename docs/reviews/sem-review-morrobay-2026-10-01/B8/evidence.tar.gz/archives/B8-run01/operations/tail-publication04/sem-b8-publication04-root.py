"""Root-invoked B8 metadata publication04 and exact candidate03 preparation."""
from __future__ import annotations

import argparse
import hashlib
import os
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Literal, Self

import sem_b8_tail_core as core
import sem_b8_tail_models as models
from pydantic import Field, model_validator

PARENT = '4179b938a45c994db103574b6a47f1e6b103ea17'
DOC = Path('docs/reviews/sem-review-morrobay-2026-10-01/B8')
FILES = ('ARTIFACTS.sha256','README.md','REPORT.md','evidence-index.json',
         'evidence.tar.gz','generation-receipt.json','report.json')
PATHS = sorted([str(DOC/name) for name in FILES]+['codex-to-codex.md'])
MAXIMUM = 64*2**20


class Recipe(models.Record):
    schema_version: Literal[1] = 1
    parent: Literal['4179b938a45c994db103574b6a47f1e6b103ea17']
    repo: Path
    base: Path
    operation: Path
    destination: Path
    workspace_parent: Path
    python: Path
    helper: models.FilePin
    sources: list[models.FilePin]
    initial_files: dict[str,models.Identity]
    initial_index_tree: str = Field(pattern=r'^[a-f0-9]{40}$')
    generation_argv: list[str]
    prior_destinations: list[Path]
    required_retained_sources: dict[str,models.Identity]
    commit_message: str

    @model_validator(mode='after')
    def fixed_surface(self) -> Self:
        if sorted(self.initial_files) != PATHS or len(self.prior_destinations) != 3:
            raise ValueError('exact eight initial paths and three prior generation bases required')
        if self.operation != self.base/'operations/tail-publication04':
            raise ValueError('fresh fixed operation04 namespace required')
        if self.destination.is_relative_to(self.base) or self.destination.is_relative_to(self.repo):
            raise ValueError('external fresh generation destination required')
        if self.helper.path != self.operation/'sem-b8-publication04-root.py':
            raise ValueError('exact root workflow helper path required')
        return self


def data(path: Path, deadline: core.Deadline) -> bytes:
    deadline.check()
    core.require(path.is_absolute() and not path.is_symlink() and path.is_file()
                 and path.stat().st_size <= MAXIMUM, 'bounded regular metadata/source read required: '+str(path))
    chunks: list[bytes] = []
    size = 0
    with path.open('rb') as stream:
        while chunk := stream.read(2**20):
            deadline.check()
            size += len(chunk)
            core.require(size <= MAXIMUM, 'metadata/source read exceeded bound')
            chunks.append(chunk)
    deadline.check()
    return b''.join(chunks)


def identity(value: bytes) -> models.Identity:
    return models.Identity(bytes=len(value),sha256=hashlib.sha256(value).hexdigest())


def file_pin(path: Path, deadline: core.Deadline) -> models.FilePin:
    return models.FilePin(path=path,**identity(data(path,deadline)).model_dump())


def observe(recipe: Recipe, deadline: core.Deadline) -> None:
    core.require(file_pin(Path(__file__).resolve(),deadline) == recipe.helper, 'root workflow helper changed')
    for pin in recipe.sources:
        core.require(file_pin(pin.path,deadline) == pin, 'frozen operation source/evidence changed: '+str(pin.path))


def git(recipe: Recipe, deadline: core.Deadline, *args: str, stdin: bytes | None = None) -> bytes:
    deadline.check()
    result = subprocess.run(['git','-C',str(recipe.repo),*args],input=stdin,capture_output=True,
                            timeout=deadline.remaining(),check=False)
    core.require(result.returncode == 0, 'git command refused '+repr(args)+': '+result.stderr.decode(errors='replace'))
    return result.stdout


def initial_state(recipe: Recipe, deadline: core.Deadline) -> None:
    observe(recipe,deadline)
    core.require(git(recipe,deadline,'rev-parse','HEAD').decode().strip() == recipe.parent, 'parent HEAD moved')
    core.require(git(recipe,deadline,'diff','--cached','--name-only','-z').decode().split('\0')[:-1] == PATHS,
                 'initial staged paths are not exactly eight')
    core.require(not git(recipe,deadline,'diff','--name-only'), 'unstaged tracked changes appeared')
    core.require(git(recipe,deadline,'write-tree').decode().strip() == recipe.initial_index_tree, 'initial index tree changed')
    for name,pin in recipe.initial_files.items():
        current = identity(data(recipe.repo/name,deadline))
        indexed = identity(git(recipe,deadline,'show',':'+name))
        core.require(current == indexed == pin, 'initial file/index changed: '+name)


def launch_generation(recipe: Recipe, deadline: core.Deadline) -> models.Json:
    initial_state(recipe,deadline)
    core.require(not recipe.destination.exists() and not recipe.destination.is_symlink(), 'generation04 destination reused')
    launch = recipe.operation/'generation04.launch.json'
    log = recipe.operation/'generation04.log'
    core.require(not launch.exists() and not log.exists(), 'generation04 launch ID reused')
    with log.open('xb') as stream:
        child = subprocess.Popen(recipe.generation_argv,stdout=stream,stderr=subprocess.STDOUT,
                                 start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        result: models.Json = {'observed_utc':core.utc(),'pid':child.pid,'argv':recipe.generation_argv,
            'log':str(log),'scope':'Root metadata-only generation04; all generation01–03 and failed candidates retained',
            'root_workflow_helper':recipe.helper.model_dump(mode='json'),'start_new_session':True}
        core.write(launch,result,fresh=True)
    return result


def generation_closed(recipe: Recipe, deadline: core.Deadline) -> models.Json:
    launch = core.read(recipe.operation/'generation04.launch.json',deadline)
    core.require(launch['argv'] == recipe.generation_argv, 'generation launch command differs')
    try:
        os.kill(launch['pid'],0)
    except ProcessLookupError:
        pass
    else:
        raise ValueError('generation child is still present; candidate preparation refused')
    receipt = core.read(recipe.destination/'generation-receipt.json',deadline)
    report = core.read(recipe.destination/'report.json',deadline)
    core.require(receipt['outcome'] == 'passed' and receipt['qualified_cells'] == 40
                 and report['qualified_cells'] == 40 and report['attempted_cells'] == 44 and report['skipped_cells'] == 16
                 and report['all60_qualified'] is report['all60_attempted'] is False
                 and report['protocol_outcome'] == 'completed_with_failures'
                 and report['protocol_finished_terminal_evidence'] is True, 'generation04 final scope/outcome differs')
    provenance = report['tail_publication_provenance']
    core.require(provenance['publisher_wrapper']['sha256'] == 'f9c85a8b262d1dd645b1f9547b6a7da7b7a3c8893fc32c6328fa43a5c8b4f390'
                 and provenance['publication_gate']['sha256'] == '4c1c457634455ab656de13a138f6da08497b5be4affdf51f972cc04327d55c88',
                 'generation wrapper-v6/gate-v4 source pins differ')
    artifacts = data(recipe.destination/'ARTIFACTS.sha256',deadline).decode().splitlines()
    core.require(len(artifacts) == 6, 'generation artifact index differs')
    seen: set[str] = set()
    for line in artifacts:
        digest,name = line.split('  ')
        core.require(name in FILES and name != 'ARTIFACTS.sha256' and name not in seen
                     and file_pin(recipe.destination/name,deadline).sha256 == digest, 'generation artifact SHA differs')
        seen.add(name)
    core.require(seen == set(FILES)-{'ARTIFACTS.sha256'}, 'generation artifact file set differs')
    return report


def verify_index(recipe: Recipe, deadline: core.Deadline) -> None:
    observe(recipe,deadline)
    prep = core.read(recipe.operation/'candidate-preparation03.json',deadline)
    core.require(git(recipe,deadline,'rev-parse','HEAD').decode().strip() == recipe.parent
                 and git(recipe,deadline,'write-tree').decode().strip() == prep['tree'], 'HEAD/index differs from gated candidate')
    plan = core.read(recipe.operation/'candidate-plan03.json',deadline)
    core.require(git(recipe,deadline,'diff','--cached','--name-only','-z').decode().split('\0')[:-1] == PATHS
                 and not git(recipe,deadline,'diff','--name-only'), 'publication stage/working paths changed')
    for name,pin in plan['files'].items():
        expected = models.Identity.model_validate(pin)
        core.require(identity(data(recipe.repo/name,deadline)) == expected
                     and identity(git(recipe,deadline,'show',':'+name)) == expected, 'publication bytes changed: '+name)


def prepare_candidate(recipe: Recipe, deadline: core.Deadline) -> models.Json:
    initial_state(recipe,deadline)
    report = generation_closed(recipe,deadline)
    attempt = recipe.operation/'candidate-preparation-attempt03.json'
    core.write(attempt,{'observed_utc':core.utc(),'outcome':'checking','helper':recipe.helper.model_dump(mode='json')},fresh=True)
    prefix = git(recipe,deadline,'show',recipe.parent+':codex-to-codex.md')
    existing = data(recipe.repo/'codex-to-codex.md',deadline)
    core.require(existing.startswith(prefix), 'existing coordination text does not preserve parent prefix')
    entry = (f"\n\n## {core.utc()} — Codex on Morrobay: B8 truthful publication disclosure\n\n"
        "Generation04 retains generation01–03 and both failed candidate gates. Wrapper v6 changes only the prose sentence to explicitly state that 60/60 qualification and 60/60 attempted calls are false. Gate v4 binds that source and preserves every disclosure, positive-cell, ratio and named closed-OOM predicate. Source-only 25 controls, Ruff and strict mypy passed. B8 protocol completed_with_failures: 40/60 qualified; 44/60 attempted; 16 skipped; 2 ratios withheld. No engine cell, timer, input, resource setting or raw receipt changed. Actual detached candidate and committed gates remain required before publication.\n").encode()
    core.require(not any(line.startswith((b'<<<<<<<',b'=======',b'>>>>>>>')) for line in (existing+entry).splitlines()),
                 'coordination conflict marker found')
    for name in FILES:
        shutil.copyfile(recipe.destination/name,recipe.repo/DOC/name)
    with (recipe.repo/'codex-to-codex.md').open('ab') as stream:
        stream.write(entry);stream.flush();os.fsync(stream.fileno())
    core.write(recipe.operation/'codex-entry03.json',{'observed_utc':core.utc(),'entry':entry.decode(),
        'previous_identity':identity(existing).model_dump(mode='json')},fresh=True)
    git(recipe,deadline,'add','--',*PATHS)
    git(recipe,deadline,'diff','--cached','--check')
    core.require(git(recipe,deadline,'diff','--cached','--name-only','-z').decode().split('\0')[:-1] == PATHS,
                 'stage differs from exact eight paths')
    tree = git(recipe,deadline,'write-tree').decode().strip()
    candidate = git(recipe,deadline,'commit-tree',tree,'-p',recipe.parent,'-m','B8 publication candidate03; no branch mutation').decode().strip()
    worktree = recipe.workspace_parent/('b8-final-tail-candidate03-'+candidate[:10])
    core.require(not worktree.exists(), 'candidate03 worktree reused')
    git(recipe,deadline,'worktree','add','--detach',str(worktree),candidate)
    index = core.read(recipe.destination/'evidence-index.json',deadline)
    members = {r['retained_source']:models.Identity(bytes=r['bytes'],sha256=r['sha256']) for r in index['members']}
    for path,pin in recipe.required_retained_sources.items():
        core.require(members.get(path) == pin, 'prior failed source/log/receipt absent or changed: '+path)
    files = {name:identity(data(recipe.repo/name,deadline)).model_dump(mode='json') for name in PATHS}
    current = data(recipe.repo/'codex-to-codex.md',deadline)
    pin = report['tail_publication_provenance']['derived_plan']
    plan: models.Json = {'tree':tree,'parent':recipe.parent,'files':files,'base':str(recipe.base),
        'benchmark_plan':{k:pin[k] for k in ('bytes','sha256')},
        'required_retained_sources':{p:v.model_dump(mode='json') for p,v in recipe.required_retained_sources.items()},
        'codex_parent_sha256':identity(prefix).sha256,'codex_append_sha256':identity(current[len(prefix):]).sha256,
        'require_complete':False}
    core.write(recipe.operation/'candidate-plan03.json',plan,fresh=True)
    result: models.Json = {'observed_utc':core.utc(),'candidate':candidate,'tree':tree,'parent':recipe.parent,
        'worktree':str(worktree),'plan_sha256':file_pin(recipe.operation/'candidate-plan03.json',deadline).sha256,
        'indexed_metadata_members':len(members),'required_retained_sources':len(recipe.required_retained_sources),
        'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes']}
    core.write(recipe.operation/'candidate-preparation03.json',result,fresh=True)
    verify_index(recipe,deadline)
    gate_args = [str(recipe.python),'-B',str(recipe.operation/'sem-B8-tail-publication-gate-v4.py'),
        '--worktree',str(worktree),'--expected-commit',candidate,'--plan',str(recipe.operation/'candidate-plan03.json'),
        '--out',str(recipe.operation/'candidate-gate03.json')]
    recipe_pin = file_pin(recipe.operation/'workflow-recipe.json',deadline)
    verify_args = [str(recipe.python),'-B',str(recipe.helper.path),'--recipe',str(recipe_pin.path),
                   '--recipe-sha256',recipe_pin.sha256,'verify-index']
    chain = '#!/bin/sh\nset -eu\nexport PYTHONDONTWRITEBYTECODE=1\n'+ ' &&\n'.join([
        shlex.join(gate_args),shlex.join(['git','-C',str(recipe.repo),'diff','--cached','--check']),
        shlex.join(verify_args),shlex.join(['git','-C',str(recipe.repo),'commit','-m',recipe.commit_message])])+'\n'
    with (recipe.operation/'candidate-gate-and-commit03.sh').open('x') as stream:
        stream.write(chain);stream.flush();os.fsync(stream.fileno())
    observe(recipe,deadline)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--recipe',type=Path,required=True)
    parser.add_argument('--recipe-sha256',required=True)
    parser.add_argument('action',choices=('launch-generation','prepare-candidate','verify-index'))
    args = parser.parse_args()
    deadline = core.Deadline.after(1800)
    raw = data(args.recipe.resolve(),deadline)
    core.require(identity(raw).sha256 == args.recipe_sha256, 'root recipe SHA differs')
    recipe = Recipe.model_validate_json(raw)
    result: models.Json
    if args.action == 'launch-generation':
        result = launch_generation(recipe,deadline)
    elif args.action == 'prepare-candidate':
        result = prepare_candidate(recipe,deadline)
    else:
        verify_index(recipe,deadline)
        result = {'outcome':'passed_exact_index_working_bytes_and_parent_checks','observed_utc':core.utc()}
    print(result)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
