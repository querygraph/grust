"""Metadata-only generator wrapper installing the B8 host closure adapter.

--frozen-generator PATH --adapter PATH --adapter-sha256 HEX, followed by the
unchanged frozen generator CLI. Generated guest/config/plan bytes use the original
functions. Preparation receipt adds wrapper and named closure adapter provenance.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import pathlib
import sys
from collections.abc import Callable
from types import ModuleType
from typing import Any, cast

import pydantic

GENERATOR_SHA = '504c0127e4897c9f5d74c7d89680b0a25ecc5680a1cdb40976def8fcfcb50ce9'
VERSION = 'b8-metadata-generator-host-closure-v2'


class FilePin(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra='forbid', frozen=True)
    path: pathlib.Path
    bytes: int = pydantic.Field(ge=0)
    sha256: str = pydantic.Field(pattern=r'^[a-f0-9]{64}$')


class Options(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra='forbid', frozen=True)
    frozen_generator: pathlib.Path
    adapter: pathlib.Path
    adapter_sha256: str = pydantic.Field(pattern=r'^[a-f0-9]{64}$')


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def pin(path: pathlib.Path) -> FilePin:
    require(path.is_absolute() and path.is_file() and not path.is_symlink(), 'absolute regular host helper')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return FilePin(path=path, bytes=path.stat().st_size, sha256=digest)


def module(path: pathlib.Path, name: str, expected_sha256: str) -> ModuleType:
    before = pin(path)
    require(before.sha256 == expected_sha256, 'verified host source before import: ' + name)
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, 'host helper import loader')
    assert spec is not None and spec.loader is not None
    loaded = importlib.util.module_from_spec(spec)
    sys.modules[name] = loaded
    spec.loader.exec_module(loaded)
    require(pin(path) == before, 'host source changed on import: ' + name)
    return loaded


def install_generator(original: ModuleType, options: Options) -> None:
    original_load = cast(Callable[[object], ModuleType], original.load_queue)
    installed: ModuleType | None = None

    def load_queue(arguments: object) -> ModuleType:
        nonlocal installed
        require(installed is None, 'generator adapter installs once; no retries')
        queue = original_load(arguments)
        existing = sys.modules.get('run_pair_queue')
        require(existing is None or existing is queue, 'another queue module already loaded')
        sys.modules['run_pair_queue'] = queue
        adapter = module(options.adapter, 'pinned_b8_host_closure_adapter_v2', options.adapter_sha256)
        result: Any = adapter.install(queue, options.adapter_sha256)
        require(result is queue, 'adapter must preserve the original queue module')
        installed = adapter
        receipt_type = cast(type[pydantic.BaseModel], original.Preparation)
        extended = pydantic.create_model(
            'PreparationHostClosureV2', __base__=receipt_type,
            closure_adapter=(cast(type[pydantic.BaseModel], adapter.Provenance), pydantic.Field(default_factory=adapter.provenance)),
            generator_wrapper=(FilePin, pydantic.Field(default_factory=lambda: pin(pathlib.Path(__file__).resolve()))),
            generator_wrapper_version=(str, VERSION),
        )
        original.__dict__['Preparation'] = extended
        return queue

    original.__dict__['load_queue'] = load_queue


def main() -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--frozen-generator', type=pathlib.Path, required=True)
    parser.add_argument('--adapter', type=pathlib.Path, required=True)
    parser.add_argument('--adapter-sha256', required=True)
    arguments, remaining = parser.parse_known_args()
    options = Options.model_validate(vars(arguments))
    require('queues' in remaining, 'this host correction is for fresh queue preparation only')
    original = module(options.frozen_generator, 'frozen_b8_metadata_generator', GENERATOR_SHA)
    install_generator(original, options)
    sys.argv = [str(options.frozen_generator), *remaining]
    result = original.main()
    require(isinstance(result, int), 'generator exit code')
    return cast(int, result)


if __name__ == '__main__':
    raise SystemExit(main())
