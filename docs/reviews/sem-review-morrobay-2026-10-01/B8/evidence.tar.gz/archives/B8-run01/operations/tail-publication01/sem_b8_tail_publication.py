"""Finite metadata I/O and declared tail views; frozen positive predicates unchanged."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import io
import json
import os
import re
import sys
import tarfile
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from types import ModuleType
from typing import Any, cast

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_publication_models_v2 as schema

PUBLISHER = '6a5e76f1e549cbbf7e5b19e680059d2f1c960808a0c86ce9011409043ae30937'
HOST_WRAPPER = '6420a71cdd971cc42d09ba5be6be4d98e4ad8c6b4d0a713985e2205376f10408'
GATE = '703a3832648b538ea67cc170c145ca69a2ccbd9aedc7b1e6a8a96f7cbc216fa7'
HOST_GATE = '1f51104259f5cfb27f0dbba588d481cd9ea441560e64b25aae3e95fc6e0f413d'
CORE = 'd2a6586df48fc4f00e0afb8a427db375f41f1ea773cf16d76adf4e1108822277'
MODELS = '5b984d9d5c5c51999b2943fdd316216b29aea11d4e8c658fa07c5f8947d0c44b'
PUB_MODELS = 'c3ee1875f8e80f351a41e425a82e9dd21c6988b8afc4633475187a6ceb6b0e77'
RUNNER = '39b878c330b14597020760698712ae05b8d6b92d828c5cf7ebc899b685a2af7a'
RUN_CLI = 'bb23b19b9ea4496c0915a592f8eacc5ba35bb2498a805cc1b3d5944d18d5fc12'
PREP = 'a48805d3cb0c9ed0917cedf3496e29018b63674ce1cdbb8c62f6e491e4ca000b'
PREP_CLI = '58cd473ea1600fcaa81de88a649e6cac3028865f7ad655f650d007c284756e3c'
AUDIT_CLI = '05db2e3028924e8c9e24e48d5e734b7214e3ad6028b5002e9108803288b31670'
ALLOWED = {'.json', '.jsonl', '.log', '.py', '.md', '.sha256', '.txt'}
EXCLUDED = {'result', 'staging', '__pycache__', '.git', '.mypy_cache', '.ruff_cache'}
LIMIT = 64*2**20
CHUNK = 2**20
Reader = Callable[[Path], bytes]

DISCLOSURE = ('The original Graph500 adjacency union warmup genuinely OOMed at the unchanged 32 GiB limit. '
    'The root-reviewed serial tail used fresh IDs and changed only config output paths; algorithms, inputs, '
    'resources and engine timers are unchanged. Both real warmups must qualify before that contrast’s '
    'measured calls. Failed warmups cause explicit not_started_due_to_failed_warmup rows with no synthetic '
    'PID, oracle or timing. Failed/skipped rows never enter ratios. Raw receipts are unchanged. A declared '
    'in-memory queue projection delegates passed cells to the unchanged frozen positive metadata predicates. '
    'All 31 original outcomes, mappings, controller/authorization/closure/lock evidence remain indexed. '
    'The original OOM prevents all 60 qualification and all 60 attempted calls under the warmup policy; the protocol can finish with closed failures/skips retained. The allocation cause remains unexplained. Packaging uses a finite '
    'per-chunk metadata deadline; physical payload manifests remain on Apo and are not rehashed here.')


def decode(data: bytes) -> models.Json:
    def pairs(values: list[tuple[str, Any]]) -> models.Json:
        result: models.Json = {}
        for key, value in values:
            core.require(key not in result, 'duplicate metadata JSON key')
            result[key] = value
        return result
    value: Any = json.loads(data, object_pairs_hook=pairs,
        parse_constant=lambda _v: (_ for _ in ()).throw(ValueError('nonfinite metadata JSON')))
    core.require(isinstance(value, dict), 'metadata object required')
    return cast(models.Json, value)


@dataclass(slots=True)
class IO:
    deadline: core.Deadline

    def read(self, path: Path) -> bytes:
        self.deadline.check()
        core.require(path.is_absolute() and (path.suffix in ALLOWED or path.name == 'evidence.tar.gz') and path.is_file() and not path.is_symlink()
                     and '..' not in path.parts and path.stat().st_size <= LIMIT, 'bounded regular metadata read')
        before = path.stat()
        chunks: list[bytes] = []
        count = 0
        with path.open('rb') as stream:
            while chunk := stream.read(CHUNK):
                self.deadline.check()
                count += len(chunk)
                core.require(count <= LIMIT, 'metadata grew beyond bound')
                chunks.append(chunk)
        after = path.stat()
        core.require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns),
                     'metadata changed while reading')
        self.deadline.check()
        return b''.join(chunks)

    def pin(self, path: Path) -> models.FilePin:
        data = self.read(path)
        return models.FilePin(path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

    def archive_pin(self, path: Path) -> models.FilePin:
        return core.pin(path, self.deadline)


def checked(expected: models.FilePin, read: Reader) -> bytes:
    data = read(expected.path)
    core.require(len(data) == expected.bytes and hashlib.sha256(data).hexdigest() == expected.sha256,
                 'metadata source pin changed: '+str(expected.path))
    return data


def json_pin(expected: models.FilePin, read: Reader) -> models.Json:
    return decode(checked(expected, read))


def metadata_pins(values: list[models.FilePin], read: Reader) -> None:
    for value in values:
        if value.path.suffix in ALLOWED:
            checked(value, read)


def source_module(path: Path, expected: str, name: str, io_state: IO) -> ModuleType:
    before = io_state.pin(path)
    core.require(before.sha256 == expected, 'exact frozen module source')
    spec = importlib.util.spec_from_file_location(name, path)
    core.require(spec is not None and spec.loader is not None, 'source module loader')
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    core.require(io_state.pin(path) == before, 'source changed while importing')
    return module


def function_pin(source: models.FilePin, name: str, read: Reader) -> schema.FunctionPin:
    text = checked(source, read).decode()
    parsed = ast.parse(text)
    matches = [n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == name]
    core.require(len(matches) == 1 and matches[0].end_lineno is not None, 'unique frozen function source')
    node = matches[0]
    assert node.end_lineno is not None
    data = ''.join(text.splitlines(keepends=True)[node.lineno-1:node.end_lineno]).encode()
    return schema.FunctionPin(source=source, function=name, function_sha256=hashlib.sha256(data).hexdigest(),
        function_bytes=len(data), delegation='Original function body is imported unchanged; typed adapter validates metadata before delegation.')


def plan_and_mapping(prepared: models.Prepared, config: schema.NativeQueueConfig, read: Reader) -> None:
    old = json_pin(prepared.original_plan, read)
    derived = json_pin(prepared.derived_plan, read)
    core.require({k:v for k,v in old.items() if k != 'steps'} == {k:v for k,v in derived.items() if k != 'steps'}
                 and len(old['steps']) == len(derived['steps']) == 60 and old['steps'][:31] == derived['steps'][:31]
                 and prepared.original_failed_step.model_dump(mode='json') == old['steps'][30]
                 and len(prepared.mappings) == 29 and config.plan == prepared.derived_plan,
                 'original31/derived60 plan preservation')
    original_config = schema.NativeQueueConfig.model_validate(json_pin(prepared.original_queue_config, read))
    original_index = json_pin(original_config.config_index, read)
    derived_index = json_pin(config.config_index, read)
    core.require(original_config.plan == prepared.original_plan
                 and {k:v for k,v in original_config.model_dump(mode='json').items() if k not in {'output','plan','config_index'}}
                 == {k:v for k,v in config.model_dump(mode='json').items() if k not in {'output','plan','config_index'}},
                 'derived queue changed source/input/profile fields')
    core.require(set(original_index['files']) == {s['run_id'] for s in old['steps']}
                 and set(derived_index['files']) == {s['run_id'] for s in derived['steps']}, 'exact complete config index rosters')
    for field in ('driver','campaign','support_manifest'):
        core.require(original_index[field] == derived_index[field] == config.model_dump(mode='json')[field], 'unchanged index source pin')
    core.require(original_index['plan'] == prepared.original_plan.model_dump(mode='json')
                 and derived_index['plan'] == prepared.derived_plan.model_dump(mode='json'), 'exact index plan source pin')
    for step in old['steps'][:31]:
        core.require(original_index['files'][step['run_id']] == derived_index['files'][step['run_id']], 'original31 config pin changed')
    guest = json_pin(config.campaign, read)['guest_root']
    for mapping, old_step, actual in zip(prepared.mappings, old['steps'][31:], derived['steps'][31:], strict=True):
        core.require(mapping.original.model_dump(mode='json') == old_step and mapping.actual.model_dump(mode='json') == actual
                     and actual['run_id'] == 'b8-tail01-'+old_step['run_id'].removeprefix('b8-')
                     and {k:v for k,v in old_step.items() if k != 'run_id'} == {k:v for k,v in actual.items() if k != 'run_id'}
                     and original_index['files'][old_step['run_id']] == mapping.original_config.model_dump(mode='json')
                     and derived_index['files'][actual['run_id']] == mapping.actual_config.model_dump(mode='json'),
                     'exact original-to-fresh mapping/source pins')
        before, after = json_pin(mapping.original_config, read), json_pin(mapping.actual_config, read)
        core.require({k:v for k,v in before.items() if k != 'output'} == {k:v for k,v in after.items() if k != 'output'}
                     and before['output'] == guest+'/cells/'+mapping.original.run_id
                     and after['output'] == guest+'/cells/'+mapping.actual.run_id, 'output-only actual config difference')


def archived_owner(expected: models.FilePin, directory: Path, read: Reader) -> models.FilePin:
    p = directory/'owner.json'
    data = read(p)
    actual = models.FilePin(path=p, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    core.require(actual.identity() == expected.identity(), 'preserved owned-lock bytes differ')
    return actual


def closure_evidence(expected: models.FilePin, read: Reader, base: Path, run_id: str,
                     config_pin: models.FilePin, gate_archive: Path | None) -> tuple[models.FailureClosure, models.FilePin | None]:
    value = models.FailureClosure.model_validate(json_pin(expected, read))
    core.require(value.run_id == run_id and value.gate_owner.run_id == run_id
                 and value.gate_owner.pid == value.host_child_pid and value.gate_owner.host == str(base/run_id)
                 and config_pin in value.evidence_pins
                 and value.raw_outcomes == {'host':'error','producer':'oom','bootstrap':'checking','engine':'error',
                    'engine_returncode':1,'container_exit':1,'container_oom_killed':True,
                    'supervisor_configured_method_label': value.raw_outcomes['supervisor_configured_method_label'],
                    'engine_actual_method': value.raw_outcomes['engine_actual_method']}, 'named natural OOM scope/raw outcomes')
    metadata_pins(value.source_pins+value.evidence_pins, read)
    host = decode(read(base/run_id/'result.json'))
    producer = decode(read(base/run_id/'container/artifacts/receipt.json'))
    boot = decode(read(base/run_id/'container/artifacts/bootstrap-receipt.json'))
    engine = decode(read(base/run_id/'container/artifacts/engine/engine-receipt.json'))
    separate = decode(read(base/run_id/'container-record.json'))
    embedded = host['records']['container']
    config = json_pin(config_pin,read)
    actual_method = (('min-label-whole-update-left-join-array-explode' if config['variant'] == 'array-explode'
        else 'min-label-labels-union-messages') if config['shape'] == 'min-label-initial-round'
        else config['shape']+'-'+config['variant'])
    core.require(value.raw_outcomes['supervisor_configured_method_label'] == config['shape']+':'+config['variant']
                 and value.raw_outcomes['engine_actual_method'] == actual_method
                 and producer['engine_receipt'] == engine and engine['outcome'] == 'error'
                 and boot['outcome'] == 'checking' and boot['producer_returncode'] == 1
                 and boot['identities_before'] == boot['identities_after'], 'failed exact engine/config/source metadata differs')
    absence = embedded['absence_verified']
    core.require(isinstance(absence,dict) and absence.get('returncode') == 1
                 and re.search(r'(?:no such object|no such container):\s*'+re.escape('sem-review-b8-'+run_id)+r'(?:\s|$)',
                     absence.get('stderr',''),re.IGNORECASE) is not None
                 and {k:v for k,v in embedded.items() if k != 'absence_verified'}
                     == {k:v for k,v in separate.items() if k != 'absence_verified'}
                 and ('absence_verified' not in separate or separate['absence_verified'] == absence),
                 'failed container absence/record equality differs')
    state = separate['inspect']['state']
    created = separate['create']['stdout'].strip()
    core.require(created == separate['inspect']['id'] and re.fullmatch(r'[a-f0-9]{64}',created) is not None
                 and state['Running'] is False and state['Paused'] is False and state['ExitCode'] == 1
                 and state['OOMKilled'] is True and not state['Error']
                 and state['Pid'] == 0 and state['Dead'] is False and state['Restarting'] is False
                 and separate['create']['returncode'] == separate['remove']['returncode'] == separate['copied']['artifacts']['returncode'] == 0
                 and separate['attach_returncode'] == 1
                 and not any(separate.get(k) for k in ('transport_errors','outer_timeout','kill','forced_cleanup_kill','operator_interrupted')),
                 'failed natural OOM container closure uncertain')
    limits = separate['inspect']['limits']
    core.require(limits['NanoCpus'] == 16*10**9 and limits['CpusetCpus'] == '0-15'
                 and limits['Memory'] == limits['MemorySwap'] == 32*2**30 and limits['Init'] is True
                 and limits['PidMode'] in ('','private') and limits['PidsLimit'] == 1024,
                 'failed container envelope differs')
    targets = ['sem-review-b8-'+run_id,created]
    core.require(len(value.probes) == 3, 'failed name/id/idle probe roster differs')
    for probe,target in zip(value.probes[:2],targets,strict=True):
        core.require(probe.argv[-2:] == ['inspect',target] and probe.returncode == 1
                     and re.search(r'(?:no such object|no such container):\s*'+re.escape(target)+r'(?:\s|$)',
                         probe.stderr,re.IGNORECASE) is not None, 'named failed container absence uncertain')
    idle = value.probes[2]
    core.require(idle.argv[-2:] == ['ps','-q'] and idle.returncode == 0 and not idle.stdout.strip(), 'failed closure idle uncertain')
    collected = decode(read(base/run_id/'collected-manifest.json'))
    inventory = {k:v.model_dump(mode='json') for k,v in value.physical_inventory.items()}
    core.require(inventory == collected == host['artifacts'] and host['outcome'] == 'error'
                 and host['certain_container_closure'] is True and host['archive_verified'] is True
                 and host['payload_removed'] is False and host['producer_outcome'] == 'oom'
                 and producer['outcome'] == 'oom' and producer['engine_wait_completed'] is True
                 and producer['engine_returncode'] == 1 and producer['ownership_admitted'] is True,
                 'failed full collection/owned wait metadata differs')
    core.require(producer['identities_before'] == producer['identities_after']
                 and producer['identities_before']['native'] == value.native_package_manifest
                 and producer['actual_engine_method'] == value.raw_outcomes['supervisor_configured_method_label']
                 and producer['engine_receipt']['actual_method'] == value.raw_outcomes['engine_actual_method'],
                 'failed source/raw method labels differ')
    for field in ('remaining_processes','remaining_after_cleanup','final_processes','preexisting_processes','emergency_cleanup',
                  'finalization_errors','interruption_signals','observer_error','outer_timeout'):
        core.require(not producer.get(field), 'failure ownership/cleanup uncertain')
    core.require(core.resource_oom(producer) == value.oom_events, 'natural OOM cgroup evidence differs')
    return value, None if gate_archive is None else archived_owner(value.gate_owner_pin, gate_archive, read)


def project_tail(prepared_pin: models.FilePin, authorization_pin: models.FilePin, tail_pin: models.FilePin,
                 read: Reader, base: Path, exists: Callable[[Path],bool] = Path.exists) -> tuple[models.Prepared, models.TailReceipt, schema.QueueProjection, list[schema.CellProjection]]:
    prepared = models.Prepared.model_validate(json_pin(prepared_pin, read))
    authorization = models.Authorization.model_validate(json_pin(authorization_pin, read))
    tail = models.TailReceipt.model_validate(json_pin(tail_pin, read))
    core.require(tail.prepared == prepared_pin and tail.authorization == authorization_pin
                 and tail.outcome == 'completed_with_failures' and bool(tail.finished_utc) and tail.active_child_pid is None
                 and tail.serial_lock_retained is False and tail.serial_lock_archived is not None
                 and not tail.error and not tail.interruption_signals and len(tail.cells) == 29
                 and authorization.original_queue_config == prepared.original_queue_config
                 and authorization.named_failures == {m.actual.run_id:m.actual_config.sha256 for m in prepared.mappings}
                 and tail.original_failed_step == prepared.original_failed_step
                 and tail.original31 == prepared.original31_evidence, 'finalized root-approved known tail scope')
    metadata_pins(prepared.sources+prepared.original31_evidence+tail.sources, read)
    config = schema.NativeQueueConfig.model_validate(json_pin(prepared.queue_config, read))
    core.require(config.host_root == base and config.output == tail_pin.path.parent, 'actual tail config/root/receipt namespace')
    plan_and_mapping(prepared, config, read)
    original_queue = json_pin(prepared.original_graph_queue_receipt, read)
    original_cit = json_pin(prepared.original_cit_queue_receipt, read)
    old_config = schema.NativeQueueConfig.model_validate(json_pin(prepared.original_queue_config, read))
    core.require(original_queue['config'] == old_config.model_dump(mode='json') and original_queue['outcome'] == 'error'
                 and original_queue['cells'][0]['step'] == prepared.original_failed_step.model_dump(mode='json')
                 and len(original_cit['cells']) == 30 and original_cit['outcome'] == 'passed'
                 and original_cit['config']['plan'] == prepared.original_plan.model_dump(mode='json'), 'unaltered original queue/config/plan receipts')
    old_steps = json_pin(prepared.original_plan,read)['steps']
    core.require(len(original_queue['cells']) == 30 and original_queue['finished_utc']
                 and original_queue['active_child_pid'] is None and original_queue['lock_retained'] is True,
                 'retained original Graph queue closure scope differs')
    for pending,step in zip(original_queue['cells'][1:],old_steps[31:],strict=True):
        core.require(pending['step'] == step and pending['outcome'] == 'pending'
                     and all(pending.get(k) is None for k in ('child_pid','returncode','audit','started_utc','finished_utc')),
                     'original unused IDs were attempted or rewritten')
    cit_config_path = prepared.original_queue_config.path.parent/'queue-cit-patents.json'
    core.require(decode(read(cit_config_path)) == original_cit['config'], 'original cit queue actual config bytes differ')
    first_pin = models.FilePin.model_validate(json_pin(old_config.config_index, read)['files'][prepared.original_failed_step.run_id])
    closure_evidence(prepared.original_oom_closure, read, base, prepared.original_failed_step.run_id, first_pin, None)
    warmups: dict[str,list[tuple[str,bool]]] = {prepared.original_failed_step.shape: [(prepared.original_failed_step.run_id,False)]}
    progress: list[schema.ProgressProjection] = []
    projections: list[schema.CellProjection] = []
    for cell, mapping in zip(tail.cells, prepared.mappings, strict=True):
        core.require(cell.mapping == mapping and cell.disposition in ('passed','closed_oom','not_started_due_to_failed_warmup'), 'exact29 terminal mapping/disposition')
        step = mapping.actual
        if step.role == 'measured':
            pair = warmups.get(step.shape, [])
            core.require(len(pair) == 2, 'both actual warmups required before measured/skip')
            failures = [run_id for run_id,qualified in pair if not qualified]
            core.require((cell.disposition == 'not_started_due_to_failed_warmup') == bool(failures), 'warmup prerequisite policy differs')
        else:
            failures = []
            warmups.setdefault(step.shape, []).append((step.run_id,cell.disposition == 'passed' and cell.qualified))
        if cell.disposition == 'not_started_due_to_failed_warmup':
            core.require(cell.cause_warmup_ids == failures and not cell.qualified and not cell.raw_receipts and cell.error is None
                         and cell.failure_closure is None and cell.failure_gate_retained is None
                         and cell.child_pid is None and cell.returncode is None,
                         'policy skip carries synthetic attempted/failed evidence')
            assert cell.child_pid is None and cell.returncode is None
            projections.append(schema.SkippedProjection(mapping=mapping, failed_warmup_ids=failures,
                child_pid=cell.child_pid, returncode=cell.returncode, command=cell.command))
            core.require(cell.log is None and cell.started_utc is None and cell.finished_utc is None and cell.pass_audit is None,
                         'skip has actual launch/timer/audit evidence')
            core.require(not exists(base/step.run_id) and not exists(base/(step.run_id+'.host.log')),
                         'skipped alias has host directory/log evidence')
        else:
            core.require(cell.child_pid is not None and cell.child_pid > 0 and bool(cell.started_utc) and bool(cell.finished_utc)
                         and cell.log == base/(step.run_id+'.host.log') and bool(cell.raw_receipts), 'attempted actual launch evidence')
            expected_command = [str(config.python),'-B',str(config.driver.path),'run','--campaign',str(config.campaign.path),
                '--run-id',step.run_id,'--kind','cell','--config',str(mapping.actual_config.path)]
            core.require(cell.command == expected_command, 'actual child command binding')
            host_path = base/step.run_id/'result.json'
            host_data = read(host_path)
            host_pin = models.FilePin(path=host_path, bytes=len(host_data), sha256=hashlib.sha256(host_data).hexdigest())
            core.require(json_pin(host_pin, read) == cell.raw_receipts['host'], 'retained raw host differs from actual bytes')
            archived: models.FilePin | None = None
            if cell.disposition == 'closed_oom':
                core.require(not cell.qualified and cell.returncode == 1 and cell.pass_audit is None
                             and cell.failure_closure is not None and cell.failure_gate_retained is not None, 'failed row qualified/missing closure')
                assert cell.failure_closure is not None and cell.failure_gate_retained is not None
                failure, archived = closure_evidence(cell.failure_closure, read, base, step.run_id, mapping.actual_config, cell.failure_gate_retained)
                core.require(failure.host_child_pid == cell.child_pid, 'failed exact child PID differs')
            else:
                core.require(cell.qualified and cell.returncode == 0 and cell.pass_audit is not None
                             and cell.pass_audit.get('qualified') is True and cell.failure_closure is None
                             and cell.failure_gate_retained is None and not cell.cause_warmup_ids and not cell.error,
                             'passed actual row qualification differs')
            projections.append(schema.AttemptedProjection(mapping=mapping, disposition=cast(Any,cell.disposition),
                raw_host_receipt=host_pin, qualified=cell.qualified, failure_closure=cell.failure_closure, archived_failure_gate_owner=archived))
        progress.append(schema.ProgressProjection(step=step,outcome=cast(Any,cell.disposition),command=cell.command,log=cell.log,
            started_utc=cell.started_utc,finished_utc=cell.finished_utc,child_pid=cell.child_pid,returncode=cell.returncode,
            audit=cell.pass_audit,qualified=cell.qualified))
    prerequisites = tail.prerequisite_observations['original_full_prerequisites']
    core.require(prerequisites['references'] == original_cit['prerequisite_observations']['references'], 'tail references differ from original closed proof')
    idle = models.Probe.model_validate(tail.prerequisite_observations['final_idle'])
    core.require(idle.returncode == 0 and not idle.stdout.strip() and idle.argv[-2:] == ['ps','-q'],
                 'final tail Docker idle observation missing')
    projection = schema.QueueProjection(raw_receipt=tail_pin, actual_config=prepared.queue_config, config=config,
        owner_pid=tail.owner_pid, outcome='completed_with_failures',finished_utc=cast(str,tail.finished_utc),
        pins=tail.sources,prerequisite_observations=prerequisites,cells=progress)
    serial = decode(read(cast(Path,tail.serial_lock_archived)/'owner.json'))
    core.require(serial['owner_pid'] == tail.owner_pid and serial['token'] == tail.token
                 and serial['config'] == config.model_dump(mode='json') and serial['dataset'] == 'graph500-24'
                 and serial['prepared'] == prepared_pin.model_dump(mode='json')
                 and serial['authorization'] == authorization_pin.model_dump(mode='json'), 'archived final own serial owner differs')
    serial_data = read(cast(Path,tail.serial_lock_archived)/'owner.json')
    serial_identity = models.Identity(bytes=len(serial_data),sha256=hashlib.sha256(serial_data).hexdigest())
    for cell in tail.cells:
        if cell.failure_closure is not None:
            failed = models.FailureClosure.model_validate(json_pin(cell.failure_closure,read))
            core.require(failed.serial_owner_pin.identity() == serial_identity,
                         'future failed closure serial ownership differs from final archived own lock')
    return prepared, tail, projection, projections


def walk(root: Path, deadline: core.Deadline) -> Iterator[Path]:
    core.require(root.is_dir() and not root.is_symlink(), 'owned metadata archive root')
    pending = [root]
    count = 0
    while pending:
        deadline.check()
        with os.scandir(pending.pop()) as children:
            for child in children:
                deadline.check()
                count += 1
                core.require(count <= 100000, 'bounded metadata archive entry count')
                path = Path(child.path)
                if child.name in EXCLUDED and child.is_dir(follow_symlinks=False):
                    continue
                core.require(not child.is_symlink(), 'metadata archive symlink prohibited')
                if child.is_dir(follow_symlinks=False):
                    pending.append(path)
                elif child.is_file(follow_symlinks=False):
                    if path.suffix in ALLOWED:
                        yield path
                else:
                    raise ValueError('archive special file prohibited')


def package(dest: Path, roots: list[Path], tools: list[models.FilePin], io_state: IO) -> models.Json:
    core.require(len({r.name for r in roots}) == len(roots), 'unique archive roots')
    seen: set[Path] = set()
    origins: list[tuple[str,Path]] = []
    for n,p in enumerate(tools):
        checked(p,io_state.read)
        if p.path not in seen:
            origins.append(("tools/"+str(n)+'-'+p.path.name,p.path))
            seen.add(p.path)
    for root in roots:
        for source_path in walk(root,io_state.deadline):
            if source_path not in seen:
                origins.append(('archives/'+root.name+'/'+source_path.relative_to(root).as_posix(),source_path))
                seen.add(source_path)
    core.require(len({n for n,_p in origins}) == len(origins), 'safe unique indexed metadata members')
    members: list[models.Json] = []
    with tarfile.open(dest/'evidence.tar.gz','x:gz',compresslevel=3) as archive:
        for name,path in sorted(origins):
            io_state.deadline.check()
            pure = PurePosixPath(name)
            core.require(not pure.is_absolute() and '..' not in pure.parts and str(pure) == name, 'safe metadata member path')
            data = io_state.read(path)
            info = tarfile.TarInfo(name)
            info.size,info.mode,info.mtime = len(data),0o644,0
            archive.addfile(info,io.BytesIO(data))
            io_state.deadline.check()
            members.append({'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'retained_source':str(path)})
    with (dest/'evidence.tar.gz').open('rb') as archive_file:
        os.fsync(archive_file.fileno())
    core.directory_fsync(dest)
    core.require(len({m['retained_source'] for m in members}) == len(members), 'duplicate retained source across tools/base')
    for member in members:
        expected = models.FilePin(path=Path(member['retained_source']),bytes=member['bytes'],sha256=member['sha256'])
        checked(expected,io_state.read)
    archived = io_state.archive_pin(dest/'evidence.tar.gz')
    return {'schema_version':1,'observed_utc':core.utc(),'archive':'evidence.tar.gz','archive_bytes':archived.bytes,
        'archive_sha256':archived.sha256,'members':members,'scope':'Finite metadata/raw plans/logs/helpers only; no physical arrays/Parquet/binary/bundle reads.'}
