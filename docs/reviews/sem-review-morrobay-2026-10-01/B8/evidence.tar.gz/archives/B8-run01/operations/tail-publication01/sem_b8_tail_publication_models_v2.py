"""Declared metadata projections; raw tail receipts remain immutable evidence."""
from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal, Self

import sem_b8_tail_models as models
from pydantic import Field, model_validator


class Limits(models.Record):
    timeout_seconds: float = Field(gt=0, le=7200)
    chunk_bytes: Literal[1048576] = 1048576
    metadata_file_limit: Literal[67108864] = 67108864
    maximum_entries: Literal[100000] = 100000


class NativeQueueConfig(models.Record):
    host_root: Path
    output: Path
    python: Path
    driver: models.FilePin
    campaign: models.FilePin
    plan: models.FilePin
    config_index: models.FilePin
    prerequisites: models.FilePin
    support_manifest: models.FilePin


class FunctionPin(models.Record):
    source: models.FilePin
    function: str
    function_sha256: models.Digest
    function_bytes: int = Field(gt=0)
    delegation: str


class ProgressProjection(models.Record):
    step: models.Step
    outcome: Literal['passed', 'closed_oom', 'not_started_due_to_failed_warmup']
    command: list[str]
    log: Path | None
    started_utc: str | None
    finished_utc: str | None
    child_pid: int | None
    returncode: int | None
    audit: models.Json | None
    qualified: bool

    @model_validator(mode='after')
    def qualification(self) -> Self:
        if self.outcome == 'passed':
            if not self.qualified or self.returncode != 0 or not self.audit or self.audit.get('qualified') is not True:
                raise ValueError('passed projection requires unchanged qualified audit and rc0')
        elif self.qualified or self.audit is not None:
            raise ValueError('failed/skipped projection never qualifies')
        if self.outcome == 'not_started_due_to_failed_warmup' and any((self.command, self.log, self.child_pid,
                self.returncode is not None, self.started_utc, self.finished_utc)):
            raise ValueError('skip cannot fabricate launch evidence')
        return self


class QueueProjection(models.Record):
    version: Literal['b8-tail-in-memory-qualification-view-v1'] = 'b8-tail-in-memory-qualification-view-v1'
    raw_receipt: models.FilePin
    actual_config: models.FilePin
    config: NativeQueueConfig
    dataset: Literal['graph500-24'] = 'graph500-24'
    owner_pid: int = Field(gt=0)
    outcome: Literal['completed_with_failures']
    finished_utc: str
    active_child_pid: None = None
    lock_retained: Literal[False] = False
    error: None = None
    pins: list[models.FilePin]
    prerequisite_observations: models.Json
    cells: list[ProgressProjection]
    field_mapping: str = 'mapping.actual→step; disposition→outcome; pass_audit→audit; original_full_prerequisites→prerequisite_observations; sources→pins; actual derived config is read from its pinned file.'
    raw_receipt_rewritten: Literal[False] = False
    bare_frozen_queue_execution_claim: Literal[False] = False


class AttemptedProjection(models.Record):
    kind: Literal['attempted'] = 'attempted'
    mapping: models.Mapping
    disposition: Literal['passed', 'closed_oom']
    raw_host_receipt: models.FilePin
    qualified: bool
    failure_closure: models.FilePin | None = None
    archived_failure_gate_owner: models.FilePin | None = None

    @model_validator(mode='after')
    def classification(self) -> Self:
        if (self.disposition == 'passed') != self.qualified:
            raise ValueError('attempted pass/OOM qualification differs')
        if self.disposition == 'closed_oom' and (self.failure_closure is None or self.archived_failure_gate_owner is None):
            raise ValueError('closed OOM requires immutable failure and owned-lock evidence')
        return self


class SkippedProjection(models.Record):
    kind: Literal['warmup_policy_skip'] = 'warmup_policy_skip'
    mapping: models.Mapping
    qualified: Literal[False] = False
    failed_warmup_ids: list[models.RunId] = Field(min_length=1)
    child_pid: None = None
    returncode: None = None
    command: list[str] = Field(default_factory=list, max_length=0)
    measured_seconds: None = None
    engine_call_started: Literal[False] = False


CellProjection = Annotated[AttemptedProjection | SkippedProjection, Field(discriminator='kind')]


class TailProvenance(models.Record):
    version: Literal['b8-finalized-tail-publication-v2'] = 'b8-finalized-tail-publication-v2'
    observed_utc: str
    publisher_wrapper: models.FilePin
    publication_adapter: models.FilePin
    publication_models: models.FilePin
    publication_gate: models.FilePin
    frozen_publisher: models.FilePin
    frozen_host_wrapper: models.FilePin
    frozen_gate: models.FilePin
    frozen_host_gate: models.FilePin
    immutable_helper_sources: list[models.FilePin]
    frozen_predicates: list[FunctionPin]
    prepared: models.FilePin
    preparation_attempt: models.FilePin
    authorization: models.FilePin
    root_authorization_review: models.FilePin
    tail_queue: models.FilePin
    original_plan: models.FilePin
    derived_plan: models.FilePin
    original_cit_receipt: models.FilePin
    original_graph_receipt: models.FilePin
    original_continuation_receipt: models.FilePin
    original_oom_closure: models.FilePin
    original_lock_preservation: models.FilePin
    preserved_serial_owner: models.FilePin
    queue_projection: QueueProjection
    cell_projection: list[CellProjection]
    limits: Limits
    original31_preserved: Literal[True] = True
    config_difference_fields: tuple[Literal['output']] = ('output',)
    raw_receipts_rewritten: Literal[False] = False
    guest_algorithm_changed: Literal[False] = False
    engine_timer_changed: Literal[False] = False
    resource_budget_changed: Literal[False] = False
    all60_qualified: Literal[False] = False
    all60_attempted: Literal[False] = False
    protocol_finished_terminal_evidence: Literal[True] = True
    legacy_eligible_final_DONE_means_all60_qualified: Literal[True] = True
    qualification_scope: str = 'Metadata and retained full-oracle evidence only; closed OOM is process/source/archive closure, not correctness or timing qualification.'
