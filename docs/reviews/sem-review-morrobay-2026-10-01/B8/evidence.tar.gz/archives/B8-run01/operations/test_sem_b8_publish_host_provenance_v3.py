"""Bounded host provenance controls; synthetic records are not benchmark evidence."""
from __future__ import annotations

import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from collections.abc import Callable
from pathlib import Path
from types import ModuleType
from typing import Any, cast

SPEC = importlib.util.spec_from_file_location('b8_publication_provenance_controls','/tmp/sem-b8-publish-host-provenance-v3.py')
assert SPEC is not None and SPEC.loader is not None
WRAP: ModuleType = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = WRAP; SPEC.loader.exec_module(WRAP)
BASE = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01')
Json = dict[str, Any]


def adapter_value() -> Json:
    return {'version':'b8-host-embedded-absence-v2',
            'adapter':WRAP.pin(Path('/tmp/sem-b8-queue-closure-adapter-v2.py')).model_dump(mode='json'),
            'frozen_queue':WRAP.pin(BASE/'support/run_pair_queue.py').model_dump(mode='json'),
            'original_function_sha256':WRAP.FUNCTION_SHA,
            'predicate_change':'Compare only absence_verified separately; require embedded absence; all other archived predicates unchanged.',
            'guest_change':False,'timer_change':False,'raw_archive_rewrite':False}


def preparation(directory: Path) -> Json:
    names = ('plan.json','config-index.json','prerequisites.json','queue-cit-patents.json','queue-graph500-24.json','sem-b8-configs.py')
    for name in names:
        content = Path('/tmp/sem-b8-configs.py').read_bytes() if name.endswith('.py') else b'{"synthetic_fixture":true}\n'
        (directory/name).write_bytes(content)
    return {'outcome':'prepared','finished_utc':'synthetic-not-observed','error':None,'traceback':None,
            'source_sha256':WRAP.CONFIG_SHA,'closure_adapter':adapter_value(),
            'generator_wrapper':WRAP.pin(Path('/tmp/sem-b8-configs-closure-v2.py')).model_dump(mode='json'),
            'generator_wrapper_version':'b8-metadata-generator-host-closure-v2',
            'options':{'action':'queues','output':str(directory),'queue_sha256':WRAP.QUEUE_SHA},
            'artifacts':{name:WRAP.pin(directory/name).model_dump(mode='json') for name in names}}


class Controls(unittest.TestCase):
    def test_actual_frozen_predicate_ast_and_guard(self) -> None:
        adapter = WRAP.ClosureAdapter.model_validate(adapter_value())
        guard = WRAP.adapter_check(adapter,WRAP.raw)
        self.assertEqual(guard['original_function_sha256'],WRAP.FUNCTION_SHA)
        self.assertEqual(guard['changed_statement_indices'],[3,4])
        self.assertGreater(guard['statement_count'],5)
        with self.assertRaisesRegex(ValueError,'source differs'):
            WRAP.predicate_guard((BASE/'support/run_pair_queue.py').read_bytes()+b'\n',Path('/tmp/sem-b8-queue-closure-adapter-v2.py').read_bytes())

    def test_wrong_adapter_or_guest_change_refused(self) -> None:
        for key in ('adapter','frozen_queue','predicate_change','guest_change'):
            value=adapter_value()
            if key in {'adapter','frozen_queue'}:
                value[key]['sha256']='0'*64
            elif key=='predicate_change':
                value[key]='weaken all closure checks'
            else:
                value[key]=True
            with self.subTest(key=key),self.assertRaises(ValueError):
                WRAP.adapter_check(WRAP.ClosureAdapter.model_validate(value),WRAP.raw)

    def test_prepared_real_source_pins_and_tamper(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory=Path(temporary);value=preparation(directory);path=directory/'preparation.json'
            path.write_text(json.dumps(value));identity=WRAP.pin(path)
            adapter=WRAP.ClosureAdapter.model_validate(adapter_value())
            WRAP.preparation_check(value,identity,adapter,WRAP.raw)
            for key in ('outcome','source_sha256','generator_wrapper_version'):
                changed=copy.deepcopy(value);changed[key]='incorrect'
                with self.subTest(key=key),self.assertRaises(ValueError):
                    WRAP.preparation_check(changed,identity,adapter,WRAP.raw)
            (directory/'plan.json').write_text('{}')
            with self.assertRaisesRegex(ValueError,'pin differs'):
                WRAP.preparation_check(value,identity,adapter,WRAP.raw)

    def test_final_queue_must_bind_adapter_and_prepared_config(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            value=preparation(Path(temporary));adapter=WRAP.ClosureAdapter.model_validate(adapter_value())
            queue: Json={'outcome':'passed','finished_utc':'synthetic-not-observed','active_child_pid':None,
                         'closure_adapter':adapter_value(),'pins':[adapter.adapter.model_dump(mode='json'),adapter.frozen_queue.model_dump(mode='json')],
                         'config':{key:value['artifacts'][name] for key,name in (('plan','plan.json'),('config_index','config-index.json'),('prerequisites','prerequisites.json'))}}
            WRAP.queue_check(queue,adapter,value)
            for key in ('missing-adapter','missing-pin','live-child','wrong-plan'):
                changed=copy.deepcopy(queue)
                if key=='missing-adapter':
                    del changed['closure_adapter']
                elif key=='missing-pin':
                    changed['pins']=changed['pins'][:1]
                elif key=='live-child':
                    changed['active_child_pid']=1
                else:
                    changed['config']['plan']['sha256']='0'*64
                with self.subTest(key=key),self.assertRaises((ValueError,KeyError)):
                    WRAP.queue_check(changed,adapter,value)

    def test_full_reference_gate_requires_both_complete_archives(self) -> None:
        adapter=WRAP.ClosureAdapter.model_validate(adapter_value())
        value: Json={'outcome':'passed','finished_utc':'synthetic-not-observed','error':None,'traceback':None,'engine_executed':False,
                     'adapter':adapter.adapter.model_dump(mode='json'),
                     'helper':WRAP.pin(Path('/tmp/sem-b8-closure-reference-gate-v2.py')).model_dump(mode='json'),
                     'references':{name:{'outcome':'passed','full_physical_archive_hashed_before_after':True,'reference_artifacts':{'synthetic':True},'archive':{'synthetic':True}}
                                   for name in ('cit-reference01','graph500-reference01')}}
        WRAP.reference_gate_check(value,adapter,WRAP.raw)
        changed=copy.deepcopy(value);changed['references']['graph500-reference01']['full_physical_archive_hashed_before_after']=False
        with self.assertRaisesRegex(ValueError,'observation absent'):
            WRAP.reference_gate_check(changed,adapter,WRAP.raw)

    def test_generated_provenance_and_disclosure_precede_final_hash(self) -> None:
        pin=WRAP.pin(Path('/tmp/sem-b8-publish-host-provenance-v3.py'))
        adapter=WRAP.ClosureAdapter.model_validate(adapter_value())
        provenance=WRAP.Provenance(publisher_wrapper=pin,frozen_publisher=pin,frozen_publication_gate=pin,
            closure_adapter=adapter,preparation=pin,config_wrapper=pin,frozen_config_generator=pin,
            reference_closure_gate=pin,required_retained_evidence=[],queue_receipts=[],predicate_guard={})
        module=ModuleType('synthetic_publisher_writes')

        def write(path: Path,value: Json | str) -> None:
            path.write_text(value if isinstance(value,str) else json.dumps(value,sort_keys=True))

        def markdown(report: Json,detailed: bool) -> str:
            self.assertIn('host_closure_provenance',report)
            return 'retained frozen queue, host; detailed='+str(detailed)

        module.__dict__.update(write=write,markdown=markdown);WRAP.install(module,provenance)
        wrapped_write=cast(Callable[[Path,Json | str],None],module.write)
        wrapped_markdown=cast(Callable[[Json,bool],str],module.markdown)
        with tempfile.TemporaryDirectory() as temporary:
            directory=Path(temporary);report: Json={'scope':'retained frozen queue evidence'}
            wrapped_write(directory/'report.json',report)
            text=wrapped_markdown(report,False);wrapped_write(directory/'README.md',text)
            self.assertIn(WRAP.DISCLOSURE,text)
            self.assertNotIn('retained frozen queue, host',text)
            before=WRAP.pin(directory/'README.md')
            wrapped_write(directory/'generation-receipt.json',{'outcome':'passed'})
            self.assertEqual(before,WRAP.pin(directory/'README.md'))
            self.assertEqual(json.loads((directory/'generation-receipt.json').read_text())['host_closure_provenance'],report['host_closure_provenance'])


if __name__ == '__main__':
    unittest.main()
