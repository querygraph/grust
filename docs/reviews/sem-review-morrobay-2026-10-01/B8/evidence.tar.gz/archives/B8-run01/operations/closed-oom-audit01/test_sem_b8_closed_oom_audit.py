"""Small real-schema metadata and fake-process controls; no Docker/payload actions."""
from __future__ import annotations

import copy
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

import sem_b8_tail_core as core
import sem_b8_tail_models as models

FIXTURES = Path('/tmp/sem-b8-closed-oom-fixtures01')
RUN = 'b8-graph500-24-adjacency-01-union'


class Fixture:
    def __init__(self) -> None:
        self.deadline = core.Deadline.after(60)
        self.host = core.read(FIXTURES/'host.json', self.deadline)
        self.producer = core.read(FIXTURES/'producer.json', self.deadline)
        self.boot = core.read(FIXTURES/'bootstrap.json', self.deadline)
        self.engine = core.read(FIXTURES/'engine.json', self.deadline)
        self.container = core.read(FIXTURES/'container.json', self.deadline)
        self.support = core.read(FIXTURES/'support-manifest.json', self.deadline)
        self.native = core.read(FIXTURES/'historical-bootstrap.json', self.deadline)['identities_before']['native']
        values = core.read(FIXTURES/'effective.json', self.deadline)
        self.effective: Any = SimpleNamespace(**{k: Path(v) if k in ('repo', 'harness_repo', 'output', 'vertices', 'edges', 'binary', 'support') else v for k, v in values.items()})
        self.effective.model_dump = lambda **_kwargs: values
        queue = SimpleNamespace(SOURCE=self.engine['controller_pin'], HARNESS=self.producer['identities_before']['harness'],
            RUNTIME=self.engine['runtime_pin'], NATIVE=self.engine['native_pin'], actual_method=lambda shape, variant: shape+'-'+variant,
            absence=lambda _record: None)
        host = SimpleNamespace(SAIL_SHA=self.producer['identities_before']['binary'],
            NATIVE_SHA=self.native['files_sha256']['_native.cpython-312-x86_64-linux-gnu.so'],
            PYTHON=self.producer['command'][0], IMAGE=self.container['inspect']['image'], DOCKER=['fake-docker'])
        self.frozen = core.Frozen(queue, host, SimpleNamespace(), self.deadline, [])

    def metadata(self) -> dict[str, dict[str, int]]:
        with patch.object(core, 'read', return_value=self.support):
            return core.failure_metadata(self.host, self.producer, self.boot, self.engine,
                RUN, self.effective, self.frozen, self.native)


class MetadataControls(unittest.TestCase):
    def setUp(self) -> None:
        self.f = Fixture()

    def test_actual_closed_oom_metadata_accepted_only_as_failure(self) -> None:
        result = self.f.metadata()
        self.assertEqual(result['final']['oom_kill'], 1)
        self.assertEqual(self.f.boot['outcome'], 'checking')
        core.failed_container(self.f.container, self.f.frozen)

    def test_native_python_file_change_refused(self) -> None:
        native = copy.deepcopy(self.f.native)
        native['files_sha256']['client.py'] = '0'*64
        self.f.producer['identities_before']['native'] = native
        self.f.producer['identities_after']['native'] = native
        with self.assertRaisesRegex(ValueError, 'full native'):
            self.f.metadata()

    def test_bootstrap_native_change_refused(self) -> None:
        for key in ('identities_before', 'identities_after'):
            self.f.boot[key]['native']['root'] = '/different/package'
        with self.assertRaisesRegex(ValueError, 'bootstrap'):
            self.f.metadata()

    def test_nonwaited_or_live_engine_refused(self) -> None:
        for field, value in [('engine_wait_completed', False), ('engine_pid', 0), ('final_processes', [{'pid': 99}])]:
            with self.subTest(field=field):
                f = Fixture()
                f.producer[field] = value
                with self.assertRaisesRegex(ValueError, 'ownership'):
                    f.metadata()

    def test_emergency_cleanup_and_observer_errors_refused(self) -> None:
        for field, value in [('emergency_cleanup', [42]), ('observer_error', 'failed'), ('outer_timeout', True), ('interruption_signals', [15])]:
            with self.subTest(field=field):
                f = Fixture()
                f.producer[field] = value
                with self.assertRaises(ValueError):
                    f.metadata()

    def test_source_identity_change_refused(self) -> None:
        self.f.producer['identities_after']['controller'] = '0'*40
        with self.assertRaisesRegex(ValueError, 'source closure'):
            self.f.metadata()

    def test_changed_engine_command_refused(self) -> None:
        self.f.producer['command'][-1] = '/another/config'
        with self.assertRaisesRegex(ValueError, 'command/config'):
            self.f.metadata()

    def test_failure_requires_real_oom_and_unchanged_envelope(self) -> None:
        for field, value in [('memory.events', 'oom 0\noom_kill 0\n'), ('memory.max', str(48*2**30)), ('memory.swap.max', '100')]:
            with self.subTest(field=field):
                f = Fixture()
                f.producer['cgroups']['final'][field] = value
                with self.assertRaises(ValueError):
                    f.metadata()

    def test_uncertain_container_copy_transport_force_refused(self) -> None:
        for change in ('copy', 'transport', 'kill', 'still_running', 'not_oom'):
            with self.subTest(change=change):
                f = Fixture()
                if change == 'copy':
                    f.container['copied']['artifacts']['returncode'] = 1
                elif change == 'transport':
                    f.container['transport_errors'] = ['transport lost']
                elif change == 'kill':
                    f.container['kill'] = {'returncode': 0}
                elif change == 'still_running':
                    f.container['inspect']['state']['Running'] = True
                else:
                    f.container['inspect']['state']['OOMKilled'] = False
                with self.assertRaises(ValueError):
                    core.failed_container(f.container, f.frozen)


class ProbeAndIOControls(unittest.TestCase):
    def test_requires_name_id_and_idle_proofs(self) -> None:
        f = Fixture()
        calls: list[list[str]] = []
        def probe(argv: list[str], _deadline: core.Deadline) -> models.Probe:
            calls.append(argv)
            target = argv[-1]
            return models.Probe(argv=argv, observed_utc=core.utc(), returncode=0 if target == '-q' else 1,
                stdout='', stderr='' if target == '-q' else 'Error: No such object: '+target)
        result = core.fresh_probes(f.frozen, RUN, f.container['inspect']['id'], probe)
        self.assertEqual(len(result), 3)
        self.assertEqual(calls[1][-1], f.container['inspect']['id'])

    def test_missing_id_proof_and_nonidle_refused(self) -> None:
        f = Fixture()
        for broken in (f.container['inspect']['id'], '-q'):
            def probe(argv: list[str], _deadline: core.Deadline, broken: str = broken) -> models.Probe:
                target = argv[-1]
                return models.Probe(argv=argv, observed_utc=core.utc(), returncode=0 if target in (broken, '-q') else 1,
                    stdout='running-id' if broken == '-q' and target == '-q' else '',
                    stderr='Error: No such object: '+target)
            with self.subTest(target=broken), self.assertRaises(ValueError):
                core.fresh_probes(f.frozen, RUN, f.container['inspect']['id'], probe)

    def test_hash_deadline_expires_between_chunks(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory)/'payload'
            p.write_bytes(b'x'*(core.CHUNK*2))
            with patch.object(time, 'monotonic', side_effect=[0.0, 0.0, 2.0]), self.assertRaises(TimeoutError):
                core.pin(p, core.Deadline(1.0))
            self.assertEqual(p.stat().st_size, core.CHUNK*2)

    def test_complete_inventory_and_symlink_refusal(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'a').write_bytes(b'a')
            (root/'nested').mkdir()
            (root/'nested/b').write_bytes(b'b')
            actual = core.inventory(root, core.Deadline.after(10))
            self.assertEqual(set(actual), {'a', 'nested/b'})
            (root/'link').symlink_to(root/'a')
            with self.assertRaisesRegex(ValueError, 'symlink'):
                core.inventory(root, core.Deadline.after(10))

    def test_fresh_durable_output_refuses_overwrite(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory)/'receipt.json'
            core.write(p, {'outcome': 'control'}, fresh=True)
            original = p.read_bytes()
            with self.assertRaisesRegex(ValueError, 'existing'):
                core.write(p, {'outcome': 'rewritten'}, fresh=True)
            self.assertEqual(p.read_bytes(), original)


if __name__ == '__main__':
    unittest.main()
