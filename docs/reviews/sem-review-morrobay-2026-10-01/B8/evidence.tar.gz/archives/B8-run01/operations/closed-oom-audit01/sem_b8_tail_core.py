"""Finite host-only I/O and natural-OOM closure; original pass predicates retained."""
from __future__ import annotations

import errno
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

import sem_b8_tail_models as models

BASE = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01')
QUEUE_SHA = 'abe3842e4d5ae77122c42857ff1cb0298e3d42ccba7030e99c9a902967b05a94'
ADAPTER_SHA = '99c53056d946d16c705e041769acccd5034c321093c7706d261c1174ae6038f2'
DRIVER_SHA = 'ab2c33497e31df9b1f0010be78446df4eb936f09af4235264b6bb421e2f28e98'
POLICY = 'b8-tail-warmups-before-two-UAAU-blocks-v1'
CHUNK = 2**20


@dataclass(frozen=True, slots=True)
class Deadline:
    end: float

    @classmethod
    def after(cls, seconds: float) -> Deadline:
        require(0 < seconds <= 7200, 'finite host audit deadline required')
        return cls(time.monotonic() + seconds)

    def check(self) -> None:
        if time.monotonic() >= self.end:
            raise TimeoutError('host source/archive deadline elapsed')

    def remaining(self, cap: float = 30) -> float:
        self.check()
        return max(0.001, min(cap, self.end-time.monotonic()))


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def utc() -> str:
    return datetime.now(UTC).isoformat()


def pin(path: Path, deadline: Deadline) -> models.FilePin:
    deadline.check()
    require(path.is_absolute() and path.is_file() and not path.is_symlink(), 'regular absolute pin: '+str(path))
    before = path.stat()
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        while chunk := stream.read(CHUNK):
            deadline.check()
            digest.update(chunk)
            size += len(chunk)
    after = path.stat()
    require(size == before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns,
            'file changed while hashing: '+str(path))
    deadline.check()
    return models.FilePin(path=path, bytes=size, sha256=digest.hexdigest())


def verify(expected: models.FilePin, deadline: Deadline) -> None:
    require(pin(expected.path, deadline) == expected, 'immutable pin changed: '+str(expected.path))


def read(path: Path, deadline: Deadline) -> models.Json:
    deadline.check()
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= 64*CHUNK,
            'bounded regular metadata: '+str(path))
    chunks: list[bytes] = []
    with path.open('rb') as stream:
        while chunk := stream.read(CHUNK):
            deadline.check()
            chunks.append(chunk)
            require(sum(map(len, chunks)) <= 64*CHUNK, 'metadata grew beyond bound')
    data: Any = json.loads(b''.join(chunks))
    deadline.check()
    require(isinstance(data, dict), 'metadata object required: '+str(path))
    return cast(models.Json, data)


def directory_fsync(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        try:
            os.fsync(descriptor)
        except OSError as error:
            if sys.platform != 'darwin' or error.errno not in (errno.EINVAL, errno.ENOTSUP):
                raise
    finally:
        os.close(descriptor)


def write(path: Path, value: models.Record | models.Json, *, fresh: bool = False) -> None:
    require(path.parent.is_dir() and not path.parent.is_symlink(), 'existing owned output parent required')
    if fresh:
        require(not path.exists() and not path.is_symlink(), 'refuse existing output: '+str(path))
    payload = value.model_dump(mode='json') if isinstance(value, models.Record) else value
    temporary = path.with_name(path.name+'.writing')
    with temporary.open('x') as stream:
        json.dump(payload, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    directory_fsync(path.parent)


def inventory(root: Path, deadline: Deadline) -> dict[str, models.Identity]:
    require(root.is_dir() and not root.is_symlink(), 'regular collected artifact root')
    pending = [root]
    result: dict[str, models.Identity] = {}
    entries = 0
    while pending:
        deadline.check()
        with os.scandir(pending.pop()) as children:
            for child in children:
                deadline.check()
                entries += 1
                require(entries <= 100000, 'bounded archive entry count')
                require(not child.is_symlink(), 'archive symlink prohibited')
                path = Path(child.path)
                if child.is_file(follow_symlinks=False):
                    result[path.relative_to(root).as_posix()] = pin(path, deadline).identity()
                else:
                    require(child.is_dir(follow_symlinks=False), 'archive special file prohibited')
                    pending.append(path)
    require(bool(result), 'nonempty complete archive required')
    return dict(sorted(result.items()))


@dataclass(slots=True)
class Frozen:
    queue: Any
    host: Any
    adapter: Any
    deadline: Deadline
    sources: list[models.FilePin]

    def bounded_io(self) -> None:
        # Source assertions, function bodies and absence adapter remain unchanged.
        def bounded_pin(path: Path) -> Any:
            return self.queue.FilePin.model_validate(pin(path, self.deadline).model_dump())

        def bounded_inventory(root: Path) -> models.Json:
            return {k: v.model_dump() for k, v in inventory(root, self.deadline).items()}

        self.queue.__dict__['pin'] = bounded_pin
        self.queue.__dict__['read'] = lambda path: read(path, self.deadline)
        self.host.__dict__['sha'] = lambda path: pin(path, self.deadline).sha256
        self.host.__dict__['collected_inventory'] = bounded_inventory


def load(deadline: Deadline) -> Frozen:
    support = BASE/'support'
    manifest = read(support/'support-manifest.json', deadline)
    sources = [pin(support/'support-manifest.json', deadline)]
    for name, expected in manifest['files_sha256'].items():
        require(re.fullmatch(r'[A-Za-z0-9_.-]+', name) is not None, 'support basename')
        actual = pin(support/name, deadline)
        require(actual.sha256 == expected, 'support source changed: '+name)
        sources.append(actual)
    require(pin(support/'run_pair_queue.py', deadline).sha256 == QUEUE_SHA
            and pin(support/'run_shapes_host.py', deadline).sha256 == DRIVER_SHA,
            'exact frozen queue/host bytes')
    sys.path.insert(0, str(support))
    imported = __import__('run_pair_queue')
    host = __import__('run_shapes_host')
    require(Path(cast(str, imported.__file__)).resolve() == support/'run_pair_queue.py'
            and Path(cast(str, host.__file__)).resolve() == support/'run_shapes_host.py', 'exact imported queue/host origins')
    adapter_path = BASE/'operations/sem-b8-queue-closure-adapter-v2.py'
    actual = pin(adapter_path, deadline)
    require(actual.sha256 == ADAPTER_SHA, 'exact original closure adapter bytes')
    spec = importlib.util.spec_from_file_location('b8_tail_original_absence_adapter', adapter_path)
    require(spec is not None and spec.loader is not None, 'host adapter module loader')
    assert spec is not None and spec.loader is not None
    adapter = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = adapter
    spec.loader.exec_module(adapter)
    adapter.install(imported, ADAPTER_SHA)
    frozen = Frozen(imported, host, adapter, deadline, [*sources, actual,
        pin(Path(__file__).resolve(), deadline), pin(Path(models.__file__).resolve(), deadline)])
    frozen.bounded_io()
    return frozen


def capture(argv: list[str], deadline: Deadline) -> models.Probe:
    completed = subprocess.run(argv, capture_output=True, text=True, check=False, timeout=deadline.remaining())
    return models.Probe(argv=argv, observed_utc=utc(), returncode=completed.returncode,
                        stdout=completed.stdout, stderr=completed.stderr)


def pid_absent(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    return False


ProbeFn = Callable[[list[str], Deadline], models.Probe]
PidFn = Callable[[int], bool]


def resource_oom(producer: models.Json) -> dict[str, dict[str, int]]:
    cgroups = producer.get('cgroups') or {}
    require(set(cgroups) >= {'before', 'after_engine', 'final'}, 'failure cgroup phases required')
    observations: dict[str, dict[str, int]] = {}
    for name, snap in cgroups.items():
        require(snap.get('cpu.max') == '1600000 100000' and snap.get('cpuset.cpus.effective') == '0-15'
                and snap.get('memory.max') == str(32*2**30) and snap.get('memory.swap.max') == '0', 'unchanged failure resources')
        events: dict[str, int] = {}
        for line in snap['memory.events'].splitlines():
            key, raw = line.split()
            require(key not in events, 'duplicate OOM event counter')
            value = int(raw)
            require(value >= 0, 'negative OOM event counter')
            events[key] = value
        require({'oom', 'oom_kill'} <= set(events), 'required OOM counters')
        observations[name] = events
    before = observations['before']
    require(before['oom'] == before['oom_kill'] == before.get('oom_group_kill', 0) == 0, 'fresh failure OOM baseline')
    last = observations['final']
    require(last['oom'] > 0 and last['oom_kill'] > 0, 'actual natural OOM evidence required')
    for key, count in observations['after_engine'].items():
        require(key in last and last[key] >= count >= before.get(key, 0), 'OOM event set/count closure changed')
    return observations


def failed_container(record: models.Json, frozen: Frozen) -> None:
    item = record.get('inspect') or {}
    state = item.get('state') or {}
    created = record.get('create') or {}
    require(created.get('returncode') == 0 and re.fullmatch(r'[a-f0-9]{64}', created.get('stdout', '').strip()) is not None
            and item.get('id') == created['stdout'].strip() and item.get('image') == frozen.host.IMAGE,
            'natural failure exact container identity')
    require(record.get('attach_returncode') == state.get('ExitCode') == 1
            and state.get('Running') is False and state.get('OOMKilled') is True and not state.get('Error')
            and state.get('Pid') == 0 and state.get('Dead') is False and state.get('Restarting') is False
            and state.get('Paused') is False, 'natural closed OOM state requires exact rc1/OOMKilledtrue')
    require(record.get('remove', {}).get('returncode') == 0
            and record.get('copied', {}).get('artifacts', {}).get('returncode') == 0
            and not any(record.get(k) for k in ('transport_errors', 'kill', 'forced_cleanup_kill', 'outer_timeout', 'operator_interrupted')),
            'failed container copy/removal/transport/cleanup uncertain')
    limits = item.get('limits') or {}
    require(limits.get('NanoCpus') == 16*10**9 and limits.get('CpusetCpus') == '0-15'
            and limits.get('Memory') == limits.get('MemorySwap') == 32*2**30 and limits.get('Init') is True
            and limits.get('PidMode') in ('', 'private') and limits.get('PidsLimit') == 1024, 'failed container envelope')
    frozen.queue.absence(record)


def failure_metadata(host: models.Json, producer: models.Json, boot: models.Json, engine: models.Json,
                     run_id: str, effective: Any, frozen: Frozen, native_manifest: models.Json) -> dict[str, dict[str, int]]:
    require(host.get('run_id') == run_id and host.get('action') == 'run' and host.get('kind') == 'cell'
            and host.get('outcome') == 'error' and bool(host.get('finished_utc'))
            and host.get('certain_container_closure') is True and host.get('lock_retained') is True
            and host.get('archive_verified') is True and host.get('producer_outcome') == 'oom'
            and host.get('payload_removed') is False, 'raw finalized failed host closure')
    require(producer.get('outcome') == 'oom' and bool(producer.get('finished_utc'))
            and producer.get('engine_returncode') == 1 and producer.get('engine_wait_completed') is True
            and producer.get('ownership_admitted') is True and producer.get('execution_verified') is False
            and isinstance(producer.get('engine_pid'), int) and producer['engine_pid'] > 0
            and producer.get('config') == effective.model_dump(mode='json')
            and not any(producer.get(k) for k in ('remaining_processes', 'remaining_after_cleanup', 'final_processes',
                 'preexisting_processes', 'emergency_cleanup', 'finalization_errors', 'interruption_signals', 'observer_error', 'outer_timeout')),
            'natural engine OOM ownership/wait/finalization')
    identities = producer.get('identities_before') or {}
    require(bool(identities) and identities == producer.get('identities_after')
            and identities.get('controller') == frozen.queue.SOURCE and identities.get('harness') == frozen.queue.HARNESS
            and identities.get('binary') == frozen.host.SAIL_SHA
            and identities.get('support') == read(BASE/'support/support-manifest.json', frozen.deadline)
            and identities.get('native') == native_manifest, 'failure immutable full native package/source closure')
    require(boot.get('kind') == 'cell' and bool(boot.get('finished_utc')) and boot.get('outcome') == 'checking'
            and boot.get('producer_returncode') == 1 and bool(boot.get('identities_before'))
            and boot.get('identities_before') == boot.get('identities_after')
            and boot['identities_before'].get('native') == native_manifest
            and not any(boot.get(k) for k in ('error', 'traceback', 'final_guard_traceback')), 'raw failed bootstrap closure')
    require(producer.get('engine_receipt') == engine and engine.get('outcome') == 'error' and bool(engine.get('finished_utc'))
            and not engine.get('cleanup_errors') and engine.get('result_exported') is False
            and engine.get('controller_pin') == frozen.queue.SOURCE and engine.get('runtime_pin') == frozen.queue.RUNTIME
            and engine.get('native_pin') == frozen.queue.NATIVE
            and producer.get('actual_engine_method') == effective.shape+':'+effective.variant
            and engine.get('actual_method') == frozen.queue.actual_method(effective.shape, effective.variant),
            'failed engine exact method/source/cleanup receipt')
    expected = {'repo': str(effective.repo), 'harness_repo': str(effective.harness_repo), 'output': str(effective.output/'engine'),
        'vertices': str(effective.vertices), 'edges': str(effective.edges), 'binary': str(effective.binary), 'mode': 'local',
        'partitions': 16, 'pool_bytes': 30*2**30, 'native_quota': 256*2**20, 'shape': effective.shape, 'variant': effective.variant}
    require(engine.get('config') == expected and producer.get('command') == [frozen.host.PYTHON, '-B',
            str(effective.support/'engine_shapes.py'), '--config', str(effective.output/'engine-config.json')], 'failed actual engine command/config')
    return resource_oom(producer)


def audit_oom(frozen: Frozen, queue_config_path: Path, run_id: str, expected_child_pid: int, expected_gate_token: str,
              expected_serial_pid: int, expected_serial_token: str, launch_receipt: Path, *, serial_may_be_current: bool = False, probe: ProbeFn = capture, dead: PidFn = pid_absent) -> models.FailureClosure:
    deadline, queue = frozen.deadline, frozen.queue
    config = queue.QueueConfig.model_validate(read(queue_config_path, deadline))
    require(config.host_root == BASE and config.driver.sha256 == DRIVER_SHA, 'fixed B8 host/driver scope')
    launch_pin = pin(launch_receipt, deadline)
    evidence = [pin(queue_config_path, deadline), launch_pin]
    for key in ('driver', 'campaign', 'plan', 'config_index', 'prerequisites', 'support_manifest'):
        target = models.FilePin.model_validate(getattr(config, key).model_dump())
        verify(target, deadline)
        evidence.append(target)
    campaign = frozen.host.Campaign.model_validate(read(config.campaign.path, deadline))
    require(campaign.host_root == BASE, 'exact campaign host scope')
    index = queue.ConfigIndex.model_validate(read(config.config_index.path, deadline))
    require(all(getattr(index, key) == getattr(config, key) for key in ('driver', 'campaign', 'plan', 'support_manifest')),
            'immutable failed queue manifest bindings')
    plan = queue.Plan.model_validate(read(config.plan.path, deadline))
    steps = [s for s in plan.steps if s.run_id == run_id]
    require(len(steps) == 1 and steps[0].dataset == 'graph500-24', 'exact planned Graph failure run')
    cell_pin = models.FilePin.model_validate(index.files[run_id].model_dump())
    verify(cell_pin, deadline)
    effective = frozen.host.CellConfiguration.model_validate(read(cell_pin.path, deadline))
    step = steps[0]
    require(effective.dataset == step.dataset and effective.shape == step.shape and effective.variant == step.variant
            and effective.output == Path(campaign.guest_root)/'cells'/run_id
            and effective.repo == Path(campaign.guest_root)/'repo' and effective.support == Path(campaign.guest_root)/'support'
            and effective.harness_repo == Path(frozen.host.HARNESS_REPO) and effective.binary == Path(frozen.host.SAIL)
            and effective.minimum_free_bytes == campaign.guest_reserve_bytes
            and effective.support_sha256 == config.support_manifest.sha256, 'failed cell exact resource/source/output tuple')
    launch = read(launch_receipt, deadline)
    rows = launch.get('cells', [launch])
    matching = [row for row in rows if (row.get('step') or row.get('mapping', {}).get('actual') or row).get('run_id') == run_id]
    require(len(matching) == 1, 'one exact retained child launch record required')
    launched = matching[0]
    expected_command = [str(config.python), '-B', str(config.driver.path), 'run', '--campaign', str(config.campaign.path),
        '--run-id', run_id, '--kind', 'cell', '--config', str(cell_pin.path)]
    require(launched.get('child_pid') == expected_child_pid and launched.get('returncode') == 1
            and bool(launched.get('finished_utc')) and launched.get('command') == expected_command,
            'failed child wait/PID/exact command binding')
    directory, artifacts = BASE/run_id, BASE/run_id/'container/artifacts'
    names = ('result.json', 'container-record.json', 'configuration.json', 'helper-config.json', 'support-identities.json',
             'collected-manifest.json', 'container/artifacts/receipt.json', 'container/artifacts/bootstrap-receipt.json',
             'container/artifacts/engine/engine-receipt.json', 'container/artifacts/engine-config.json', 'container/artifacts/archive-manifest.json')
    evidence.extend(pin(directory/name, deadline) for name in names)
    host, producer, boot, engine = (read(directory/name, deadline) for name in
        ('result.json', 'container/artifacts/receipt.json', 'container/artifacts/bootstrap-receipt.json', 'container/artifacts/engine/engine-receipt.json'))
    require(frozen.host.CellConfiguration.model_validate(read(directory/'helper-config.json', deadline)) == effective,
            'raw failed effective config differs')
    separate = read(directory/'container-record.json', deadline)
    embedded = frozen.adapter.record_binding(host, separate)
    failed_container(embedded, frozen)
    queue.small_closed(host['records']['admission'])
    archive = queue.physical_archive(directory, host)  # Original equality predicates, bounded exact full hashes.
    queue.support_binding(directory, config, campaign)
    spec = read(directory/'configuration.json', deadline)['specification']
    helper = pin(directory/'helper-config.json', deadline)
    require(spec.get('config_sha256') == helper.sha256 and spec.get('config_text', '').encode() == helper.path.read_bytes()
            and spec.get('run_id') == run_id and spec.get('kind') == 'cell' and spec.get('controller') == queue.SOURCE
            and spec.get('harness') == queue.HARNESS and spec.get('root') == campaign.guest_root
            and spec.get('harness_repo') == frozen.host.HARNESS_REPO and spec.get('sail') == frozen.host.SAIL
            and spec.get('sail_sha256') == frozen.host.SAIL_SHA and spec.get('native_sha256') == frozen.host.NATIVE_SHA
            and spec.get('support_sha256') == config.support_manifest.sha256 and boot.get('config_sha256') == helper.sha256,
            'failed archived bootstrap config/source binding')
    require(read(artifacts/'engine-config.json', deadline) == engine['config'], 'raw failed engine config file differs')
    proof = queue.Prerequisites.model_validate(read(config.prerequisites.path, deadline)).references['graph500-24']
    for name, identity in proof.files.items():
        historical_pin = models.FilePin(path=proof.directory/name, **identity.model_dump())
        verify(historical_pin, deadline)
        evidence.append(historical_pin)
    reference = queue.audit_reference(proof, config, campaign)
    reference_boot = read(proof.directory/'container/artifacts/bootstrap-receipt.json', deadline)
    native_manifest = reference_boot['identities_before']['native']
    require(native_manifest == reference_boot['identities_after']['native']
            and native_manifest.get('root') == '/targets/graph-nuts-ffcfbd569/venv/lib/python3.12/site-packages/sail_nutmeg'
            and set(native_manifest.get('files_sha256', {})) == {'__init__.py', '_native.cpython-312-x86_64-linux-gnu.so',
                'argentea_factory.py', 'client.py', 'graph.py'}
            and native_manifest['files_sha256']['_native.cpython-312-x86_64-linux-gnu.so'] == frozen.host.NATIVE_SHA,
            'pinned historical full native package manifest')
    events = failure_metadata(host, producer, boot, engine, run_id, effective, frozen, native_manifest)
    require(producer['identities_before'].get('reference_phase') == reference
            and effective.references == Path(reference['config']['output'])
            and effective.vertices == Path(reference['config']['vertices']) and effective.edges == Path(reference['config']['edges'])
            and effective.reference_receipt_sha256 == proof.files['container/artifacts/receipt.json'].sha256,
            'failed selected full reference/input contract differs')
    gate = BASE.parent/'gate.lock'
    require(gate.is_dir() and not gate.is_symlink() and {p.name for p in gate.iterdir()} == {'owner.json'}, 'exact owned failure gate contents')
    owner_pin = pin(gate/'owner.json', deadline)
    owner = models.GateOwner.model_validate(read(owner_pin.path, deadline))
    require(owner.pid == expected_child_pid and owner.token == expected_gate_token and owner.run_id == run_id
            and owner.host == str(directory) and dead(expected_child_pid), 'failed host PID/gate owner uncertain')
    serial = BASE.parent/'serial-queue.lock'
    require(serial.is_dir() and not serial.is_symlink() and {p.name for p in serial.iterdir()} == {'owner.json'}, 'exact expected serial lock contents')
    serial_pin = pin(serial/'owner.json', deadline)
    serial_owner = read(serial_pin.path, deadline)
    require(serial_owner.get('owner_pid') == expected_serial_pid and serial_owner.get('token') == expected_serial_token
            and serial_owner.get('config') == config.model_dump(mode='json')
            and serial_owner.get('dataset') == 'graph500-24',
            'serial queue ownership differs')
    require((serial_may_be_current and expected_serial_pid == os.getpid()) or dead(expected_serial_pid),
            'prior serial queue owner still live')
    probes = fresh_probes(frozen, run_id, embedded['inspect']['id'], probe)
    for target in [*frozen.sources, *evidence, cell_pin, owner_pin, serial_pin]:
        verify(target, deadline)
    return models.FailureClosure(run_id=run_id, observed_utc=utc(), host_child_pid=expected_child_pid,
        gate_owner=owner, gate_owner_pin=owner_pin, serial_owner_pin=serial_pin, source_pins=frozen.sources,
        evidence_pins=[*evidence, cell_pin], physical_inventory={k: models.Identity.model_validate(v) for k, v in archive.items()},
        raw_outcomes={'host': host['outcome'], 'producer': producer['outcome'], 'bootstrap': boot['outcome'],
            'engine': engine['outcome'], 'engine_returncode': producer['engine_returncode'], 'container_exit': 1, 'container_oom_killed': True,
            'supervisor_configured_method_label': producer['actual_engine_method'], 'engine_actual_method': engine['actual_method']},
        oom_events=events, probes=probes, native_package_manifest=native_manifest)


def fresh_probes(frozen: Frozen, run_id: str, container_id: str, probe: ProbeFn = capture) -> list[models.Probe]:
    require(re.fullmatch(r'[a-f0-9]{64}', container_id) is not None, 'exact created container ID required')
    result: list[models.Probe] = []
    for target in ('sem-review-b8-'+run_id, container_id):
        absent = probe(frozen.host.DOCKER+['inspect', target], frozen.deadline)
        require(absent.returncode == 1 and re.search(r'(?:no such object|no such container):\s*'+re.escape(target)+r'(?:\s|$)',
            absent.stderr, re.IGNORECASE) is not None, 'fresh exact name/created ID absence not proven')
        result.append(absent)
    idle = probe(frozen.host.DOCKER+['ps', '-q'], frozen.deadline)
    require(idle.returncode == 0 and not idle.stdout.strip(), 'fresh Docker idle not proven')
    return [*result, idle]
