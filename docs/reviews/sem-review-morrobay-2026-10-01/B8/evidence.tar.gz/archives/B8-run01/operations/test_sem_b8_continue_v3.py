"""Offline continuation controls; fake children only, no configgen or queues."""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType
from typing import Any
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('sem_b8_continuation_v3_controls', '/tmp/sem-b8-continue-v3.py')
assert SPEC is not None and SPEC.loader is not None
HELPER: ModuleType = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = HELPER
SPEC.loader.exec_module(HELPER)
Json = dict[str, Any]


class Clock:
    def __init__(self) -> None:
        self.value = 0.0
    def now(self) -> float:
        return self.value
    def sleep(self, seconds: float) -> None:
        self.value += seconds


class Child:
    pid = 123456
    def __init__(self, codes: list[int | None]) -> None:
        self.codes = codes
    def poll(self) -> int | None:
        return self.codes.pop(0) if len(self.codes) > 1 else self.codes[0]


class Controls(unittest.TestCase):
    def receipt(self) -> Any:
        return HELPER.Receipt(options={}, owner_pid=1, started_utc=HELPER.utc(), observed_utc=HELPER.utc())

    def test_missing_wrong_and_exact_pythonpath(self) -> None:
        base = Path('/tmp/fake-B8')
        for environment in ({}, {'PYTHONPATH': '/tmp/wrong'}, {'PYTHONPATH': str(base/'support') + os.pathsep + '/tmp/extra'}):
            with (
                self.subTest(environment=environment),
                patch.dict(os.environ, environment, clear=True),
                self.assertRaisesRegex(ValueError, 'exact PYTHONPATH'),
            ):
                HELPER.validate_environment(base)
        with patch.dict(os.environ, {'PYTHONPATH': str(base/'support'), 'PYTHONDONTWRITEBYTECODE': '1'}, clear=True):
            self.assertEqual(HELPER.validate_environment(base)['PYTHONPATH'], str(base/'support'))

    def test_phase_success_records_identity_and_exit(self) -> None:
        with tempfile.TemporaryDirectory() as task:
            receipt, clock = self.receipt(), Clock()
            child = Child([None, 0])
            command = ['fake-configgen']
            HELPER.phase(command, 'prepare', receipt, Path(task)/'receipt.json', 10,
                         lambda _command, _log: child, clock.now, clock.sleep)
            self.assertEqual(receipt.phases[0].command, command)
            self.assertEqual(receipt.phases[0].returncode, 0)
            self.assertEqual(receipt.phases[0].pid, child.pid)
            self.assertIsNone(receipt.active_child_pid)

    def test_failure_stops_and_timeout_preserves_active_child(self) -> None:
        cases: list[tuple[list[int | None], int | None]] = [([1], None), ([None], 123456)]
        for codes, active in cases:
            with self.subTest(codes=codes), tempfile.TemporaryDirectory() as task:
                receipt, clock = self.receipt(), Clock()
                child = Child(codes)
                with self.assertRaises(ValueError):
                    HELPER.phase(['fake-queue'], 'queue', receipt, Path(task)/'receipt.json', 2,
                                 lambda _command, _log, selected=child: selected, clock.now, clock.sleep)
                self.assertEqual(len(receipt.phases), 1)
                self.assertEqual(receipt.active_child_pid, active)
                self.assertTrue((Path(task)/'receipt.json').is_file())

    def test_reference_exact_pid_wait_and_reuse_refusal(self) -> None:
        with tempfile.TemporaryDirectory() as task:
            base = Path(task)
            receipt, clock = self.receipt(), Clock()
            launch = {'command': ['fake-reference']}
            live = {'pid': HELPER.REFERENCE_PID, 'start': HELPER.REFERENCE_START, 'argv': launch['command']}
            observations: list[Json | None] = [live, None]
            HELPER.wait_reference(base, launch, receipt, base/'receipt.json', 10,
                                  lambda _pid: observations.pop(0), clock.now, clock.sleep)
            self.assertEqual([row['state'] for row in receipt.reference_observations], ['running', 'not_present'])
            wrong = copy.deepcopy(live)
            wrong['start'] = 'another process incarnation'
            with self.assertRaisesRegex(ValueError, 'PID reused'):
                HELPER.wait_reference(base, launch, receipt, base/'receipt.json', 10,
                                      lambda _pid: wrong, clock.now, clock.sleep)

    def test_reference_deadline_and_failed_host_do_not_continue(self) -> None:
        with tempfile.TemporaryDirectory() as task:
            base = Path(task)
            receipt, clock = self.receipt(), Clock()
            launch = {'command': ['fake-reference']}
            live = {'pid': HELPER.REFERENCE_PID, 'start': HELPER.REFERENCE_START, 'argv': launch['command']}
            with self.assertRaisesRegex(ValueError, 'wait deadline'):
                HELPER.wait_reference(base, launch, receipt, base/'receipt.json', 2,
                                      lambda _pid: live, clock.now, clock.sleep)
            (base/'graph500-reference01').mkdir()
            (base/'graph500-reference01/result.json').write_text(json.dumps({'finished_utc': HELPER.utc(), 'outcome': 'error'}))
            with self.assertRaisesRegex(ValueError, 'reference failed'):
                HELPER.wait_reference(base, launch, receipt, base/'receipt.json', 2,
                                      lambda _pid: live, clock.now, clock.sleep)

    def test_queue_requires_all30_qualified_and_no_lock(self) -> None:
        with tempfile.TemporaryDirectory() as task, patch.object(HELPER, 'adapter_provenance', return_value={'adapter':'fixed','frozen_queue':'fixed-queue'}):
            base = Path(task)/'B8-test';base.mkdir()
            dataset='cit-Patents'
            folder=base/'queue-cit-patents';folder.mkdir()
            steps=[{'dataset':dataset,'run_id':f'cell-{i}'} for i in range(30)]
            cells=[{'step':step,'outcome':'passed','returncode':0,'finished_utc':HELPER.utc(), 'audit':{'qualified':True}} for step in steps]
            config={'a':'pinned'}
            body={'dataset':dataset,'config':config,'outcome':'passed','finished_utc':HELPER.utc(),
                  'active_child_pid':None,'lock_retained':False,'error':None,'cells':cells,
                  'closure_adapter': {'adapter': 'fixed', 'frozen_queue': 'fixed-queue'}, 'pins':['fixed', 'fixed-queue']}
            path=folder/'receipt.json';path.write_text(json.dumps(body))
            HELPER.queue_closed(base,dataset,{'steps':steps},config)
            body['cells'][4]['audit']['qualified']=False
            path.write_text(json.dumps(body))
            with self.assertRaisesRegex(ValueError,'thirty'):
                HELPER.queue_closed(base,dataset,{'steps':steps},config)
            body['cells'][4]['audit']['qualified']=True
            path.write_text(json.dumps(body));(base.parent/'serial-queue.lock').mkdir()
            with self.assertRaisesRegex(ValueError,'phase overlap'):
                HELPER.queue_closed(base,dataset,{'steps':steps},config)

    def test_initial_receipt_serializes_gate_path_before_refusal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base=Path(temporary)/'B8';base.mkdir()
            output=base/'continuation02'
            options=HELPER.Options(base=base,output=output,closure_gate_receipt=base/'reference-closure-gate02.json',
                                   closure_gate_sha256='0'*64)
            with patch.object(HELPER,'BASE',base), patch.dict(os.environ,{},clear=True):
                self.assertEqual(HELPER.run(options),1)
            value=json.loads((output/'receipt.json').read_text())
            self.assertEqual(value['outcome'],'error')
            self.assertIn('exact PYTHONPATH',value['error'])
            self.assertEqual(value['options']['closure_gate_receipt'],str(options.closure_gate_receipt))
            self.assertEqual(value['phases'],[])

    def test_host_only_commands_bind_adapter_and_frozen_queue(self) -> None:
        base = Path('/tmp/offline-B8')
        generated = base/'generated-queues02'
        command = HELPER.preparation_command(base, generated)
        self.assertEqual(command[2], str(base/'operations/sem-b8-configs-closure-v2.py'))
        self.assertEqual(command[command.index('--frozen-generator')+1], str(base/'operations/sem-b8-configs.py'))
        self.assertEqual(command[command.index('--adapter-sha256')+1], HELPER.FROZEN['operations/sem-b8-queue-closure-adapter-v2.py'])
        self.assertEqual(command[command.index('--queue-sha256')+1], HELPER.FROZEN['controller-profile/run_pair_queue.py'])
        self.assertEqual(command[command.index('--output')+1], str(generated))
        for dataset in ('cit-Patents', 'graph500-24'):
            configuration = generated/('queue-'+dataset.lower()+'.json')
            observed = HELPER.queue_command(base, configuration, dataset)
            self.assertEqual(observed[2], str(base/'operations/sem-b8-queue-closure-adapter-v2.py'))
            self.assertEqual(observed[observed.index('--adapter-sha256')+1], HELPER.FROZEN['operations/sem-b8-queue-closure-adapter-v2.py'])
            self.assertEqual(observed[-2:], ['--dataset', dataset])

    def test_full_reference_gate_pass_and_false_proof_refusal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)/'B8';base.mkdir()
            for path in (base/'operations', base/'support', base/'continuation01', base/'generated-queues01'):
                path.mkdir()
            adapter = base/'operations/sem-b8-queue-closure-adapter-v2.py';adapter.write_text('adapter')
            helper = base/'operations/sem-b8-closure-reference-gate-v2.py';helper.write_text('helper')
            (base/'support/run_pair_queue.py').write_text('frozenqueue')
            for name in ('continuation01/receipt.json', 'generated-queues01/preparation.json'):
                (base/name).write_text(json.dumps({'outcome':'error', 'active_child_pid':None}))
            value: Json = {'outcome':'passed', 'finished_utc':HELPER.utc(), 'engine_executed':False,
                'helper':HELPER.pin(helper), 'adapter':HELPER.pin(adapter), 'references':{}}
            for name in ('cit-reference01','graph500-reference01'):
                directory=base/name;(directory/'container/artifacts').mkdir(parents=True)
                archive={'tiny.i64le':{'bytes':16,'sha256':'0'*64}}
                producer={'vertex_rows':8,'edge_rows':10,'artifacts':{'adjacency':'sealed'}}
                (directory/'result.json').write_text(json.dumps({'artifacts':archive}))
                (directory/'collected-manifest.json').write_text(json.dumps(archive))
                file=directory/'container/artifacts/receipt.json';file.write_text(json.dumps(producer))
                value['references'][name]={'outcome':'passed','full_physical_archive_hashed_before_after':True,
                    'archive':archive,'vertex_rows':8,'edge_rows':10,'reference_artifacts':producer['artifacts'],
                    'metadata_files':{'run_id':name,'directory':str(directory), 'files':{
                        'container/artifacts/receipt.json':{k:v for k,v in HELPER.pin(file).items() if k!='path'}}}}
            path=base/'reference-closure-gate02.json';path.write_text(json.dumps(value))
            frozen={**HELPER.FROZEN, 'operations/sem-b8-closure-reference-gate-v2.py':HELPER.pin(helper)['sha256'],
                    'operations/sem-b8-queue-closure-adapter-v2.py':HELPER.pin(adapter)['sha256']}
            with patch.object(HELPER,'FROZEN',frozen):
                options=HELPER.Options(base=base,output=base/'continuation02',closure_gate_receipt=path,
                                       closure_gate_sha256=HELPER.pin(path)['sha256'])
                receipt=self.receipt();HELPER.closure_gate_closed(options,receipt)
                self.assertEqual(set(receipt.full_reference_gate['references']), {'cit-reference01','graph500-reference01'})
                self.assertEqual(len(receipt.preserved_failures),2)
                HELPER.verify_pins(receipt)
                for failure in ('hash', 'missing', 'source'):
                    bad=copy.deepcopy(value)
                    if failure=='hash':
                        bad['references']['graph500-reference01']['full_physical_archive_hashed_before_after']=False
                    elif failure=='missing':
                        del bad['references']['cit-reference01']
                    else:
                        bad['adapter']['sha256']='0'*64
                    path.write_text(json.dumps(bad))
                    wrong=HELPER.Options(base=base,output=base/'continuation02',closure_gate_receipt=path,
                                         closure_gate_sha256=HELPER.pin(path)['sha256'])
                    with self.subTest(failure=failure), self.assertRaises(ValueError):
                        HELPER.closure_gate_closed(wrong,self.receipt())

    def test_changed_pin_and_existing_log_refused(self) -> None:
        with tempfile.TemporaryDirectory() as task:
            base=Path(task)
            p=base/'source.py';p.write_text('original')
            receipt=self.receipt();receipt.pins.append(HELPER.pin(p));p.write_text('mutated')
            with self.assertRaisesRegex(ValueError,'immutable'):
                HELPER.verify_pins(receipt)
            receipt=self.receipt();(base/'queue.log').write_text('retained')
            with self.assertRaisesRegex(ValueError,'fresh phase log'):
                HELPER.phase(['fake'], 'queue', receipt, base/'receipt.json', 2,
                             lambda _command,_log: self.fail('must not spawn'))


if __name__ == '__main__':
    unittest.main()
