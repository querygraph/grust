"""Fake child/closure controls for serial policy; no Docker/engines or real locks."""
from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Literal
from unittest.mock import MagicMock, patch

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_run as runner

Shape = Literal['adjacency', 'representatives', 'min-label-initial-round']
Variant = Literal['union', 'array-explode']
SHAPES: tuple[Shape, ...] = ('adjacency', 'representatives', 'min-label-initial-round')
ORDER: tuple[Variant, ...] = ('union', 'array-explode', 'union', 'array-explode', 'array-explode', 'union', 'union', 'array-explode', 'array-explode', 'union')


class FakeChild:
    def __init__(self, result: int) -> None:
        self.pid = 9876543
        self.result = result

    def wait(self, timeout: float | None = None) -> int:
        return self.result

    def poll(self) -> int | None:
        return self.result


class Fixture:
    def __init__(self, root: Path) -> None:
        self.base = root/'base'
        self.base.mkdir()
        self.output = self.base/'queue-tail'
        self.output.mkdir()
        dummy = root/'immutable.json'
        core.write(dummy, {}, fresh=True)
        self.pin = core.pin(dummy, core.Deadline.after(10))
        self.mappings: list[models.Mapping] = []
        original: models.Step | None = None
        for shape in SHAPES:
            for n, variant in enumerate(ORDER, 1):
                step = models.Step(dataset='graph500-24', shape=shape, variant=variant,
                    run_id=f'b8-graph500-24-{shape}-{n:02}-{variant}', role='warmup' if n <= 2 else 'measured',
                    sequence_within_contrast=n, measured_block=None if n <= 2 else 1 if n <= 6 else 2)
                if original is None:
                    original = step
                    continue
                actual = step.model_copy(update={'run_id': 'b8-tail01-'+step.run_id.removeprefix('b8-')})
                self.mappings.append(models.Mapping(original=step, actual=actual, original_config=self.pin, actual_config=self.pin))
        assert original is not None
        prepared = models.Prepared(observed_utc=core.utc(), original_queue_config=self.pin, queue_config=self.pin,
            original_cit_queue_receipt=self.pin, original_graph_queue_receipt=self.pin, original_continuation_receipt=self.pin,
            original_oom_closure=self.pin, original31_evidence=[], sources=[], mappings=self.mappings,
            original_plan=self.pin, derived_plan=self.pin, original_failed_step=original)
        authorization = models.Authorization(policy='b8-tail-warmups-before-two-UAAU-blocks-v1', approved_by='root',
            original_queue_config=self.pin, named_failures={m.actual.run_id: m.actual_config.sha256 for m in self.mappings})
        self.receipt = models.TailReceipt(observed_utc=core.utc(), started_utc=core.utc(), owner_pid=os.getpid(),
            token='a'*32, prepared=self.pin, authorization=self.pin, sources=[], original31=[], original_failed_step=original,
            cells=[models.Cell(mapping=m) for m in self.mappings])
        self.serial = root/'serial-queue.lock'
        self.serial.mkdir()
        config: Any = SimpleNamespace(output=self.output, python=Path('/python'), driver=self.pin, campaign=self.pin)
        owner = runner.SerialOwner(owner_pid=os.getpid(), token=self.receipt.token, config={}, started_utc=core.utc(),
            prepared=self.pin, authorization=self.pin)
        core.write(self.serial/'owner.json', owner, fresh=True)
        serial_pin = core.pin(self.serial/'owner.json', core.Deadline.after(10))
        queue = SimpleNamespace(unoccupied=lambda _base, _run: None, raw_receipts=lambda _path: {
            'host': {'records': {'container': {'inspect': {'id': 'b'*64}}}}}, Step=models.Step,
            audit_cell=MagicMock(return_value={'qualified': True, 'run_id': self.mappings[0].actual.run_id}))
        host = SimpleNamespace(DOCKER=['fake-docker'], CellConfiguration=SimpleNamespace(model_validate=lambda _value: {}))
        frozen = core.Frozen(queue, host, None, core.Deadline.after(60), [])
        self.state = runner.State(frozen, prepared, authorization, config, None, {}, self.receipt,
            core.Deadline.after(60), 10, serial_pin)

    def failure(self, cell: models.Cell) -> models.FailureClosure:
        gate = self.base.parent/'gate.lock'
        gate.mkdir()
        owner = models.GateOwner(action='run', host=str(self.base/cell.mapping.actual.run_id), pid=9876543,
            run_id=cell.mapping.actual.run_id, started_utc=core.utc(), token='c'*32)
        core.write(gate/'owner.json', owner, fresh=True)
        owner_pin = core.pin(gate/'owner.json', core.Deadline.after(10))
        return models.FailureClosure(run_id=cell.mapping.actual.run_id, observed_utc=core.utc(), host_child_pid=owner.pid,
            gate_owner=owner, gate_owner_pin=owner_pin, serial_owner_pin=self.state.serial_owner, source_pins=[],
            evidence_pins=[], physical_inventory={'control': self.pin.identity()}, native_package_manifest={},
            raw_outcomes={'producer': 'oom'}, oom_events={'final': {'oom': 1, 'oom_kill': 1}}, probes=[
                models.Probe(argv=['fake-docker', 'inspect', 'b'*64], observed_utc=core.utc(), returncode=1,
                    stdout='', stderr='no such object: '+'b'*64)])

    def idle(self) -> models.Probe:
        return models.Probe(argv=['fake-docker', 'ps', '-q'], observed_utc=core.utc(), returncode=0, stdout='', stderr='')


class SchedulingControls(unittest.TestCase):
    def test_original_failed_warmup_skips_eight_and_next_shapes_keep_exact_blocks(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            calls: list[models.Step] = []
            def passed(_state: runner.State, cell: models.Cell, _spawn: runner.Spawner) -> None:
                calls.append(cell.mapping.actual)
                cell.disposition, cell.qualified = 'passed', True
            with patch.object(core, 'BASE', f.base), patch.object(core, 'capture', return_value=f.idle()), patch.object(runner, 'run_cell', side_effect=passed):
                rc = runner.execute(f.state, lambda _argv, _log: FakeChild(0))
            self.assertEqual(rc, 1)
            self.assertEqual(f.receipt.outcome, 'completed_with_failures')
            self.assertEqual(len(calls), 21)
            skipped = [c for c in f.receipt.cells if c.disposition == 'not_started_due_to_failed_warmup']
            self.assertEqual(len(skipped), 8)
            self.assertTrue(all(not c.qualified and c.child_pid is None and c.returncode is None and not c.command and c.pass_audit is None for c in skipped))
            for shape in SHAPES[1:]:
                self.assertEqual(tuple(s.variant for s in calls if s.shape == shape), ORDER)
                self.assertEqual([s.measured_block for s in calls if s.shape == shape], [None, None, 1, 1, 1, 1, 2, 2, 2, 2])
            self.assertFalse(f.serial.exists())
            self.assertTrue(f.receipt.serial_lock_archived is not None and (f.receipt.serial_lock_archived/'owner.json').is_file())

    def test_second_shape_closed_oom_warmup_skips_its_block_then_next_shape(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            calls: list[models.Step] = []
            def accepted(_state: runner.State, cell: models.Cell, _spawn: runner.Spawner) -> None:
                calls.append(cell.mapping.actual)
                oom = cell.mapping.actual.shape == 'representatives' and cell.mapping.actual.sequence_within_contrast == 1
                cell.disposition, cell.qualified = ('closed_oom', False) if oom else ('passed', True)
            with patch.object(core, 'BASE', f.base), patch.object(core, 'capture', return_value=f.idle()), patch.object(runner, 'run_cell', side_effect=accepted):
                self.assertEqual(runner.execute(f.state, lambda _argv, _log: FakeChild(0)), 1)
            self.assertEqual(len(calls), 13)
            self.assertEqual(tuple(s.variant for s in calls if s.shape == 'min-label-initial-round'), ORDER)
            self.assertEqual(len([c for c in f.receipt.cells if c.disposition == 'not_started_due_to_failed_warmup']), 16)

    def test_uncertain_first_closure_stops_and_retains_serial(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            calls: list[str] = []
            def uncertain(_state: runner.State, cell: models.Cell, _spawn: runner.Spawner) -> None:
                calls.append(cell.mapping.actual.run_id)
                raise ValueError('uncertain owned closure')
            with patch.object(core, 'BASE', f.base), patch.object(runner, 'run_cell', side_effect=uncertain), self.assertRaisesRegex(ValueError, 'uncertain'):
                runner.execute(f.state, lambda _argv, _log: FakeChild(1))
            self.assertEqual(len(calls), 1)
            self.assertTrue(f.serial.is_dir())
            self.assertTrue(all(c.disposition == 'pending' for c in f.receipt.cells[1:]))

    def test_each_shape_requires_both_qualified_real_warmups(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            for shape in SHAPES:
                other = next(s for s in SHAPES if s != shape)
                f.receipt.original_failed_step = f.receipt.original_failed_step.model_copy(update={'shape': other})
                pair: list[models.Cell] = []
                for n, variant in enumerate(ORDER[:2], 1):
                    step = models.Step(dataset='graph500-24', shape=shape, variant=variant, run_id=f'fake-{shape}-{n}',
                        role='warmup', sequence_within_contrast=n, measured_block=None)
                    pair.append(models.Cell(mapping=models.Mapping(original=step, actual=step, original_config=f.pin, actual_config=f.pin),
                        disposition='passed', qualified=True))
                f.receipt.cells = pair
                self.assertEqual(runner.warmup_failures(f.receipt, shape), [])
                pair[1].disposition, pair[1].qualified = 'closed_oom', False
                self.assertEqual(runner.warmup_failures(f.receipt, shape), [pair[1].mapping.actual.run_id])
                pair[1].disposition = 'pending'
                with self.assertRaisesRegex(ValueError, 'terminal'):
                    runner.warmup_failures(f.receipt, shape)


class ClosureControls(unittest.TestCase):
    def test_fake_oom_owned_rename_then_next_full_pass_audit(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            first, following = f.receipt.cells[0], f.receipt.cells[9]
            closure = f.failure(first)
            f.state.frozen.queue.audit_cell.return_value = {'qualified': True, 'run_id': following.mapping.actual.run_id}
            with patch.object(core, 'BASE', f.base), patch.object(core, 'pid_absent', return_value=True), patch.object(core, 'audit_oom', return_value=closure) as audit, patch.object(core, 'fresh_probes', return_value=[]):
                # Gate is created by the fake host after launch, as in the real driver.
                gate = f.base.parent/'gate.lock'
                saved_owner = (gate/'owner.json').read_bytes()
                (gate/'owner.json').unlink()
                gate.rmdir()
                def spawn_oom(_argv: list[str], _log: Path) -> FakeChild:
                    gate.mkdir()
                    (gate/'owner.json').write_bytes(saved_owner)
                    return FakeChild(1)
                runner.run_cell(f.state, first, spawn_oom)
                self.assertEqual(first.disposition, 'closed_oom')
                self.assertFalse(first.qualified)
                self.assertIsNotNone(first.failure_closure)
                self.assertFalse(gate.exists())
                audit.assert_called_once()
                runner.run_cell(f.state, following, lambda _argv, _log: FakeChild(0))
            self.assertEqual(following.disposition, 'passed')
            self.assertTrue(following.qualified)
            f.state.frozen.queue.audit_cell.assert_called_once()
            self.assertTrue(f.serial.is_dir())

    def test_unauthorized_oom_never_releases_gate(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            cell = f.receipt.cells[0]
            f.state.authorization.named_failures.clear()
            with patch.object(core, 'BASE', f.base), patch.object(core, 'pid_absent', return_value=True), patch.object(core, 'audit_oom') as audit, self.assertRaisesRegex(ValueError, 'authorized'):
                runner.run_cell(f.state, cell, lambda _argv, _log: FakeChild(1))
            audit.assert_not_called()
            self.assertTrue(f.serial.is_dir())
            self.assertFalse(cell.qualified)

    def test_changed_owner_refuses_rename(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            (f.serial/'owner.json').write_text('{}')
            destination = f.serial.with_name('serial-queue.lock.closed-control')
            with self.assertRaisesRegex(ValueError, 'immutable pin'):
                runner.preserve_owned_lock(f.serial, f.state.serial_owner, destination, core.Deadline.after(10))
            self.assertTrue(f.serial.is_dir())
            self.assertFalse(destination.exists())

    def test_late_pass_source_failure_never_marks_qualified(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            cell = f.receipt.cells[0]
            with patch.object(core, 'BASE', f.base), patch.object(core, 'pid_absent', return_value=True), patch.object(core, 'fresh_probes', return_value=[]), patch.object(runner, 'sources', side_effect=[None, None, ValueError('changed late source')]), self.assertRaisesRegex(ValueError, 'late source'):
                runner.run_cell(f.state, cell, lambda _argv, _log: FakeChild(0))
            self.assertFalse(cell.qualified)
            self.assertEqual(cell.disposition, 'child_exited')
            self.assertTrue(f.serial.is_dir())

    def test_interrupted_wait_retains_child_identity(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            f.receipt.active_child_pid = 9876543
            f.receipt.interruption_signals = [15]
            with self.assertRaises(InterruptedError):
                runner.wait_child(FakeChild(0), f.state)
            self.assertEqual(f.receipt.active_child_pid, 9876543)
            self.assertTrue(f.serial.is_dir())

    def test_expired_wait_never_kills_child(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            f.state.queue_deadline = core.Deadline(0)
            child = FakeChild(0)
            with self.assertRaises(TimeoutError):
                runner.wait_child(child, f.state)
            self.assertEqual(child.poll(), 0)
            self.assertTrue(f.serial.is_dir())

    def test_wait_poll_mismatch_stops_before_any_audit(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            f = Fixture(Path(directory))
            child = FakeChild(0)
            child.result = 1
            with patch.object(core, 'BASE', f.base), patch.object(core, 'pid_absent', return_value=True), patch.object(runner, 'wait_child', return_value=0), self.assertRaisesRegex(ValueError, 'exact child wait'):
                runner.run_cell(f.state, f.receipt.cells[0], lambda _argv, _log: child)
            f.state.frozen.queue.audit_cell.assert_not_called()
            self.assertTrue(f.serial.is_dir())


if __name__ == '__main__':
    unittest.main()
