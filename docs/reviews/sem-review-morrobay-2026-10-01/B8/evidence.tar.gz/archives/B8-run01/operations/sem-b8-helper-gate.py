from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import json
import os
import re
import subprocess
import sys
import tarfile
import traceback
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    repo, expected, out = Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve()
    plan_path = Path('/tmp/sem-b8-helper-plan.json')
    plan = json.loads(plan_path.read_text())
    plan_sha = sha(plan_path)
    out.mkdir(parents=True, exist_ok=False)
    source = Path('/Volumes/Apo/graph-tests/workspaces/sem-review-20261001/pecan-f3b3ef8fc')
    receipt = {'started_utc': utc(), 'outcome': 'checking', 'commit': expected,
               'tree': plan['tree'], 'commands': [], 'files_sha256': plan['files_sha256'],
               'scope': 'Exact detached Grust B8 experiment helpers; offline controls only, no engine or benchmark qualification.',
               'cargo_gates': 'Not applicable: staged Python experiment material and documents, no Rust or publishable crate changes.'}
    commands = receipt['commands']
    def git(path: Path, *args: str) -> str:
        return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()
    def identity() -> dict[str, str]:
        assert subprocess.run(['git', '-C', str(repo), 'symbolic-ref', '-q', 'HEAD'],
                              stdout=subprocess.DEVNULL, check=False).returncode == 1
        observed = {'head': git(repo, 'rev-parse', 'HEAD'), 'tree': git(repo, 'rev-parse', 'HEAD^{tree}'),
                    'status': git(repo, 'status', '--porcelain=v1', '--untracked-files=all'),
                    'source': git(source, 'rev-parse', 'HEAD'), 'source_status': git(source, 'status', '--porcelain=v1')}
        assert observed['head'] == expected and observed['tree'] == plan['tree']
        assert not observed['status'] and not observed['source_status']
        assert observed['source'] == 'f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a'
        assert git(repo, 'rev-list', '--parents', '-n', '1', 'HEAD').split() == [expected, plan['parent']]
        assert set(git(repo, 'diff', '--name-only', plan['parent'], 'HEAD').splitlines()) == set(plan['files_sha256'])
        return observed
    target = repo / 'target/B8-offline-gate'
    support = repo / 'docs/reviews/sem-review-morrobay-2026-10-01/B8'
    env = {**os.environ, 'CARGO_TARGET_DIR': str(target), 'CARGO_INCREMENTAL': '0',
           'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1',
           'MYPY_CACHE_DIR': str(target / 'mypy'),
           'MYPYPATH': str(source / 'examples/extensions/graph-algorithms/src')}
    def run(label: str, argv: list[str]) -> None:
        result = subprocess.run(argv, cwd=repo, env=env, text=True, capture_output=True, timeout=180, check=False)
        (out / (label + '.log')).write_text(result.stdout + result.stderr)
        commands.append({'label': label, 'argv': argv, 'returncode': result.returncode})
        assert result.returncode == 0, label + ': ' + (result.stdout + result.stderr)[-10000:]
    try:
        receipt['before'] = identity()
        for name, digest in plan['files_sha256'].items():
            path = repo / name
            assert path.is_file() and not path.is_symlink() and sha(path) == digest, name
            if path.suffix == '.py':
                for node in ast.walk(ast.parse(path.read_text())):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        assert node.returns is not None, (name, node.name, 'return type')
                        for arg in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]:
                            assert arg.arg in ('self', 'cls') or arg.annotation is not None, (name, node.name, arg.arg)
                        assert not any(isinstance(child, (ast.Import, ast.ImportFrom)) for child in ast.walk(node)), (name, node.name, 'local import')
        assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)( |$)', (repo / 'codex-to-codex.md').read_text(), re.M)
        index = json.loads((support / 'preparation-evidence-index.json').read_text())
        archive_path = support / 'preparation-evidence.tar.gz'
        assert archive_path.stat().st_size == index['archive_bytes'] and sha(archive_path) == index['archive_sha256']
        entries = {entry['member']: entry for entry in index['members']}
        assert len(entries) == len(index['members'])
        seen = set()
        with tarfile.open(archive_path, 'r:gz') as archive:
            for member in archive:
                path = PurePosixPath(member.name)
                assert member.isfile() and not path.is_absolute() and '..' not in path.parts
                assert member.name not in seen and member.name in entries
                stream = archive.extractfile(member)
                assert stream is not None
                data = stream.read()
                assert len(data) == member.size == entries[member.name]['bytes']
                assert hashlib.sha256(data).hexdigest() == entries[member.name]['sha256']
                seen.add(member.name)
        assert seen == set(entries)
        venv = Path('/tmp/sem-output-oracle-venv/bin')
        run('ruff', [str(venv / 'ruff'), 'check', str(support)])
        run('mypy', [str(venv / 'mypy'), '--strict', '--follow-imports=silent', '--ignore-missing-imports', str(support)])
        run('controls', [str(venv / 'python'), '-B', '-m', 'unittest', 'discover', '-v', '-s', str(support), '-p', 'test_*.py'])
        receipt['versions'] = {n: importlib.metadata.version(n) for n in ('ruff', 'mypy', 'numpy', 'pyarrow', 'pydantic')}
        receipt['outcome'] = 'passed'
    except Exception as error:
        receipt.update(outcome='failed', error=repr(error), traceback=traceback.format_exc())
    finally:
        try:
            receipt['after'] = identity()
            assert receipt.get('before') == receipt['after']
            assert all(sha(repo / name) == digest for name, digest in plan['files_sha256'].items())
            assert sha(plan_path) == plan_sha
        except Exception as error:
            receipt.update(outcome='failed', finalization_error=repr(error))
        receipt['finished_utc'] = utc()
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'outcome': receipt['outcome'], 'commit': expected, 'tree': plan['tree'],
                      'receipt': str(out / 'receipt.json'), 'error': receipt.get('error')}))
    return 0 if receipt['outcome'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
