"""Read finalized B8 metadata and delegate qualification; never publish or package."""
from __future__ import annotations

import argparse
import importlib.util
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_publication_v2 as adapter


def run(base: Path, out: Path) -> models.Json:
    root = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location('b8_tail_actual_metadata_control',root/'sem-b8-publish-tail-v5.py')
    assert spec is not None and spec.loader is not None
    wrapper = importlib.util.module_from_spec(spec); sys.modules[spec.name] = wrapper; spec.loader.exec_module(wrapper)
    ops,prep = base/'operations',base/'tail-preparation01'
    options: Any = wrapper.Options(base=base,dest=root/'uncreated-B8-control-destination',
        frozen_publisher=ops/'sem-b8-publish-report-v2.py',frozen_host_wrapper=ops/'sem-b8-publish-host-provenance-v3.py',
        frozen_gate=ops/'sem-B8-publication-gate.py',frozen_host_gate=ops/'sem-B8-publication-gate-v2.py',
        publication_gate=root/'sem-B8-tail-publication-gate-v2.py',host_preparation=base/'generated-queues02/preparation.json',
        reference_closure_gate=base/'reference-closure-gate02.json',prepared=prep/'prepared.json',
        preparation_attempt=prep/'preparation-receipt.json',authorization=prep/'root-authorization01.json',
        root_review=prep/'root-review01.json',tail_receipt=base/'queue-graph500-tail01/receipt.json',
        preservation=base/'original-failed-locks-preserved01.json',
        retained_evidence=[base/'continuation01/receipt.json',base/'generated-queues01/preparation.json'])
    io_state = adapter.IO(core.Deadline.after(120))
    loaded,value = wrapper.provenance(options,io_state)
    publisher,host,historical = loaded
    wrapper.install(publisher,host,historical,value,options,io_state)
    paths = [value.original_cit_receipt.path,value.original_graph_receipt.path,value.tail_queue.path]
    queues = publisher.queue_documents(base,paths)
    plan = adapter.json_pin(value.derived_plan,io_state.read)
    rows = [publisher.audit_cell(step,base,queues) for step in plan['steps']]
    contrasts = [publisher.contrast([r for r in rows if (r['step']['dataset'],r['step']['shape']) == (d,s)])
                 for d in publisher.DATASETS for s in publisher.SHAPES]
    counts = dict(Counter(r['status'] for r in rows))
    core.require(counts == {'passed':40,'failed':4,'not_started_due_to_failed_warmup':16},
                 'actual final 40pass/4OOM/16skip metadata differs')
    core.require(sum(c['ratio_status'] == 'withheld' for c in contrasts) == 2, 'warmup-failed comparisons not withheld')
    result: models.Json = {'outcome':'PASS_ACTUAL_FINAL_METADATA_AND_UNCHANGED_POSITIVE_QUALIFICATION',
        'observed_utc':core.utc(),'source':io_state.pin(root/'sem-b8-publish-tail-v5.py').model_dump(mode='json'),
        'adapter':io_state.pin(Path(adapter.__file__).resolve()).model_dump(mode='json'),
        'actual_tail':value.tail_queue.model_dump(mode='json'),'cell_counts':counts,'all60_qualified':False,
        'all60_attempted':False,'protocol_finished_terminal_evidence':True,
        'contrasts':contrasts,'rows':[{'actual':r['step'],'original':r['original_step'],'qualified':r['qualified'],
            'status':r['status'],'reasons':r['reasons']} for r in rows],
        'physical_payload_read':False,'engine_or_Docker_actions':False,'package_or_report_written':False,
        'scope':'Read-only retained metadata and frozen positive qualification/ratio functions; not a detached candidate gate or physical oracle rerun.'}
    core.write(out,result,fresh=True)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    result = run(args.base.resolve(),args.out.resolve())
    print(result['outcome'],result['cell_counts'])
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
