"""Prepare B8 reference/tiny/queue configs from actual retained evidence.

No engine, Docker, downloading, guest mutation, retry or cleanup. Source only
until root runs it after the profile and required closed receipts exist.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from types import ModuleType
from typing import Any, Literal, cast

from pydantic import BaseModel, ConfigDict, Field

BASE = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01')
ROOT = '/targets/sem-review-20261001/B8-run01'
A2_EVIDENCE = BASE.parent / 'A2-run04/validation04/container/artifacts/receipt.json'
CIT_INPUTS = '/targets/sail-stream-experiments-20260930/sem-wcc-pilot-inputs'
CIT_FILES = {'vertices': {'bytes': 3861941, 'sha256': '0969ea9ede0969e18e76a2c70191ed7ccecaecb9f1da6d954093dbefbc8958aa'},
             'edges': {'bytes': 70037384, 'sha256': '70bcba17b5a7762ef5a0c3d16c1dc37a352461b83e338f550ae897d844f0268f'}}
URLS = {'vertices.parquet': 'https://datasets.ldbcouncil.org/graphalytics-parquet/graph500-24-v.parquet',
        'edges.parquet': 'https://datasets.ldbcouncil.org/graphalytics-parquet/graph500-24-e.parquet'}
SHAPES = ('adjacency', 'representatives', 'min-label-initial-round')
VARIANTS = ('union', 'array-explode')


class Options(BaseModel):
    model_config = ConfigDict(extra='forbid')
    action: Literal['reference', 'tiny', 'queues']
    output: Path
    driver_sha256: str = Field(pattern=r'^[a-f0-9]{64}$')
    queue_sha256: str = Field(pattern=r'^[a-f0-9]{64}$')
    dataset: Literal['cit-Patents', 'graph500-24'] | None = None
    stage_id: str = 'stage01'
    cit_reference_id: str = 'cit-reference01'
    graph500_reference_id: str = 'graph500-reference01'
    tiny_reference_id: str = 'tiny-reference01'
    graph500_stage_id: str = 'data-stage01'
    python: Path = Path('/tmp/sem-output-oracle-venv/bin/python')


class Preparation(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)
    schema_version: Literal[1] = 1
    outcome: Literal['checking', 'prepared', 'error'] = 'checking'
    options: Options
    started_utc: str
    finished_utc: str | None = None
    source_sha256: str
    artifacts: dict[str, dict[str, Any]] = Field(default_factory=dict)
    error: str | None = None
    traceback: str | None = None
    execution_scope: str = 'Configs/metadata only; no timed cell, engine, container, download, guest mutation or cleanup.'


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def sha(path: Path) -> str:
    require(path.is_file() and not path.is_symlink(), 'regular evidence file: ' + str(path))
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path: Path) -> dict[str, Any]:
    require(path.is_file() and not path.is_symlink(), 'regular metadata file: ' + str(path))
    raw: Any = json.loads(path.read_text())
    require(isinstance(raw, dict), 'metadata JSON object')
    return cast(dict[str, Any], raw)


def write(path: Path, value: BaseModel | dict[str, Any]) -> None:
    data = value.model_dump(mode='json') if isinstance(value, BaseModel) else value
    with path.open('x') as stream:
        stream.write(json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def save(path: Path, receipt: Preparation) -> None:
    temporary = path.with_suffix('.tmp')
    with temporary.open('w') as stream:
        stream.write(receipt.model_dump_json(indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def model(queue: ModuleType, name: str, fields: dict[str, Any]) -> BaseModel:
    instance = getattr(queue, name).model_validate(fields)
    require(isinstance(instance, BaseModel), 'structured queue model ' + name)
    return cast(BaseModel, instance)


def pin(queue: ModuleType, path: Path) -> dict[str, Any]:
    instance = queue.pin(path)
    require(isinstance(instance, BaseModel), 'structured FilePin')
    return cast(dict[str, Any], instance.model_dump(mode='json'))


def load_queue(options: Options) -> ModuleType:
    support = BASE / 'support'
    manifest = read(support / 'support-manifest.json')
    require(manifest.get('schema_version') == 1, 'support manifest schema')
    for name, expected in manifest['files_sha256'].items():
        require(re.fullmatch(r'[A-Za-z0-9_.-]+', name) is not None and sha(support / name) == expected,
                'committed support identity ' + name)
    driver, source = BASE / 'controller-profile/run_shapes_host.py', support / 'run_pair_queue.py'
    require(sha(driver) == options.driver_sha256 == manifest['files_sha256']['run_shapes_host.py'], 'driver identity')
    require(sha(source) == sha(BASE / 'controller-profile/run_pair_queue.py') == options.queue_sha256
            == manifest['files_sha256']['run_pair_queue.py'], 'queue identity')
    sys.path.insert(0, str(support))
    spec = importlib.util.spec_from_file_location('pinned_b8_configuration_queue', source)
    require(spec is not None and spec.loader is not None, 'committed queue import')
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    require(Path(module.host_contract.__file__).resolve() == (support / 'run_shapes_host.py').resolve()
            and Path(module.shape_reference.__file__).resolve() == (support / 'shape_reference.py').resolve(), 'metadata module origins')
    require(sha(source) == options.queue_sha256 and sha(driver) == options.driver_sha256, 'helpers changed on import')
    return module


def dataset_contracts(queue: ModuleType) -> dict[str, dict[str, Any]]:
    cit = read(A2_EVIDENCE)
    require(cit.get('outcome') == 'passed' and not cit.get('error') and bool(cit.get('finished_utc'))
            and cit.get('originals_before') == cit.get('originals_after')
            and cit['arguments']['inputs'] == CIT_INPUTS, 'historical cit evidence did not pass unchanged inputs')
    require({key: cit['originals_before'][key] for key in CIT_FILES} == CIT_FILES
            and cit['validation']['vertex_rows'] == 3774768 and cit['validation']['edge_rows'] == 16518947,
            'independent retained cit identity/count contract')
    graph_path = BASE / 'downloads/graph500-24/download-receipt.json'
    graph = read(graph_path)
    require(graph.get('outcome') == 'downloaded_and_admitted' and not graph.get('error')
            and graph.get('urls') == URLS and graph.get('admission') is not None
            and set(graph.get('files', {})) == set(URLS), 'actual official Graph500 download/admission receipt required')
    records = {
        'cit-Patents': {'vertices': CIT_FILES['vertices'], 'edges': CIT_FILES['edges'],
                       'vertex_rows': 3774768, 'edge_rows': 16518947, 'evidence': pin(queue, A2_EVIDENCE)},
        'graph500-24': {'vertices': graph['files']['vertices.parquet'], 'edges': graph['files']['edges.parquet'],
                        'vertex_rows': graph['admission']['vertex_rows'], 'edge_rows': graph['admission']['edge_rows'],
                        'evidence': pin(queue, graph_path)}}
    return {dataset: model(queue, 'DatasetContract', fields).model_dump(mode='json') for dataset, fields in records.items()}


def closed_reference(queue: ModuleType, run_id: str) -> tuple[dict[str, Any], str]:
    directory = BASE / run_id
    host, raw = read(directory / 'result.json'), read(directory / 'container/artifacts/receipt.json')
    require(host.get('outcome') == 'passed' and host.get('certain_container_closure') is True
            and host.get('archive_verified') is True and host.get('lock_retained') is False, 'reference host not closed/passed ' + run_id)
    reference = queue.shape_reference.ReferenceReceipt.model_validate(raw)
    require(reference.outcome == 'passed' and bool(reference.finished_utc) and not reference.error
            and reference.inputs_before is not None and reference.inputs_before == reference.inputs_after
            and str(reference.config.output) == ROOT + '/references/' + run_id
            and set(reference.artifacts) == set(SHAPES), 'reference producer tuple/closure ' + run_id)
    require(raw['config'] == read(directory / 'helper-config.json'), 'reference exact config')
    return raw, sha(directory / 'container/artifacts/receipt.json')


def reference_config(queue: ModuleType, options: Options) -> None:
    if options.dataset is None:
        raise ValueError('reference action requires --dataset')
    if options.dataset == 'cit-Patents':
        # This action can prepare cit before Graph500 is downloaded.
        cit = read(A2_EVIDENCE)
        require(cit.get('outcome') == 'passed' and cit.get('originals_before') == cit.get('originals_after')
                and {k: cit['originals_before'][k] for k in CIT_FILES} == CIT_FILES, 'historical cit original pins')
        raw = {'vertices': CIT_INPUTS + '/cit-Patents-v.parquet', 'edges': CIT_INPUTS + '/cit-Patents-e.parquet',
               'output': ROOT + '/references/' + options.cit_reference_id,
               'vertices_sha256': CIT_FILES['vertices']['sha256'], 'edges_sha256': CIT_FILES['edges']['sha256']}
    else:
        stage = BASE / options.graph500_stage_id
        host, producer = read(stage / 'result.json'), read(stage / 'stage-receipt.json')
        require(host.get('outcome') == 'passed' and host.get('certain_container_closure') is True
                and host.get('lock_retained') is False and producer.get('outcome') == 'passed'
                and producer.get('identities_before') == producer.get('identities_after'), 'Graph500 owned data stage not passed/closed')
        contract = dataset_contracts(queue)['graph500-24']
        require(producer.get('files') == {'vertices.parquet': contract['vertices'], 'edges.parquet': contract['edges']}, 'Graph500 staging/input evidence binding')
        raw = {'vertices': ROOT + '/inputs/graph500-24/vertices.parquet', 'edges': ROOT + '/inputs/graph500-24/edges.parquet',
               'output': ROOT + '/references/' + options.graph500_reference_id,
               'vertices_sha256': contract['vertices']['sha256'], 'edges_sha256': contract['edges']['sha256']}
    write(options.output / (options.dataset.lower() + '-reference.json'), queue.shape_reference.InputConfig.model_validate(raw))


def cell_config(queue: ModuleType, shape: str, variant: str, run_id: str, dataset: str,
                reference: dict[str, Any], receipt_sha256: str) -> BaseModel:
    campaign = queue.host_contract.Campaign.model_validate(read(BASE / 'campaign.json'))
    require(campaign.guest_root == ROOT and campaign.host_root == BASE and campaign.guest_reserve_bytes == 64 * 2**30
            and campaign.archive_reserve_bytes == 120 * 2**30, 'explicit declared B8 campaign reserves')
    return cast(BaseModel, queue.host_contract.CellConfiguration.model_validate({
        'dataset': dataset, 'shape': shape, 'variant': variant, 'repo': ROOT + '/repo',
        'harness_repo': queue.host_contract.HARNESS_REPO, 'support': ROOT + '/support',
        'output': ROOT + '/cells/' + run_id, 'vertices': reference['config']['vertices'], 'edges': reference['config']['edges'],
        'references': reference['config']['output'], 'binary': queue.host_contract.SAIL,
        'timeout_seconds': 1500, 'minimum_free_bytes': campaign.guest_reserve_bytes,
        'reference_receipt_sha256': receipt_sha256, 'support_sha256': sha(BASE / 'support/support-manifest.json')}))


def tiny_configs(queue: ModuleType, options: Options) -> None:
    reference, receipt_sha256 = closed_reference(queue, options.tiny_reference_id)
    expected = {key: {name: value for name, value in pin(queue, BASE / 'fixture' / (key + '.parquet')).items()
                     if name != 'path'} for key in ('vertices', 'edges')}
    require(reference['inputs_before'] == expected and reference['vertex_rows'] == 8 and reference['edge_rows'] == 8
            and reference['isolated_vertices'] == 1, 'tiny actual original file/count binding')
    for shape in SHAPES:
        for variant in VARIANTS:
            run_id = 'tiny-' + shape + '-' + variant + '01'
            write(options.output / (run_id + '.json'), cell_config(queue, shape, variant, run_id, 'tiny-signed-highbit', reference, receipt_sha256))


def queue_configs(queue: ModuleType, options: Options) -> None:
    references = {dataset: closed_reference(queue, run_id) for dataset, run_id in
                  (('cit-Patents', options.cit_reference_id), ('graph500-24', options.graph500_reference_id))}
    contracts = dataset_contracts(queue)
    tiny = {'vertices': pin(queue, BASE / 'fixture/vertices.parquet'), 'edges': pin(queue, BASE / 'fixture/edges.parquet')}
    tiny_controls = []
    for shape in SHAPES:
        for variant in VARIANTS:
            run_id = 'tiny-' + shape + '-' + variant + '01'
            proof = queue.host_proof(BASE / run_id, 'cell').model_dump(mode='json')
            proof.update(shape=shape, variant=variant)
            tiny_controls.append(model(queue, 'TinyProof', proof).model_dump(mode='json'))
    prerequisites = model(queue, 'Prerequisites', {'schema_version': 1,
        'stage': queue.host_proof(BASE / options.stage_id, 'stage').model_dump(mode='json'),
        'references': {dataset: queue.host_proof(BASE / run_id, 'reference').model_dump(mode='json') for dataset, run_id in
                       (('cit-Patents', options.cit_reference_id), ('graph500-24', options.graph500_reference_id))},
        'datasets': contracts, 'tiny_inputs': tiny, 'tiny_controls': tiny_controls})
    plan: BaseModel = queue.build_plan()
    write(options.output / 'plan.json', plan)
    write(options.output / 'prerequisites.json', prerequisites)
    configs: dict[str, dict[str, Any]] = {}
    for step in plan.model_dump(mode='json')['steps']:
        reference, receipt_sha256 = references[step['dataset']]
        config = cell_config(queue, step['shape'], step['variant'], step['run_id'], step['dataset'], reference, receipt_sha256)
        write(options.output / (step['run_id'] + '.json'), config)
        configs[step['run_id']] = pin(queue, options.output / (step['run_id'] + '.json'))
    common = {'driver': pin(queue, BASE / 'controller-profile/run_shapes_host.py'),
              'campaign': pin(queue, BASE / 'campaign.json'), 'plan': pin(queue, options.output / 'plan.json'),
              'support_manifest': pin(queue, BASE / 'support/support-manifest.json')}
    write(options.output / 'config-index.json', model(queue, 'ConfigIndex', {'schema_version': 1, **common, 'files': configs}))
    campaign = queue.host_contract.Campaign.model_validate(read(BASE / 'campaign.json'))
    for dataset in ('cit-Patents', 'graph500-24'):
        slug = dataset.lower()
        config = model(queue, 'QueueConfig', {'host_root': str(BASE), 'output': str(BASE / ('queue-' + slug)),
            'python': str(options.python), **common, 'config_index': pin(queue, options.output / 'config-index.json'),
            'prerequisites': pin(queue, options.output / 'prerequisites.json')})
        audit_receipt = model(queue, 'Receipt', {'config': config.model_dump(mode='json'), 'dataset': dataset,
            'owner_pid': os.getpid(), 'token': 'configuration-only-no-queue-owner', 'started_utc': utc(), 'observed_utc': utc()})
        queue.prerequisite_audits(config, audit_receipt, campaign)
        write(options.output / ('queue-' + slug + '.json'), config)
        write(options.output / ('prerequisite-audit-' + slug + '.json'), audit_receipt)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['reference', 'tiny', 'queues'])
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--driver-sha256', required=True)
    parser.add_argument('--queue-sha256', required=True)
    parser.add_argument('--dataset', choices=['cit-Patents', 'graph500-24'])
    for name, default in (('stage-id', 'stage01'), ('cit-reference-id', 'cit-reference01'),
                          ('graph500-reference-id', 'graph500-reference01'), ('tiny-reference-id', 'tiny-reference01'),
                          ('graph500-stage-id', 'data-stage01')):
        parser.add_argument('--' + name, default=default)
    parser.add_argument('--python', type=Path, default=Path('/tmp/sem-output-oracle-venv/bin/python'))
    options = Options.model_validate(vars(parser.parse_args()))
    require(options.output.is_absolute() and options.output.parent == BASE and not options.output.is_symlink()
            and re.fullmatch(r'generated-[a-z0-9-]+', options.output.name) is not None, 'fresh generated directory directly under campaign')
    for value in (options.stage_id, options.cit_reference_id, options.graph500_reference_id,
                  options.tiny_reference_id, options.graph500_stage_id):
        require(re.fullmatch(r'[a-z][a-z0-9-]{0,79}', value) is not None, 'run ID syntax')
    queue = load_queue(options)
    options.output.mkdir(exist_ok=False)
    receipt = Preparation(options=options, started_utc=utc(), source_sha256=sha(Path(__file__)))
    save(options.output / 'preparation.json', receipt)
    try:
        with (options.output / 'sem-b8-configs.py').open('xb') as stream:
            stream.write(Path(__file__).read_bytes())
            stream.flush()
            os.fsync(stream.fileno())
        if options.action == 'reference':
            reference_config(queue, options)
        elif options.action == 'tiny':
            tiny_configs(queue, options)
        else:
            queue_configs(queue, options)
        receipt.artifacts = {p.name: pin(queue, p) for p in options.output.iterdir()
                             if p.is_file() and p.name != 'preparation.json'}
        receipt.outcome = 'prepared'
    except BaseException as error:  # noqa: BLE001 - preserve failed fresh generation, never weaken proof or reuse it
        receipt.error, receipt.traceback = repr(error), traceback.format_exc()
        receipt.outcome = 'error'
    finally:
        receipt.finished_utc = utc()
        save(options.output / 'preparation.json', receipt)
    print(json.dumps({'outcome': receipt.outcome, 'output': str(options.output)}))
    return 0 if receipt.outcome == 'prepared' else 1


if __name__ == '__main__':
    raise SystemExit(main())
