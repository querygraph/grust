#!/usr/bin/env python3
"""Audit one named retained natural OOM; never releases locks or qualifies execution."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import sem_b8_tail_core as core
import sem_b8_tail_models as models

CORE_SHA = 'd2a6586df48fc4f00e0afb8a427db375f41f1ea773cf16d76adf4e1108822277'
MODELS_SHA = '5b984d9d5c5c51999b2943fdd316216b29aea11d4e8c658fa07c5f8947d0c44b'


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--queue-config', type=Path, required=True)
    parser.add_argument('--launch-receipt', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--expected-child-pid', type=int, required=True)
    parser.add_argument('--expected-gate-token', required=True)
    parser.add_argument('--expected-serial-pid', type=int, required=True)
    parser.add_argument('--expected-serial-token', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--helper-sha256', required=True)
    parser.add_argument('--timeout-seconds', type=float, default=1800)
    args = parser.parse_args()
    deadline = core.Deadline.after(args.timeout_seconds)
    own = core.pin(Path(__file__).resolve(), deadline)
    core.require(own.sha256 == args.helper_sha256, 'audit helper hash admission')
    core.require(core.pin(Path(core.__file__).resolve(), deadline).sha256 == CORE_SHA
                 and core.pin(Path(models.__file__).resolve(), deadline).sha256 == MODELS_SHA,
                 'exact own core/model origin hashes')
    core.require(args.out.is_absolute() and not args.out.exists() and not args.out.is_symlink(), 'fresh audit output')
    frozen = core.load(deadline)
    frozen.sources.append(own)
    result = core.audit_oom(frozen, args.queue_config, args.run_id, args.expected_child_pid,
        args.expected_gate_token, args.expected_serial_pid, args.expected_serial_token, args.launch_receipt)
    core.write(args.out, result, fresh=True)
    print(json.dumps({'outcome': result.outcome, 'qualified': False, 'receipt': str(args.out),
                      'receipt_sha256': core.pin(args.out, deadline).sha256, 'locks_released': False}))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, TimeoutError) as error:
        print(json.dumps({'outcome': 'audit_refused', 'error': repr(error), 'observed_utc': core.utc(),
                          'locks_released': False}), file=sys.stderr)
        raise SystemExit(1) from error
