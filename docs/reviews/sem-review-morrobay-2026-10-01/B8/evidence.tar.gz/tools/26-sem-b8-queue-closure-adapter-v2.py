"""Host-only B8 closure adapter; frozen queue/guest/plan/timers remain pinned.

CLI: --adapter-sha256 HEX --config QUEUE.json --dataset DATASET. Config
preparation loads this module after aliasing its verified queue as run_pair_queue,
then calls install(queue, expected_sha256). Raw archived receipts stay untouched.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import inspect
import pathlib
import sys
from types import ModuleType
from typing import Literal, cast

import pydantic

BASE = pathlib.Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01')
SUPPORT = BASE / 'support'
QUEUE_SHA = 'abe3842e4d5ae77122c42857ff1cb0298e3d42ccba7030e99c9a902967b05a94'
FUNCTION_SHA: Literal['7dd9fefe0888f46705c883a61787a91a2809057b4324f1fbadbf4faeb8457201'] = '7dd9fefe0888f46705c883a61787a91a2809057b4324f1fbadbf4faeb8457201'
VERSION = 'b8-host-embedded-absence-v2'


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def file_sha(path: pathlib.Path) -> str:
    require(path.is_file() and not path.is_symlink(), 'regular pinned host helper: ' + str(path))
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


require(file_sha(SUPPORT / 'run_pair_queue.py') == QUEUE_SHA, 'frozen queue bytes before import')
sys.path.insert(0, str(SUPPORT))
import run_pair_queue as frozen
import run_shapes_host as host_contract

require(pathlib.Path(frozen.__file__).resolve() == (SUPPORT / 'run_pair_queue.py').resolve(), 'frozen queue module origin')
ORIGINAL_ARCHIVE = frozen.audited_archive
AUTHORIZED: frozen.FilePin | None = None


class Provenance(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra='forbid', frozen=True)
    version: Literal['b8-host-embedded-absence-v2'] = 'b8-host-embedded-absence-v2'
    adapter: frozen.FilePin
    frozen_queue: frozen.FilePin
    original_function_sha256: Literal['7dd9fefe0888f46705c883a61787a91a2809057b4324f1fbadbf4faeb8457201'] = FUNCTION_SHA
    predicate_change: str = 'Compare only absence_verified separately; require embedded absence; all other archived predicates unchanged.'
    guest_change: Literal[False] = False
    timer_change: Literal[False] = False
    raw_archive_rewrite: Literal[False] = False


def provenance() -> Provenance:
    require(AUTHORIZED is not None, 'adapter must be authorized before receipt construction')
    assert AUTHORIZED is not None
    frozen.check_pin(AUTHORIZED)
    queue = frozen.pin(pathlib.Path(frozen.__file__).resolve())
    require(queue.sha256 == QUEUE_SHA, 'frozen queue bytes changed')
    return Provenance(adapter=AUTHORIZED, frozen_queue=queue)


class AdapterReceipt(frozen.Receipt):
    closure_adapter: Provenance = pydantic.Field(default_factory=provenance)

    @pydantic.model_validator(mode='after')
    def immutable_adapter(self) -> AdapterReceipt:
        expected = provenance()
        require(self.closure_adapter == expected, 'queue closure adapter provenance differs')
        for pin in (expected.adapter, expected.frozen_queue):
            if pin not in self.pins:
                self.pins.append(pin)
        return self


def without_absence(record: frozen.Json) -> frozen.Json:
    return {key: value for key, value in record.items() if key != 'absence_verified'}


def record_binding(host: frozen.Json, separate: frozen.Json) -> frozen.Json:
    records = host.get('records')
    require(isinstance(records, dict), 'raw host records object')
    assert isinstance(records, dict)
    embedded = records.get('container')
    require(isinstance(embedded, dict), 'embedded raw container object')
    embedded = cast(frozen.Json, embedded)
    require(isinstance(embedded.get('absence_verified'), dict), 'embedded container absence proof required')
    frozen.absence(embedded)
    require(without_absence(embedded) == without_absence(separate), 'embedded/separate container records differ outside absence_verified')
    if 'absence_verified' in separate:
        require(separate['absence_verified'] == embedded['absence_verified'], 'separate absence differs from authoritative embedded proof')
    return embedded


def audited_archive_v2(directory: pathlib.Path, run_id: str, kind: Literal['reference', 'cell'],
                       config: frozen.QueueConfig, campaign: host_contract.Campaign) -> tuple[frozen.Json, frozen.Json, frozen.Json]:
    host = frozen.read(directory/'result.json')
    frozen.host_closed(host, run_id, kind)
    record = frozen.read(directory/'container-record.json')
    embedded = record_binding(host, record)
    frozen.closed_container(embedded)
    frozen.small_closed(host['records']['admission'])
    archive = frozen.physical_archive(directory, host)
    frozen.support_binding(directory, config, campaign)
    spec = frozen.read(directory/'configuration.json')['specification']
    helper_pin = frozen.pin(directory/'helper-config.json')
    frozen.require(spec.get('config_sha256') == helper_pin.sha256 and spec.get('config_text', '').encode() == helper_pin.path.read_bytes()
            and spec.get('run_id') == run_id and spec.get('kind') == kind
            and spec.get('controller') == frozen.SOURCE and spec.get('harness') == frozen.HARNESS
            and spec.get('root') == campaign.guest_root and spec.get('harness_repo') == host_contract.HARNESS_REPO
            and spec.get('sail') == host_contract.SAIL and spec.get('sail_sha256') == host_contract.SAIL_SHA
            and spec.get('native_sha256') == host_contract.NATIVE_SHA
            and spec.get('support_sha256') == config.support_manifest.sha256, 'archived launch config/source binding')
    boot = frozen.read(directory/'container/artifacts/bootstrap-receipt.json')
    frozen.require(boot.get('outcome') == 'passed' and bool(boot.get('finished_utc')) and boot.get('producer_returncode') == 0
            and boot.get('kind') == kind and boot.get('config_sha256') == helper_pin.sha256
            and bool(boot.get('identities_before')) and boot.get('identities_before') == boot.get('identities_after')
            and not any(boot.get(k) for k in ('error', 'traceback', 'final_guard_traceback')), 'bootstrap identities/exit/config')
    return host, archive, spec


class StripFrozen(ast.NodeTransformer):
    def visit_Attribute(self, node: ast.Attribute) -> ast.AST:
        updated = self.generic_visit(node)
        assert isinstance(updated, ast.Attribute)
        if isinstance(updated.value, ast.Name) and updated.value.id == 'frozen':
            return ast.copy_location(ast.Name(id=updated.attr, ctx=updated.ctx), updated)
        return updated


def copied_predicate_guard() -> None:
    original = inspect.getsource(ORIGINAL_ARCHIVE)
    require(hashlib.sha256(original.encode()).hexdigest() == FUNCTION_SHA, 'original archived validator function SHA')
    left = ast.parse(original).body[0]
    right = StripFrozen().visit(ast.parse(inspect.getsource(audited_archive_v2)).body[0])
    require(isinstance(left, ast.FunctionDef) and isinstance(right, ast.FunctionDef), 'archived validator AST')
    assert isinstance(left, ast.FunctionDef) and isinstance(right, ast.FunctionDef)
    require(len(left.body) == len(right.body), 'copied archived validator statement count')
    for index, (old, new) in enumerate(zip(left.body, right.body, strict=True)):
        if index not in {3, 4}:
            require(ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False),
                    'frozen archived validator predicate changed at statement ' + str(index))


def install(queue: ModuleType, expected_sha256: str) -> ModuleType:
    global AUTHORIZED
    require(queue is frozen, 'adapter must share the exact verified frozen queue module')
    actual = frozen.pin(pathlib.Path(__file__).resolve())
    require(actual.sha256 == expected_sha256, 'authorized host closure adapter SHA')
    require(AUTHORIZED is None and queue.audited_archive is ORIGINAL_ARCHIVE, 'adapter already installed or archived validator replaced')
    copied_predicate_guard()
    AUTHORIZED = actual
    queue.__dict__['audited_archive'] = audited_archive_v2
    queue.__dict__['Receipt'] = AdapterReceipt
    return queue


def main() -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--adapter-sha256', required=True)
    options, remaining = parser.parse_known_args()
    require('--write-plan' not in remaining, 'adapter executes only an already frozen queue plan')
    install(frozen, str(options.adapter_sha256))
    sys.argv = [sys.argv[0], *remaining]
    return frozen.main()


if __name__ == '__main__':
    raise SystemExit(main())
