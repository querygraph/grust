"""Host-only serial tail; only full pass or authorized proven natural OOM may advance."""
from __future__ import annotations

import os
import signal
import subprocess
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Protocol

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_prepare as preparation
from pydantic import Field


class SerialOwner(models.Record):
    owner_pid: int = Field(gt=0)
    token: str
    config: models.Json
    dataset: Literal['graph500-24'] = 'graph500-24'
    started_utc: str
    prepared: models.FilePin
    authorization: models.FilePin


class Child(Protocol):
    pid: int

    def wait(self, timeout: float | None = None) -> int: ...

    def poll(self) -> int | None: ...


Spawner = Callable[[list[str], Path], Child]


@dataclass(slots=True)
class State:
    frozen: core.Frozen
    prepared: models.Prepared
    authorization: models.Authorization
    config: Any
    campaign: Any
    reference: models.Json
    receipt: models.TailReceipt
    queue_deadline: core.Deadline
    audit_seconds: float
    serial_owner: models.FilePin

    def phase(self) -> None:
        self.frozen.deadline = core.Deadline(min(self.queue_deadline.end, time.monotonic()+self.audit_seconds))
        self.frozen.deadline.check()

    def save(self) -> None:
        self.receipt.observed_utc = core.utc()
        core.write(self.config.output/'receipt.json', self.receipt)

    def stopped(self) -> None:
        self.queue_deadline.check()
        if self.receipt.interruption_signals:
            raise InterruptedError('operator interrupted; child and owned locks are retained for review')


def sources(state: State) -> None:
    for value in [*state.frozen.sources, *state.receipt.sources, state.receipt.prepared, state.receipt.authorization,
                  state.prepared.queue_config, state.prepared.original_plan, state.prepared.derived_plan,
                  *state.prepared.original31_evidence]:
        core.verify(value, state.frozen.deadline)
    for mapping in state.prepared.mappings:
        core.verify(mapping.original_config, state.frozen.deadline)
        core.verify(mapping.actual_config, state.frozen.deadline)


def check_derivation(frozen: core.Frozen, prepared: models.Prepared, config: Any, plan: Any, index: Any) -> None:
    original_config, campaign, old_plan, old_index, _ = preparation.queue_inputs(frozen, prepared.original_queue_config)
    core.require(prepared.original_plan == models.FilePin.model_validate(original_config.plan.model_dump())
                 and prepared.derived_plan == models.FilePin.model_validate(config.plan.model_dump())
                 and prepared.original_failed_step.model_dump(mode='json') == old_plan.steps[30].model_dump(mode='json'),
                 'original31/derived plan scope')
    core.require(plan.steps[:31] == old_plan.steps[:31] and len(prepared.mappings) == 29,
                 'original31 plan entries must remain byte-semantic equal')
    for mapping, previous, actual in zip(prepared.mappings, old_plan.steps[31:], plan.steps[31:], strict=True):
        core.require(mapping.original.model_dump(mode='json') == previous.model_dump(mode='json')
                     and mapping.actual.model_dump(mode='json') == actual.model_dump(mode='json')
                     and mapping.actual.run_id == preparation.PREFIX+previous.run_id.removeprefix('b8-')
                     and {k: v for k, v in mapping.original.model_dump().items() if k != 'run_id'}
                     == {k: v for k, v in mapping.actual.model_dump().items() if k != 'run_id'}
                     and mapping.original_config == models.FilePin.model_validate(old_index.files[previous.run_id].model_dump())
                     and mapping.actual_config == models.FilePin.model_validate(index.files[actual.run_id].model_dump()),
                     'exact unused original-to-fresh step/config mapping')
        original = frozen.host.CellConfiguration.model_validate(core.read(mapping.original_config.path, frozen.deadline))
        changed = frozen.host.CellConfiguration.model_validate(core.read(mapping.actual_config.path, frozen.deadline))
        before, after = original.model_dump(mode='json'), changed.model_dump(mode='json')
        core.require({k: v for k, v in before.items() if k != 'output'} == {k: v for k, v in after.items() if k != 'output'}
                     and after['output'] == campaign.guest_root+'/cells/'+mapping.actual.run_id,
                     'only output changes in actual config')
        frozen.queue.unoccupied(core.BASE, previous.run_id)
        frozen.queue.unoccupied(core.BASE, actual.run_id)


def warmup_failures(receipt: models.TailReceipt, shape: str) -> list[str]:
    warmups: list[tuple[str, bool]] = []
    if receipt.original_failed_step.shape == shape:
        warmups.append((receipt.original_failed_step.run_id, False))
    for cell in receipt.cells:
        if cell.mapping.actual.shape == shape and cell.mapping.actual.role == 'warmup':
            core.require(cell.disposition in ('passed', 'closed_oom'), 'warmup has no qualified/proven closed terminal outcome')
            warmups.append((cell.mapping.actual.run_id, cell.disposition == 'passed' and cell.qualified))
    core.require(len(warmups) == 2, 'both real warmups must complete before any measured call')
    return [run_id for run_id, qualified in warmups if not qualified]


def preserve_owned_lock(lock: Path, expected_owner: models.FilePin, destination: Path, deadline: core.Deadline) -> models.FilePin:
    core.require(lock.is_dir() and not lock.is_symlink() and {p.name for p in lock.iterdir()} == {'owner.json'},
                 'exact owned lock contents changed')
    core.require(expected_owner.path == lock/'owner.json' and destination.parent == lock.parent
                 and not destination.exists() and not destination.is_symlink(), 'fresh owned lock archive required')
    core.verify(expected_owner, deadline)
    lock.rename(destination)
    core.directory_fsync(lock.parent)
    archived = core.pin(destination/'owner.json', deadline)
    core.require(archived.identity() == expected_owner.identity()
                 and not lock.exists() and not lock.is_symlink(), 'owned lock owner evidence changed during rename')
    return archived


def wait_child(child: Child, state: State) -> int:
    while True:
        state.stopped()
        try:
            return child.wait(timeout=state.queue_deadline.remaining(30))
        except subprocess.TimeoutExpired:
            state.save()


def run_cell(state: State, cell: models.Cell, spawner: Spawner) -> None:
    state.phase()
    state.stopped()
    preparation.assert_no_locks_for_gate()
    sources(state)
    q, frozen = state.frozen.queue, state.frozen
    q.unoccupied(core.BASE, cell.mapping.original.run_id)
    q.unoccupied(core.BASE, cell.mapping.actual.run_id)
    core.verify(state.serial_owner, frozen.deadline)
    effective = frozen.host.CellConfiguration.model_validate(core.read(cell.mapping.actual_config.path, frozen.deadline))
    cell.command = [str(state.config.python), '-B', str(state.config.driver.path), 'run', '--campaign',
        str(state.config.campaign.path), '--run-id', cell.mapping.actual.run_id, '--kind', 'cell', '--config', str(cell.mapping.actual_config.path)]
    cell.log = core.BASE/(cell.mapping.actual.run_id+'.host.log')
    core.require(not cell.log.exists() and not cell.log.is_symlink(), 'fresh host log; no retry')
    cell.disposition = 'running'
    cell.started_utc = core.utc()
    state.save()
    child = spawner(cell.command, cell.log)
    core.require(child.pid > 0, 'exact host child PID required')
    cell.child_pid = state.receipt.active_child_pid = child.pid
    state.save()
    cell.returncode = wait_child(child, state)
    core.require(child.poll() == cell.returncode and core.pid_absent(child.pid), 'exact child wait/process absence')
    state.receipt.active_child_pid = None
    cell.finished_utc = core.utc()
    cell.disposition = 'child_exited'
    state.save()
    state.phase()
    cell.raw_receipts = q.raw_receipts(core.BASE/cell.mapping.actual.run_id)
    sources(state)
    state.stopped()
    if cell.returncode == 0:
        audit = q.audit_cell(q.Step.model_validate(cell.mapping.actual.model_dump()), state.config,
            state.campaign, effective, state.reference)
        core.require(audit.get('qualified') is True and audit.get('run_id') == cell.mapping.actual.run_id, 'unchanged full pass audit')
        preparation.assert_no_locks_for_gate()
        host = cell.raw_receipts['host']
        core.fresh_probes(frozen, cell.mapping.actual.run_id, host['records']['container']['inspect']['id'])
        state.stopped()
        cell.pass_audit = audit
    elif cell.returncode == 1:
        core.require(state.authorization.named_failures.get(cell.mapping.actual.run_id) == cell.mapping.actual_config.sha256,
                     'natural OOM not explicitly named/authorized for this exact actual config')
        gate = core.BASE.parent/'gate.lock'
        owner = models.GateOwner.model_validate(core.read(gate/'owner.json', frozen.deadline))
        launch = state.config.output/(cell.mapping.actual.run_id+'.launch-wait.json')
        core.write(launch, cell, fresh=True)
        closure = core.audit_oom(frozen, state.prepared.queue_config.path, cell.mapping.actual.run_id, child.pid,
            owner.token, os.getpid(), state.receipt.token, launch, serial_may_be_current=True)
        path = state.config.output/(cell.mapping.actual.run_id+'.closed-oom.json')
        core.write(path, closure, fresh=True)
        cell.failure_closure = core.pin(path, frozen.deadline)
        state.stopped()
        destination = gate.with_name('gate.lock.closed-b8-tail-'+cell.mapping.actual.run_id+'-'+owner.token)
        preserve_owned_lock(gate, closure.gate_owner_pin, destination, frozen.deadline)
        cell.failure_gate_retained = destination
        preparation.assert_no_locks_for_gate()
        core.fresh_probes(frozen, cell.mapping.actual.run_id, next(p.argv[-1] for p in closure.probes if p.argv[-2] == 'inspect' and len(p.argv[-1]) == 64))
    else:
        raise ValueError('Unexpected child returncode; retain raw failure and locks for root review')
    sources(state)
    core.verify(state.serial_owner, frozen.deadline)
    state.stopped()
    cell.qualified = cell.returncode == 0
    cell.disposition = 'passed' if cell.qualified else 'closed_oom'
    state.save()


def execute(state: State, spawner: Spawner) -> int:
    for cell in state.receipt.cells:
        state.stopped()
        if cell.mapping.actual.role == 'measured':
            failures = warmup_failures(state.receipt, cell.mapping.actual.shape)
            if failures:
                cell.disposition = 'not_started_due_to_failed_warmup'
                cell.cause_warmup_ids = failures
                core.require(cell.child_pid is None and not cell.command and cell.returncode is None
                             and cell.started_utc is None and cell.finished_utc is None and cell.pass_audit is None,
                             'policy skip must not fabricate launch/timing/qualification')
                state.save()
                continue
        run_cell(state, cell, spawner)
    state.phase()
    state.stopped()
    sources(state)
    preparation.assert_no_locks_for_gate()
    core.require(state.receipt.active_child_pid is None
                 and all(c.disposition in ('passed', 'closed_oom', 'not_started_due_to_failed_warmup') for c in state.receipt.cells),
                 'complete terminal tail coverage required')
    idle = core.capture(state.frozen.host.DOCKER+['ps', '-q'], state.frozen.deadline)
    core.require(idle.returncode == 0 and not idle.stdout.strip(), 'final Docker idle uncertain')
    state.receipt.prerequisite_observations['final_idle'] = idle.model_dump(mode='json')
    state.stopped()
    lock = core.BASE.parent/'serial-queue.lock'
    dest = lock.with_name('serial-queue.lock.closed-b8-tail-'+state.receipt.token)
    preserve_owned_lock(lock, state.serial_owner, dest, state.frozen.deadline)
    state.receipt.serial_lock_retained = False
    state.receipt.serial_lock_archived = dest
    # The immutable original Graph warmup failed; full60-PASS is impossible.
    state.receipt.outcome = 'completed_with_failures'
    state.receipt.finished_utc = core.utc()
    state.save()
    return 1


def run(frozen: core.Frozen, prepared_pin: models.FilePin, authorization_pin: models.FilePin,
        helper_pins: list[models.FilePin], queue_seconds: float, audit_seconds: float,
        spawner: Spawner | None = None) -> int:
    core.require(0 < queue_seconds <= 172800 and 0 < audit_seconds <= 7200, 'finite queue and per-phase deadlines')
    core.verify(prepared_pin, frozen.deadline)
    core.verify(authorization_pin, frozen.deadline)
    prepared = models.Prepared.model_validate(core.read(prepared_pin.path, frozen.deadline))
    authorization = models.Authorization.model_validate(core.read(authorization_pin.path, frozen.deadline))
    core.require(authorization.original_queue_config == prepared.original_queue_config
                 and authorization.named_failures == {m.actual.run_id: m.actual_config.sha256 for m in prepared.mappings},
                 'root-approved exact29 natural OOM authorization')
    preparation.assert_no_locks()
    config, campaign, plan, index, pins = preparation.queue_inputs(frozen, prepared.queue_config)
    check_derivation(frozen, prepared, config, plan, index)
    core.require(not config.output.exists() and not config.output.is_symlink(), 'fresh tail queue output; no resume')
    closure = models.FailureClosure.model_validate(core.read(prepared.original_oom_closure.path, frozen.deadline))
    core.require(closure.run_id == prepared.original_failed_step.run_id, 'original failed warmup identity')
    core.fresh_probes(frozen, closure.run_id, next(p.argv[-1] for p in closure.probes if p.argv[-2] == 'inspect' and len(p.argv[-1]) == 64))
    config.output.mkdir(mode=0o700)
    core.directory_fsync(config.output.parent)
    receipt = models.TailReceipt(observed_utc=core.utc(), started_utc=core.utc(), owner_pid=os.getpid(), token=uuid.uuid4().hex,
        prepared=prepared_pin, authorization=authorization_pin, sources=[*prepared.sources, *helper_pins, *pins],
        original31=prepared.original31_evidence, original_failed_step=prepared.original_failed_step,
        cells=[models.Cell(mapping=m) for m in prepared.mappings])
    core.write(config.output/'receipt.json', receipt, fresh=True)
    lock = core.BASE.parent/'serial-queue.lock'
    lock.mkdir(mode=0o700)
    core.directory_fsync(lock.parent)
    owner = SerialOwner(owner_pid=os.getpid(), token=receipt.token, config=config.model_dump(mode='json'),
        started_utc=receipt.started_utc, prepared=prepared_pin, authorization=authorization_pin)
    owner_path = lock/'owner.json'
    core.write(owner_path, owner, fresh=True)
    state = State(frozen, prepared, authorization, config, campaign, {}, receipt,
        core.Deadline(time.monotonic()+queue_seconds), audit_seconds, core.pin(owner_path, frozen.deadline))
    old_handlers: dict[int, Any] = {}

    def interrupted(number: int, _frame: Any) -> None:
        state.receipt.interruption_signals.append(number)

    try:
        for number in (signal.SIGINT, signal.SIGTERM):
            old_handlers[number] = signal.signal(number, interrupted)
        state.phase()
        sources(state)
        temporary = frozen.queue.Receipt(config=config, dataset='graph500-24', owner_pid=os.getpid(), token=receipt.token,
            started_utc=receipt.started_utc, observed_utc=core.utc())
        references = frozen.queue.prerequisite_audits(config, temporary, campaign)
        state.reference = references['graph500-24']
        receipt.prerequisite_observations['original_full_prerequisites'] = temporary.prerequisite_observations
        receipt.sources.extend(models.FilePin.model_validate(p.model_dump()) for p in temporary.pins)
        receipt.outcome = 'running'
        state.save()
        return execute(state, frozen.queue.spawn if spawner is None else spawner)
    except BaseException as error:  # noqa: BLE001 -- Durable refusal for signals/errors; no engine cleanup.
        receipt.outcome = 'interrupted' if receipt.interruption_signals or isinstance(error, (KeyboardInterrupt, InterruptedError)) else 'uncertain'
        receipt.error = repr(error)
        receipt.finished_utc = core.utc()
        for cell in receipt.cells:
            if cell.disposition in ('running', 'child_exited'):
                cell.disposition, cell.error = 'uncertain', repr(error)
        state.save()
        return 2
    finally:
        for restored_number, previous in old_handlers.items():
            signal.signal(restored_number, previous)
