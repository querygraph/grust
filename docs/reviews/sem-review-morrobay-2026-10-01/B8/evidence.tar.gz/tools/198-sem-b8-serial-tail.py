#!/usr/bin/env python3
"""Execute one fresh root-approved B8 tail; no retries, forced cleanup or budget changes."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import sem_b8_tail_core as core
import sem_b8_tail_prepare as preparation
import sem_b8_tail_run as runner

PREPARATION_SHA = 'a48805d3cb0c9ed0917cedf3496e29018b63674ce1cdbb8c62f6e491e4ca000b'
RUNNER_SHA = '39b878c330b14597020760698712ae05b8d6b92d828c5cf7ebc899b685a2af7a'


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--prepared-sha256', required=True)
    parser.add_argument('--authorization', type=Path, required=True)
    parser.add_argument('--authorization-sha256', required=True)
    parser.add_argument('--helper-sha256', required=True)
    parser.add_argument('--audit-timeout-seconds', type=float, default=1800)
    parser.add_argument('--queue-timeout-seconds', type=float, default=43200)
    args = parser.parse_args()
    deadline = core.Deadline.after(args.audit_timeout_seconds)
    own = core.pin(Path(__file__).resolve(), deadline)
    core.require(own.sha256 == args.helper_sha256, 'root-selected tail launcher source')
    prep = core.pin(Path(preparation.__file__).resolve(), deadline)
    run = core.pin(Path(runner.__file__).resolve(), deadline)
    core.require(prep.sha256 == PREPARATION_SHA and run.sha256 == RUNNER_SHA, 'exact frozen implementation source hashes')
    helper_pins = [*preparation.own_sources(deadline), own, run]
    prepared = core.pin(args.prepared, deadline)
    authorization = core.pin(args.authorization, deadline)
    core.require(prepared.sha256 == args.prepared_sha256 and authorization.sha256 == args.authorization_sha256,
                 'root-reviewed exact prepared/authorization identities')
    frozen = core.load(deadline)
    frozen.sources.extend(helper_pins)
    result = runner.run(frozen, prepared, authorization, helper_pins, args.queue_timeout_seconds, args.audit_timeout_seconds)
    print(json.dumps({'returncode': result, 'scope': 'B8 tail only; original OOM preserved; failed/skipped never timing-qualified'}))
    return result


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, TimeoutError) as error:
        print(json.dumps({'outcome': 'tail_refused_or_uncertain', 'error': repr(error), 'observed_utc': core.utc(),
                          'forced_cleanup': False}), file=sys.stderr)
        raise SystemExit(2) from error
