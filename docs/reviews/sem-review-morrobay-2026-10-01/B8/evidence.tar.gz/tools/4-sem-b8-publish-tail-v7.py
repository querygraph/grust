"""Publish a finalized known-failure tail as immutable metadata evidence only."""
from __future__ import annotations

import argparse
import copy
import sys
from collections.abc import Callable
from pathlib import Path
from types import ModuleType
from typing import Any, cast

import sem_b8_tail_core as core
import sem_b8_tail_models as models
import sem_b8_tail_publication_models_v2 as schema
import sem_b8_tail_publication_v2 as adapter
from pydantic import Field


class Options(models.Record):
    base: Path
    dest: Path
    frozen_publisher: Path
    frozen_host_wrapper: Path
    frozen_gate: Path
    frozen_host_gate: Path
    publication_gate: Path
    host_preparation: Path
    reference_closure_gate: Path
    prepared: Path
    preparation_attempt: Path
    authorization: Path
    root_review: Path
    tail_receipt: Path
    preservation: Path
    retained_evidence: list[Path] = Field(default_factory=list)
    prior_base: list[Path] = Field(default_factory=list)
    timeout_seconds: float = Field(default=1800, gt=0, le=7200)


def dependencies(io_state: adapter.IO) -> list[models.FilePin]:
    values: list[models.FilePin] = []
    for module, expected in ((core,adapter.CORE),(models,adapter.MODELS),(schema,adapter.PUB_MODELS)):
        value = io_state.pin(Path(cast(str,module.__file__)).resolve())
        core.require(value.sha256 == expected, 'publication imported dependency source differs')
        values.append(value)
    return values


def root_proof(options: Options, prepared: models.Prepared, tail: models.TailReceipt,
               io_state: adapter.IO) -> models.FilePin:
    read = io_state.read
    attempt = adapter.decode(read(options.preparation_attempt))
    prepared_pin, auth_pin = io_state.pin(options.prepared), io_state.pin(options.authorization)
    preserve_pin = io_state.pin(options.preservation)
    core.require(attempt['outcome'] == 'prepared' and attempt['finished_utc'] and not attempt['error']
                 and attempt['prepared'] == prepared_pin.model_dump(mode='json')
                 and attempt['preservation'] == preserve_pin.model_dump(mode='json')
                 and attempt['original_oom_closure'] == prepared.original_oom_closure.model_dump(mode='json'),
                 'finalized preparation proof differs')
    review = adapter.decode(read(options.root_review))
    core.require(review['outcome'] == 'root_reviewed_and_authorized' and bool(review['observed_utc'])
                 and review['prepared'] == prepared_pin.model_dump(mode='json')
                 and review['authorization'] == auth_pin.model_dump(mode='json')
                 and review['retained_original_outcomes'] == 31 and review['fresh_output_only_mappings'] == 29
                 and review['resource_or_algorithm_change'] is False and review['original_failed_id_retry'] is False
                 and review['measured_cells_require_both_qualified_warmups'] is True
                 and review['unknown_failure_retains_locks_and_stops'] is True,
                 'root authorization review does not bind actual prepared/authorization bytes')
    proposal = models.FilePin.model_validate(review['proposed_authorization'])
    adapter.checked(proposal,read)
    core.require(proposal.identity() == auth_pin.identity(), 'root authorized bytes differ from proposed exact scope')
    preservation = adapter.decode(read(options.preservation))
    core.require(preservation['outcome'] == 'original_failed_locks_preserved'
                 and preservation['failure_closure'] == prepared.original_oom_closure.model_dump(mode='json')
                 and preservation['owner_bytes_preserved'] is True
                 and preservation['locks_deleted'] is False and preservation['receipts_rewritten'] is False,
                 'original failed lock preservation differs')
    closure = models.FailureClosure.model_validate(adapter.json_pin(prepared.original_oom_closure,read))
    for field,old in (('archived_gate_owner',closure.gate_owner_pin),('archived_serial_owner',closure.serial_owner_pin)):
        retained = models.FilePin.model_validate(preservation[field])
        adapter.checked(retained,read)
        core.require(retained.identity() == old.identity(), 'original archived owner bytes differ')
    for probe in preservation['probes']:
        value = models.Probe.model_validate(probe)
        core.require((value.argv[-2:] == ['ps','-q'] and value.returncode == 0 and not value.stdout.strip())
                     or (value.argv[-2] == 'inspect' and value.returncode == 1
                         and any(s in value.stderr.lower() for s in ('no such object','no such container'))),
                     'preserved lock closure observation uncertain')
    core.require(len(preservation['probes']) == 3, 'original name/id/idle observation roster differs')
    values = [*prepared.sources,*tail.sources]
    required = {adapter.CORE,adapter.MODELS,adapter.RUNNER,adapter.RUN_CLI,adapter.PREP,adapter.PREP_CLI}
    core.require(required <= {p.sha256 for p in values}, 'immutable tail helper source pins missing')
    return io_state.pin(cast(Path,tail.serial_lock_archived)/'owner.json')


def provenance(options: Options, io_state: adapter.IO) -> tuple[Any,schema.TailProvenance]:
    dep = dependencies(io_state)
    publisher = adapter.source_module(options.frozen_publisher,adapter.PUBLISHER,'b8_tail_frozen_publisher',io_state)
    host = adapter.source_module(options.frozen_host_wrapper,adapter.HOST_WRAPPER,'b8_tail_host_wrapper',io_state)
    adapter.source_module(options.frozen_gate,adapter.GATE,'b8_tail_original_gate_source',io_state)
    adapter.source_module(options.frozen_host_gate,adapter.HOST_GATE,'b8_tail_original_host_gate_source',io_state)
    # Replace only metadata IO. Frozen schema/33-line AST predicate guard remains unchanged.
    host.__dict__['raw'] = io_state.read
    host.__dict__['pin'] = lambda path: host.FilePin.model_validate(io_state.pin(path).model_dump())
    prepared_pin, auth_pin, tail_pin = (io_state.pin(p) for p in (options.prepared,options.authorization,options.tail_receipt))
    prepared, tail, projected, cells = adapter.project_tail(prepared_pin,auth_pin,tail_pin,io_state.read,options.base)
    serial_owner = root_proof(options,prepared,tail,io_state)
    historical_options = host.Options(frozen_publisher=options.frozen_publisher,frozen_publication_gate=options.frozen_gate,
        base=options.base,dest=options.dest,preparation=options.host_preparation,
        reference_closure_gate=options.reference_closure_gate,
        queue_receipt=[prepared.original_cit_queue_receipt.path,prepared.original_graph_queue_receipt.path],
        retained_evidence=options.retained_evidence,prior_base=options.prior_base)
    historical = host.build_provenance(historical_options)
    audit_source = io_state.pin(options.base/'operations/closed-oom-audit01/sem-b8-closed-oom-audit.py')
    core.require(audit_source.sha256 == adapter.AUDIT_CLI, 'retained original failure auditor source differs')
    functions = [adapter.function_pin(io_state.pin(options.frozen_publisher),name,io_state.read)
                 for name in ('qualify_cell','contrast')]
    functions += [adapter.function_pin(io_state.pin(options.frozen_gate),name,io_state.read)
                  for name in ('cell','ratios','report_gate','execute')]
    actual = schema.TailProvenance(observed_utc=core.utc(), publisher_wrapper=io_state.pin(Path(__file__).resolve()),
        publication_adapter=io_state.pin(Path(adapter.__file__).resolve()), publication_models=dep[2],
        publication_gate=io_state.pin(options.publication_gate), frozen_publisher=io_state.pin(options.frozen_publisher),
        frozen_host_wrapper=io_state.pin(options.frozen_host_wrapper), frozen_gate=io_state.pin(options.frozen_gate),
        frozen_host_gate=io_state.pin(options.frozen_host_gate), immutable_helper_sources=dep+[audit_source]+prepared.sources+tail.sources,
        frozen_predicates=functions, prepared=prepared_pin, preparation_attempt=io_state.pin(options.preparation_attempt),
        authorization=auth_pin, root_authorization_review=io_state.pin(options.root_review), tail_queue=tail_pin,
        original_plan=prepared.original_plan, derived_plan=prepared.derived_plan,
        original_cit_receipt=prepared.original_cit_queue_receipt, original_graph_receipt=prepared.original_graph_queue_receipt,
        original_continuation_receipt=prepared.original_continuation_receipt, original_oom_closure=prepared.original_oom_closure,
        original_lock_preservation=io_state.pin(options.preservation), preserved_serial_owner=serial_owner,
        queue_projection=projected, cell_projection=cells, limits=schema.Limits(timeout_seconds=options.timeout_seconds))
    return (publisher,host,historical), actual


def skipped_row(step: models.Json, projection: schema.SkippedProjection) -> models.Json:
    return {'step':step,'qualified':False,'status':'not_started_due_to_failed_warmup',
        'outcomes':dict.fromkeys(('host','producer','engine','oracle')),'evidence':{},
        'reasons':['Actual calls were not started because warmup prerequisite failed: '+', '.join(projection.failed_warmup_ids)],
        'raw_plans':None,'correctness':None,'timing_diagnostics':dict.fromkeys(('launch_to_exit_seconds',
            'launch_until_interruption_seconds','boundary','outside_boundary','engine_phases','engine_scope',
            'oracle_seconds','supervisor_phases')),
        'memory_diagnostics':dict.fromkeys(('sampled_engine_pss_peak_bytes','sampled_engine_rows','sampled_engine_pss_rows',
            'sampling','boundaries','cgroups')),'guest_steal_fraction':None,'errors':dict.fromkeys(('host','producer','engine')),
        'tail_projection':projection.model_dump(mode='json'),'original_step':projection.mapping.original.model_dump(mode='json')}


def install(module: ModuleType, host: ModuleType, historical: Any, value: schema.TailProvenance,
            options: Options, io_state: adapter.IO) -> None:
    host.install(module,historical)
    old_queues = cast(Callable[[Path,list[Path]],list[Any]],module.queue_documents)
    old_cell = cast(Callable[[models.Json,Path,list[Any]],models.Json],module.audit_cell)
    old_write = cast(Callable[[Path,models.Json | str],None],module.write)
    old_markdown = cast(Callable[[models.Json,bool],str],module.markdown)
    structured = value.model_dump(mode='json')
    mapped = {c.mapping.actual.run_id:c for c in value.cell_projection}

    def raw(path: Path) -> bytes:
        # The only compressed read is the freshly generated metadata-only archive
        # for the frozen artifact digest. Physical payload reads remain prohibited.
        return io_state.read(path)

    def queues(base: Path, paths: list[Path]) -> list[Any]:
        expected = [value.original_cit_receipt.path,value.original_graph_receipt.path,value.tail_queue.path]
        core.require(paths == expected and base == options.base, 'exact original+tail queue roster required')
        result = old_queues(base,paths)
        core.require(all(not d.error for d in result), 'queue metadata source audit failed')
        for i,doc in enumerate(result):
            if doc.path == value.tail_queue.path:
                result[i] = module.Document(doc.path,value.queue_projection.model_dump(mode='json'),doc.bytes,doc.sha256,None)
        return result

    def cell(step: models.Json, base: Path, queues_value: list[Any]) -> models.Json:
        projection = mapped.get(step['run_id'])
        if isinstance(projection,schema.SkippedProjection):
            core.require(step == projection.mapping.actual.model_dump(mode='json'), 'skip actual step differs')
            return skipped_row(step,projection)
        row = old_cell(step,base,queues_value)
        if projection is not None:
            core.require(row['qualified'] == projection.qualified, 'frozen pass qualification disagrees with actual finalized tail')
            row['tail_projection'] = projection.model_dump(mode='json')
            row['original_step'] = projection.mapping.original.model_dump(mode='json')
        else:
            row['original_step'] = step
        return row

    def write(path: Path, output: models.Json | str) -> None:
        if path.name in {'report.json','generation-receipt.json'}:
            core.require(isinstance(output,dict), 'structured tail report required')
            assert isinstance(output,dict)
            output['tail_publication_provenance'] = structured
            output['all60_qualified'] = False
            output['all60_attempted'] = False
            output['protocol_finished_terminal_evidence'] = True
            output['protocol_outcome'] = 'completed_with_failures'
            if path.name == 'report.json':
                core.require(output['qualified_cells'] == 30+sum(c.qualified for c in value.cell_projection),
                             'original/tail pass count disagrees with unchanged qualification')
                output['attempted_cells'] = sum(c['status'] != 'not_started_due_to_failed_warmup' for c in output['cells'])
                output['skipped_cells'] = sum(c['status'] == 'not_started_due_to_failed_warmup' for c in output['cells'])
                for row,payload in zip(output['cells'],output['physical_payloads'],strict=True):
                    if row['status'] == 'not_started_due_to_failed_warmup':
                        payload['apo_collected_manifest'] = None
                        payload['scope'] = 'Warmup-policy skip: no process, physical payload or collected manifest was created.'
                output['native_quota_observation'] = {'configured_bytes':268435456,'actual_reservation_observed':False,
                    'actual_prepayment_observed':False,'scope':'Configured quota only; actual reservation/prepayment events unobserved.'}
        old_write(path,output)

    def markdown(report: models.Json, detailed: bool) -> str:
        # JSON serialization sorts object keys. Render the same ordered values
        # in a private Markdown view; structured/raw evidence remains unchanged.
        view = copy.deepcopy(report)
        for row in view['cells']:
            row['outcomes'] = dict(sorted(row['outcomes'].items()))
        text = old_markdown(view,detailed)
        if detailed:
            header = '| Run | Role / block | Host / producer / engine / oracle | Seconds | Qualified |'
            core.require(text.count(header) == 1, 'frozen outcome table header changed')
            text = text.replace(header,'| Run | Role / block | Engine / host / oracle / producer | Seconds | Qualified |')
        old = 'Only a 60/60 qualified report with finalized passed queues is eligible for final DONE.'
        core.require(text.count(old) == 1, 'frozen prose completion sentence changed')
        text = text.replace(old,'60/60 qualification is false; 60/60 attempted calls are false; the protocol completed_with_failures with closed failures and explicit skips retained. B8 DONE denotes protocol completion with failures. The all60_qualified and all60_attempted fields are false.')
        text = text.replace('Status: **incomplete_receipt_evidence**.',
                            'Protocol: **completed_with_failures**. Qualification status: **incomplete_receipt_evidence**.')
        text += '\n## Finalized serial tail\n\n'+adapter.DISCLOSURE+'\n\n'
        text += f"Protocol: **completed_with_failures**; {report['qualified_cells']}/60 qualified, {report['attempted_cells']}/60 attempted, {report['skipped_cells']} skipped. All60 qualification and all60 attempted calls are false.\n"
        text += '\nNative quota: 256 MiB configured; actual reservation and prepayment events are unobserved.\n'
        if detailed:
            text += '\n| Original planned ID | Actual fresh ID | Disposition |\n| --- | --- | --- |\n'
            for projection in value.cell_projection:
                disposition = 'not_started_due_to_failed_warmup' if isinstance(projection,schema.SkippedProjection) else projection.disposition
                text += f'| {projection.mapping.original.run_id} | {projection.mapping.actual.run_id} | {disposition} |\n'
        return text

    tool_pins = [value.frozen_publisher,value.frozen_host_wrapper,value.frozen_gate,value.frozen_host_gate,
        value.publisher_wrapper,value.publication_adapter,value.publication_models,value.publication_gate,
        value.preserved_serial_owner,*value.immutable_helper_sources]
    tool_pins.extend(c.archived_failure_gate_owner for c in value.cell_projection
        if isinstance(c,schema.AttemptedProjection) and c.archived_failure_gate_owner is not None)
    module.__dict__.update(raw=raw,queue_documents=queues,audit_cell=cell,write=write,markdown=markdown,
        package=lambda dest,roots:adapter.package(dest,roots,tool_pins,io_state))


def run(options: Options) -> models.Json:
    core.require(options.base.is_absolute() and options.dest.is_absolute() and not options.dest.exists()
                 and not options.dest.is_relative_to(options.base), 'fresh explicit output outside live archive required')
    io_state = adapter.IO(core.Deadline.after(options.timeout_seconds))
    loaded, value = provenance(options,io_state)
    publisher,host,historical = loaded
    install(publisher,host,historical,value,options,io_state)
    result: models.Json = publisher.publish(options.base,value.derived_plan.path,
        [value.original_cit_receipt.path,value.original_graph_receipt.path,value.tail_queue.path],options.prior_base,options.dest)
    for pinned in [value.prepared,value.authorization,value.tail_queue,value.original_plan,value.derived_plan,
                   value.original_cit_receipt,value.original_graph_receipt,value.original_oom_closure,*value.immutable_helper_sources]:
        if pinned.path.suffix in adapter.ALLOWED:
            adapter.checked(pinned,io_state.read)
    core.require(result['outcome'] == 'passed' and result['eligible_final_DONE'] is False,
                 'tail publication must preserve all60 nonqualification')
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('base','dest','frozen-publisher','frozen-host-wrapper','frozen-gate','frozen-host-gate',
                 'publication-gate','host-preparation','reference-closure-gate','prepared','preparation-attempt',
                 'authorization','root-review','tail-receipt','preservation'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('retained-evidence','prior-base'):
        parser.add_argument('--'+name,type=Path,action='append',default=[])
    parser.add_argument('--timeout-seconds',type=float,default=1800)
    arguments = vars(parser.parse_args())
    for key,value in arguments.items():
        if isinstance(value,Path):
            arguments[key] = value.resolve()
        elif isinstance(value,list):
            arguments[key] = [p.resolve() for p in value]
    options = Options.model_validate(arguments)
    try:
        result = run(options)
    except (OSError,ValueError,KeyError,TypeError,StopIteration) as error:
        print('B8_TAIL_PUBLICATION_REFUSED '+str(error),file=sys.stderr)
        return 1
    print('B8_TAIL_PUBLICATION '+str(result['outcome'])+' dest='+str(options.dest))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
