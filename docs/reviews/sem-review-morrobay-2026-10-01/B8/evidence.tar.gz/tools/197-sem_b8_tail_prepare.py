"""Fresh B8 output-only derivation; retained original31 evidence is never rewritten."""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Literal

import sem_b8_tail_core as core
import sem_b8_tail_models as models
from pydantic import Field

CORE_SHA = 'd2a6586df48fc4f00e0afb8a427db375f41f1ea773cf16d76adf4e1108822277'
MODELS_SHA = '5b984d9d5c5c51999b2943fdd316216b29aea11d4e8c658fa07c5f8947d0c44b'
PREFIX = 'b8-tail01-'


class Preservation(models.Record):
    outcome: Literal['original_failed_locks_preserved']
    observed_utc: str
    failure_closure: models.FilePin
    archived_gate_owner: models.FilePin
    archived_serial_owner: models.FilePin
    original_gate_path: Path
    original_serial_path: Path
    planned_gate_archive: Path
    planned_serial_archive: Path
    probes: list[models.Probe]
    original_child_pid: int
    original_serial_pid: int
    original_continuation_pid: int
    locks_deleted: Literal[False]
    receipts_rewritten: Literal[False]
    owner_bytes_preserved: Literal[True]


class PreparationAttempt(models.Record):
    observed_utc: str
    started_utc: str
    finished_utc: str | None = None
    outcome: Literal['preparing', 'prepared', 'refused'] = 'preparing'
    original_queue_config: models.FilePin
    original_oom_closure: models.FilePin
    preservation: models.FilePin
    sources: list[models.FilePin]
    prepared: models.FilePin | None = None
    observations: models.Json = Field(default_factory=dict)
    error: str | None = None
    scope: str = 'Host-only config/ID/output derivation; no engine/algorithm/resource/timer changes or original artifact rewrites.'


def own_sources(deadline: core.Deadline) -> list[models.FilePin]:
    core_pin = core.pin(Path(core.__file__).resolve(), deadline)
    model_pin = core.pin(Path(models.__file__).resolve(), deadline)
    core.require(core_pin.sha256 == CORE_SHA and model_pin.sha256 == MODELS_SHA,
                 'frozen audit-only dependency identities')
    return [core_pin, model_pin, core.pin(Path(__file__).resolve(), deadline)]


def assert_no_locks() -> None:
    for name in ('gate.lock', 'serial-queue.lock'):
        p = core.BASE.parent/name
        core.require(not p.exists() and not p.is_symlink(), 'prior gate/serial lock still present: '+name)


def assert_no_locks_for_gate() -> None:
    gate = core.BASE.parent/'gate.lock'
    core.require(not gate.exists() and not gate.is_symlink(), 'global host gate still present')


def validate_preservation(expected: models.FilePin, closure: models.FailureClosure,
                          closure_pin: models.FilePin, deadline: core.Deadline) -> Preservation:
    core.verify(expected, deadline)
    value = Preservation.model_validate(core.read(expected.path, deadline))
    core.require(value.failure_closure == closure_pin
                 and value.original_gate_path == core.BASE.parent/'gate.lock'
                 and value.original_serial_path == core.BASE.parent/'serial-queue.lock', 'exact original lock preservation scope')
    for actual, previous in ((value.archived_gate_owner, closure.gate_owner_pin),
                             (value.archived_serial_owner, closure.serial_owner_pin)):
        core.require(actual.path.name == 'owner.json' and actual.path.is_relative_to(core.BASE)
                     and actual.identity() == previous.identity(), 'archived original owner identity/path')
        core.verify(actual, deadline)
    core.require(value.archived_gate_owner.path.parent == value.planned_gate_archive
                 and value.archived_serial_owner.path.parent == value.planned_serial_archive
                 and value.original_child_pid == closure.host_child_pid,
                 'actual archived owner directories/failure child differ')
    for pid in (value.original_child_pid, value.original_serial_pid, value.original_continuation_pid):
        core.require(pid > 0 and core.pid_absent(pid), 'original preserved owner still live')
    assert_no_locks()
    return value


def queue_inputs(frozen: core.Frozen, expected: models.FilePin) -> tuple[Any, Any, Any, Any, list[models.FilePin]]:
    core.verify(expected, frozen.deadline)
    q = frozen.queue
    config = q.QueueConfig.model_validate(core.read(expected.path, frozen.deadline))
    core.require(config.host_root == core.BASE and config.driver.sha256 == core.DRIVER_SHA,
                 'exact original B8 queue/host scope')
    pins = [expected]
    for name in ('driver', 'campaign', 'plan', 'config_index', 'prerequisites', 'support_manifest'):
        value = models.FilePin.model_validate(getattr(config, name).model_dump())
        core.verify(value, frozen.deadline)
        pins.append(value)
    campaign = frozen.host.Campaign.model_validate(core.read(config.campaign.path, frozen.deadline))
    core.require(campaign.host_root == core.BASE, 'original campaign host root')
    plan = q.Plan.model_validate(core.read(config.plan.path, frozen.deadline))
    index = q.ConfigIndex.model_validate(core.read(config.config_index.path, frozen.deadline))
    core.require(all(getattr(index, key) == getattr(config, key) for key in ('driver', 'campaign', 'plan', 'support_manifest'))
                 and set(index.files) == {s.run_id for s in plan.steps}, 'exact60 original plan/index bindings')
    for expected_cell in index.files.values():
        value = models.FilePin.model_validate(expected_cell.model_dump())
        core.verify(value, frozen.deadline)
        pins.append(value)
    return config, campaign, plan, index, pins


def retained31(frozen: core.Frozen, config: Any, campaign: Any, plan: Any, index: Any,
               references: dict[str, models.Json], closure: models.FailureClosure) -> list[models.FilePin]:
    deadline, q = frozen.deadline, frozen.queue
    paths = [core.BASE/'queue-cit-patents/receipt.json', core.BASE/'queue-graph500-24/receipt.json',
             core.BASE/'continuation02/receipt.json']
    pins = [core.pin(p, deadline) for p in paths]
    cit, graph, continuation = [core.read(p, deadline) for p in paths]
    core.require(cit.get('outcome') == 'passed' and bool(cit.get('finished_utc'))
                 and cit.get('lock_retained') is False and cit.get('active_child_pid') is None
                 and len(cit.get('cells', [])) == 30, 'finalized30 cit queue required')
    for previous in (cit, graph, continuation):
        core.require(bool(previous.get('finished_utc')) and previous.get('active_child_pid') is None
                     and isinstance(previous.get('owner_pid'), int) and core.pid_absent(previous['owner_pid']),
                     'retained original parent owner still live/uncertain')
    core.require(graph.get('outcome') == continuation.get('outcome') == 'error'
                 and graph.get('config') == config.model_dump(mode='json') and graph.get('dataset') == 'graph500-24'
                 and graph.get('lock_retained') is True and len(graph.get('cells', [])) == 30,
                 'original closed Graph/continuation failure scope')
    rows = graph['cells']
    core.require(rows[0].get('step') == plan.steps[30].model_dump(mode='json')
                 and rows[0].get('child_pid') == closure.host_child_pid and rows[0].get('returncode') == 1
                 and rows[0].get('outcome') == 'failed_or_unqualified'
                 and rows[0].get('audit') is None and closure.run_id == plan.steps[30].run_id,
                 'original named natural OOM launch/failure retained')
    for row, step in zip(rows[1:], plan.steps[31:], strict=True):
        core.require(row.get('step') == step.model_dump(mode='json') and row.get('outcome') == 'pending'
                     and all(row.get(k) is None for k in ('started_utc', 'finished_utc', 'child_pid', 'returncode', 'audit')),
                     'original Graph tail was already attempted/changed')
        q.unoccupied(core.BASE, step.run_id)
    for row, step in zip(cit['cells'], plan.steps[:30], strict=True):
        core.require(row.get('step') == step.model_dump(mode='json') and row.get('outcome') == 'passed'
                     and row.get('returncode') == 0 and bool(row.get('finished_utc'))
                     and row.get('audit', {}).get('qualified') is True
                     and isinstance(row.get('child_pid'), int) and core.pid_absent(row['child_pid']),
                     'every original cit cell qualified/exited')
        effective = frozen.host.CellConfiguration.model_validate(core.read(index.files[step.run_id].path, deadline))
        actual = q.audit_cell(step, config, campaign, effective, references['cit-Patents'])
        core.require(actual == row['audit'], 'original unchanged full cit audit differs')
        pins.extend(core.pin(core.BASE/step.run_id/name, deadline) for name in
                    ('result.json', 'container-record.json', 'collected-manifest.json', 'container/artifacts/receipt.json',
                     'container/artifacts/bootstrap-receipt.json', 'container/artifacts/engine/engine-receipt.json'))
    for target in closure.evidence_pins + closure.source_pins:
        core.verify(target, deadline)
    pins.extend(closure.evidence_pins)
    for target in pins:
        core.verify(target, deadline)
    return pins


def derive(frozen: core.Frozen, config: Any, campaign: Any, plan: Any, index: Any,
           references: dict[str, models.Json], dest: Path, queue_run_id: str) -> tuple[Any, list[models.Mapping]]:
    deadline, q = frozen.deadline, frozen.queue
    steps: list[Any] = []
    files: dict[str, Any] = {}
    mappings: list[models.Mapping] = []
    proofs = q.Prerequisites.model_validate(core.read(config.prerequisites.path, deadline)).references
    for ordinal, step in enumerate(plan.steps):
        deadline.check()
        original_pin = models.FilePin.model_validate(index.files[step.run_id].model_dump())
        core.verify(original_pin, deadline)
        effective = frozen.host.CellConfiguration.model_validate(core.read(original_pin.path, deadline))
        reference = references[step.dataset]
        required = {'dataset': step.dataset, 'shape': step.shape, 'variant': step.variant,
            'repo': campaign.guest_root+'/repo', 'harness_repo': frozen.host.HARNESS_REPO,
            'support': campaign.guest_root+'/support', 'output': campaign.guest_root+'/cells/'+step.run_id,
            'binary': frozen.host.SAIL, 'references': reference['config']['output'],
            'vertices': reference['config']['vertices'], 'edges': reference['config']['edges'],
            'minimum_free_bytes': campaign.guest_reserve_bytes,
            'reference_receipt_sha256': proofs[step.dataset].files['container/artifacts/receipt.json'].sha256,
            'support_sha256': config.support_manifest.sha256}
        values = effective.model_dump(mode='json')
        core.require(all(values.get(k) == v for k, v in required.items()), 'original exact config tuple: '+step.run_id)
        if ordinal <= 30:
            steps.append(step)
            files[step.run_id] = index.files[step.run_id]
            continue
        q.unoccupied(core.BASE, step.run_id)
        actual_id = PREFIX+step.run_id.removeprefix('b8-')
        actual = q.Step.model_validate({**step.model_dump(mode='json'), 'run_id': actual_id})
        q.unoccupied(core.BASE, actual_id)
        new_values = {**values, 'output': campaign.guest_root+'/cells/'+actual_id}
        changed = frozen.host.CellConfiguration.model_validate(new_values)
        core.require({k: v for k, v in values.items() if k != 'output'}
                     == {k: v for k, v in changed.model_dump(mode='json').items() if k != 'output'},
                     'only config output may change')
        path = dest/(actual_id+'.json')
        core.write(path, changed.model_dump(mode='json'), fresh=True)
        actual_pin = core.pin(path, deadline)
        steps.append(actual)
        files[actual_id] = q.FilePin.model_validate(actual_pin.model_dump())
        mappings.append(models.Mapping(original=models.Step.model_validate(step.model_dump()),
            actual=models.Step.model_validate(actual.model_dump()), original_config=original_pin, actual_config=actual_pin))
    core.require(len(mappings) == 29 and len({m.actual.run_id for m in mappings}) == 29, 'exact29 fresh tail derivations')
    values = {**plan.model_dump(mode='json'), 'steps': [s.model_dump(mode='json') for s in steps]}
    new_plan = q.Plan.model_validate(values)  # Original60-order/schema/protocol validators unchanged.
    plan_path = dest/'plan.json'
    core.write(plan_path, new_plan.model_dump(mode='json'), fresh=True)
    plan_pin = q.FilePin.model_validate(core.pin(plan_path, deadline).model_dump())
    new_index = q.ConfigIndex.model_validate({**index.model_dump(mode='json'), 'plan': plan_pin.model_dump(mode='json'),
        'files': {k: v.model_dump(mode='json') for k, v in files.items()}})
    index_path = dest/'config-index.json'
    core.write(index_path, new_index.model_dump(mode='json'), fresh=True)
    new_config = q.QueueConfig.model_validate({**config.model_dump(mode='json'), 'output': str(core.BASE/queue_run_id),
        'plan': plan_pin.model_dump(mode='json'), 'config_index': core.pin(index_path, deadline).model_dump(mode='json')})
    queue_path = dest/'queue-graph500-tail01.json'
    core.write(queue_path, new_config.model_dump(mode='json'), fresh=True)
    return new_config, mappings


def prepare(frozen: core.Frozen, original: models.FilePin, closure_pin: models.FilePin, preservation_pin: models.FilePin,
            dest: Path, queue_run_id: str, sources: list[models.FilePin]) -> models.Prepared:
    core.require(dest.is_absolute() and dest.parent == core.BASE and not dest.exists() and not dest.is_symlink(),
                 'fresh owned preparation directory required; no resume')
    core.require(re.fullmatch(r'queue-graph500-tail[a-z0-9-]{1,40}', queue_run_id) is not None,
                 'named fresh tail queue output')
    assert_no_locks()
    frozen.queue.unoccupied(core.BASE, queue_run_id)
    core.verify(closure_pin, frozen.deadline)
    closure = models.FailureClosure.model_validate(core.read(closure_pin.path, frozen.deadline))
    preservation = validate_preservation(preservation_pin, closure, closure_pin, frozen.deadline)
    core.require(core.pid_absent(closure.host_child_pid), 'original failed host child still live')
    probes = core.fresh_probes(frozen, closure.run_id, next(p.argv[-1] for p in closure.probes if p.argv[-2] == 'inspect' and len(p.argv[-1]) == 64))
    config, campaign, plan, index, input_pins = queue_inputs(frozen, original)
    dest.mkdir(mode=0o700)
    core.directory_fsync(dest.parent)
    sources = [*frozen.sources, *sources, *input_pins, preservation_pin, preservation.archived_gate_owner,
               preservation.archived_serial_owner, closure_pin]
    attempt = PreparationAttempt(observed_utc=core.utc(), started_utc=core.utc(), original_queue_config=original,
        original_oom_closure=closure_pin, preservation=preservation_pin, sources=sources,
        observations={'fresh_absence_idle': [p.model_dump(mode='json') for p in probes]})
    receipt_path = dest/'preparation-receipt.json'
    core.write(receipt_path, attempt, fresh=True)
    try:
        temporary = frozen.queue.Receipt(config=config, dataset='graph500-24', owner_pid=os.getpid(), token='audit-only',
            started_utc=core.utc(), observed_utc=core.utc())
        references = frozen.queue.prerequisite_audits(config, temporary, campaign)
        previous = retained31(frozen, config, campaign, plan, index, references, closure)
        attempt.observations['original_prerequisites'] = temporary.prerequisite_observations
        derived, mappings = derive(frozen, config, campaign, plan, index, references, dest, queue_run_id)
        for expected in [*sources, *previous, *[models.FilePin.model_validate(p.model_dump()) for p in temporary.pins]]:
            core.verify(expected, frozen.deadline)
        assert_no_locks()
        prepared = models.Prepared(observed_utc=core.utc(), original_queue_config=original,
            queue_config=core.pin(dest/'queue-graph500-tail01.json', frozen.deadline),
            original_cit_queue_receipt=core.pin(core.BASE/'queue-cit-patents/receipt.json', frozen.deadline),
            original_graph_queue_receipt=core.pin(core.BASE/'queue-graph500-24/receipt.json', frozen.deadline),
            original_continuation_receipt=core.pin(core.BASE/'continuation02/receipt.json', frozen.deadline),
            original_oom_closure=closure_pin, original31_evidence=previous, sources=sources,
            mappings=mappings, original_plan=models.FilePin.model_validate(config.plan.model_dump()),
            derived_plan=models.FilePin.model_validate(derived.plan.model_dump()),
            original_failed_step=models.Step.model_validate(plan.steps[30].model_dump()))
        core.write(dest/'prepared.json', prepared, fresh=True)
        authorization = models.Authorization(policy='b8-tail-warmups-before-two-UAAU-blocks-v1', approved_by='root', original_queue_config=original,
            named_failures={m.actual.run_id: m.actual_config.sha256 for m in mappings})
        core.write(dest/'authorization-for-root-review.json', authorization, fresh=True)
        attempt.prepared = core.pin(dest/'prepared.json', frozen.deadline)
        attempt.outcome = 'prepared'
        attempt.finished_utc = attempt.observed_utc = core.utc()
        core.write(receipt_path, attempt)
        return prepared
    except BaseException as error:  # Preserve partial preparation; never launch or clean engines/locks.
        attempt.outcome = 'refused'
        attempt.error = repr(error)
        attempt.finished_utc = attempt.observed_utc = core.utc()
        core.write(receipt_path, attempt)
        raise
