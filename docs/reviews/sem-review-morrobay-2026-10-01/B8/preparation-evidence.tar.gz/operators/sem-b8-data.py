"""Operator-only Graph500-24 download and separately owned guest staging.

Preparation source; this author did not run either action. Both actions retain
their fresh namespace and shared gate lock on any error. No retries or cleanup.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import traceback
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import ModuleType
from typing import Any, Literal, cast

import pyarrow.parquet as pq
from pydantic import BaseModel, ConfigDict, Field

PARENT = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001')
BASE = PARENT / 'B8-run01'
LOCK = PARENT / 'gate.lock'
URLS = {'vertices.parquet': 'https://datasets.ldbcouncil.org/graphalytics-parquet/graph500-24-v.parquet',
        'edges.parquet': 'https://datasets.ldbcouncil.org/graphalytics-parquet/graph500-24-e.parquet'}
# These are observed HEAD lengths, not accepted payload identities or row counts.
HEAD_BYTES = {'vertices.parquet': 9119859, 'edges.parquet': 837233354}
GUEST = '/targets/sem-review-20261001/B8-run01/inputs/graph500-24'

STAGE = r'''
import tarfile
require(spec['dataset_root'] == str(root / 'inputs/graph500-24'), 'dataset staging scope')
destination = pathlib.Path(spec['dataset_root'])
require(not destination.exists() and not destination.is_symlink(), 'dataset already staged')
observations = admission()
before = guard()
destination.mkdir(parents=True)
receipt: dict[str, Any] = {'schema_version': 1, 'outcome': 'checking', 'admission': observations,
                         'identities_before': before, 'started_utc': datetime.now(timezone.utc).isoformat()}
save(destination / 'stage-receipt.json', receipt)
try:
    with tarfile.open(fileobj=sys.stdin.buffer, mode='r|') as archive:
        names: set[str] = set()
        for member in archive:
            require(member.isfile() and member.name in spec['files'] and member.name not in names, 'unlisted/duplicate dataset member')
            names.add(member.name)
            path = scoped(destination, member.name)
            input_stream = archive.extractfile(member)
            require(input_stream is not None, 'dataset member stream missing')
            with path.open('xb') as stream:
                shutil.copyfileobj(input_stream, stream)
                stream.flush(); os.fsync(stream.fileno())
            require(path.stat().st_size == spec['files'][member.name]['bytes']
                    and sha(path) == spec['files'][member.name]['sha256'], 'dataset bytes changed')
    require(names == set(spec['files']), 'dataset missing member')
    quiet()
    receipt['files'] = spec['files']
    receipt['identities_after'] = guard()
    require(receipt['identities_before'] == receipt['identities_after'], 'borrowed identities changed')
    require(shutil.disk_usage('/targets').free >= spec['guest_reserve_bytes'], 'guest reserve after dataset staging')
    receipt['outcome'] = 'passed'
except BaseException as error:
    receipt.update(outcome='error', error=repr(error), traceback=traceback.format_exc())
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save(destination / 'stage-receipt.json', receipt)
print(json.dumps(receipt, allow_nan=False))
sys.exit(0 if receipt['outcome'] == 'passed' else 1)
'''


class Record(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)


class Identity(Record):
    bytes: int
    sha256: str = Field(pattern=r'^[a-f0-9]{64}$')


class Admission(Record):
    vertex_rows: int
    edge_rows: int
    maximum_edge_row_group_rows: int
    reference_memory_model_bytes: int
    reference_disk_model_bytes: int
    preparation_envelope_bytes: Literal[34359738368] = 34359738368
    footer_source: str = 'Actual downloaded Parquet metadata; no catalog row-count substitution.'


class DownloadReceipt(Record):
    schema_version: Literal[1] = 1
    outcome: Literal['checking', 'downloaded_and_admitted', 'error'] = 'checking'
    started_utc: str
    finished_utc: str | None = None
    urls: dict[str, str] = URLS
    prior_head_bytes: dict[str, int] = HEAD_BYTES
    files: dict[str, Identity] = Field(default_factory=dict)
    raw_schemas: dict[str, str] = Field(default_factory=dict)
    admission: Admission | None = None
    commands: list[list[str]] = Field(default_factory=list)
    error: str | None = None
    traceback: str | None = None
    qualification: str = 'Full input domain/uniqueness and all shape references are constructed in the separate reference phase.'


@dataclass(frozen=True, slots=True)
class Options:
    action: Literal['download', 'stage']
    run_id: str
    profile: Path
    profile_sha256: str


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def wrapper(profile: Path, expected_sha256: str) -> ModuleType:
    require(profile == BASE / 'controller-profile/run_shapes_host.py' and not profile.is_symlink(), 'exact host driver scope')
    require(re.fullmatch(r'[a-f0-9]{64}', expected_sha256) is not None, 'reviewed driver SHA256 required')
    with profile.open('rb') as stream:
        require(hashlib.file_digest(stream, 'sha256').hexdigest() == expected_sha256, 'driver changed before import')
    provenance = json.loads((profile.parent / 'provenance.json').read_text())
    support = json.loads((BASE / 'support/support-manifest.json').read_text())
    expected = support['files_sha256']['run_shapes_host.py']
    require(expected == expected_sha256 == provenance['driver_sha256'], 'driver/support/provenance pin mismatch')
    # Hash without importing any engine or helper from a mutable working tree.
    import_spec = importlib.util.spec_from_file_location('pinned_b8_dataset_host', profile)
    require(import_spec is not None and import_spec.loader is not None, 'host driver import')
    assert import_spec is not None and import_spec.loader is not None
    module = importlib.util.module_from_spec(import_spec)
    sys.modules[import_spec.name] = module
    import_spec.loader.exec_module(module)
    require(module.sha(profile) == expected == provenance['driver_sha256'], 'committed host driver changed')
    module.configure_campaign(BASE / 'campaign.json')
    return module


def footer_admission(directory: Path, host: ModuleType) -> tuple[Admission, dict[str, str]]:
    schemas: dict[str, str] = {}
    metadata: dict[str, Any] = {}
    for name, columns in (('vertices.parquet', ['id']), ('edges.parquet', ['source', 'target'])):
        with pq.ParquetFile(directory / name) as parquet:
            schemas[name] = str(parquet.schema_arrow)
            require(all(column in parquet.schema_arrow.names and str(parquet.schema_arrow.field(column).type) == 'int64'
                        for column in columns), 'downloaded BIGINT columns ' + name)
            metadata[name] = parquet.metadata
    v, e = metadata['vertices.parquet'].num_rows, metadata['edges.parquet'].num_rows
    groups = metadata['edges.parquet']
    r = max((groups.row_group(i).num_rows for i in range(groups.num_row_groups)), default=0)
    bytes_on_disk = sum((directory / name).stat().st_size for name in URLS)
    memory = 64 * e + 32 * r + 128 * v + 128 * 262144 + bytes_on_disk + 3 * 2**30
    disk = 64 * e + 32 * v + 2 * 2**30
    require(memory <= 32 * 2**30, 'actual-footer reference memory estimate exceeds 32GiB')
    require(shutil.disk_usage(BASE).free >= host.CAMPAIGN.archive_reserve_bytes + disk,
            'Apo reserve plus outside-timer reference disk model')
    return Admission(vertex_rows=v, edge_rows=e, maximum_edge_row_group_rows=r,
                     reference_memory_model_bytes=memory, reference_disk_model_bytes=disk), schemas


def download(directory: Path, host: ModuleType) -> None:
    receipt = DownloadReceipt(started_utc=utc())
    host.save(directory / 'download-receipt.json', receipt)
    try:
        host.snapshot()
        for name, url in URLS.items():
            part = directory / (name + '.partial')
            # Fresh download directory owns this path. curl uses HTTPS only,
            # one attempt, and a fixed URL; logs never contain credentials.
            command = ['/usr/bin/curl', '--fail', '--location', '--proto', '=https', '--proto-redir', '=https',
                       '--silent', '--show-error', '--max-time', '7200', '--output', str(part),
                       '--dump-header', str(directory / (name + '.headers')), url]
            receipt.commands.append(command)
            host.save(directory / 'download-receipt.json', receipt)
            require(not part.exists(), 'download partial already exists')
            result = subprocess.run(command, capture_output=True, text=True, timeout=7230, check=False)
            (directory / (name + '.curl.log')).write_text(result.stdout + result.stderr)
            require(result.returncode == 0 and part.is_file() and not part.is_symlink(), 'download failed ' + name)
            part.rename(directory / name)
            path = directory / name
            receipt.files[name] = Identity(bytes=path.stat().st_size, sha256=host.sha(path))
            # HEAD length changes are evidence, not automatically trusted as the
            # new payload identity. Preserve the actual body hash and footer.
            require(receipt.files[name].bytes > 0, 'empty dataset payload')
        receipt.admission, receipt.raw_schemas = footer_admission(directory, host)
        receipt.outcome = 'downloaded_and_admitted'
    except BaseException as error:  # noqa: BLE001 - preserve partial downloads and failed admission
        receipt.error, receipt.traceback = repr(error), traceback.format_exc()
        receipt.outcome = 'error'
        raise
    finally:
        receipt.finished_utc = utc()
        host.save(directory / 'download-receipt.json', receipt)


def stage(directory: Path, host: ModuleType) -> None:
    original = BASE / 'downloads/graph500-24'
    source = DownloadReceipt.model_validate_json((original / 'download-receipt.json').read_text())
    require(source.outcome == 'downloaded_and_admitted' and source.admission is not None, 'unadmitted download')
    for name, expected in source.files.items():
        require((original / name).stat().st_size == expected.bytes and host.sha(original / name) == expected.sha256,
                'downloaded input changed ' + name)
    pins = host.host_pins()
    spec = host.specification(pins)
    spec.update(dataset_root=GUEST, files={name: value.model_dump() for name, value in source.files.items()})
    require(set(spec['files']) == set(URLS), 'exact Graph500 input file set')
    host.snapshot()
    host.idle()
    image = host.capture(host.DOCKER + ['image', 'inspect', host.IMAGE, '--format', '{{.Id}}'])
    require(image.returncode == 0 and image.stdout.strip() == host.IMAGE, 'gate image identity')
    with tarfile.open(directory / 'payload.tar', 'x') as archive:
        for name in sorted(URLS):
            archive.add(original / name, arcname=name, recursive=False)
    host.save(directory / 'configuration.json', {'source_download_receipt_sha256': host.sha(original / 'download-receipt.json'),
              'specification': spec, 'payload_sha256': host.sha(directory / 'payload.tar'),
              'ownership': 'Exact pinned B8 owned_small;1CPU/512MiB/no-network/private writable-volume helper; no engine.'})
    host.owned_small(directory, 'sem-review-b8-' + directory.name + '-data-stage', host.COMMON + STAGE,
                     spec, directory / 'payload.tar', GUEST + '/stage-receipt.json', writable=True)
    receipt = json.loads((directory / 'stage-receipt.json').read_text())
    require(receipt.get('outcome') == 'passed' and receipt.get('identities_before') == receipt.get('identities_after')
            and receipt.get('files') == spec['files'], 'dataset producer receipt')
    # The full reference config can now bind actual bytes; do not manufacture
    # a reference receipt hash or cell configuration before its reference job.
    host.save(directory / 'graph500-reference01.json', {'vertices': GUEST + '/vertices.parquet',
              'edges': GUEST + '/edges.parquet', 'output': host.ROOT + '/references/graph500-reference01',
              'vertices_sha256': source.files['vertices.parquet'].sha256,
              'edges_sha256': source.files['edges.parquet'].sha256})


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['download', 'stage'])
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--profile', type=Path, default=BASE / 'controller-profile/run_shapes_host.py')
    parser.add_argument('--profile-sha256', required=True)
    raw = parser.parse_args()
    options = Options(cast(Literal['download', 'stage'], raw.action), raw.run_id, raw.profile, raw.profile_sha256)
    require(re.fullmatch(r'[a-z][a-z0-9-]{0,63}', options.run_id) is not None, 'fresh run ID syntax')
    host = wrapper(options.profile, options.profile_sha256)
    directory = (BASE / 'downloads/graph500-24') if options.action == 'download' else BASE / options.run_id
    directory.mkdir(parents=True, exist_ok=False)
    token = uuid.uuid4().hex
    result: dict[str, Any] = {'outcome': 'checking', 'action': options.action, 'started_utc': utc(),
                              'lock_retained': True, 'lock_owner_acquired': False,
                              'certain_container_closure': False, 'profile_sha256': host.sha(options.profile)}
    try:
        LOCK.mkdir(exist_ok=False)
        host.save(LOCK / 'owner.json', {'pid': os.getpid(), 'token': token, 'run_id': options.run_id,
                  'action': options.action, 'host': str(directory), 'started_utc': utc()})
        result['lock_owner_acquired'] = True
        host.save(directory / 'result.json', result)
        if options.action == 'download':
            download(directory, host)
        else:
            stage(directory, host)
            result['certain_container_closure'] = True
        host.release_lock(token)
        result.update(outcome='passed', lock_retained=False)
    except BaseException as error:  # noqa: BLE001 - preserve lock/namespace for owned failure review
        result.update(outcome='error', error=repr(error), traceback=traceback.format_exc())
    finally:
        result['finished_utc'] = utc()
        host.save(directory / 'result.json', result)
    print(json.dumps({'outcome': result['outcome'], 'directory': str(directory)}))
    return 0 if result['outcome'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
