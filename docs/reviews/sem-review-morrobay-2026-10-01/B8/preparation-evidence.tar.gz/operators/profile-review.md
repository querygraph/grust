# B8 profile and public-data preparation source

Prepared for root review. No profile was created, no public payload downloaded,
no guest volume staged, no container launched, no Git mutation or cleanup done.

## Builder

`/tmp/sem-b8-profile.py --helper-commit <full40hex>` prepares the fresh host
`/Volumes/Apo/graph-tests/results/sem-review-20261001/B8-run01` and guest tuple
`/targets/sem-review-20261001/B8-run01`. `--check-only` writes nothing. Both modes
refuse a preexisting host namespace; the builder never removes partial work.

Before creating that namespace, it reads every flat B8 `.py` from the exact
Grust commit with `git show`. All existing helpers/tests plus
`run_pair_queue.py` and `test_run_pair_queue.py` must be committed. The builder
does not require the mutable working-tree HEAD to remain at that commit.
Root's detached gate must cover the exact helper commit first.

The driver and queue are copied verbatim to `controller-profile/`; there are
no namespace substitutions, source rewrites, A2 profile derivatives or engine
imports. Host driver constants must equal the A2 image/matrix/source/harness/
binary/native pins. The retained A2-run04 delta bundle must have SHA256
`b53951c1242e56b6fd1b9a59e204469846c2043eee1f47e7855db351e2e64454`,
name f3b and require frozen6ae. Staging retains the existing f3/6ae/561/ff pins.

Campaign overrides are explicit:

| Field | Value |
|---|---:|
| `guest_reserve_bytes` | 64 GiB |
| `archive_reserve_bytes` | 120 GiB on Apo |
| `reference_timeout_seconds` | 7200 s |
| `cell_timeout_seconds` | 3600 s |
| `archive_copy_timeout_seconds` | 1800 s |

`support/` contains committed helpers, support/payload manifests and tar.
Payload names and SHA256 bind every initial file, including the delta, fixture,
fixture contract and tiny reference config. `payload-preparation.json` binds
the helper commit/tree, exact builder, helper and artifact bytes, declared
campaign and preparation outcome. Failed partial profiles remain on disk.
Host-only `controller-profile/` also retains the external builder and data
source bytes. File fsync is used; host directory power-loss durability is not
claimed. Preparation does not claim that a gate or execution passed.

## Small signed fixture

Host inputs are `B8-run01/fixture/{vertices,edges}.parquet`; identical bytes are
staged under `<guest_root>/inputs/tiny-signed-highbit/`. Vertices have `id:int64`;
edges have `source:int64,target:int64`. Eight vertices and eight edge rows
include signed extremes, an ID above 2^53, duplicate `(1,2)`, loops `(2,2)` and
`(0,0)`, and isolated `-7694170072594669674`.

`fixture-contract.json` preserves physical schemas, actual Parquet file pins,
logical row hashes (ordered little-endian signed INT64), decimal-string IDs,
independent expected shape rows and source semantics. It is fixture evidence,
not an observed engine pass. `tiny-reference.json` pins the actual generated
Parquet bytes and outputs `<guest_root>/references/tiny-reference01`.
Six tiny cell configs wait for the actual closed reference receipt hash.

## Later root-only public data actions

`/tmp/sem-b8-data.py` provides separate `download` and `stage` actions. It takes
`--run-id <fresh-id> --profile-sha256 <reviewed-driver64hex>` and imports the
exact profile driver only after hashing it. It takes the shared `gate.lock`,
never removes a stale lock, and preserves failures/partials. Do not execute it
while A2/A3 or any other heavy gate job owns the lock.

Download uses the two [official Graph500-24 Parquet URLs](https://ldbcouncil.org/benchmarks/graphalytics/datasets/)
recorded in `B8/graph500-24-head.json`: HTTPS-only curl, one attempt, fresh
`.partial` files, retained headers/logs, and actual body length/SHA256. Prior
HEAD lengths are explicitly metadata only. Actual Parquet footer V/E/R and raw
schemas drive the 32 GiB reference memory estimate; catalog counts do not.
Full graph-domain/reference construction remains a separate reference phase.

Stage requires that completed download receipt and rehashes both bodies. It
uses the pinned driver's existing `owned_small` primitive (1 CPU, 512 MiB,
private PID namespace, no network), streaming a fresh tar into the owned
`<guest_root>/inputs/graph500-24` directory. Borrowed source/binary/manifests
are checked before/after; every staged body is checked; clean owned exit,
container removal and host receipt collection are required. The existing
600 s small-container deadline applies; staging a large dataset has not been
qualified under that deadline. Failure is retained without retry or cleanup.
The resulting Graph500 reference config binds actual bytes; no oracle or cell
receipt hash is invented. Cit-Patents uses its historical guest files without
copying them. Full queue/config manifests wait for both full reference hosts
and six closed tiny controls.

## Gates and execution order

1. Root freezes/gates the integrated B8 helper commit in a detached worktree:
   repository Ruff, strict mypy and the existing focused offline controls,
   including the queue controls. Retain the exact commit and verdict.
2. Review/hash the external builder/data source and static gate evidence at
   `/tmp/sem-b8-profile-static-controls.json`. The known A2 helper commit is
   intentionally refused by `--check-only` because it has no committed B8 files.
3. Run builder `--check-only` against the gated future B8 commit, then prepare
   once without `--check-only`. Verify profile provenance/manifests before root
   calls the exact driver `stage --campaign campaign.json --run-id stage01`.
4. Root runs tiny/full references and six tiny controls serially, then freezes
   all60 paired configurations and prerequisite proofs before either queue.
   Root executes cit-Patents first, Graph500-24 next; no retries or resume.

The disk reserves are proposals adopted as explicit profile admission values,
not observed storage or memory peaks. Raw outputs stay on Apo. Only the frozen
driver's existing verified passed-cell removal scope may reclaim guest cells;
this preparation source performs no output/archive cleanup.
