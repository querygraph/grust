"""Prepare one immutable B8 profile from committed Grust helpers; no Docker.

Root reviews and runs this builder after the integrated detached-tree gates.
--check-only validates committed support and existing pins without creating files.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.metadata
import json
import os
import shutil
import struct
import subprocess
import tarfile
import traceback
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Literal

import pyarrow as pa
import pyarrow.parquet as pq
from pydantic import BaseModel, ConfigDict, Field

REPO = Path('/Users/alexy/src/grust')
PARENT = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001')
BASE = PARENT / 'B8-run01'
ROOT = '/targets/sem-review-20261001/B8-run01'
PREFIX = 'docs/reviews/sem-review-morrobay-2026-10-01/B8/'
DELTA = PARENT / 'A2-run04/support/delta.bundle'
DELTA_SHA = 'b53951c1242e56b6fd1b9a59e204469846c2043eee1f47e7855db351e2e64454'
CONTROLLER = 'f3b3ef8fc054ce7788ec2b46ec8b034ccec1f98a'
HARNESS = '6ae2e43a903c2cee02da170465c922c72b76198e'
RUNTIME = '56194b170155301ba91077f0ba3df31fe2c78b6b'
NATIVE = 'ffcfbd5690e3f3681ef9ac18ba959bc231cf9f73'
MATRIX = Path('/Users/alexy/src/sail-extensions-gates/stream-experiments-20260930/harness/run_matrix.py')
MATRIX_SHA = '21d12c888caabb59acece11a2ee27837974c1f34b08cc499600e305d6341e1a0'
PINNED_HOST = {
    'CONTROLLER': CONTROLLER, 'HARNESS': HARNESS,
    'HARNESS_REPO': '/targets/pecan-typed-tests-20261001/candidate',
    'DEPS': '/targets/pecan-typed-tests-20261001/deps',
    'PYTHON': '/targets/graph-nuts-ffcfbd569/venv/bin/python',
    'MATRIX_SHA': MATRIX_SHA,
    'IMAGE': 'sha256:f3518d652fbea8b9b9f9ebf9849277ca3bd39d0c21bb2c6e36fbaeaa2dc2678e',
    'SAIL': '/targets/sail-compact-host-56194b170155/sail-linux-x86_64-56194b170155-release',
    'SAIL_SHA': '5b7f506c19afd76a28b84c1459397b4ab30ff4cfc761f4195789425b963facec',
    'NATIVE_SHA': 'eb0be839de652e059799dea3bba22cc0908998bd97cfa2f4cf04c67817e2ee50',
}
REQUIRED = {'engine_shapes.py', 'supervise_shape.py', 'prepare_shapes.py', 'shape_reference.py',
            'shape_oracle.py', 'run_shapes_host.py', 'run_pair_queue.py', 'test_run_pair_queue.py',
            'test_engine_shapes.py', 'test_supervise_shape.py', 'test_shape_oracle.py', 'test_run_shapes_host.py'}
GUEST_RESERVE = 64 * 2**30
APO_RESERVE = 120 * 2**30
IDS = [-(2**63), -7694170072594669674, -3, 0, 1, 2, 2**53 + 1, 2**63 - 1]
EDGES = [(1, 2), (1, 2), (2, 1), (2, 2), (-3, -(2**63)), (2**53 + 1, 0), (0, 0), (2**63 - 1, -(2**63))]
Digest = Annotated[str, Field(pattern=r'^[a-f0-9]{64}$')]
Commit = Annotated[str, Field(pattern=r'^[a-f0-9]{40}$')]


class Record(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)


class Options(Record):
    helper_commit: Commit
    check_only: bool = False


class Identity(Record):
    bytes: int
    sha256: Digest


class Campaign(Record):
    host_root: Path = BASE
    guest_root: str = ROOT
    archive_reserve_bytes: int = APO_RESERVE
    guest_reserve_bytes: int = GUEST_RESERVE
    archive_copy_timeout_seconds: int = 1800
    reference_timeout_seconds: int = 7200
    cell_timeout_seconds: int = 3600


class InputConfig(Record):
    vertices: str
    edges: str
    output: str
    vertices_sha256: Digest
    edges_sha256: Digest


class SupportManifest(Record):
    schema_version: Literal[1] = 1
    files_sha256: dict[str, Digest]
    delta_bundle_sha256: Digest = DELTA_SHA
    controller_sha: str = CONTROLLER
    harness_sha: str = HARNESS
    helper_repository_commit: Commit
    helper_repository_tree: str


class PayloadManifest(SupportManifest):
    """files_sha256 names are relative to the guest root rather than support."""


class ProfileReceipt(Record):
    schema_version: Literal[1] = 1
    outcome: Literal['checking', 'prepared', 'error'] = 'checking'
    started_utc: str
    finished_utc: str | None = None
    helper_repository_commit: Commit
    helper_repository_tree: str
    builder: Identity
    campaign: Campaign
    helpers: dict[str, Identity]
    artifacts: dict[str, Identity] = Field(default_factory=dict)
    runtime_source: str = RUNTIME
    native_source: str = NATIVE
    retained_a2_delta: str = str(DELTA)
    host_pins: dict[str, str] = PINNED_HOST
    transformations: list[str] = ['Exact git-show helper bytes; no source substitutions or driver derivatives.']
    execution_scope: str = 'Preparation only: no Docker, guest staging, downloads, engines, Git mutation, or cleanup.'
    durability_scope: str = 'File fsync; no host directory power-loss durability claim.'
    error: str | None = None
    traceback: str | None = None


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def identity(path: Path) -> Identity:
    require(path.is_file() and not path.is_symlink(), 'regular file required: ' + str(path))
    with path.open('rb') as stream:
        return Identity(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def git(*argv: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *argv], timeout=60)


def write_bytes(path: Path, data: bytes) -> None:
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def write_json(path: Path, value: BaseModel | dict[str, object]) -> None:
    data = value.model_dump(mode='json') if isinstance(value, BaseModel) else value
    write_bytes(path, (json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + '\n').encode())


def save_receipt(path: Path, receipt: ProfileReceipt) -> None:
    temporary = path.with_suffix('.tmp')
    with temporary.open('w') as stream:
        stream.write(receipt.model_dump_json(indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def helpers_at(commit: str) -> tuple[str, dict[str, bytes]]:
    require(git('rev-parse', commit + '^{commit}').decode().strip() == commit, 'exact committed helper SHA required')
    tree = git('rev-parse', commit + '^{tree}').decode().strip()
    paths = git('ls-tree', '-r', '--name-only', commit, '--', PREFIX).decode().splitlines()
    files: dict[str, bytes] = {}
    for name in paths:
        if name.endswith('.py'):
            require(str(Path(name).parent) + '/' == PREFIX, 'support helpers must be flat: ' + name)
            files[Path(name).name] = git('show', commit + ':' + name)
    require(REQUIRED <= files.keys(), 'committed B8 support incomplete; missing: ' + ', '.join(sorted(REQUIRED - files.keys())))
    constants = {node.targets[0].id: ast.literal_eval(node.value)
                 for node in ast.parse(files['run_shapes_host.py']).body
                 if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                 and node.targets[0].id in PINNED_HOST}
    require(constants == PINNED_HOST, 'committed host identities differ from the retained A2 pins')
    return tree, files


def affine(vertex: int) -> int:
    """Independent polynomial product/long division for fixture expectations."""
    coefficient = (-4767286540954276203) & (2**64 - 1)
    product = 0
    for bit in range(64):
        if (vertex & (2**64 - 1)) & (1 << bit):
            product ^= coefficient << bit
    while product.bit_length() > 64:
        product ^= ((1 << 64) | 0x1B) << (product.bit_length() - 65)
    product ^= 2949826092126892291
    return product if product < 2**63 else product - 2**64


def row_sha(rows: Sequence[Sequence[int]]) -> str:
    return sha(b''.join(struct.pack('<' + 'q' * len(row), *row) for row in rows))


def fixture(directory: Path) -> dict[str, object]:
    directory.mkdir()
    vertices, edges = directory / 'vertices.parquet', directory / 'edges.parquet'
    pq.write_table(pa.table({'id': pa.array(IDS, type=pa.int64())}), vertices,
                   compression='zstd', version='2.6', row_group_size=8)
    pq.write_table(pa.table({'source': pa.array([a for a, _ in EDGES], type=pa.int64()),
                            'target': pa.array([b for _, b in EDGES], type=pa.int64())}), edges,
                   compression='zstd', version='2.6', row_group_size=8)
    for path in (vertices, edges):
        with path.open('rb') as stream:
            os.fsync(stream.fileno())
    adjacency = sorted(set(EDGES + [(b, a) for a, b in EDGES]))
    active = sorted({v for a, b in EDGES if a != b for v in (a, b)})
    representatives = [(v, min([affine(v)] + [affine(b if a == v else a)
                            for a, b in EDGES if a != b and v in (a, b)])) for v in active]
    labels = [(v, min([v] + [b if a == v else a for a, b in EDGES if v in (a, b)])) for v in IDS]
    expected = {'adjacency': adjacency, 'representatives': representatives, 'min-label-initial-round': labels}
    return {'schema_version': 1, 'created_utc': utc(), 'dataset': 'tiny-signed-highbit',
            'bigint_json_encoding': 'Decimal strings; logical row hashes use ordered signed little-endian INT64 rows.',
            'vertices': [str(v) for v in IDS], 'edges': [[str(a), str(b)] for a, b in EDGES],
            'vertex_rows': len(IDS), 'edge_rows': len(EDGES), 'isolated_vertices': ['-7694170072594669674'],
            'row_sha256': {'vertices': row_sha([(v,) for v in IDS]), 'edges': row_sha(EDGES)},
            'files': {'vertices.parquet': identity(vertices).model_dump(), 'edges.parquet': identity(edges).model_dump()},
            'raw_schemas': {'vertices.parquet': str(pq.ParquetFile(vertices).schema_arrow),
                            'edges.parquet': str(pq.ParquetFile(edges).schema_arrow)},
            'packages': {'pyarrow': importlib.metadata.version('pyarrow'), 'pydantic': importlib.metadata.version('pydantic')},
            'expected_shapes': {shape: {'rows': [[str(a), str(b)] for a, b in rows], 'row_sha256': row_sha(rows)}
                                for shape, rows in expected.items()},
            'sem_contract': {'vertex_id': 'non-null unique BIGINT', 'edge_columns': ['source BIGINT', 'target BIGINT'],
                             'endpoints_exist': True, 'duplicates_and_self_loops': 'Allowed and retained in input identity.',
                             'representatives': 'First active-endpoint contraction map after self-loop filtering; signed MIN of f(neighbour) and f(id).',
                             'min_label': 'Whole initial label update including the isolated vertex.',
                             'source': 'https://github.com/querygraph/sail/blob/' + CONTROLLER + '/examples/extensions/graph-algorithms/src/pyspark_pecan/wcc_randomized.py#L100-L109'},
            'qualification': 'Fixture only; no engine result or full WCC qualification is claimed.'}


def build(options: Options) -> ProfileReceipt | None:
    tree, files = helpers_at(options.helper_commit)
    require(identity(DELTA).sha256 == DELTA_SHA, 'retained A2-run04 delta changed')
    require(identity(MATRIX).sha256 == MATRIX_SHA, 'frozen matrix changed')
    data_source = Path(__file__).with_name('sem-b8-data.py')
    identity(data_source)
    require(git('bundle', 'list-heads', str(DELTA)).decode().split()[0] == CONTROLLER, 'delta does not name f3 controller')
    with DELTA.open('rb') as stream:
        header = []
        while line := stream.readline():
            if line == b'\n':
                break
            header.append(line.decode().strip())
    require(any(line.startswith('-' + HARNESS + ' ') for line in header), 'delta prerequisite is not frozen6ae')
    require(not BASE.exists() and not BASE.is_symlink(), 'B8-run01 already exists; no reuse or cleanup')
    if options.check_only:
        print(json.dumps({'outcome': 'checked_only', 'commit': options.helper_commit, 'tree': tree,
                          'helpers': {name: sha(data) for name, data in files.items()}, 'campaign': Campaign().model_dump(mode='json')}))
        return None
    BASE.mkdir()
    receipt = ProfileReceipt(started_utc=utc(), helper_repository_commit=options.helper_commit,
                             helper_repository_tree=tree, builder=identity(Path(__file__)), campaign=Campaign(),
                             helpers={name: Identity(bytes=len(data), sha256=sha(data)) for name, data in files.items()})
    save_receipt(BASE / 'payload-preparation.json', receipt)
    try:
        support, driver = BASE / 'support', BASE / 'controller-profile'
        support.mkdir()
        driver.mkdir()
        for name, data in files.items():
            write_bytes(support / name, data)
        shutil.copyfile(DELTA, support / 'delta.bundle')
        require(identity(support / 'delta.bundle').sha256 == DELTA_SHA, 'copied delta identity')
        manifest = SupportManifest(files_sha256={name: sha(data) for name, data in files.items()},
                                   helper_repository_commit=options.helper_commit, helper_repository_tree=tree)
        write_json(support / 'support-manifest.json', manifest)
        fixture_record = fixture(BASE / 'fixture')
        write_json(BASE / 'fixture/fixture-contract.json', fixture_record)
        prepare = InputConfig(vertices=ROOT + '/inputs/tiny-signed-highbit/vertices.parquet',
                              edges=ROOT + '/inputs/tiny-signed-highbit/edges.parquet',
                              output=ROOT + '/references/tiny-reference01',
                              vertices_sha256=identity(BASE / 'fixture/vertices.parquet').sha256,
                              edges_sha256=identity(BASE / 'fixture/edges.parquet').sha256)
        write_json(BASE / 'tiny-reference.json', prepare)
        write_json(BASE / 'campaign.json', Campaign())
        write_bytes(driver / 'run_shapes_host.py', files['run_shapes_host.py'])
        write_bytes(driver / 'run_pair_queue.py', files['run_pair_queue.py'])
        write_bytes(driver / 'sem-b8-profile.py', Path(__file__).read_bytes())
        write_bytes(driver / 'sem-b8-data.py', data_source.read_bytes())
        write_json(driver / 'provenance.json', {'helper_commit': options.helper_commit, 'helper_tree': tree,
                   'source_prefix': PREFIX, 'driver_sha256': sha(files['run_shapes_host.py']),
                   'queue_sha256': sha(files['run_pair_queue.py']), 'deployment_only_diff': [],
                   'copy_policy': 'Exact committed bytes, dynamic --campaign; no A2 literal replacement.'})
        payload_files = {'support/' + name: support / name for name in files}
        payload_files.update({'support/support-manifest.json': support / 'support-manifest.json',
                              'delta.bundle': support / 'delta.bundle', 'tiny-reference.json': BASE / 'tiny-reference.json'})
        payload_files.update({'inputs/tiny-signed-highbit/' + p.name: p for p in (BASE / 'fixture').iterdir()})
        payload_manifest = PayloadManifest(files_sha256={name: identity(p).sha256 for name, p in payload_files.items()},
                                           helper_repository_commit=options.helper_commit, helper_repository_tree=tree)
        write_json(support / 'payload-manifest.json', payload_manifest)
        payload_files['payload-manifest.json'] = support / 'payload-manifest.json'
        with tarfile.open(support / 'payload.tar', 'x', format=tarfile.PAX_FORMAT) as archive:
            for name, path in sorted(payload_files.items()):
                archive.add(path, arcname=name, recursive=False)
        with (support / 'payload.tar').open('rb') as stream:
            os.fsync(stream.fileno())
        require(identity(driver / 'run_shapes_host.py') == receipt.helpers['run_shapes_host.py'], 'driver bytes changed')
        receipt.artifacts = {str(p.relative_to(BASE)): identity(p) for p in BASE.rglob('*')
                             if p.is_file() and p.name != 'payload-preparation.json'}
        receipt.outcome = 'prepared'
    except BaseException as error:  # noqa: BLE001 - preserve a failed fresh profile without reuse or cleanup
        receipt.error, receipt.traceback = repr(error), traceback.format_exc()
        receipt.outcome = 'error'
    finally:
        receipt.finished_utc = utc()
        save_receipt(BASE / 'payload-preparation.json', receipt)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--helper-commit', required=True)
    parser.add_argument('--check-only', action='store_true')
    options = Options.model_validate(vars(parser.parse_args()))
    receipt = build(options)
    if receipt is not None:
        print(json.dumps({'outcome': receipt.outcome, 'base': str(BASE), 'helper_commit': options.helper_commit}))
        return 0 if receipt.outcome == 'prepared' else 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
