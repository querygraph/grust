"""Bounded identity, native client admission and portable retention primitives."""
from __future__ import annotations

import hashlib
import json
import os
import signal
import stat
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import TypeVar, cast

from native_models import (
    HARNESS,
    RUNTIME,
    SOURCE,
    Client,
    Config,
    Identity,
    Pin,
    Process,
    Record,
)
from pydantic import BaseModel, JsonValue, TypeAdapter

T = TypeVar("T", bound=BaseModel)
JSON_OBJECT = TypeAdapter(dict[str, JsonValue])
FROZEN = {"engine_pecan.py": "18cbb5e8d3483c599fb51fed26553f7f947400542df2c3eb29e54b90c22c487a",
          "output_oracle.py": "2d1dd6adeffc19457cb96ef378a39b53b8b1ce2f5150127fbda5e9666a1f483e"}
CLIENT_PROBE = r'''
import hashlib,importlib,importlib.metadata,json,os,platform,sys,sysconfig
from pathlib import Path
def pin(path):
 p=Path(path).resolve()
 with p.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha}
names=['pydantic','pydantic_core','pydantic_core._pydantic_core','numpy','numpy._core._multiarray_umath','pyarrow','pyarrow.lib','grpc','grpc._cython.cygrpc','pyspark.sql.connect.dataframe','pyspark.sql.connect.session']
modules={n:pin(importlib.import_module(n).__file__) for n in names}
assert platform.system()=='Darwin' and platform.machine()=='x86_64'
print(json.dumps({'python':sys.executable,'python_version':platform.python_version(),'base_prefix':sys.base_prefix,'versions':{d.metadata['Name'].lower().replace('_','-'):d.version for d in importlib.metadata.distributions()},'extensions':sorted(str(e) for e in importlib.metadata.entry_points(group='pysail.extensions')),'modules':modules,'executable':pin(sys.executable),'libpython':pin(Path(sysconfig.get_config_var('LIBDIR'))/sysconfig.get_config_var('LDLIBRARY')),'python_symlink':os.readlink(sys.executable) if Path(sys.executable).is_symlink() else None}))
'''
BOOT = "import json,runpy,sys; c=json.load(open(sys.argv[1])); sys.path[:0]=[sys.argv[2],c['repo']+'/examples/extensions/graph-algorithms/src',c['harness_repo']+'/examples/extensions/benchmarks']; sys.argv=[sys.argv[3],'--config',sys.argv[1]]; runpy.run_path(sys.argv[0],run_name='__main__')"


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def identity(path: Path) -> Identity:
    require(path.is_file() and not path.is_symlink(), f"unsafe/missing file: {path}")
    before = path.stat()
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_ino, after.st_size, after.st_mtime_ns), f"file changed while hashing: {path}")
    return Identity(bytes=after.st_size, sha256=digest)


def verify(pin: Pin) -> Identity:
    observed = identity(pin.path)
    require(observed == Identity(bytes=pin.bytes, sha256=pin.sha256), f"pin mismatch: {pin.path}")
    return observed


def write(path: Path, record: BaseModel | dict[str, JsonValue], *, fresh: bool = False) -> None:
    if fresh:
        require(not path.exists() and not path.is_symlink(), f"refusing existing file: {path}")
    text = record.model_dump_json(indent=2) if isinstance(record, BaseModel) else json.dumps(record, indent=2, allow_nan=False)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("x" if fresh else "w") as stream:
        stream.write(text + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def load(path: Path) -> dict[str, JsonValue]:
    require(path.stat().st_size <= 16 * 2**20, "JSON observation exceeds bound")
    return JSON_OBJECT.validate_json(path.read_bytes())


def command(argv: list[str], *, env: dict[str, str] | None = None, seconds: int = 30) -> str:
    child = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, start_new_session=True)
    try:
        stdout, stderr = child.communicate(timeout=seconds)
    except BaseException:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=5)
        raise
    require(child.returncode == 0, f"command failed: {argv[0]}: {stderr[:2000]}")
    require(len(stdout) <= 8 * 2**20, "command output exceeds bound")
    return stdout


def environment(library: Path) -> dict[str, str]:
    result = {k: v for k, v in os.environ.items() if not k.startswith(("SAIL_", "DYLD_"))
              and k not in {"PYTHONHOME", "PYTHONPATH", "RUST_LOG", "LD_LIBRARY_PATH"}}
    result.update(DYLD_LIBRARY_PATH=str(library), PYTHONDONTWRITEBYTECODE="1",
                  OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                  VECLIB_MAXIMUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
    return result


def client(python: Path, library: Path, lock: Pin) -> Client:
    verify(lock)
    raw = JSON_OBJECT.validate_json(command([str(python), "-I", "-B", "-c", CLIENT_PROBE], env=environment(library), seconds=90))
    raw.update(observed_utc=utc(), lock=cast(JsonValue, lock.model_dump(mode="json")))
    observed = Client.model_validate(raw)
    require(observed.python == python and not observed.extensions, "native client origin/extensions mismatch")
    expected = {"pyspark": "4.0.1", "pydantic": "2.11.10", "pydantic-core": "2.33.2",
                "pyarrow": "21.0.0", "numpy": "2.5.3", "protobuf": "7.36.2"}
    require(all(observed.versions.get(k) == v for k, v in expected.items()), "native client locked dependency mismatch")
    allowed = python.parent.parent.resolve()
    require(all(pin.path.is_relative_to(allowed) for pin in observed.modules.values()), "module outside fresh native client")
    verify(lock)
    return observed


def same_client(actual: Client, expected: Client) -> None:
    require(actual.model_dump(exclude={"observed_utc"}) == expected.model_dump(exclude={"observed_utc"}),
            "native client code/ABI/versions changed")


def source(config: Config) -> dict[str, str]:
    repo = config.engine.repo
    head = command(["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"]).strip()
    tree = command(["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD^{tree}"]).strip()
    dirty = command(["/usr/bin/git", "-C", str(repo), "status", "--porcelain=v1", "--untracked-files=all"])
    branch = subprocess.run(["/usr/bin/git", "-C", str(repo), "symbolic-ref", "-q", "HEAD"], capture_output=True, timeout=10, check=False)
    require(head == SOURCE and tree == config.source_tree and not dirty and branch.returncode == 1,
            "requires exact clean detached nativeb522 controller")
    runtime_tree = command(["/usr/bin/git", "-C", str(repo), "rev-parse", RUNTIME + "^{tree}"]).strip()
    parity = command(["/usr/bin/git", "-C", str(repo), "diff", "--exit-code", "--name-only", RUNTIME, SOURCE,
                      "--", "crates/", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml"])
    require(not parity, "compiled runtime source paths differ from b522 controller")
    admission = load(config.source_admission.path)
    require(admission.get("controller") == SOURCE and admission.get("tree") == config.source_tree
            and admission.get("compiled_runtime") == RUNTIME and admission.get("source") == str(repo),
            "root controller/runtime source admission mismatch")
    return {"commit": head, "tree": tree, "compiled_runtime": RUNTIME,
            "compiled_runtime_tree": runtime_tree, "compiled_runtime_paths_parity": "empty diff"}


def guard_files(config: Config) -> dict[str, Identity]:
    pins = [config.client, config.build, config.retirement, config.preservation,
            config.reference_receipt, config.support_manifest, config.source_admission,
            *config.originals.values(), *config.helpers.values()]
    records = {str(pin.path): verify(pin) for pin in pins}
    admitted_client = Client.model_validate(load(config.client.path))
    controller_lock = config.engine.repo / "examples/extensions/requirements.lock"
    observed_lock = identity(controller_lock)
    require(observed_lock == Identity(bytes=admitted_client.lock.bytes, sha256=admitted_client.lock.sha256),
            "new controller requirements differ from admitted native client lock")
    records[str(controller_lock)] = observed_lock
    build = load(config.build.path)
    steps = build.get("steps")
    require(isinstance(steps, list), "build steps absent")
    binaries = [s.get("binary") for s in cast(list[JsonValue], steps)
                if isinstance(s, dict) and s.get("name") == "sail"]
    require(len(binaries) == 1, "exactly one compiled Sail identity required")
    binary = Pin.model_validate(binaries[0])
    require(binary.path == config.engine.binary, "compiled binary path mismatch")
    records[str(binary.path)] = verify(binary)
    manifest = load(config.support_manifest.path)
    require(manifest.get("source") == SOURCE and manifest.get("harness") == HARNESS
            and manifest.get("compiled_runtime_source") == RUNTIME,
            "frozen support manifest source mismatch")
    support = config.support_manifest.path.parent / "support"
    for name, digest in FROZEN.items():
        observed = identity(support / name)
        require(observed.sha256 == digest, f"frozen helper changed: {name}")
        records[str(support / name)] = observed
    for section, root in (("source_pins", config.engine.repo), ("frozen_harness_files", config.engine.harness_repo / "examples/extensions/benchmarks")):
        raw = manifest.get(section)
        require(isinstance(raw, dict), "missing manifest source section")
        for name, value in cast(dict[str, JsonValue], raw).items():
            require(isinstance(value, dict), "source identity must be object")
            item = cast(dict[str, JsonValue], value)
            path = root / name
            observed = identity(path)
            require(observed.sha256 == item.get("sha256"), f"source/harness file changed: {path}")
            records[str(path)] = observed
    require(identity(Path(__file__)).sha256 == config.helpers["native_io.py"].sha256,
            "actual parent helper origin changed")
    require(config.membership.sha256 == "b07f8665c87f94286da7beb1ac5a9d13c4932fea31d8f1a382f9ecb1d3c0c8dc",
            "requires original full cit membership oracle")
    return records


def processes() -> list[tuple[Process, str]]:
    output: list[tuple[Process, str]] = []
    for line in command(["/bin/ps", "-axo", "pid=,ppid=,pgid=,rss=,command="], seconds=5).splitlines():
        fields = line.strip().split(None, 4)
        if len(fields) != 5:
            continue
        pid, ppid, pgid, rss = (int(x) for x in fields[:4])
        text = fields[4]
        output.append((Process(pid=pid, ppid=ppid, pgid=pgid, rss_bytes=rss * 1024,
                               command_sha256=hashlib.sha256(text.encode()).hexdigest()), text))
    return output


def matching_server(text: str, binary: Path) -> bool:
    return text.startswith(str(binary) + " spark server --ip 127.0.0.1 --port ")


def group_absent(pgid: int, table: list[tuple[Process, str]]) -> bool:
    return all(row.pgid != pgid for row, _ in table)


def inventory(root: Path) -> dict[str, Identity]:
    require(root.is_dir() and not root.is_symlink(), "missing/unsafe child output")
    result: dict[str, Identity] = {}
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), "child output symlink refused")
        if path.is_file():
            result[str(path.relative_to(root))] = identity(path)
        else:
            require(path.is_dir(), "special child output refused")
    return result


def retain(root: Path, destination: Path) -> dict[str, Identity]:
    before = inventory(root)
    destination.mkdir(parents=True, exist_ok=False)
    for name, expected in before.items():
        source_path, target = root / name, destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with source_path.open("rb") as stream, target.open("xb") as output:
            while block := stream.read(8 * 2**20):
                output.write(block)
            output.flush()
            os.fsync(output.fileno())
        require(identity(target) == expected, f"retained bytes differ: {name}")
    require(inventory(root) == before and inventory(destination) == before, "complete child retention differs")
    return before


def close_group(pgid: int) -> None:
    if group_absent(pgid, processes()):
        return
    for signum, seconds in ((signal.SIGTERM, 10), (signal.SIGKILL, 5)):
        try:
            os.killpg(pgid, signum)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if group_absent(pgid, processes()):
                return
            time.sleep(0.05)
    raise RuntimeError("owned process group remains after cancellation")


class Owner(Record):
    pid: int
    config_sha256: str
    token: str


def acquire(paths: tuple[Path, ...], owner: Owner) -> None:
    require(len(set(paths)) == len(paths) and bool(paths), "distinct shared locks required")
    require(all(not p.exists() and not p.is_symlink() for p in paths), "shared gate/queue lock is occupied")
    for path in paths:
        path.mkdir()  # Exclusive creation; any failure retains earlier owned locks.
        write(path / "owner.json", owner, fresh=True)


def release(paths: tuple[Path, ...], owner: Owner) -> None:
    for path in paths:
        require(Owner.model_validate(load(path / "owner.json")) == owner, "lock owner changed")
        require({p.name for p in path.iterdir()} == {"owner.json"}, "unexpected lock member")
    for path in paths:
        (path / "owner.json").unlink()
        path.rmdir()


def require_regular_mode(path: Path) -> None:
    require(stat.S_ISREG(path.lstat().st_mode), "requires a regular file")
