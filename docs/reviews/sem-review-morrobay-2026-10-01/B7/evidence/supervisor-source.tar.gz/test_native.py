"""Bounded offline failures and closure/retention controls; no engine or payload jobs."""
from __future__ import annotations

import hashlib
import os
import signal
import tempfile
import unittest
from pathlib import Path
from typing import cast
from unittest.mock import Mock, patch

import native_io as io
import supervise_native as subject
from native_models import (
    HARNESS,
    RUNTIME,
    SOURCE,
    Client,
    Config,
    EngineConfig,
    Pin,
    Process,
    Receipt,
    Sampler,
)
from pydantic import JsonValue, ValidationError


def pin(path: str) -> Pin:
    return Pin(path=Path(path), bytes=3, sha256="a" * 64)


def config(snapshot: bool = True) -> Config:
    base = Path("/Volumes/Apo/graph-tests/results/sem-review-20261001")
    engine = EngineConfig(repo=base / "test-source", harness_repo=base / "test-harness",
                          output=Path("/Users/alexy/src/grust-benchmark-runs/B7-native-snapshot01/test-cell"),
                          vertices=Path("/tmp/vertices"), edges=Path("/tmp/edges"), binary=base / "test-sail",
                          snapshot_inputs=snapshot)
    return Config(output=base / "test-parent", retention=base / "test-retention", engine=engine,
                  python=base / "test-venv/bin/python", library_path=Path("/tmp/lib"),
                  client=pin("/tmp/client"), build=pin("/tmp/build"), retirement=pin("/tmp/retirement"),
                  preservation=pin("/tmp/preservation"), reference_receipt=pin("/tmp/reference"),
                  support_manifest=pin("/tmp/support-manifest.json"), membership=pin("/tmp/membership"),
                  originals={"vertices": pin("/tmp/vertices"), "edges": pin("/tmp/edges"),
                             "wcc_membership": pin("/tmp/membership")}, helpers={}, source_tree="b" * 40,
                  source_admission=pin("/tmp/source-admission"),
                  locks=(base / "gate.lock", base / "serial-queue.lock"))


def child(configured: Config) -> dict[str, JsonValue]:
    names = ["server_startup", "session_startup", "input_handles", "input_snapshot", "public_algorithm",
             "result_export", "result_close", "session_stop", "server_shutdown"]
    return {"outcome": "passed", "finished_utc": "fixture", "config": cast(JsonValue, configured.engine.model_dump(mode="json")),
            "declared_controller_pin": SOURCE, "declared_runtime_pin": RUNTIME, "declared_harness_pin": HARNESS,
            "cleanup_errors": [], "staging_payload_after_shutdown": [], "incomplete_rounds": [],
            "before": None, "after": None, "guest_steal_fraction": None,
            "result": {"algorithm": "wcc-randomized-contraction", "method": "randomized", "seed": 42, "converged": True},
            "output_projection": ["id", "component"], "pecan_snapshot_inputs": configured.engine.snapshot_inputs,
            "snapshots_in_engine_boundary": configured.engine.snapshot_inputs,
            "phases": [{"name": name, "status": "end"} for name in names], "driver_pid": 222,
            "origins": {"algorithms": str((configured.engine.repo / "examples/extensions/graph-algorithms/src/pyspark_pecan/algorithms.py").resolve()),
                        "runtime": str((configured.engine.harness_repo / "examples/extensions/benchmarks/runtime.py").resolve()),
                        "measurement": str((configured.engine.harness_repo / "examples/extensions/benchmarks/measurement.py").resolve()),
                        "python_executable": str(configured.python)}}


def sampler() -> Sampler:
    return Sampler(samples=4, execution_samples=3, owned_servers=[Process(pid=222, ppid=111,
                   pgid=222, rss_bytes=1000, command_sha256="c" * 64)])


class Controls(unittest.TestCase):
    def test_one_cell_raw_contract(self) -> None:
        cfg = config()
        self.assertEqual(subject.check_child(cfg, child(cfg), sampler()), 222)

    def test_wrong_actual_algorithm_rejected(self) -> None:
        cfg, raw = config(), child(config())
        cast(dict[str, JsonValue], raw["result"])["algorithm"] = "wcc"
        with self.assertRaisesRegex(ValueError, "actual WCC"):
            subject.check_child(cfg, raw, sampler())

    def test_child_config_relocation_mismatch(self) -> None:
        cfg, raw = config(), child(config())
        cast(dict[str, JsonValue], raw["config"])["vertices"] = "/tmp/other-vertices"
        with self.assertRaisesRegex(ValueError, "child config"):
            subject.check_child(cfg, raw, sampler())

    def test_import_origin_mismatch(self) -> None:
        cfg, raw = config(), child(config())
        cast(dict[str, JsonValue], raw["origins"])["runtime"] = "/tmp/other-runtime.py"
        with self.assertRaisesRegex(ValueError, "origin"):
            subject.check_child(cfg, raw, sampler())

    def test_failed_cleanup_retained(self) -> None:
        cfg, raw = config(), child(config())
        raw["cleanup_errors"] = [{"operation": "server_shutdown", "error": "fixture"}]
        with self.assertRaisesRegex(ValueError, "cleanup"):
            subject.check_child(cfg, raw, sampler())

    def test_staging_payload_refuses_pass(self) -> None:
        cfg, raw = config(), child(config())
        raw["staging_payload_after_shutdown"] = ["partial.parquet"]
        with self.assertRaisesRegex(ValueError, "cleanup"):
            subject.check_child(cfg, raw, sampler())

    def test_invented_profile_rejected(self) -> None:
        cfg, raw = config(), child(config())
        raw["wcc_profile"] = {}
        with self.assertRaisesRegex(ValueError, "profiler output"):
            subject.check_child(cfg, raw, sampler())

    def test_server_unobserved_refuses_pass(self) -> None:
        cfg = config()
        with self.assertRaisesRegex(ValueError, "ownership"):
            subject.check_child(cfg, child(cfg), Sampler(samples=2, execution_samples=1))

    def test_sampler_success(self) -> None:
        subject.sampler_passed(sampler())

    def test_sampler_error_alive_empty_and_zero_execution(self) -> None:
        for changes in ({"error": "fixture"}, {"thread_alive": True}, {"samples": 0}, {"execution_samples": 0}):
            with self.subTest(changes=changes), self.assertRaisesRegex(ValueError, "sampler"):
                subject.sampler_passed(sampler().model_copy(update=changes))

    def test_extra_component_count_action_rejected(self) -> None:
        cfg, raw = config(), child(config())
        cast(list[JsonValue], raw["phases"]).append({"name": "profile_component_count", "status": "end"})
        with self.assertRaisesRegex(ValueError, "coverage|component-count"):
            subject.check_child(cfg, raw, sampler())

    def test_invented_or_failed_phase_rejected(self) -> None:
        for phase in ({"name": "profile_aggregate", "status": "start"},
                      {"name": "public_algorithm", "status": "error"}):
            with self.subTest(phase=phase):
                cfg, raw = config(), child(config())
                cast(list[JsonValue], raw["phases"]).append(cast(JsonValue, phase))
                with self.assertRaisesRegex(ValueError, "unknown or failed phase"):
                    subject.check_child(cfg, raw, sampler())

    def test_both_requested_snapshot_variants(self) -> None:
        for flag in (True, False):
            with self.subTest(snapshot=flag):
                cfg = config(flag)
                self.assertEqual(subject.check_child(cfg, child(cfg), sampler()), 222)

    def test_snapshot_receipt_mismatch_rejected(self) -> None:
        for field in ("pecan_snapshot_inputs", "snapshots_in_engine_boundary"):
            with self.subTest(field=field):
                cfg, raw = config(False), child(config(False))
                raw[field] = True
                with self.assertRaisesRegex(ValueError, "snapshot"):
                    subject.check_child(cfg, raw, sampler())

    def test_snapshot_flag_requires_explicit_strict_bool(self) -> None:
        data = config().engine.model_dump(mode="json")
        for flag in ("false", "true", 0, 1, None):
            with self.subTest(flag=flag), self.assertRaises(ValidationError):
                EngineConfig.model_validate({**data, "snapshot_inputs": flag})
        del data["snapshot_inputs"]
        with self.assertRaises(ValidationError):
            EngineConfig.model_validate(data)

    def test_profiler_origin_rejected(self) -> None:
        cfg, raw = config(), child(config())
        cast(dict[str, JsonValue], raw["origins"])["profile_wcc"] = "/tmp/profile_wcc.py"
        with self.assertRaisesRegex(ValueError, "profiler import"):
            subject.check_child(cfg, raw, sampler())

    def test_controller_runtime_separate_source_contract(self) -> None:
        cfg = config()
        admitted = {"controller": SOURCE, "tree": cfg.source_tree,
                    "compiled_runtime": RUNTIME, "source": str(cfg.engine.repo)}
        with (patch.object(io, "command", side_effect=[SOURCE, cfg.source_tree, "", "c" * 40, ""]) as commands,
              patch("native_io.subprocess.run", return_value=Mock(returncode=1)),
              patch.object(io, "load", return_value=admitted)):
            actual = io.source(cfg)
        self.assertEqual(actual["commit"], SOURCE)
        self.assertEqual(actual["compiled_runtime"], RUNTIME)
        self.assertEqual(actual["compiled_runtime_tree"], "c" * 40)
        self.assertEqual(commands.call_args_list[-1].args[0][-5:],
                         ["--", "crates/", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml"])

    def test_controller_runtime_code_difference_rejected(self) -> None:
        cfg = config()
        with (patch.object(io, "command", side_effect=[SOURCE, cfg.source_tree, "", "c" * 40, "crates/changed.rs\n"]),
              patch("native_io.subprocess.run", return_value=Mock(returncode=1)),
              self.assertRaisesRegex(ValueError, "runtime source paths")):
            io.source(cfg)

    def test_wrong_runtime_source_admission_rejected(self) -> None:
        cfg = config()
        admitted = {"controller": SOURCE, "tree": cfg.source_tree,
                    "compiled_runtime": SOURCE, "source": str(cfg.engine.repo)}
        with (patch.object(io, "command", side_effect=[SOURCE, cfg.source_tree, "", "c" * 40, ""]),
              patch("native_io.subprocess.run", return_value=Mock(returncode=1)),
              patch.object(io, "load", return_value=admitted),
              self.assertRaisesRegex(ValueError, "source admission")):
            io.source(cfg)

    def test_group_absence_uses_actual_table(self) -> None:
        record = sampler().owned_servers[0]
        self.assertFalse(io.group_absent(222, [(record, "owned")]))
        self.assertTrue(io.group_absent(111, [(record, "owned")]))

    def test_exact_server_command_scope(self) -> None:
        binary = Path("/tmp/native/sail")
        self.assertTrue(io.matching_server("/tmp/native/sail spark server --ip 127.0.0.1 --port 123", binary))
        self.assertFalse(io.matching_server("/tmp/native/sail-other spark server --ip 127.0.0.1 --port 123", binary))

    def test_native_namespace_and_actual_mutex_required(self) -> None:
        data = config().model_dump(mode="json")
        data["locks"] = ["/tmp/other-gate"]
        with self.assertRaises(ValidationError):
            Config.model_validate(data)
        data = config().model_dump(mode="json")
        data["engine"]["output"] = "/Volumes/Apo/not-native-SSD"
        with self.assertRaises(ValidationError):
            Config.model_validate(data)

    def test_existing_mutex_never_removed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first, second = root / "gate", root / "queue"
            second.mkdir()
            owner = io.Owner(pid=1, config_sha256="x", token="y")
            with self.assertRaisesRegex(ValueError, "occupied"):
                io.acquire((first, second), owner)
            self.assertTrue(second.exists())
            self.assertFalse(first.exists())

    def test_owned_release_refuses_changed_owner(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            lock = Path(temporary) / "gate"
            owner = io.Owner(pid=1, config_sha256="x", token="y")
            io.acquire((lock,), owner)
            changed = owner.model_copy(update={"token": "other"})
            io.write(lock / "owner.json", changed)
            with self.assertRaisesRegex(ValueError, "owner changed"):
                io.release((lock,), owner)
            self.assertTrue(lock.exists())

    def test_complete_retention_binds_nested_raw_files(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            (source / "result").mkdir(parents=True)
            (source / "result/part.parquet").write_bytes(b"fixture")
            (source / "receipt.json").write_bytes(b"{}")
            destination = root / "retained"
            actual = io.retain(source, destination)
            self.assertEqual(set(actual), {"result/part.parquet", "receipt.json"})
            self.assertEqual(actual, io.inventory(destination))
            self.assertEqual(actual["result/part.parquet"].sha256, hashlib.sha256(b"fixture").hexdigest())

    def test_result_symlink_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            (source / "link").symlink_to(root / "outside")
            with self.assertRaisesRegex(ValueError, "symlink"):
                io.retain(source, root / "retained")

    def test_admission_subprocess_killed_and_waited_on_timeout(self) -> None:
        fake = Mock()
        fake.pid = 987
        fake.communicate.side_effect = subprocess_timeout = TimeoutError("fixture")
        with (patch("native_io.subprocess.Popen", return_value=fake),
              patch("native_io.os.killpg") as killed,
              self.assertRaisesRegex(TimeoutError, "fixture")):
            io.command(["/tmp/probe"])
        self.assertIs(fake.communicate.side_effect, subprocess_timeout)
        killed.assert_called_once_with(987, signal.SIGKILL)
        fake.wait.assert_called_once_with(timeout=5)

    def test_environment_drops_ambient_native_controls(self) -> None:
        with patch.dict(os.environ, {"SAIL_MODE": "process-cluster", "PYTHONPATH": "foreign", "RUST_LOG": "trace", "DYLD_INSERT_LIBRARIES": "foreign"}):
            result = io.environment(Path("/tmp/lib"))
        self.assertNotIn("SAIL_MODE", result)
        self.assertNotIn("PYTHONPATH", result)
        self.assertNotIn("RUST_LOG", result)
        self.assertNotIn("DYLD_INSERT_LIBRARIES", result)
        self.assertEqual(result["DYLD_LIBRARY_PATH"], "/tmp/lib")

    def test_client_code_change_is_fatal(self) -> None:
        original = Client(observed_utc="fixture", python=Path("/tmp/python"), python_version="3.12.6",
                          base_prefix=Path("/tmp/base"), versions={}, extensions=[], modules={},
                          executable=pin("/tmp/python"), libpython=pin("/tmp/libpython"),
                          python_symlink=None, lock=pin("/tmp/lock"))
        changed = original.model_copy(update={"executable": pin("/tmp/different-python")})
        with self.assertRaisesRegex(ValueError, "code/ABI"):
            io.same_client(changed, original)
        io.same_client(original.model_copy(update={"observed_utc": "later"}), original)

    def test_forced_final_cleanup_cannot_qualify(self) -> None:
        receipt = Receipt(config=config(), started_utc="fixture", outcome="passed_diagnostic")
        with patch.object(io, "close_group") as close:
            subject.cancel_owned(receipt, 222, "server")
        close.assert_called_once_with(222)
        self.assertEqual(receipt.outcome, "error")
        self.assertIn("child cleanup cannot qualify", receipt.errors[0])

    def test_cleanup_failure_preserves_original_engine_error(self) -> None:
        receipt = Receipt(config=config(), started_utc="fixture", outcome="error", errors=["original engine failure"])
        with patch.object(io, "close_group", side_effect=RuntimeError("closure fixture")), self.assertRaisesRegex(RuntimeError, "closure fixture"):
            subject.cancel_owned(receipt, 222, "server")
        self.assertEqual(receipt.errors[0], "original engine failure")
        self.assertEqual(receipt.outcome, "error")


if __name__ == "__main__":
    unittest.main()
