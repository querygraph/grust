"""Typed native B7 snapshot contrast; configured software pools are not OS limits."""
from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, JsonValue, model_validator

SOURCE = "b522bf3a9c38d3861a114bf672abe7f7d6c7c491"
RUNTIME = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
HARNESS = "6ae2e43a903c2cee02da170465c922c72b76198e"
ROWS = 3_774_768
MAXIMUM = 6_009_554


class Record(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Identity(Record):
    bytes: int = Field(ge=0)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class Pin(Identity):
    path: Path

    @model_validator(mode="after")
    def absolute(self) -> Pin:
        if not self.path.is_absolute():
            raise ValueError("pin path must be absolute")
        return self


class Client(Record):
    schema_version: Literal[1] = 1
    observed_utc: str
    execution_class: Literal["native-macOS-x86_64"] = "native-macOS-x86_64"
    python: Path
    python_version: Literal["3.12.6"]
    base_prefix: Path
    versions: dict[str, str]
    extensions: list[str]
    modules: dict[str, Pin]
    executable: Pin
    libpython: Pin
    python_symlink: str | None
    lock: Pin
    scope: str = "selected imported Python/native ABI origins, actual distribution versions and lockfile identity; root UV sync evidence is distinct; no full distribution archive"


class EngineConfig(Record):
    repo: Path
    harness_repo: Path
    output: Path
    vertices: Path
    edges: Path
    binary: Path
    mode: Literal["local"] = "local"
    algorithm: Literal["wcc-randomized"] = "wcc-randomized"
    source: Literal[5795784] = 5795784
    partitions: Literal[16] = 16
    pool_bytes: Literal[32212254720] = 32212254720
    native_quota: Literal[268435456] = 268435456
    snapshot_inputs: bool = Field(strict=True)


class Config(Record):
    schema_version: Literal[1] = 1
    output: Path  # Fresh parent evidence directory on Apo.
    retention: Path  # Fresh complete child-copy directory on Apo.
    engine: EngineConfig  # Fresh child output on the native SSD.
    python: Path
    library_path: Path
    client: Pin
    build: Pin
    retirement: Pin
    preservation: Pin
    reference_receipt: Pin
    support_manifest: Pin
    membership: Pin
    originals: dict[Literal["vertices", "edges", "wcc_membership"], Pin]
    helpers: dict[str, Pin]  # Exact local parent helper bytes, including unchanged oracle.
    source_tree: str = Field(pattern=r"^[0-9a-f]{40}$")
    source_admission: Pin
    locks: tuple[Path, ...]
    engine_seconds: int = Field(default=1500, ge=1200, le=2400)
    oracle_seconds: int = Field(default=300, ge=30, le=1200)
    closure_seconds: int = Field(default=300, ge=30, le=600)
    sample_interval_seconds: float = Field(default=0.2, ge=0.05, le=1)
    require_execution_samples: Literal[True] = True
    minimum_ssd_free_bytes: int = Field(default=16 * 2**30, ge=2**30)
    minimum_apo_free_bytes: int = Field(default=16 * 2**30, ge=2**30)

    @model_validator(mode="after")
    def one_cell(self) -> Config:
        paths = (self.output, self.retention, self.engine.output, self.python, self.library_path,
                 self.engine.repo, self.engine.harness_repo, self.engine.binary,
                 self.engine.vertices, self.engine.edges, *self.locks)
        if any(not path.is_absolute() for path in paths):
            raise ValueError("all paths must be absolute")
        if set(self.originals) != {"vertices", "edges", "wcc_membership"}:
            raise ValueError("all three original identities required")
        if (self.originals["vertices"].path != self.engine.vertices
                or self.originals["edges"].path != self.engine.edges
                or self.originals["wcc_membership"] != self.membership):
            raise ValueError("explicit input relocation must bind exact child paths")
        if self.output == self.retention or self.engine.output == self.output:
            raise ValueError("parent evidence, SSD engine and retention must be distinct")
        if str(self.engine.output).startswith("/Volumes/"):
            raise ValueError("B7 child I/O must use the native internal SSD")
        lock_root = Path("/Volumes/Apo/graph-tests/results/sem-review-20261001")
        if set(self.locks) != {lock_root / "gate.lock", lock_root / "serial-queue.lock"}:
            raise ValueError("requires the actual shared graph gate and serial queue locks")
        if not str(self.output).startswith("/Volumes/Apo/") or not str(self.retention).startswith("/Volumes/Apo/"):
            raise ValueError("parent and retention must use Apo")
        return self


class Process(Record):
    pid: int
    ppid: int
    pgid: int
    rss_bytes: int
    command_sha256: str


class Sample(Record):
    observed_utc: str
    elapsed_seconds: float
    execution_active: bool
    processes: list[Process]
    rss_sum_bytes: int
    vm_stat: str | None = None
    swap_usage: str | None = None


class Sampler(Record):
    samples: int = 0
    execution_samples: int = 0
    max_sampled_rss_sum_bytes: int = 0
    error: str | None = None
    thread_alive: bool = False
    owned_servers: list[Process] = Field(default_factory=list)
    scope: str = "periodic ps RSS observations of owned processes; sum may include shared pages; sampled maximum is not true peak; host vm_stat/swap are separate raw observations"


class Receipt(Record):
    schema_version: Literal[1] = 1
    config: Config
    started_utc: str
    finished_utc: str | None = None
    outcome: Literal["checking", "passed_diagnostic", "error"] = "checking"
    execution_class: Literal["native-macOS-local"] = "native-macOS-local"
    timing_scope: str = "parent immediately-before-Popen to waited child exit, including startup/configured snapshot or bypass/public WCC/full Parquet/cleanup; oracle and retention occur afterward; one exploratory snapshot contrast, no A2 execution parity or exclusive kernel timer claimed"
    resource_scope: str = "software threads16/partitions16/greedy30GiB configured; no OS CPU/memory/swap cap, cgroups, PSS, steal, extension prepayment or dedicated-host comparison claimed"
    command: list[str] = Field(default_factory=list)
    environment: dict[str, str] = Field(default_factory=dict)
    child_pid: int | None = None
    server_pid: int | None = None
    returncode: int | None = None
    launch_to_exit_seconds: float | None = None
    child_group_absent: bool = False
    server_group_absent: bool = False
    matching_server_absent: bool = False
    sampler: Sampler = Field(default_factory=Sampler)
    before: dict[str, Identity] = Field(default_factory=dict)
    after: dict[str, Identity] = Field(default_factory=dict)
    source_before: dict[str, str] = Field(default_factory=dict)
    source_after: dict[str, str] = Field(default_factory=dict)
    client_before: Client | None = None
    client_after: Client | None = None
    child: dict[str, JsonValue] | None = None
    correctness: dict[str, JsonValue] | None = None
    retention_files: dict[str, Identity] = Field(default_factory=dict)
    retention_verified: bool = False
    locks_released: bool = False
    errors: list[str] = Field(default_factory=list)
