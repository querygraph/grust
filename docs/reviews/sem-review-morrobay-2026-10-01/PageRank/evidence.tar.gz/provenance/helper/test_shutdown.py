"""Bounded shutdown adapter controls from real source with fake processes/clock."""
from __future__ import annotations

import ast
import contextlib
import signal
import subprocess
import unittest
from collections.abc import Iterator
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Literal
from unittest.mock import Mock

from pydantic import BaseModel, ConfigDict


def compile_nodes(nodes: list[ast.stmt], namespace: dict[str, Any]) -> None:
    module = ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module="__future__",
        names=[ast.alias(name="annotations")], level=0), *nodes], type_ignores=[]))
    exec(compile(module, "<owned-shutdown-control>", "exec"), namespace)  # noqa: S102


def subject(exists: list[bool], times: list[float]) -> tuple[dict[str, Any], Mock, SimpleNamespace]:
    source = Path(__file__).parent/'support/shutdown.py'
    original = Mock()
    runtime = SimpleNamespace(group_exists=Mock(side_effect=exists), stop_group=original)
    kill = Mock()
    namespace: dict[str, Any] = {'__name__': __name__, 'BaseModel':BaseModel, 'ConfigDict':ConfigDict,
        'Literal':Literal,'runtime':runtime,'subprocess':subprocess,'Iterator':Iterator,
        'contextlib':contextlib,'os':SimpleNamespace(killpg=kill),'signal':signal,
        'time':SimpleNamespace(monotonic=Mock(side_effect=times),sleep=Mock())}
    tree=ast.parse(source.read_text())
    compile_nodes([n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))],namespace)
    return namespace,kill,runtime


class Controls(unittest.TestCase):
    def test_normal_sigint_no_escalation(self) -> None:
        ns,kill,_=subject([False],[0,0])
        process=Mock(pid=123)
        observations:list[Any]=[]
        ns['stop_group'](process,observations)
        kill.assert_called_once_with(123,signal.SIGINT)
        self.assertFalse(observations[0].sigkill_escalated)
        self.assertEqual(observations[0].outcome,'closed')
        process.poll.assert_called_once()

    def test_escalation_recorded_even_if_closed(self) -> None:
        ns,kill,_=subject([False],[0,16,16,16])
        observations:list[Any]=[]
        ns['stop_group'](Mock(pid=123),observations)
        self.assertEqual([c.args for c in kill.call_args_list],[(123,signal.SIGINT),(123,signal.SIGKILL)])
        self.assertTrue(observations[0].sigkill_escalated)
        self.assertEqual(observations[0].outcome,'closed')

    def test_group_still_live_retains_error(self) -> None:
        ns,_,_=subject([],[0,16,16,22])
        observations:list[Any]=[]
        with self.assertRaisesRegex(RuntimeError,'remains after SIGKILL'):
            ns['stop_group'](Mock(pid=123),observations)
        self.assertTrue(observations[0].sigkill_escalated)
        self.assertEqual(observations[0].outcome,'error')

    def test_already_absent_waited(self) -> None:
        ns,kill,_=subject([],[])
        kill.side_effect=ProcessLookupError()
        process=Mock(pid=123)
        observations:list[Any]=[]
        ns['stop_group'](process,observations)
        process.wait.assert_called_once_with()
        self.assertEqual(observations[0].sigint,'already_absent')

    def test_original_error_retained_and_hook_restored(self) -> None:
        ns,kill,runtime=subject([],[])
        original=runtime.stop_group
        error=RuntimeError('signal refused')
        kill.side_effect=error
        observations:list[Any]=[]
        with self.assertRaises(RuntimeError) as caught, ns['observe'](observations):
            runtime.stop_group(Mock(pid=123))
        self.assertIs(caught.exception,error)
        self.assertIs(runtime.stop_group,original)
        self.assertIn('signal refused',observations[0].error)

    def test_record_bound_refuses_unbounded_history(self) -> None:
        ns,kill,_=subject([],[])
        records:list[Any]=[ns['ShutdownRecord'](pid=100+i) for i in range(4)]
        with self.assertRaisesRegex(RuntimeError,'bound exceeded'):
            ns['stop_group'](Mock(pid=123),records)
        kill.assert_not_called()


if __name__=='__main__':
    unittest.main()
