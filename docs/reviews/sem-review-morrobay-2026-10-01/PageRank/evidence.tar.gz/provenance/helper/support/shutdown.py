"""Observe the unchanged frozen server group shutdown sequence; no engine jobs."""
from __future__ import annotations

import contextlib
import os
import signal
import subprocess
import time
from collections.abc import Iterator
from typing import Literal

import runtime
from pydantic import BaseModel, ConfigDict


class ShutdownRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    pid: int
    sigint: Literal["pending", "sent", "already_absent"] = "pending"
    sigkill_escalated: bool = False
    outcome: Literal["checking", "closed", "error"] = "checking"
    error: str | None = None


def stop_group(process: subprocess.Popen[bytes], observations: list[ShutdownRecord]) -> None:
    """Exact 6ae SIGINT/15s/SIGKILL/5s wait sequence with bounded evidence."""
    if len(observations) >= 4:
        raise RuntimeError("shutdown record bound exceeded")
    record = ShutdownRecord(pid=process.pid)
    observations.append(record)
    try:
        try:
            os.killpg(process.pid, signal.SIGINT)
            record.sigint = "sent"
        except ProcessLookupError:
            record.sigint = "already_absent"
            process.wait()
            record.outcome = "closed"
            return
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            process.poll()
            if not runtime.group_exists(process.pid):
                record.outcome = "closed"
                return
            time.sleep(0.05)
        record.sigkill_escalated = True
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if not runtime.group_exists(process.pid):
                record.outcome = "closed"
                return
            time.sleep(0.05)
        raise RuntimeError("Sail process group remains after SIGKILL; use a container init to reap descendants")
    except BaseException as error:
        record.outcome = "error"
        record.error = repr(error)
        raise


@contextlib.contextmanager
def observe(observations: list[ShutdownRecord]) -> Iterator[None]:
    """Replace only this child process's lookup, restoring it on all exits."""
    original = runtime.stop_group

    def observed(process: subprocess.Popen[bytes]) -> None:
        stop_group(process, observations)

    runtime.stop_group = observed
    try:
        yield
    finally:
        runtime.stop_group = original
