"""Native graphframes PageRank read/algorithm/full-export CLI envelope; no oracle."""
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType
from typing import Literal

import native_models
from native_models import EngineConfig, Record
from pydantic import Field

CONTROLLER = "0d1ef2ca3c3320a1ac9059f09ea4e0bcb7e4fb97"
RUNTIME = "b4da56dabe20bba8e29563e06acc5179b2113ce3"
HARNESS = "6ae2e43a903c2cee02da170465c922c72b76198e"


class Receipt(Record):
    config: EngineConfig
    started_utc: str
    finished_utc: str | None = None
    outcome: Literal["running", "passed", "error"] = "running"
    driver_pid: int | None = None
    inherited_library_path: str | None = None
    cleanup_errors: list[str] = Field(default_factory=list)
    returncode: int | None = None
    command: list[str]
    declared_controller_pin: str = CONTROLLER
    declared_runtime_pin: str = RUNTIME
    declared_harness_pin: str = HARNESS
    origins: dict[str, str]
    phases: list[dict[str, str | float]]
    error: str | None = None
    traceback: str | None = None
    forced_cleanup: bool = False
    execution_class: Literal["native-macOS-local"] = "native-macOS-local"
    phase_scope: str = "public_algorithm is the single native CLI invocation: setup/read/Pregel/normalization/full Parquet export; no exclusive kernel/export split"


def command(config: EngineConfig) -> list[str]:
    return [str(config.binary), "page-rank", "--vertices", str(config.vertices), "--edges", str(config.edges),
            "--output", (config.output / "result").as_uri(), "--format", "parquet", "--id-col-name", "id",
            "--src-col-name", "source", "--dst-col-name", "target", "--max-memory", "30G",
            "--num-workers", "16", "--checkpoint-dir", str(config.output / "work"),
            "--max-temp-file", "200G", "--tol", "0.01", "--reset-prob", "0.15", "--max-iter", "10"]


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def persist(path: Path, receipt: Receipt) -> None:
    temporary = path.with_suffix(".tmp")
    with temporary.open("w") as stream:
        stream.write(receipt.model_dump_json(indent=2) + "\n"); stream.flush(); os.fsync(stream.fileno())
    temporary.replace(path)


def interrupted(signum: int, _frame: FrameType | None) -> None:
    raise TimeoutError("native CLI deadline") if signum == signal.SIGALRM else InterruptedError(f"signal {signum}")


def execute(config: EngineConfig) -> int:
    if config.engine != "graphframes" or config.mode != "local" or sys.platform != "darwin":
        raise ValueError("graphframes benchmark requires local native macOS")
    config.output.mkdir(parents=True, exist_ok=False)
    receipt = Receipt(config=config, started_utc=utc(), command=command(config), phases=[],
                      inherited_library_path=os.environ.get("DYLD_LIBRARY_PATH"),
                      origins={"native_models":str(Path(native_models.__file__).resolve()), "python_executable":sys.executable})
    path = config.output / "engine-receipt.json"
    persist(path, receipt)
    process: subprocess.Popen[bytes] | None = None
    for signum in (signal.SIGALRM, signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, interrupted)
    try:
        signal.alarm(1200)
        began = time.perf_counter()
        receipt.phases.append({"name":"public_algorithm","status":"start","elapsed_seconds":0.0})
        persist(path, receipt)
        environment = {k:v for k,v in os.environ.items() if not k.startswith("GRAPHFRAMES_")}
        environment.update(TOKIO_WORKER_THREADS="16", RAYON_NUM_THREADS="16", RUST_LOG="graphframes_rs=warn")
        with (config.output / "native-cli.log").open("xb") as log:
            process = subprocess.Popen(receipt.command, cwd=config.output, env=environment, stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            receipt.driver_pid = process.pid
            persist(path, receipt)
            receipt.returncode = process.wait(timeout=1200)
        receipt.phases.append({"name":"public_algorithm","status":"end","duration_seconds":time.perf_counter()-began})
        if receipt.returncode != 0:
            raise RuntimeError("native graphframes CLI returned error")
        receipt.outcome = "passed"
    except BaseException as error:  # noqa: BLE001 -- preserve failed ID and owned CLI cleanup.
        receipt.outcome = "error"; receipt.error = repr(error); receipt.traceback = traceback.format_exc()
    finally:
        signal.alarm(30)
        try:
            if process is not None and process.poll() is None:
                receipt.outcome = "error"
                receipt.forced_cleanup = True
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                receipt.returncode = process.wait(timeout=5)
        except BaseException as error:  # noqa: BLE001 -- cleanup error cannot replace original failure.
            receipt.outcome = "error"
            receipt.cleanup_errors.append(repr(error))
        finally:
            receipt.finished_utc = utc()
            persist(path, receipt)
            signal.alarm(0)
    print(json.dumps({"outcome":receipt.outcome,"receipt":str(path)}), flush=True)
    return 0 if receipt.outcome == "passed" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()
    return execute(EngineConfig.model_validate_json(args.config.read_bytes()))


if __name__ == "__main__":
    raise SystemExit(main())
