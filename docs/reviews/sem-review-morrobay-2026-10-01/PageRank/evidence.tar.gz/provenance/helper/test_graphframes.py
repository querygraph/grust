"""Native CLI lifecycle controls with fake child; no binary execution."""
from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType
from unittest.mock import Mock, patch

import native_io as io
from native_models import EngineConfig


def module() -> ModuleType:
    path=Path(__file__).parent/'support/engine_graphframes.py'
    spec=importlib.util.spec_from_file_location('owned_gf_child',path)
    if spec is None or spec.loader is None:
        raise RuntimeError('no owned child loader')
    loaded=importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = loaded
    spec.loader.exec_module(loaded)
    return loaded


def config(output: Path) -> EngineConfig:
    return EngineConfig(repo=Path('/controller'),harness_repo=Path('/harness'),output=output,
        vertices=Path('/inputs/v.parquet'),edges=Path('/inputs/e.parquet'),binary=Path('/gf'),
        mode='local',engine='graphframes',pool_bytes=30*2**30,snapshot_inputs=False)


class Controls(unittest.TestCase):
    def test_natural_wait_and_full_cli_contract(self) -> None:
        child=module()
        process=Mock(pid=444)
        process.wait.return_value=0
        process.poll.return_value=0
        with tempfile.TemporaryDirectory() as temporary:
            cfg=config(Path(temporary)/'fresh')
            with (patch.object(child.sys,'platform','darwin'),patch.object(child.subprocess,'Popen',return_value=process),
                  patch.object(child.signal,'signal'),patch.object(child.signal,'alarm'),patch('builtins.print')):
                self.assertEqual(child.execute(cfg),0)
            receipt=io.load(cfg.output/'engine-receipt.json')
            self.assertEqual(receipt['outcome'],'passed')
            self.assertFalse(receipt['forced_cleanup'])
            self.assertEqual(receipt['command'],child.command(cfg))
            process.wait.assert_called_once_with(timeout=1200)
            self.assertEqual(child.command(cfg)[child.command(cfg).index('--max-memory')+1],'30G')

    def test_timeout_is_error_even_if_forced_wait_succeeds(self) -> None:
        child=module()
        process=Mock(pid=444)
        process.wait.side_effect=[TimeoutError('engine timeout'),0]
        process.poll.return_value=None
        with tempfile.TemporaryDirectory() as temporary:
            cfg=config(Path(temporary)/'fresh')
            with (patch.object(child.sys,'platform','darwin'),patch.object(child.subprocess,'Popen',return_value=process),
                  patch.object(child.signal,'signal'),patch.object(child.signal,'alarm'),
                  patch.object(child.os,'killpg') as killed,patch('builtins.print')):
                self.assertEqual(child.execute(cfg),1)
            receipt=io.load(cfg.output/'engine-receipt.json')
            self.assertEqual(receipt['outcome'],'error')
            self.assertTrue(receipt['forced_cleanup'])
            self.assertIn('engine timeout',str(receipt['error']))
            killed.assert_called_once()

    def test_cleanup_error_preserves_engine_error(self) -> None:
        child=module()
        process=Mock(pid=444)
        process.wait.side_effect=[TimeoutError('original'),TimeoutError('cleanup wait')]
        process.poll.return_value=None
        with tempfile.TemporaryDirectory() as temporary:
            cfg=config(Path(temporary)/'fresh')
            with (patch.object(child.sys,'platform','darwin'),patch.object(child.subprocess,'Popen',return_value=process),
                  patch.object(child.signal,'signal'),patch.object(child.signal,'alarm'),
                  patch.object(child.os,'killpg'),patch('builtins.print')):
                self.assertEqual(child.execute(cfg),1)
            receipt=io.load(cfg.output/'engine-receipt.json')
            self.assertIn('original',str(receipt['error']))
            self.assertIn('cleanup wait',str(receipt['cleanup_errors']))
            self.assertIsNotNone(receipt['finished_utc'])


if __name__=='__main__':
    unittest.main()
