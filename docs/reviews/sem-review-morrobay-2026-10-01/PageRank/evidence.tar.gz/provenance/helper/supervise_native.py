"""One native PageRank cell, then full physical comparison after waited exit."""
from __future__ import annotations

import argparse
import os
import platform
import shutil
import signal
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from types import FrameType
from typing import cast

import native_io as io
import native_models
import pagerank_io
import pagerank_models
import pagerank_oracle
from native_models import (
    GF_SOURCE,
    HARNESS,
    MAXIMUM,
    ROWS,
    RUNTIME,
    SOURCE,
    Client,
    Config,
    EngineConfig,
    EngineExitedProof,
    ExitObservation,
    Identity,
    Pin,
    Receipt,
    ResultDataset,
    Sample,
    Sampler,
)
from pydantic import JsonValue


def object_field(raw: dict[str, JsonValue], name: str) -> dict[str, JsonValue]:
    value = raw.get(name)
    io.require(isinstance(value, dict), f"missing object: {name}")
    return cast(dict[str, JsonValue], value)


def admitted(config: Config) -> None:
    retired, build = io.load(config.retirement.path), io.load(config.build.path)
    io.require(retired.get("outcome") == "graph_VM_deleted_data_preserved" and bool(retired.get("finished_utc")),
               "VM retirement/full portable preservation must finish before timing")
    io.require(build.get("outcome") == "passed_optimized_native_binaries" and bool(build.get("finished_utc")),
               "native optimized build must finish before timing")
    io.require(build.get("machine") == "x86_64", "build architecture mismatch")
    steps = build.get("steps")
    io.require(isinstance(steps, list), "missing native build steps")
    selected = "sail" if config.engine.engine == "pecan" else "graphframes"
    sails = [s for s in cast(list[JsonValue], steps) if isinstance(s, dict) and s.get("name") == selected]
    io.require(len(sails) == 1, "exactly one selected native build step required")
    step = sails[0]
    binary = Pin.model_validate(object_field(step, "binary"))
    io.require(binary.path == config.engine.binary, "wrong compiled native path")
    io.verify(binary)
    source_before = object_field(object_field(build, "sources_before"), selected)
    parity = io.source(config)
    expected_commit = RUNTIME if config.engine.engine == "pecan" else GF_SOURCE
    expected_tree = parity["compiled_runtime_tree"] if config.engine.engine == "pecan" else parity["graphframes_tree"]
    io.require(source_before.get("commit") == expected_commit
               and source_before.get("tree") == expected_tree,
               "build source/tree mismatch")
    io.require(step.get("returncode") == 0 and object_field(step, "probe").get("returncode") == 0
               and object_field(step, "source_after") == source_before, "native build/probe/source closure failed")
    release = object_field(build, "release_environment")
    required = {"CARGO_PROFILE_RELEASE_OPT_LEVEL": "3", "CARGO_PROFILE_RELEASE_LTO": "true",
                "CARGO_PROFILE_RELEASE_CODEGEN_UNITS": "1", "CARGO_PROFILE_RELEASE_DEBUG": "0",
                "CARGO_PROFILE_RELEASE_STRIP": "true", "CARGO_INCREMENTAL": "0"}
    io.require(all(release.get(k) == v for k, v in required.items()), "optimized release profile mismatch")
    io.require("Mach-O 64-bit executable x86_64" in io.command(["/usr/bin/file", str(binary.path)]),
               "current selected binary is not native x86_64 Mach-O")
    io.command([str(binary.path), "--version"], env=io.environment(config.library_path))
    prior = io.load(config.reference_receipt.path)
    validation = object_field(prior, "validation")
    io.require(prior.get("outcome") == "passed" and validation.get("vertex_rows") == ROWS
               and validation.get("maximum_id") == MAXIMUM and validation.get("edge_rows") == 16_518_947,
               "requires exact retained A2 cit admission")
    originals = object_field(prior, "originals_before")
    io.require(originals == object_field(prior, "originals_after"), "original admission lacks closure")
    for name, pin in config.originals.items():
        io.require(originals.get(name) == Identity(bytes=pin.bytes, sha256=pin.sha256).model_dump(),
                   "native input bytes differ from original A2")
    preserved = io.load(config.preservation.path)
    io.require(preserved.get("outcome") == "passed_same_retained_A2_reference_source_bytes"
               and preserved.get("source_receipt_sha256") == config.reference_receipt.sha256,
               "native original preservation receipt mismatch")
    for module_name, module in (("native_models.py", native_models), ("native_io.py", io)):
        io.require(Path(cast(str, module.__file__)).resolve() == config.helpers[module_name].path.resolve(),
                   f"actual helper import origin mismatch: {module_name}")
    io.require(Path(__file__).resolve() == config.helpers["supervise_native.py"].path.resolve(),
               "supervisor origin mismatch")
    for oracle_name, module in (("pagerank_models.py", pagerank_models), ("pagerank_io.py", pagerank_io),
                         ("pagerank_oracle.py", pagerank_oracle)):
        io.require(Path(cast(str, module.__file__)).resolve() == config.oracle_helpers[oracle_name].path.resolve(),
                   "actual oracle import origin mismatch: " + oracle_name)
        io.verify(config.oracle_helpers[oracle_name])


def graphframes_command(config: EngineConfig) -> list[str]:
    return [str(config.binary), "page-rank", "--vertices", str(config.vertices), "--edges", str(config.edges),
            "--output", (config.output / "result").as_uri(), "--format", "parquet", "--id-col-name", "id",
            "--src-col-name", "source", "--dst-col-name", "target", "--max-memory", "30G",
            "--num-workers", "16", "--checkpoint-dir", str(config.output / "work"),
            "--max-temp-file", "200G", "--tol", "0.01", "--reset-prob", "0.15", "--max-iter", "10"]


def check_child(config: Config, raw: dict[str, JsonValue], sampler: Sampler) -> int:
    io.require(raw.get("outcome") == "passed" and bool(raw.get("finished_utc")), "child did not pass")
    io.require(EngineConfig.model_validate(raw.get("config")) == config.engine, "child config mismatch")
    expected_runtime = RUNTIME if config.engine.engine == "pecan" else GF_SOURCE
    io.require(raw.get("declared_controller_pin") == SOURCE and raw.get("declared_runtime_pin") == expected_runtime
               and raw.get("declared_harness_pin") == HARNESS, "child source declarations mismatch")
    phases = raw.get("phases")
    io.require(isinstance(phases, list), "missing child phases")
    origins = object_field(raw, "origins")
    if config.engine.engine == "pecan":
        io.require(raw.get("cleanup_errors") == [] and raw.get("staging_payload_after_shutdown") == []
                   and raw.get("incomplete_rounds") == [], "child cleanup/round closure failed")
        io.require(raw.get("before") is None and raw.get("after") is None and raw.get("guest_steal_fraction") is None,
                   "native child must not invent Linux observations")
        shutdown = raw.get("shutdown")
        io.require(isinstance(shutdown, list) and bool(shutdown) and all(isinstance(r, dict)
                   and r.get("pid") == raw.get("driver_pid") and r.get("outcome") == "closed"
                   and r.get("sigkill_escalated") is False and r.get("error") is None
                   and r.get("sigint") in {"sent", "already_absent"} for r in shutdown),
                   "server shutdown escalated, failed, or lacks evidence")
        result = object_field(raw, "result")
        io.require(result.get("algorithm") == "pagerank-pregel-delta" and result.get("method") == "pregel_delta"
                   and result.get("seed") is None and result.get("iterations") == 10 and result.get("converged") is None,
                   "actual fixed-step PageRank result contract mismatch")
        io.require(raw.get("output_projection") == ["id", "pagerank"], "raw export projection changed")
        io.require(raw.get("pecan_snapshot_inputs") is False and raw.get("snapshots_in_engine_boundary") is False,
                   "matched PageRank requires snapshot bypass")
        required = {"server_startup", "session_startup", "input_handles", "input_snapshot", "public_algorithm",
                    "result_export", "result_close", "session_stop", "server_shutdown"}
        expected = {"algorithms": config.engine.repo / "examples/extensions/graph-algorithms/src/pyspark_pecan/algorithms.py",
                    "runtime": config.engine.harness_repo / "examples/extensions/benchmarks/runtime.py",
                    "measurement": config.engine.harness_repo / "examples/extensions/benchmarks/measurement.py",
                    "shutdown": config.support_manifest.path.parent / "support/shutdown.py",
                    "python_executable": config.python}
        io.require(set(origins) == set(expected) | {"python_version"}, "unknown child import origin")
        io.require(isinstance(origins.get("python_version"), str) and str(origins["python_version"]).startswith("3.12.6 "), "child Python version changed")
        io.require(raw.get("worker_count") == (2 if config.engine.mode == "process-cluster" else 0)
                   and raw.get("threads_per_process") == 16 and raw.get("worker_task_slots") == 64,
                   "declared runtime topology changed")
        if config.engine.mode == "process-cluster":
            io.require(sampler.max_simultaneous_workers == 2 and len(sampler.owned_workers) == 2,
                       "two owned process-cluster workers were not actually observed")
        else:
            io.require(not sampler.owned_workers, "unexpected local workers")
    else:
        io.require(raw.get("returncode") == 0 and raw.get("forced_cleanup") is False
                   and raw.get("error") is None and raw.get("traceback") is None and raw.get("cleanup_errors") == [], "native CLI did not finish naturally")
        io.require(raw.get("command") == graphframes_command(config.engine), "actual graphframes command changed")
        required = {"public_algorithm"}
        expected = {"native_models": config.helpers["native_models.py"].path, "python_executable": config.python}
        io.require(set(origins) == set(expected), "unknown graphframes child origin")
        io.require(not sampler.owned_workers, "graphframes must remain one local CLI process")
    io.require("wcc_profile" not in raw and "profile_wcc" not in origins, "unexpected profiler metadata")
    io.require(all(origins.get(k) == str(v.resolve() if k != "python_executable" else v) for k, v in expected.items()),
               "child import/python origin mismatch")
    ended = {p.get("name") for p in cast(list[JsonValue], phases)
             if isinstance(p, dict) and p.get("status") == "end"}
    io.require(ended == required, "full engine phase/cleanup coverage missing")
    io.require(all(isinstance(p, dict) and p.get("name") in required and p.get("status") in {"start", "end"}
                   for p in cast(list[JsonValue], phases)), "unknown or failed child phase")
    io.require(raw.get("inherited_library_path") == str(config.library_path), "child native library path differs")
    pid = raw.get("driver_pid")
    io.require(isinstance(pid, int) and not isinstance(pid, bool) and pid > 1, "missing native runtime identity")
    server_pid = cast(int, pid)
    io.require({p.pid for p in sampler.owned_servers} == {server_pid}, "runtime ownership not independently observed")
    return server_pid


def workers_absent(sampler: Sampler, table: list[tuple[native_models.Process, str]]) -> bool:
    return all(all(row.pid != known.pid and row.pgid != known.pgid for row, _ in table)
               for known in sampler.owned_workers)


def exited_dataset(config: Config, receipt: Receipt, child_config: Path) -> ResultDataset:
    io.require(receipt.child_pid is not None and receipt.returncode == 0 and receipt.child_group_absent
               and receipt.server_group_absent and receipt.worker_processes_absent,
               "pre-oracle proof needs natural waited exit and all owned groups absent")
    files = io.inventory(config.engine.output / "result")
    io.require(bool(files), "raw result inventory is empty")
    child_receipt = config.engine.output / "engine-receipt.json"
    proof = EngineExitedProof(engine=config.engine.engine, run_id=config.run_id, child_pid=cast(int, receipt.child_pid),
                              returncode=0, wait_completed=True, child_group_absent=True, server_group_absent=True,
                              raw_directory=config.engine.output / "result", raw_files=files,
                              child_receipt=Pin(path=child_receipt, **io.identity(child_receipt).model_dump()),
                              configuration=Pin(path=child_config, **io.identity(child_config).model_dump()),
                              observed_utc=io.utc())
    path = config.output / "engine-exited.json"
    io.write(path, proof, fresh=True)
    receipt.engine_exited = Pin(path=path, **io.identity(path).model_dump())
    return ResultDataset(engine=config.engine.engine, directory=proof.raw_directory, files=files,
                         exit=ExitObservation(engine=config.engine.engine, run_id=config.run_id,
                                              child_pid=cast(int, receipt.child_pid), returncode=0, wait_completed=True,
                                              producer_receipt=receipt.engine_exited))


def compare_output(config: Config, candidate: ResultDataset) -> pagerank_models.OracleReceipt:
    oracle_config = pagerank_models.OracleConfig.model_validate_json(io.JSON_OBJECT.dump_json({
        "dataset": "cit-Patents", "expected_rows": ROWS,
        "input_vertices": config.originals["vertices"].model_dump(mode="json"),
        "graphframes_reference": (config.reference or candidate).model_dump(mode="json"),
        "candidate": candidate.model_dump(mode="json"), "output": str(config.output / "oracle"),
        "reference_preparation_only": config.reference_preparation_only,
        "limits": {"timeout_seconds": float(config.oracle_seconds), "closure_timeout_seconds": float(config.closure_seconds)}}))
    path = config.output / "oracle-config.json"
    io.write(path, oracle_config, fresh=True)
    pin = pagerank_models.FilePin(path=path, **io.identity(path).model_dump())
    correctness = pagerank_oracle.verify(oracle_config, configuration=pin)
    wanted = "reference_prepared" if config.reference_preparation_only else "passed_full_physical_pagerank"
    io.require(correctness.outcome == wanted and correctness.own_identity_closure_passed
               and correctness.full_physical_domain_passed and correctness.expected_domain_rows == ROWS
               and correctness.reference_rows == correctness.candidate_rows == correctness.unique_candidate_rows == ROWS,
               "full physical PageRank oracle did not pass")
    if config.reference_preparation_only:
        io.require(not correctness.full_numeric_comparison_passed and correctness.compared_rows == 0,
                   "reference preparation cannot qualify a numerical self-comparison")
    else:
        io.require(correctness.full_numeric_comparison_passed and correctness.compared_rows == ROWS
                   and correctness.numeric_mismatches == 0, "full numeric PageRank comparison failed")
    return correctness


@dataclass(slots=True)
class MemorySampler:
    config: Config
    child_pid: int
    began: float
    receipt: Sampler = field(default_factory=Sampler)
    stop: threading.Event = field(default_factory=threading.Event)
    thread: threading.Thread | None = None

    def start(self) -> None:
        self.thread = threading.Thread(target=self.run, name="pagerank-native-rss", daemon=True)
        self.thread.start()

    def run(self) -> None:
        host_due = 0.0
        path = self.config.output / "native-memory.jsonl"
        try:
            with path.open("x") as stream:
                while not self.stop.is_set():
                    table = io.processes()
                    for row, text in table:
                        if (row.ppid == self.child_pid and row.pgid == row.pid
                                and io.matching_server(text, self.config.engine.binary)
                                and row.pid not in {p.pid for p in self.receipt.owned_servers}):
                            self.receipt.owned_servers.append(row)
                    server_ids = {p.pid for p in self.receipt.owned_servers}
                    workers = [row for row, text in table if row.ppid in server_ids and row.pgid in server_ids
                               and io.matching_worker(text, self.config.engine.binary)]
                    for row in workers:
                        if row.pid not in {p.pid for p in self.receipt.owned_workers}:
                            self.receipt.owned_workers.append(row)
                    self.receipt.max_simultaneous_workers = max(self.receipt.max_simultaneous_workers, len(workers))
                    groups = {self.child_pid, *(p.pgid for p in self.receipt.owned_servers)}
                    observed = [row for row, _ in table if row.pgid in groups]
                    active = False
                    child_path = self.config.engine.output / "engine-receipt.json"
                    if child_path.is_file():
                        raw = io.load(child_path)
                        phases = raw.get("phases", [])
                        if isinstance(phases, list):
                            public = [p for p in phases if isinstance(p, dict) and p.get("name") == "public_algorithm"]
                            active = bool(public and isinstance(public[-1], dict) and public[-1].get("status") == "start")
                    active = active and any(p.pid in {s.pid for s in self.receipt.owned_servers} for p in observed)
                    now = time.monotonic()
                    vm, swap = None, None
                    if now >= host_due:
                        vm = io.command(["/usr/bin/vm_stat"], seconds=5)
                        swap = io.command(["/usr/sbin/sysctl", "vm.swapusage"], seconds=5)
                        host_due = now + 1
                    sample = Sample(observed_utc=io.utc(), elapsed_seconds=now - self.began,
                                 execution_active=active, processes=observed,
                                 rss_sum_bytes=sum(p.rss_bytes for p in observed), vm_stat=vm, swap_usage=swap)
                    stream.write(sample.model_dump_json() + "\n")
                    stream.flush()
                    os.fsync(stream.fileno())
                    self.receipt.samples += 1
                    self.receipt.execution_samples += int(active)
                    self.receipt.max_sampled_rss_sum_bytes = max(self.receipt.max_sampled_rss_sum_bytes, sample.rss_sum_bytes)
                    self.stop.wait(self.config.sample_interval_seconds)
        except BaseException as error:  # noqa: BLE001 -- observation failures remain fatal evidence.
            self.receipt.error = repr(error)

    def finish(self) -> Sampler:
        self.stop.set()
        if self.thread is not None:
            self.thread.join(timeout=12)
            self.receipt.thread_alive = self.thread.is_alive()
        return self.receipt


def interrupted(signum: int, _frame: FrameType | None) -> None:
    raise TimeoutError("parent deadline") if signum == signal.SIGALRM else InterruptedError(f"signal {signum}")


def sampler_passed(sampler: Sampler) -> None:
    io.require(not sampler.error and not sampler.thread_alive and sampler.samples > 0
               and sampler.execution_samples > 0, "native sampler failed or lacked actual execution coverage")


def cancel_owned(receipt: Receipt, pgid: int, scope: str) -> None:
    receipt.outcome = "error"
    receipt.errors.append(f"forced final cancellation of live owned {scope} group {pgid}; child cleanup cannot qualify")
    io.close_group(pgid)


def execute(config: Config, config_path: Path) -> int:
    io.require(platform.system() == "Darwin" and platform.machine() == "x86_64", "requires native macOS x86_64")
    io.require(not config.output.exists() and not config.retention.exists() and not config.engine.output.exists(),
               "fresh evidence/SSD/retention paths required")
    io.require(all(not p.is_symlink() for root in (config.output, config.retention, config.engine.output)
                   for p in (root, *root.parents)), "symlinked output ancestry refused")
    config.output.mkdir(parents=True, exist_ok=False)
    receipt = Receipt(config=config, started_utc=io.utc())
    path = config.output / "receipt.json"
    io.write(path, receipt)
    owner = io.Owner(pid=os.getpid(), config_sha256=io.identity(config_path).sha256, token=uuid.uuid4().hex)
    process: subprocess.Popen[bytes] | None = None
    sampler: MemorySampler | None = None
    acquired = False
    began: float | None = None
    try:
        io.acquire(config.locks, owner)
        acquired = True
        signal.alarm(config.engine_seconds + config.oracle_seconds + 2 * config.closure_seconds + 120)
        receipt.before = io.guard_files(config)
        receipt.source_before = io.source(config)
        admitted(config)
        expected = Client.model_validate(io.load(config.client.path))
        receipt.client_before = io.client(config.python, config.library_path, expected.lock)
        io.same_client(receipt.client_before, expected)
        config.engine.output.parent.mkdir(parents=True, exist_ok=True)
        io.require(shutil.disk_usage(config.engine.output.parent).free >= config.minimum_ssd_free_bytes
                   and shutil.disk_usage(config.output).free >= config.minimum_apo_free_bytes, "insufficient native storage")
        io.require(not any(io.matching_server(text, config.engine.binary) for _, text in io.processes()),
                   "same native Sail binary already has an active server")
        child_config = config.output / "child-config.json"
        io.write(child_config, config.engine, fresh=True)
        support = config.support_manifest.path.parent / "support"
        child_name = "engine_pecan.py" if config.engine.engine == "pecan" else "engine_graphframes.py"
        receipt.command = [str(config.python), "-I", "-B", "-c", io.BOOT, str(child_config),
                           str(support), str(support / child_name)]
        env = io.environment(config.library_path)
        receipt.environment = {k: env[k] for k in ("DYLD_LIBRARY_PATH", "PYTHONDONTWRITEBYTECODE", "OMP_NUM_THREADS",
                                                   "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")}
        io.write(config.output / "configuration.json", config, fresh=True)
        with (config.output / "child.log").open("xb") as log:
            began = time.monotonic()
            process = subprocess.Popen(receipt.command, env=env, cwd=config.output, stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            receipt.child_pid = process.pid
            sampler = MemorySampler(config, process.pid, began)
            sampler.start()
            io.write(path, receipt)
            try:
                receipt.returncode = process.wait(timeout=config.engine_seconds)
            finally:
                if process.poll() is not None:
                    receipt.launch_to_exit_seconds = time.monotonic() - began
                receipt.sampler = sampler.finish()
        signal.alarm(config.oracle_seconds + 2 * config.closure_seconds)
        io.require(receipt.returncode == 0, "engine child returned error")
        sampler_passed(receipt.sampler)
        receipt.child = io.load(config.engine.output / "engine-receipt.json")
        receipt.server_pid = check_child(config, receipt.child, receipt.sampler)
        table = io.processes()
        receipt.child_group_absent = io.group_absent(process.pid, table)
        receipt.server_group_absent = io.group_absent(receipt.server_pid, table)
        receipt.matching_server_absent = not any(io.matching_server(text, config.engine.binary) for _, text in table)
        receipt.worker_processes_absent = workers_absent(receipt.sampler, table)
        io.require(receipt.child_group_absent and receipt.server_group_absent and receipt.matching_server_absent
                   and receipt.worker_processes_absent,
                   "independent native engine closure not certain")
        io.write(path, receipt)
        candidate = exited_dataset(config, receipt, child_config)
        signal.alarm(config.oracle_seconds + config.closure_seconds)
        correctness = compare_output(config, candidate)
        receipt.correctness = cast(dict[str, JsonValue], correctness.model_dump(mode="json"))
        io.write(config.output / "correctness.json", correctness, fresh=True)
        signal.alarm(config.closure_seconds)
        receipt.retention_files = io.retain(config.engine.output, config.retention)
        receipt.retention_verified = True
        io.write(config.output / "retention-index.json", {k: cast(JsonValue, v.model_dump()) for k, v in receipt.retention_files.items()}, fresh=True)
        receipt.source_after = io.source(config)
        receipt.after = io.guard_files(config)
        receipt.client_after = io.client(config.python, config.library_path, expected.lock)
        io.same_client(receipt.client_after, expected)
        io.require(receipt.before == receipt.after and receipt.source_before == receipt.source_after,
                   "source/original/helper identity closure failed")
        receipt.outcome = "reference_prepared" if config.reference_preparation_only else "passed_matched_pr_diagnostic"
        io.write(path, receipt)  # Physical evidence complete before releasing our locks.
    except BaseException as error:  # noqa: BLE001 -- failed IDs and owned closure must survive cancellation.
        receipt.outcome = "error"
        receipt.errors.append(repr(error))
    finally:
        signal.alarm(config.closure_seconds)
        if sampler is not None:
            receipt.sampler = sampler.finish()
        if process is not None:
            try:
                if process.poll() is None:
                    cancel_owned(receipt, process.pid, "child")
                receipt.returncode = process.wait(timeout=5)
                if receipt.launch_to_exit_seconds is None and began is not None:
                    receipt.launch_to_exit_seconds = time.monotonic() - began
                for known in receipt.sampler.owned_servers:
                    table = io.processes()
                    live = [(p, t) for p, t in table if p.pid == known.pid]
                    if live:
                        io.require(all(p.pgid == known.pgid and p.command_sha256 == known.command_sha256
                                       and io.matching_server(t, config.engine.binary) for p, t in live),
                                   "server ownership changed; refused cancellation")
                        cancel_owned(receipt, known.pgid, "server")
                for known in receipt.sampler.owned_workers:
                    table = io.processes()
                    live = [(p, t) for p, t in table if p.pid == known.pid]
                    if live:
                        io.require(all(p.pgid == known.pgid and p.ppid == known.ppid
                                       and p.command_sha256 == known.command_sha256
                                       and io.matching_worker(t, config.engine.binary) for p, t in live),
                                   "worker ownership changed; refused cancellation")
                        cancel_owned(receipt, known.pgid, "worker")
                table = io.processes()
                receipt.worker_processes_absent = workers_absent(receipt.sampler, table)
                receipt.child_group_absent = io.group_absent(process.pid, table)
                receipt.server_group_absent = bool(receipt.sampler.owned_servers) and all(io.group_absent(p.pgid, table) for p in receipt.sampler.owned_servers)
                receipt.matching_server_absent = not any(io.matching_server(t, config.engine.binary) for _, t in table)
                io.require(receipt.child_group_absent and receipt.matching_server_absent and receipt.worker_processes_absent, "native group remains after final cleanup")
            except BaseException as error:  # noqa: BLE001 -- retain closure uncertainty and original failure.
                receipt.outcome = "error"
                receipt.errors.append("final owned closure: " + repr(error))
        if receipt.sampler.error or receipt.sampler.thread_alive:
            receipt.outcome = "error"
            receipt.errors.append("memory sampler final failure")
        try:
            io.write(config.output / "sampler-receipt.json", receipt.sampler)
        except BaseException as error:  # noqa: BLE001 -- missing complete sampler evidence refuses success.
            receipt.outcome = "error"
            receipt.errors.append("sampler receipt retention: " + repr(error))
        if receipt.outcome == "error" and config.engine.output.is_dir() and not config.retention.exists():
            try:
                io.require(receipt.child_group_absent and receipt.matching_server_absent,
                           "refused partial copy while engine ownership closure is uncertain")
                receipt.retention_files = io.retain(config.engine.output, config.retention)
                receipt.retention_verified = True
            except BaseException as error:  # noqa: BLE001 -- retain partial failure artifacts without retry.
                receipt.errors.append("partial retention: " + repr(error))
        if receipt.outcome in {"reference_prepared", "passed_matched_pr_diagnostic"}:
            try:
                io.require(receipt.server_group_absent and receipt.worker_processes_absent and receipt.retention_verified,
                           "final release requires certain server closure and retained data")
                io.write(path, receipt)
                io.release(config.locks, owner)
                receipt.locks_released = True
            except BaseException as error:  # noqa: BLE001 -- failed owner release must remain an error.
                receipt.outcome = "error"
                receipt.errors.append("owned release: " + repr(error))
        receipt.finished_utc = io.utc()
        if acquired and receipt.outcome == "error":
            receipt.errors.append("owned locks retained; root must audit closure before preserving owner")
        io.write(path, receipt)
        signal.alarm(0)
    return 0 if receipt.outcome in {"reference_prepared", "passed_matched_pr_diagnostic"} and receipt.locks_released else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--admit-client", action="store_true")
    parser.add_argument("--python", type=Path)
    parser.add_argument("--lock", type=Path)
    parser.add_argument("--library-path", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM):
        signal.signal(signum, interrupted)
    if args.admit_client:
        io.require(all(isinstance(x, Path) for x in (args.python, args.lock, args.library_path, args.output)),
                   "admit-client requires --python/--lock/--library-path/--output")
        identity = io.identity(args.lock)
        signal.alarm(120)
        candidate = io.client(args.python, args.library_path, Pin(path=args.lock, **identity.model_dump()))
        io.write(args.output, candidate, fresh=True)
        signal.alarm(0)
        return 0
    io.require(isinstance(args.config, Path), "--config required")
    return execute(Config.model_validate_json(args.config.read_bytes()), args.config)


if __name__ == "__main__":
    raise SystemExit(main())
