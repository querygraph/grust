"""Metadata-only config construction after root has copied the frozen preparation."""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Literal, cast

import native_io as io
from native_models import (
    Config,
    EngineExitedProof,
    ExitObservation,
    Pin,
    Receipt,
    ResultDataset,
)
from pydantic import JsonValue

BASE = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001')


def pin(path: Path) -> Pin:
    return Pin(path=path, **io.identity(path).model_dump())


def reference(parent_path: Path) -> ResultDataset:
    parent = Receipt.model_validate_json(parent_path.read_bytes())
    io.require(parent.outcome == 'reference_prepared' and parent.finished_utc is not None
               and parent.locks_released and parent.retention_verified and not parent.errors
               and parent.child_group_absent and parent.server_group_absent and parent.worker_processes_absent
               and parent.matching_server_absent and parent.returncode == 0 and parent.engine_exited is not None,
               'requires a closed, fully retained separate graphframes reference preparation')
    proof_pin = cast(Pin, parent.engine_exited)
    io.verify(proof_pin)
    proof = EngineExitedProof.model_validate_json(proof_pin.path.read_bytes())
    io.require(proof.engine == 'graphframes' and proof.run_id == parent.config.run_id
               and proof.child_pid == parent.child_pid, 'reference parent/exited proof mismatch')
    return ResultDataset(engine='graphframes', directory=proof.raw_directory, files=proof.raw_files,
        exit=ExitObservation(engine='graphframes', run_id=proof.run_id, child_pid=proof.child_pid,
                             returncode=0, wait_completed=True, producer_receipt=proof_pin))


def build(baseline: Path, preparation: Path, campaign: Path, run_id: str,
          engine: Literal['pecan', 'graphframes'], mode: Literal['local', 'process-cluster'],
          reference_parent: Path | None) -> Config:
    io.require(all(p.is_absolute() for p in (baseline, preparation, campaign)), 'absolute construction paths required')
    raw = io.load(baseline)
    engine_raw = raw.pop('engine')
    io.require(isinstance(engine_raw, dict), 'baseline engine configuration missing')
    old_engine = cast(dict[str, JsonValue], engine_raw)
    old_engine.update(repo=str(BASE.parent.parent/'workspaces/sem-review-20261001/pagerank-0d1ef2ca3'),
        output=str(Path('/Users/alexy/src/grust-benchmark-runs')/campaign.name/run_id),
        algorithm='pagerank', engine=engine, mode=mode if engine == 'pecan' else 'local',
        snapshot_inputs=False, pool_bytes=(10 if engine == 'pecan' and mode == 'process-cluster' else 30)*2**30,
        method='pregel_delta', reset_probability=.15, tolerance=.01, max_iterations=10,
        normalize=True, vote_to_halt=False)
    # Select the root-admitted binary pin from completed build metadata, without reading its payload.
    build_receipt = io.load(Pin.model_validate(raw['build']).path)
    steps = build_receipt.get('steps')
    io.require(isinstance(steps,list), 'build metadata steps missing')
    binaries = [step.get('binary') for step in cast(list[JsonValue],steps) if isinstance(step,dict)
                and step.get('name') == ('sail' if engine == 'pecan' else 'graphframes')]
    io.require(len(binaries)==1, 'one completed selected build identity required')
    old_engine['binary']=str(Pin.model_validate(binaries[0]).path)
    originals = raw['originals']
    io.require(isinstance(originals,dict), 'baseline original pins missing')
    raw['originals']={k:v for k,v in cast(dict[str,JsonValue],originals).items() if k in {'vertices','edges'}}
    raw.pop('membership',None)
    admission_path=BASE/'PageRank-native-preparation01/source-admission.json'
    admission=io.load(admission_path)
    raw.update(engine=old_engine, output=str(campaign/'cells'/run_id), retention=str(campaign/'retained'/run_id),
        run_id=run_id, contrast_mode=mode,
        graphframes_repo=str(BASE.parent.parent/'workspaces/sem-review-20261001/graphframes-rs'),
        reference_preparation_only=reference_parent is None,
        reference=None if reference_parent is None else reference(reference_parent).model_dump(mode='json'),
        source_tree=admission['tree'], source_admission=pin(admission_path).model_dump(mode='json'),
        support_manifest=pin(preparation/'support-manifest.json').model_dump(mode='json'),
        helpers={name:pin(preparation/name).model_dump(mode='json')
                 for name in ('native_models.py','native_io.py','supervise_native.py')},
        oracle_helpers={name:pin(BASE/'PageRank-native-oracle01'/name).model_dump(mode='json')
                        for name in ('pagerank_models.py','pagerank_io.py','pagerank_oracle.py')})
    return Config.model_validate(raw)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',type=Path,default=BASE/'B7-native-pair01/configs/warmup-inplace.json')
    parser.add_argument('--preparation',type=Path,required=True)
    parser.add_argument('--campaign',type=Path,required=True)
    parser.add_argument('--run-id',required=True)
    parser.add_argument('--engine',choices=['pecan','graphframes'],required=True)
    parser.add_argument('--mode',choices=['local','process-cluster'],required=True)
    parser.add_argument('--reference-parent',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    io.write(args.output,build(args.baseline,args.preparation,args.campaign,args.run_id,args.engine,args.mode,args.reference_parent),fresh=True)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
