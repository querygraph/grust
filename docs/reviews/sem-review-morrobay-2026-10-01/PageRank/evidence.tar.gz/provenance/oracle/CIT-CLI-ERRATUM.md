# B11 Cit-Patents CLI column mapping erratum

The frozen source/oracle bundle and its freeze636d4e2ed4fd71a83376843dd464a4396af70319304296897d27edbded7ce348 remain unchanged. The SOURCE-CONTRACTS.md generic CLI example requires two additional flags when used with the retained Cit-Patents Parquet: `--src-col-name source --dst-col-name target`. Those input fields are source/target; graphframes-rs b4da defaults to src/dst.

```text
graphframes page-rank --vertices V --edges E --output file:///OUTPUT/ --format parquet --src-col-name source --dst-col-name target --tol 0.01 --reset-prob 0.15 --max-iter 10 --num-workers 16 --max-memory POOL --checkpoint-dir WORK
```

This changes the documentation command only. Exact PageRank equations and all frozen oracle predicates remain unchanged. Independent peer read-only review found no further source/domain/math/closure blocker. No actual execution or additional tests were performed for this erratum.

Observed 2026-10-02T11:50:05.969312+00:00.
