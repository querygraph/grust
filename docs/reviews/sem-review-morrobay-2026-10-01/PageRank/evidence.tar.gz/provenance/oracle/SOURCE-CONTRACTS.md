# B11 PageRank source contract

Source-only verdict: the requested positive-cap contract matches between Pecan `0d1ef2ca3c3320a1ac9059f09ea4e0bcb7e4fb97` and graphframes-rs `b4da56dabe20bba8e29563e06acc5179b2113ce3`. Full runtime outputs have not been compared here. [Source hashes and binary receipt pins](source-contract-audit.json) retain the exact reviewed bytes.

For vertex v, initialize rank r0(v) = delta d0(v) = 0.15. In step1 every vertex participates; thereafter send only when the previous delta > 0.01. For every stored directed edge u→v, the message is d(u)/outdegree(u); parallel edges and loops contribute individually. Let m(v) be the sum of incoming messages, zero when none. Set d(v) = 0.85 m(v), and r(v) = previous r(v) + d(v). Execute exactly10steps, without early voting, then return r(v)/sum(r). Sinks and isolates remain in the vertex state; no dangling redistribution is added.

Pecan source: `pagerank_pregel_delta.py:45` (sender filter/message and left-joined gain), `:66` (initial state), `:72` (positive-cap loop), `:93` (normalization), `:101` (count_vertices=False); `algorithms.py:223` (dispatch), `types.py:84` (options). GraphFrames source: `src/algorithm/centrality/pagerank.rs:113` (full-degree input), `:145` (new delta), `:166` (uniform seeding), `:172` (SrcToDst/participation), `:194` (positive-cap/no voting), `:214` (normalization), `:222` (exact id/pagerank output); `src/algorithm/pregel.rs:381` (loop/filter), `:482` (left state join), `:504` (voting-only count). CLI `src/main.rs:161`/`:741` sets tol/reset/max_iter; symmetrization is an explicit flag, default false.

Matching calls:

```python
graph.pagerank(vertices, edges, method="pregel_delta", reset_probability=0.15,
               tolerance=0.01, max_iterations=10, normalize=True,
               vote_to_halt=False, partitions=16)
```

```text
graphframes page-rank --vertices V --edges E --output file:///OUTPUT/ --format parquet --tol 0.01 --reset-prob 0.15 --max-iter 10 --num-workers 16 --max-memory POOL --checkpoint-dir WORK
```

Omit `--symmetrize` and `--personalized`. Input snapshot/repartition/software-pool settings and timer boundaries are separate controller/execution choices and must be recorded per cell. The fixed 10-step delta algorithm is distinct from ordinary LDBC fixed-point PageRank, static Pregel, and tolerance-convergence mode; this review qualifies none of those contracts.

Existing optimized macOS GraphFrames binary: SHA `41780fcebd40c420281f1b2ac0df15ed19679d06f917faacfe2f1402db15a952`, 72,311,876 bytes. Existing Sail runtime was compiled at `9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3`; the observed diff to controller0d1ef is empty only for `crates/`, `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml`. This permits separately declared reuse under root admission; it does not make the Python controllers identical.

Observed 2026-10-02T11:35:48.981144+00:00. No engine imports, native probes, runtime jobs, builds, or production payload reads were performed for this review.
