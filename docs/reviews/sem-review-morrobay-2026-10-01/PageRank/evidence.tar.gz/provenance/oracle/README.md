# B11 full physical PageRank oracle

The [source contract review](SOURCE-CONTRACTS.md) matches Pecan controller `0d1ef2ca3c3320a1ac9059f09ea4e0bcb7e4fb97` with graphframes-rs `b4da56dabe20bba8e29563e06acc5179b2113ce3`: directed delta PageRank, reset0.15, tolerance0.01, exactly10steps, no voting, final normalization. Actual large outputs have not been produced or compared by this preparation.

## Interface

```python
from pagerank_models import OracleConfig
from pagerank_oracle import verify

config = OracleConfig.model_validate_json(configuration_bytes)
receipt = verify(config)
```

```text
python -B /PATH/pagerank_oracle.py --config /ABSOLUTE/config.json
```

Use the exact isolated helper directory on the parent import path. Unique module basenames avoid collisions with other frozen oracles. [config-schema.json](config-schema.json) is the generated typed schema.

`OracleConfig` contains:

- `dataset`: `cit-Patents` or bounded `tiny`; `expected_rows`: complete vertex count. Cit requires exactly3,774,768 rows and the unchanged retained input vertex file bytes/SHA.
- `input_vertices`: one `FilePin(path, bytes, sha256)` naming the original physical vertex Parquet.
- `graphframes_reference` and `candidate`: `ResultDataset(engine, directory, files, exit)`. `files` is the complete immutable regular-file inventory keyed by canonical relative name, including any non-Parquet sidecar files. `exit` is `ExitObservation(engine, run_id, child_pid, returncode=0, wait_completed=True, producer_receipt=FilePin)`.
- `output`: fresh absolute oracle output directory. No resume, retry, or overwrite.
- `reference_preparation_only`: true only when reference and candidate are the exact same closed GraphFrames dataset. Otherwise both physical directories must be disjoint.
- `limits`: bounded file/entry/byte/rowgroup counts, batch size, conservative utility memory model, overall verification deadline and a separate finite closure-audit deadline.

`ExitObservation.producer_receipt` pins the parent's immutable `engine-exited.json`, parsed as strict `ExitProof`. Its exact fields are `engine`, `run_id`, `child_pid`, `returncode=0`, `wait_completed=true`, `child_group_absent=true`, `server_group_absent=true`, `raw_directory`, `raw_files`, `child_receipt` FilePin, `configuration` FilePin, and `observed_utc`. The proof must bind exactly the declared engine/run/PID/output inventory. Its child receipt and configuration are independently rehashed. For GraphFrames, the runtime group is the native CLI group; no additional Sail server is implied. The parent produces this proof from actual waited process observations, after exit and before the oracle.

## Complete physical check

The original input must contain exactly one physical `id:int64` field, all rows non-null and unique. Every reference and candidate Parquet requires exactly the two uniquely named fields `id:int64` and `pagerank:float64`, in either physical column order. Rank and ID must be non-null; every rank must be finite. No casts, output rewriting, normalization, or sentinel adapters occur in the oracle.

Every reference and candidate row must belong to the complete original vertex domain exactly once, including signed extreme IDs. Batch, file, footer and total counts must agree. Every candidate rank is compared against the pinned GraphFrames rank at the same vertex, with absolute error at most binary64 `1e-12` (`0x1.19799812dea11p-40`). Near the subtraction-rounding boundary, an exact integer cross-product predicate decides acceptance. Relative error is diagnostic only: `abs(actual-reference)/abs(reference)`; zero reference with nonzero actual records `inf` in the hex/string diagnostic and null in the finite numeric field.

Numeric mismatches retain all compared-row counts, mismatch totals, maximum absolute/relative differences, and up to16 exact hex witnesses. Complete input/reference/raw inventories and helper/proof/configuration bytes are checked again at closure, using chunked hashes with propagated finite deadlines. All utility outcomes retain a fresh receipt. Final integrity failure downgrades an otherwise successful result.

## Outcomes and boundaries

A comparison is accepted only with `outcome="passed_full_physical_pagerank"`, `full_physical_domain_passed=true`, `full_numeric_comparison_passed=true`, and `own_identity_closure_passed=true`, plus exactly the expected compared/reference/candidate/unique counts and zero numeric mismatches. The parent still qualifies final retention and independently observed process ownership.

The first GraphFrames self-reference can yield only `reference_prepared`: full physical domain and immutable closure pass, but numeric comparison is false and compared rows are zero. This creates no Pecan comparison claim.

Failure outcomes remain `mismatch`, `error`, `timeout`, or `interrupted`; their raw outputs are preserved by the parent. The oracle never starts, signals, retries, or cleans an engine. Its I/O, domain checking and every numerical comparison occur outside waited engine execution. The oracle receipt explicitly leaves `performance_comparison` and `independent_parent_retention_qualified` false.

This preparation is source plus tiny physical-fixture evidence only. It establishes no runtime comparison, speed claim, generic PageRank equivalence, or LDBC fixed-point PageRank qualification.
