"""Bounded physical fixtures; no engine, network, or production payload access."""
from __future__ import annotations

import json
import math
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import pagerank_io as io
import pagerank_models as models
import pagerank_oracle as oracle
import pyarrow as pa
import pyarrow.parquet as pq
from pydantic import ValidationError


class PhysicalOracleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.deadline = io.Deadline(time.monotonic(), 60)
        self.vertices = self.root/"vertices.parquet"
        pq.write_table(pa.table({"id": pa.array([-2**63, 1, 2], type=pa.int64())}), self.vertices)
        self.reference = self.dataset("reference", "graphframes", [-2**63, 1, 2], [0.2, 0.3, 0.5])

    def dataset(self, name: str, engine: models.Engine, ids: list[int | None],
                ranks: list[float | None], *, id_type: pa.DataType | None = None,
                rank_type: pa.DataType | None = None, extra: bool = False,
                reorder: bool = False, split: bool = False) -> models.ResultDataset:
        directory = self.root/name
        directory.mkdir()
        fields = {"id": pa.array(ids, type=id_type or pa.int64()),
                  "pagerank": pa.array(ranks, type=rank_type or pa.float64())}
        if extra:
            fields["extra"] = pa.array([0]*len(ids))
        if reorder:
            fields = dict(reversed(list(fields.items())))
        table = pa.table(fields)
        if split:
            pq.write_table(table.slice(0, 1), directory/"part0.parquet")
            pq.write_table(table.slice(1), directory/"part1.parquet")
        else:
            pq.write_table(table, directory/"part.parquet")
        child = self.root/(name+"-child.json")
        child.write_text('{"outcome":"passed"}\n')
        config = self.root/(name+"-config.json")
        config.write_text('{"method":"pregel_delta"}\n')
        files = io.inventory(directory, models.Limits(), self.deadline)
        proof = models.ExitProof(engine=engine, run_id=name, child_pid=101, returncode=0,
            wait_completed=True, child_group_absent=True, server_group_absent=True,
            raw_directory=directory, raw_files=files, child_receipt=io.pin(child, self.deadline),
            configuration=io.pin(config, self.deadline), observed_utc=io.utc())
        proof_path = self.root/(name+"-exited.json")
        proof_path.write_text(proof.model_dump_json(indent=2))
        return models.ResultDataset(engine=engine, directory=directory, files=files,
            exit=models.ExitObservation(engine=engine, run_id=name, child_pid=101, returncode=0,
                wait_completed=True, producer_receipt=io.pin(proof_path, self.deadline)))

    def config(self, candidate: models.ResultDataset, *, prep: bool = False,
               limits: models.Limits | None = None) -> models.OracleConfig:
        return models.OracleConfig(dataset="tiny", expected_rows=3,
            input_vertices=io.pin(self.vertices, self.deadline),
            graphframes_reference=self.reference, candidate=candidate, output=self.root/"oracle-result",
            reference_preparation_only=prep, limits=limits or models.Limits(batch_rows=1))

    def test_full_signed_domain_unordered_parts_and_columns(self) -> None:
        candidate = self.dataset("candidate", "pecan", [2, -2**63, 1], [0.5, 0.2, 0.3], reorder=True, split=True)
        config = self.config(candidate)
        parsed = models.OracleConfig.model_validate_json(config.model_dump_json())
        receipt = oracle.verify(parsed)
        self.assertEqual(receipt.outcome, "passed_full_physical_pagerank")
        self.assertEqual((receipt.compared_rows, receipt.unique_candidate_rows), (3, 3))
        self.assertEqual(receipt.max_absolute_error, 0.0)
        self.assertTrue(receipt.own_identity_closure_passed)
        self.assertFalse(receipt.independent_parent_retention_qualified)

    def test_bad_physical_cases_are_durable(self) -> None:
        cases: list[tuple[str, list[int | None], list[float | None], pa.DataType, pa.DataType, bool]] = [
            ("duplicate", [1, 1, 2], [0.3, 0.3, 0.5], pa.int64(), pa.float64(), False),
            ("unknown", [-2**63, 1, 3], [0.2, 0.3, 0.5], pa.int64(), pa.float64(), False),
            ("missing", [1, 2], [0.3, 0.5], pa.int64(), pa.float64(), False),
            ("null-id", [None, 1, 2], [0.2, 0.3, 0.5], pa.int64(), pa.float64(), False),
            ("null-rank", [-2**63, 1, 2], [None, 0.3, 0.5], pa.int64(), pa.float64(), False),
            ("nan", [-2**63, 1, 2], [math.nan, 0.3, 0.5], pa.int64(), pa.float64(), False),
            ("infinity", [-2**63, 1, 2], [math.inf, 0.3, 0.5], pa.int64(), pa.float64(), False),
            ("i32", [0, 1, 2], [0.2, 0.3, 0.5], pa.int32(), pa.float64(), False),
            ("f32", [-2**63, 1, 2], [0.2, 0.3, 0.5], pa.int64(), pa.float32(), False),
            ("extra-field", [-2**63, 1, 2], [0.2, 0.3, 0.5], pa.int64(), pa.float64(), True),
        ]
        for name, ids, ranks, id_type, rank_type, extra in cases:
            with self.subTest(name=name):
                candidate = self.dataset(name, "pecan", ids, ranks, id_type=id_type, rank_type=rank_type, extra=extra)
                config = self.config(candidate).model_copy(update={"output": self.root/(name+"-oracle")})
                result = oracle.verify(config)
                self.assertEqual(result.outcome, "mismatch")
                self.assertFalse(result.full_numeric_comparison_passed)
                self.assertEqual(json.loads((config.output/"receipt.json").read_text())["outcome"], "mismatch")

    def test_numeric_mismatch_checks_all_rows(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2+2e-12, 0.3, 0.5+3e-12])
        result = oracle.verify(self.config(candidate))
        self.assertEqual(result.outcome, "mismatch")
        self.assertEqual((result.compared_rows, result.numeric_mismatches), (3, 2))
        self.assertEqual(len(result.witnesses), 2)
        self.assertTrue(result.full_physical_domain_passed)
        self.assertIsNotNone(result.max_relative_error)

    def test_exact_absolute_boundary(self) -> None:
        self.assertTrue(oracle.within_bound(models.ABSOLUTE_BOUND, 0.0))
        self.assertFalse(oracle.within_bound(math.nextafter(models.ABSOLUTE_BOUND, math.inf), 0.0))

    def test_physical_absolute_boundary_and_zero_relative_diagnostic(self) -> None:
        self.reference = self.dataset("zero-reference", "graphframes", [-2**63, 1, 2], [0.0, 0.3, 0.5])
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [models.ABSOLUTE_BOUND, 0.3, 0.5])
        result = oracle.verify(self.config(candidate))
        self.assertEqual(result.outcome, "passed_full_physical_pagerank")
        self.assertEqual(result.max_absolute_error, models.ABSOLUTE_BOUND)
        self.assertEqual(result.max_relative_error_hex, "inf")
        self.assertIsNone(result.max_relative_error)

    def test_reference_preparation_not_numeric_pass(self) -> None:
        with self.assertRaises(ValidationError):
            self.config(self.reference)
        result = oracle.verify(self.config(self.reference, prep=True))
        self.assertEqual(result.outcome, "reference_prepared")
        self.assertFalse(result.full_numeric_comparison_passed)
        self.assertEqual(result.compared_rows, 0)

    def test_duplicate_original_domain_refused(self) -> None:
        pq.write_table(pa.table({"id": pa.array([1, 1, 2], type=pa.int64())}), self.vertices)
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        result = oracle.verify(self.config(candidate))
        self.assertEqual(result.outcome, "mismatch")
        self.assertIn("duplicate original", str(result.error))

    def test_changed_reference_pin_refused(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        (self.reference.directory/"part.parquet").write_bytes(b"tampered")
        result = oracle.verify(self.config(candidate))
        self.assertEqual(result.outcome, "mismatch")
        self.assertTrue(result.integrity_errors)

    def test_wrong_exit_output_binding_refused(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        proof_path = candidate.exit.producer_receipt.path
        proof = models.ExitProof.model_validate_json(proof_path.read_bytes())
        proof_path.write_text(proof.model_copy(update={"raw_directory": self.reference.directory}).model_dump_json())
        observation = candidate.exit.model_copy(update={"producer_receipt": io.pin(proof_path, self.deadline)})
        result = oracle.verify(self.config(candidate.model_copy(update={"exit": observation})))
        self.assertEqual(result.outcome, "mismatch")
        self.assertIn("raw output binding", str(result.error))

    def test_incomplete_exit_proof_refused(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        proof_path = candidate.exit.producer_receipt.path
        value = json.loads(proof_path.read_text())
        value["wait_completed"] = False
        proof_path.write_text(json.dumps(value))
        observation = candidate.exit.model_copy(update={"producer_receipt": io.pin(proof_path, self.deadline)})
        result = oracle.verify(self.config(candidate.model_copy(update={"exit": observation})))
        self.assertEqual(result.outcome, "error")
        self.assertFalse(result.full_numeric_comparison_passed)

    def test_exit_flags_and_returncode_do_not_coerce(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        proof = json.loads(candidate.exit.producer_receipt.path.read_text())
        for field, value in [("returncode", False), ("returncode", 1), ("wait_completed", 1),
                             ("child_group_absent", False), ("server_group_absent", False)]:
            with self.subTest(field=field, value=value), self.assertRaises(ValidationError):
                models.ExitProof.model_validate_json(json.dumps({**proof, field: value}))

    def test_uninventoried_extra_raw_file_refused(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        (candidate.directory/"extra.log").write_text("new")
        result = oracle.verify(self.config(candidate))
        self.assertEqual(result.outcome, "mismatch")
        self.assertTrue(result.integrity_errors)

    def test_late_configuration_change_downgrades_pass(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        original = oracle.compare

        def change_after_comparison(ids: oracle.I64, actual: oracle.F64, expected: oracle.F64,
                                    record: models.OracleReceipt, config: models.OracleConfig,
                                    deadline: io.Deadline) -> None:
            original(ids, actual, expected, record, config, deadline)
            (self.root/"candidate-config.json").write_text("changed")

        with patch.object(oracle, "compare", change_after_comparison):
            result = oracle.verify(self.config(candidate))
        self.assertEqual(result.outcome, "error")
        self.assertTrue(result.full_numeric_comparison_passed)
        self.assertFalse(result.own_identity_closure_passed)

    def test_deadline_and_no_overwrite(self) -> None:
        candidate = self.dataset("candidate", "pecan", [-2**63, 1, 2], [0.2, 0.3, 0.5])
        config = self.config(candidate, limits=models.Limits(timeout_seconds=1e-12))
        result = oracle.verify(config)
        self.assertEqual(result.outcome, "timeout")
        with self.assertRaises(io.Mismatch):
            oracle.verify(config)


if __name__ == "__main__":
    unittest.main()
