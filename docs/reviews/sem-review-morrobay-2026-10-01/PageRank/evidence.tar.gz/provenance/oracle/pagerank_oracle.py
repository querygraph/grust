"""Every physical PageRank row versus a sealed graphframes output after exit."""
from __future__ import annotations

import argparse
import math
import sys
import time
import traceback
from pathlib import Path
from typing import cast

import numpy as np
import numpy.typing as npt
import pagerank_io as io
import pagerank_models as models
import pyarrow as pa
import pyarrow.parquet as pq

I64 = npt.NDArray[np.int64]
F64 = npt.NDArray[np.float64]


def physical(path: Path, name: str, rank: bool, config: models.OracleConfig,
             deadline: io.Deadline) -> models.PhysicalFile:
    deadline.check()
    with pq.ParquetFile(path) as parquet:
        schema = parquet.schema_arrow
        expected = {"id": pa.int64(), "pagerank": pa.float64()} if rank else {"id": pa.int64()}
        fields = tuple(models.PhysicalField(name=f.name, arrow_type=str(f.type), nullable=f.nullable) for f in schema)
        groups = [sum(parquet.metadata.row_group(i).column(j).total_uncompressed_size
                      for j in range(parquet.metadata.row_group(i).num_columns))
                  for i in range(parquet.metadata.num_row_groups)]
        maximum = max(groups, default=0)
        io.require(maximum <= config.limits.maximum_row_group_bytes, "uncompressed rowgroup exceeds admission")
        result = models.PhysicalFile(file=name, fields=fields, footer_rows=parquet.metadata.num_rows,
                                    maximum_row_group_bytes=maximum)
        io.require(len(schema.names) == len(expected) and set(schema.names) == set(expected),
                   "physical field names differ: " + name)
        io.require(all(schema.field(key).type == kind for key, kind in expected.items()),
                   "physical BIGINT/DOUBLE types differ: " + name)
        return result


def domain(config: models.OracleConfig, record: models.OracleReceipt, deadline: io.Deadline) -> I64:
    descriptor = physical(config.input_vertices.path, config.input_vertices.path.name, False, config, deadline)
    record.physical_schemas["input"] = [descriptor]
    io.require(descriptor.footer_rows == config.expected_rows, "input footer differs from expected completeV")
    ids: I64 = np.empty(config.expected_rows, dtype=np.int64)
    count = 0
    with pq.ParquetFile(config.input_vertices.path) as parquet:
        for batch in parquet.iter_batches(batch_size=config.limits.batch_rows, use_threads=False):
            deadline.check()
            column = batch.column(batch.schema.get_field_index("id"))
            io.require(column.null_count == 0, "null input vertex")
            values = cast(I64, column.to_numpy(zero_copy_only=False))
            io.require(count + len(values) <= len(ids), "input exceeds expected vertex count")
            ids[count:count+len(values)] = values
            count += len(values)
    io.require(count == config.expected_rows, "input physical/footer count differs")
    ids.sort()
    io.require(bool(np.all(ids[1:] > ids[:-1])), "duplicate original vertex ID")
    record.expected_domain_rows = count
    ids.setflags(write=False)
    return ids


def admit_exit(dataset: models.ResultDataset, role: str, record: models.OracleReceipt,
               deadline: io.Deadline) -> None:
    observed = dataset.exit
    proof = models.ExitProof.model_validate_json(io.metadata(observed.producer_receipt, deadline))
    io.require((proof.engine, proof.run_id, proof.child_pid, proof.returncode, proof.wait_completed) ==
               (observed.engine, observed.run_id, observed.child_pid, observed.returncode, observed.wait_completed),
               "parent waited-exit binding differs: " + role)
    io.require(proof.raw_directory == dataset.directory and proof.raw_files == dataset.files,
               "parent exited proof raw output binding differs: " + role)
    record.exit_proofs[role] = proof
    for name, pin in {"exit-proof": observed.producer_receipt, "child-receipt": proof.child_receipt,
                      "configuration": proof.configuration}.items():
        io.verify(pin, deadline)
        record.identity_before[role+"/"+name] = pin


def values(dataset: models.ResultDataset, role: str, ids: I64, config: models.OracleConfig,
           record: models.OracleReceipt, deadline: io.Deadline) -> F64:
    io.require(io.inventory(dataset.directory, config.limits, deadline) == dataset.files,
               "complete raw inventory differs: " + role)
    for name, identity in dataset.files.items():
        record.identity_before[role+"/raw/"+name] = models.FilePin(path=dataset.directory/name,
                                                                **identity.model_dump())
    names = [name for name in dataset.files if name.endswith(".parquet")]
    io.require(bool(names), "no physical PageRank Parquet: " + role)
    descriptors = [physical(dataset.directory/name, name, True, config, deadline) for name in names]
    record.physical_schemas[role] = descriptors
    io.require(sum(p.footer_rows for p in descriptors) == len(ids), "raw footer cardinality differs: " + role)
    seen = np.zeros(len(ids), dtype=np.bool_)
    ranks: F64 = np.empty(len(ids), dtype=np.float64)
    count = 0
    for descriptor in descriptors:
        file_rows = 0
        with pq.ParquetFile(dataset.directory/descriptor.file) as parquet:
            for batch in parquet.iter_batches(batch_size=config.limits.batch_rows, use_threads=False):
                deadline.check()
                columns = [batch.column(batch.schema.get_field_index(name)) for name in ("id", "pagerank")]
                io.require(all(column.null_count == 0 for column in columns), "null raw ID/rank: " + role)
                keys = cast(I64, columns[0].to_numpy(zero_copy_only=False))
                scores = cast(F64, columns[1].to_numpy(zero_copy_only=False))
                io.require(bool(np.all(np.isfinite(scores))), "nonfinite raw DOUBLE rank: " + role)
                positions = np.searchsorted(ids, keys)
                present = positions < len(ids)
                matched = np.zeros(len(keys), dtype=np.bool_)
                matched[present] = ids[positions[present]] == keys[present]
                io.require(bool(np.all(matched)), "raw ID outside complete original vertex domain: " + role)
                unique = np.unique(positions)
                io.require(len(unique) == len(positions) and not bool(np.any(seen[unique])),
                           "duplicate raw ID inside/across batches/files: " + role)
                seen[positions] = True
                ranks[positions] = scores
                count += len(keys)
                file_rows += len(keys)
                if role == "reference":
                    record.reference_rows = count
                else:
                    record.candidate_rows = count
        io.require(file_rows == descriptor.footer_rows, "physical/footer rows differ: " + role)
    io.require(count == len(ids) and bool(np.all(seen)), "missing raw vertex: " + role)
    ranks.setflags(write=False)
    return ranks


def within_bound(actual: float, expected: float) -> bool:
    """Exact binary64 difference versus the fixed binary64 1e-12 bound."""
    a, ad = actual.as_integer_ratio()
    b, bd = expected.as_integer_ratio()
    t, td = models.ABSOLUTE_BOUND.as_integer_ratio()
    return abs(a*bd-b*ad)*td <= t*ad*bd


def compare(ids: I64, actual: F64, expected: F64, record: models.OracleReceipt,
            config: models.OracleConfig, deadline: io.Deadline) -> None:
    max_abs, max_rel = 0.0, 0.0
    bound = models.ABSOLUTE_BOUND
    lower, upper = np.nextafter(bound, -np.inf), np.nextafter(bound, np.inf)
    for start in range(0, len(ids), config.limits.batch_rows):
        deadline.check()
        stop = min(len(ids), start+config.limits.batch_rows)
        a, e = actual[start:stop], expected[start:stop]
        with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
            difference = np.abs(a-e)
            relative = np.where(e == 0, np.where(a == 0, 0.0, np.inf), difference/np.abs(e))
        failed = difference > bound
        # Correct only subtraction-rounding edge cases, retaining vector throughput.
        for offset in np.flatnonzero((difference >= lower) & (difference <= upper)):
            deadline.check()
            failed[offset] = not within_bound(float(a[offset]), float(e[offset]))
        record.numeric_mismatches += int(np.count_nonzero(failed))
        max_abs = max(max_abs, float(difference.max(initial=0)))
        max_rel = max(max_rel, float(relative.max(initial=0)))
        for offset in np.flatnonzero(failed)[:max(0, 16-len(record.witnesses))]:
            record.witnesses.append(models.NumericWitness(vertex_id=int(ids[start+offset]),
                actual_hex=float(a[offset]).hex(), reference_hex=float(e[offset]).hex(),
                absolute_error_hex=float(difference[offset]).hex()))
        record.compared_rows += stop-start
    record.max_absolute_error = max_abs if math.isfinite(max_abs) else None
    record.max_absolute_error_hex = max_abs.hex()
    record.max_relative_error = max_rel if math.isfinite(max_rel) else None
    record.max_relative_error_hex = max_rel.hex()
    io.require(record.compared_rows == len(ids) and record.numeric_mismatches == 0,
               "full per-vertex PageRank absolute bound exceeded")
    record.full_numeric_comparison_passed = True


def outcome(error: BaseException) -> models.Outcome:
    if isinstance(error, io.TimedOut):
        return "timeout"
    if isinstance(error, (KeyboardInterrupt, SystemExit)):
        return "interrupted"
    return "mismatch" if isinstance(error, io.Mismatch) else "error"


def verify(config: models.OracleConfig, *, configuration: models.FilePin | None = None) -> models.OracleReceipt:
    """No engine actions; caller supplies parent-sealed exit proofs and immutable inventories."""
    started = time.monotonic()
    deadline = io.Deadline(started, config.limits.timeout_seconds)
    io.fresh(config)
    record = models.OracleReceipt(config=config, started_utc=io.utc(), observed_utc=io.utc())
    path = config.output/"receipt.json"
    io.save(path, record)
    try:
        modeled = config.expected_rows*64 + config.limits.batch_rows*256 + 2*config.limits.maximum_row_group_bytes + 512*2**20
        io.require(modeled <= config.limits.memory_budget_bytes, "conservative ordinal/rowgroup/library memory admission refused")
        sources = (Path(__file__).resolve(), Path(models.__file__).resolve(), Path(io.__file__).resolve())
        for source in sources:
            record.identity_before["helper/"+source.name] = io.pin(source, deadline)
        if configuration is not None:
            io.verify(configuration, deadline)
            record.identity_before["oracle-configuration"] = configuration
        io.verify(config.input_vertices, deadline)
        record.identity_before["input-vertices"] = config.input_vertices
        admit_exit(config.graphframes_reference, "reference", record, deadline)
        admit_exit(config.candidate, "candidate", record, deadline)
        ids = domain(config, record, deadline)
        reference = values(config.graphframes_reference, "reference", ids, config, record, deadline)
        candidate = values(config.candidate, "candidate", ids, config, record, deadline)
        record.unique_candidate_rows = len(ids)
        record.full_physical_domain_passed = True
        if config.reference_preparation_only:
            record.outcome = "reference_prepared"
        else:
            compare(ids, candidate, reference, record, config, deadline)
            record.outcome = "passed_full_physical_pagerank"
    except BaseException as error:  # noqa: BLE001 - retain utility failure; never owns engines.
        record.outcome = outcome(error)
        record.error, record.traceback = repr(error), traceback.format_exc()
    finally:
        closure = io.Deadline(time.monotonic(), config.limits.closure_timeout_seconds)
        for role, dataset in (("reference", config.graphframes_reference), ("candidate", config.candidate)):
            try:
                io.require(io.inventory(dataset.directory, config.limits, closure) == dataset.files,
                           "complete raw inventory changed at closure: " + role)
            except BaseException as error:  # noqa: BLE001 - preserve all closure failures.
                record.integrity_errors.append(role+": "+repr(error))
        for key, expected in record.identity_before.items():
            try:
                actual = io.pin(expected.path, closure)
                record.identity_after[key] = actual
                io.require(actual == expected, "immutable closure differs: "+key)
            except BaseException as error:  # noqa: BLE001 - preserve all closure failures.
                record.integrity_errors.append(key+": "+repr(error))
        record.own_identity_closure_passed = not record.integrity_errors and record.identity_before == record.identity_after
        if not record.own_identity_closure_passed and record.outcome in ("passed_full_physical_pagerank", "reference_prepared"):
            record.outcome, record.error = "error", "immutable source/input/reference/raw closure failed"
        record.finished_utc = io.utc()
        io.save(path, record)
    return record


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    configuration = io.pin(args.config.resolve(), io.Deadline(time.monotonic(), 300))
    config = models.OracleConfig.model_validate_json(io.metadata(configuration, io.Deadline(time.monotonic(), 300)))
    result = verify(config, configuration=configuration)
    return 0 if result.outcome in ("passed_full_physical_pagerank", "reference_prepared") else 1


if __name__ == "__main__":
    sys.exit(main())
