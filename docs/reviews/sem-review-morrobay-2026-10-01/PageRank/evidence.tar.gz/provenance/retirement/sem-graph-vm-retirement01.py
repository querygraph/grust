from __future__ import annotations
import datetime,hashlib,json,os,shutil,subprocess,sys,tarfile
from pathlib import Path
BASE=Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/graph-vm-retirement01')
DOCKER=['/usr/local/bin/docker','--context','colima-sail-gate']
EXCLUDE=['*/target','*/target-*','*/target_*','*/native-target','*/core-target','*/host-target','*/venv','*/.venv','*/deps','*/__pycache__','*/.git','*/staging','*/tmp','*/.pytest_cache']
def utc()->str:return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(r:dict)->None:
 p=BASE/'receipt.json';t=p.with_suffix('.json.tmp');t.write_text(json.dumps(r,indent=2)+'\n');t.replace(p)
def main()->int:
 r={'started_utc':utc(),'outcome':'preserving_experiment_data','pid':os.getpid(),'excluded_regenerable_names':EXCLUDE,'scope':'portable experiment inputs/results/receipts/source, excluding compiled caches and transient staging; no VM image retained','steps':[],'main_free_bytes_before':shutil.disk_usage('/Users/alexy').free};save(r)
 assert subprocess.check_output(DOCKER+['ps','-q'],text=True).strip()==''
 assert shutil.disk_usage(BASE).free>256*2**30
 archive=BASE/'experiment-data.tar.zst';cmd=['/usr/local/bin/colima','ssh','--profile','sail-gate','--','sudo','tar','-C','/var/lib/docker/volumes/sail-extension-targets/_data','--one-file-system',*['--exclude='+x for x in EXCLUDE],'-cf','-','.']
 r['archive_command']=cmd;save(r)
 with (BASE/'archive-source.log').open('xb') as source_log,(BASE/'archive-compressor.log').open('xb') as compress_log,archive.open('xb') as output:
  source=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=source_log);assert source.stdout is not None
  compressor=subprocess.Popen(['/usr/local/bin/zstd','-1','-T2','-c'],stdin=source.stdout,stdout=output,stderr=compress_log);source.stdout.close();r['source_pid']=source.pid;r['compressor_pid']=compressor.pid;save(r)
  compress_rc=compressor.wait();source_rc=source.wait();assert source_rc==compress_rc==0,(source_rc,compress_rc)
 r['outcome']='auditing_preserved_archive';r['archive_bytes']=archive.stat().st_size;save(r)
 with archive.open('rb') as stream:r['archive_sha256']=hashlib.file_digest(stream,'sha256').hexdigest()
 decoder=subprocess.Popen(['/usr/local/bin/zstd','-dc',str(archive)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert decoder.stdout is not None
 files=total=0
 with (BASE/'member-index.jsonl').open('x') as index,tarfile.open(fileobj=decoder.stdout,mode='r|') as contents:
  for member in contents:
   name=member.name.removeprefix('./');relative=Path(name or '.')
   assert not relative.is_absolute() and '..' not in relative.parts,name
   row={'path':member.name,'bytes':member.size,'mode':member.mode,'mtime':member.mtime,'kind':'file' if member.isfile() else 'directory' if member.isdir() else 'symlink' if member.issym() else 'hardlink' if member.islnk() else 'other'}
   assert row['kind']!='other',name
   if member.isfile():
    f=contents.extractfile(member);assert f is not None;h=hashlib.sha256();count=0
    while chunk:=f.read(8*2**20):h.update(chunk);count+=len(chunk)
    assert count==member.size;row['sha256']=h.hexdigest();files+=1;total+=count
   elif member.issym() or member.islnk():row['link_target']=member.linkname
   index.write(json.dumps(row,separators=(',',':'))+'\n')
 decoder.stdout.close();err=decoder.stderr.read() if decoder.stderr else b'';assert decoder.wait()==0,err
 r.update(outcome='data_preserved_and_full_archive_audited',member_files=files,uncompressed_regular_bytes=total,archive_finished_utc=utc());save(r)
 assert subprocess.check_output(DOCKER+['ps','-q'],text=True).strip()==''
 with (BASE/'stop.log').open('xb') as log:
  rc=subprocess.run(['/usr/local/bin/colima','stop','--profile','sail-gate'],stdout=log,stderr=subprocess.STDOUT).returncode;assert rc==0
 statuses=[json.loads(x) for x in subprocess.check_output(['/usr/local/bin/colima','list','--json'],text=True).splitlines()];assert next(x for x in statuses if x['name']=='sail-gate')['status']=='Stopped'
 r['stopped_before_deletion_utc']=utc();save(r)
 # All benchmark data are now in the audited portable archive; retain production profile separately.
 production=Path('/Users/alexy/.colima/default/colima.yaml');production_sha=hashlib.sha256(production.read_bytes()).hexdigest()
 with (BASE/'delete.log').open('xb') as log:
  argv=['/usr/local/bin/colima','--profile','sail-gate','delete','--data','--force'];rc=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT).returncode;r['delete_command']=argv;r['delete_returncode']=rc;assert rc==0
 assert not Path('/Users/alexy/.colima/_lima/_disks/colima-sail-gate/datadisk').exists()
 assert hashlib.sha256(production.read_bytes()).hexdigest()==production_sha
 r.update(outcome='graph_VM_deleted_data_preserved',finished_utc=utc(),main_free_bytes_after=shutil.disk_usage('/Users/alexy').free,production_config_sha256=production_sha);save(r)
 print(json.dumps({'outcome':r['outcome'],'archive':str(archive),'archive_bytes':r['archive_bytes'],'main_free_bytes_after':r['main_free_bytes_after']}),flush=True);return 0
if __name__=='__main__':sys.exit(main())
