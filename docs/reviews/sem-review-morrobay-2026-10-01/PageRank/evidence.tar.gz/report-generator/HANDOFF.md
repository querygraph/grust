# Native PageRank metadata report generator

Grust AGENTS governs this source-only preparation. The generator reads only bounded regular metadata/source files and already frozen small source archives. It refuses Parquet, binaries, wheels and large VM/data archives before opening them. Root remains responsible for native jobs and complete raw payload/identity/process audits.

## Commands

Run after all 21 cells and the independent root audit have closed:

```sh
/tmp/sem-output-oracle-venv/bin/python -B /tmp/sem-pagerank-report01/prepare_report.py --campaign /Volumes/Apo/graph-tests/results/sem-review-20261001/PageRank-native-pair01 --output /tmp/sem-pagerank-report01-generated01 --config /tmp/sem-pagerank-report01-config02.json
/tmp/sem-output-oracle-venv/bin/python -B /tmp/sem-pagerank-report01/generate_report.py --config /tmp/sem-pagerank-report01-config02.json
```

A normal script invocation includes its sibling source directory. For isolated `-I`, use a root-controlled `-c` bootstrap that inserts the exact helper directory before `runpy.run_path`; direct isolated script execution omits that directory.

Preparation verifies the final audit binds immutable queue and plan bytes, then pins all selected small metadata and source bytes. Generation requires the original fixed 21-cell order, every parent/child/exit/oracle/retention binding and all numeric/domain/cleanup predicates. It recomputes the four adjacent ratios per mode and requires exact equality with root's audited summaries. Every package input is checked again after archiving. An error retains generation-receipt.json and partial files, and refuses retry/resume in that destination.

`report.json` exposes `contrasts.{local,process-cluster}` with n_per_engine, paired_ratios, geometric_mean_ratio and maximum_absolute_error, and all 21 id/kind/mode/engine/outcome records. README gives only shared-host ratios; raw original seconds remain in portable JSON. INPUTS maps original absolute metadata paths to safe portable names. The complete physical evidence archive inventory and original helper source-archive inventory are retained, with a separately generated exact oracle source archive.

There is no new data or native qualification by this generator. Root's separately sealed complete raw retention/current source and input/client/process audit is authoritative. The tiny controls mock metadata reads and never import native helpers or engines. No original source or result bytes are changed.
