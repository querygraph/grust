"""Read and archive small regular metadata only; never open raw graph/result payloads."""
from __future__ import annotations

import hashlib
import io
import json
import re
import stat
import tarfile
from pathlib import Path, PurePosixPath
from typing import cast

import pydantic
import report_models as models

SUFFIXES = {".json", ".jsonl", ".log", ".txt", ".md", ".py", ".rs", ".toml",
            ".lock", ".patch", ".sh", ".yml", ".yaml"}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def relative(name: str) -> str:
    path = PurePosixPath(name)
    require(bool(name) and "\\" not in name and not path.is_absolute()
            and all(part not in (".", "..", "") for part in name.split("/"))
            and path.as_posix() == name, "unsafe archive relative name: " + name)
    return name


def permitted(path: Path) -> bool:
    return path.suffix in SUFFIXES or path.name == "source-only.tar.gz"


def read(path: Path, maximum: int = 64 * 2**20) -> bytes:
    require(permitted(path), "refusing nonmetadata/payload path: " + str(path))
    for part in (path, *path.parents):
        system_tmp = part == Path("/tmp") and part.resolve() == Path("/private/tmp")
        require(not part.is_symlink() or system_tmp, "symlink metadata path: " + str(path))
    info = path.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_size <= maximum,
            "nonregular or oversized metadata: " + str(path))
    with path.open("rb") as stream:
        result = stream.read(maximum + 1)
    require(len(result) == info.st_size and len(result) <= maximum,
            "metadata changed size during read")
    return result


def identity_bytes(data: bytes) -> models.Identity:
    return models.Identity(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def pin(path: Path) -> models.Pin:
    return models.Pin(path=path, **identity_bytes(read(path)).model_dump())


def verify(pin: models.Pin) -> bytes:
    data = read(pin.path)
    require(identity_bytes(data).model_dump() == pin.model_dump(exclude={"path"}),
            "changed metadata pin: " + str(pin.path))
    return data


def load(path: Path) -> models.Json:
    return models.JSON.validate_json(read(path))


def obj(value: pydantic.JsonValue, context: str) -> models.Json:
    require(isinstance(value, dict), "expected object: " + context)
    return cast(models.Json, value)


def array(value: pydantic.JsonValue, context: str) -> list[pydantic.JsonValue]:
    require(isinstance(value, list), "expected array: " + context)
    return cast(list[pydantic.JsonValue], value)


def number(value: pydantic.JsonValue, context: str) -> float:
    require(type(value) in (int, float), "expected number: " + context)
    return float(cast(float, value))


def true(record: models.Json, names: tuple[str, ...]) -> None:
    for name in names:
        require(record.get(name) is True, "required true predicate: " + name)


def equal(actual: pydantic.JsonValue, expected: pydantic.JsonValue, context: str) -> None:
    require(type(actual) is type(expected) and actual == expected, context)


def write(path: Path, record: models.Json) -> None:
    path.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")


def archive_inventory(data: bytes) -> dict[str, models.Identity]:
    require(len(data) <= 64 * 2**20, "source archive compressed bound")
    found: dict[str, models.Identity] = {}
    total = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        for member in archive:
            name = relative(member.name)
            timestamps = set(member.pax_headers) <= {"mtime"} and all(
                len(value) <= 128 and re.fullmatch(r"-?[0-9]+(?:\.[0-9]+)?", value) is not None
                for value in member.pax_headers.values())
            require(member.isfile() and timestamps and member.size <= 64 * 2**20,
                    "source archive must contain bounded plain regular files")
            require(permitted(Path(name)) and not name.endswith(".tar.gz"),
                    "source archive contains a payload or nested archive")
            require(name not in found and len(found) < 4096, "duplicate/too many archive members")
            require(not any(name.startswith(n + "/") or n.startswith(name + "/") for n in found),
                    "archive path shadow conflict")
            total += member.size
            require(total <= 128 * 2**20, "source archive expanded byte bound")
            stream = archive.extractfile(member)
            require(stream is not None, "missing regular archive stream")
            if stream is None:
                raise ValueError("archive member stream missing")
            with stream:
                payload = stream.read(member.size + 1)
            require(len(payload) == member.size, "archive member size mismatch")
            found[name] = identity_bytes(payload)
    require(bool(found), "empty source archive")
    return found


def pack(path: Path, files: dict[str, bytes]) -> models.Json:
    with tarfile.open(path, "w:gz", format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(files.items()):
            relative(name)
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.mtime = 0
            archive.addfile(member, io.BytesIO(data))
    # Package may contain already-verified source archives, so verify outer physical members directly.
    verified: models.Json = {}
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            name = relative(member.name)
            require(member.isfile() and name in files and name not in verified, "outer archive member differs")
            stream = archive.extractfile(member)
            if stream is None:
                raise ValueError("missing package member stream")
            with stream:
                payload = stream.read(member.size + 1)
            require(payload == files[name] and member.size == len(payload), "physical package bytes differ")
            verified[name] = identity_bytes(payload).model_dump()
    require(set(verified) == set(files), "incomplete physical package verification")
    return verified
