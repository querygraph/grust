"""Seal completed small PageRank metadata for a separate report destination."""
from __future__ import annotations

import argparse
from pathlib import Path

import report_io as io
import report_models as models
import report_qualify as qualify


def add(files: dict[str, models.Pin], name: str, path: Path,
        expected: models.Json | None = None) -> None:
    io.relative(name)
    io.require(name not in files, "duplicate report input name")
    actual = io.pin(path)
    if expected is not None:
        io.equal(actual.model_dump(exclude={"path"}),
                 {k: expected[k] for k in ("bytes", "sha256")}, "original declared metadata bytes differ")
    files[name] = actual


def tree(files: dict[str, models.Pin], prefix: str, root: Path) -> None:
    io.require(root.is_dir() and not root.is_symlink(), "missing or symlink source directory")
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError("symlink under source directory")
        if path.is_file() and io.permitted(path):
            add(files, prefix + "/" + path.relative_to(root).as_posix(), path)


def prepare(campaign: Path, output: Path) -> models.Configuration:
    # Refuse an unfinished/missing root audit before reading mutable queue data.
    audit_path = campaign / "root-audit01.json"
    audit = io.load(audit_path)
    io.equal(audit.get("outcome"), "passed_independent_native_pagerank_campaign_audit", "root audit not qualified")
    queue_pin = models.Pin.model_validate(audit.get("queue_pin"))
    plan_pin = models.Pin.model_validate(audit.get("plan_pin"))
    io.require(queue_pin.path == campaign / "queue.json" and plan_pin.path == campaign / "plan01.json",
               "audit campaign paths differ")
    plan = models.JSON.validate_json(io.verify(plan_pin))
    template_pin = models.Pin.model_validate(plan.get("template"))
    template = models.JSON.validate_json(io.verify(template_pin))
    files: dict[str, models.Pin] = {}
    # Only inspect the dedicated campaign/source directories; raw Parquet is never read.
    tree(files, "campaign", campaign)
    for role in ("helper", "oracle"):
        root = plan.get(role)
        io.require(isinstance(root, str), "source directory path missing")
        tree(files, "provenance/" + role, Path(str(root)))
    for name in ("client", "build", "retirement", "preservation", "reference_receipt", "source_admission"):
        pin = models.Pin.model_validate(template.get(name))
        add(files, "provenance/" + name + ".json", pin.path, pin.model_dump(mode="json"))
    manifest = io.load(models.Pin.model_validate(template.get("support_manifest")).path)
    repo = Path(str(qualify.at(template, "engine")["repo"]))
    for name, raw in qualify.at(manifest, "source_pins").items():
        io.relative(name)
        add(files, "provenance/controller/" + name, repo / name, io.obj(raw, "source pin"))
    for name, raw in qualify.at(manifest, "frozen_harness_files").items():
        pin = models.Pin.model_validate(raw)
        add(files, "provenance/harness/" + name, pin.path, pin.model_dump(mode="json"))
    audit_sources = io.load(Path(str(plan["oracle"])) / "source-contract-audit.json")
    for name, raw in qualify.at(audit_sources, "sources").items():
        pin = models.Pin.model_validate(raw)
        add(files, "provenance/source-contract/" + name + pin.path.suffix, pin.path, pin.model_dump(mode="json"))
    # Build/retirement roots are not walked: their targets/venvs and retired VM archive are excluded.
    build_root = models.Pin.model_validate(template["build"]).path.parent
    for name in ("launch.json", "owner.log", "sail-build.log", "graphframes-build.log", "sem-native-optimized-build01.py"):
        add(files, "provenance/build/" + name, build_root / name)
    retired_root = models.Pin.model_validate(template["retirement"]).path.parent
    for name in ("launch.json", "owner.log", "stop.log", "delete.log", "sem-graph-vm-retirement01.py"):
        add(files, "provenance/retirement/" + name, retired_root / name)
    source_root = models.Pin.model_validate(template["source_admission"]).path.parent
    add(files, "provenance/coordination-ack.json", source_root / "coordination-ack.json")
    for path in sorted(Path(__file__).parent.glob("*")):
        if path.is_file() and io.permitted(path):
            add(files, "report-generator/" + path.name, path)
    config = models.Configuration(campaign=campaign, output=output, queue=queue_pin, plan=plan_pin,
                                  audit=io.pin(audit_path), files=files)
    qualify.qualify(config)
    return config


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    io.require(not args.config.exists() and not args.output.exists(), "fresh config/output required")
    config = prepare(args.campaign, args.output)
    args.config.write_text(config.model_dump_json(indent=2) + "\n")
    print(config.model_dump_json(include={"queue", "plan", "audit"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
