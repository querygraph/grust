"""Generate a portable, independently bound native PageRank metadata report."""
from __future__ import annotations

import argparse
import datetime
import json
import traceback
from pathlib import Path

import report_io as io
import report_models as models
import report_qualify as qualify


def utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def readme(report: models.Json) -> str:
    contrasts = qualify.at(report, "contrasts")
    lines = ["# Native matched PageRank", "", "## Findings", "",
             ("All 21 outcomes qualified: one separate GraphFrames reference, four warmups, "
             "and two ABBA blocks per mode. Warmups and the reference are excluded from pairs; "
             "each mode has four measured calls per engine."), "",
             "| Mode | Four adjacent Pecan / GraphFrames ratios | Geometric mean | Maximum absolute error |",
             "| --- | --- | ---: | ---: |"]
    for mode in ("local", "process-cluster"):
        c = io.obj(contrasts[mode], "contrast")
        ratios = ", ".join(f"{io.number(v, 'ratio'):.6f}" for v in io.array(c["paired_ratios"], "ratios"))
        lines.append(f"| {mode} | {ratios} | {io.number(c['geometric_mean_ratio'], 'ratio'):.6f} | "
                     f"{io.number(c['maximum_absolute_error'], 'error'):.6g} |")
    lines += ["", ("These are ratios on shared Morrobay. A ratio above one means the Pecan "
              "launch through exit interval was longer in that adjacent pair."), "",
              "## Contract and timing", "",
              ("Both engines use the original directed edges with multiplicity; initial rank and delta "
              "0.15, damping 0.85, send on the first step and thereafter only when the previous delta "
              "exceeds 0.01, ten fixed steps, no dangling redistribution, and final normalization. "
              "Pecan uses `pregel_delta`, `vote_to_halt=False`, and `snapshot_inputs=False`."), "",
              ("The independent physical oracle checks every original vertex exactly once in raw "
              "`id: int64, pagerank: float64` outputs and compares each score with the separate "
              "GraphFrames reference at absolute tolerance `1e-12`. Reference preparation checks "
              "domain and finite physical values; it has no numerical self-comparison. "
              "All candidate outputs passed with zero mismatches."), "",
              ("The primary timer starts immediately before child Popen and ends after its waited exit. "
              "It includes startup, reads, algorithm actions, full raw Parquet export, and cleanup. "
              "The oracle and retention checks run afterward."), "",
              "## Sources and resources", "",
              ("Pecan controller `0d1ef2ca3`; optimized native Sail `9f0aa7d2a`; GraphFrames "
              "`b4da56dabe`; frozen Python runtime and measurement helpers `6ae2e43a9`. "
              "The controller and compiled Sail have an observed empty diff over `crates/`, "
              "`Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml`. "
              "The actual native optimized build, client admission, and input preservation are retained."), "",
              ("Local settings are 16 threads and 16 partitions with 30 GiB per engine's configured "
              "pool. GraphFrames uses FairSpillPool; Pecan uses greedy pools. Pecan process cluster "
              "has a driver and two workers, each configured with 16 threads and 10 GiB: "
              "48 possible threads and 30 GiB total pools. GraphFrames remains local with 16 "
              "threads and a 30 GiB pool. This is a disclosed resource asymmetry. "
              "These are software settings on a physical 128 GiB macOS host. There is no "
              "OS CPU, memory or swap cap and no PSS, cgroup or steal measurement. "
              "Retained periodic RSS observations may include shared pages and are sampled maxima."), "",
              "## Evidence", "",
              ("[report.json](report.json) retains all 21 outcomes and raw timer fields. "
              "[evidence.tar.gz](evidence.tar.gz) contains exact small original metadata, complete "
              "logs, source helpers and source archives. [INPUTS.json](INPUTS.json) maps every "
              "portable name to its original path and byte identity. "
              "[archive-verification.json](archive-verification.json) binds every physical archive "
              "member. Binaries and raw Parquet are represented by the independently audited "
              "inventories, and are not embedded. This report does not qualify generic LDBC PageRank."), ""]
    return "\n".join(lines)


def run(config_path: Path) -> int:
    config_pin = io.pin(config_path)
    config = models.Configuration.model_validate_json(io.verify(config_pin))
    io.require(not config.output.exists(), "refusing existing report destination; no retry/resume")
    config.output.mkdir(parents=True, exist_ok=False)
    receipt: models.Json = {"started_utc": utc(), "outcome": "checking", "configuration": config_pin.model_dump(mode="json"),
                           "errors": [], "production_payloads_read": False, "runtime_jobs_launched": False}
    io.write(config.output / "generation-receipt.json", receipt)
    try:
        report = qualify.qualify(config)
        files: dict[str, bytes] = {}
        nested: models.Json = {}
        total = 0
        for name, pin in sorted(config.files.items()):
            io.relative(name)
            data = io.verify(pin)
            total += len(data)
            io.require(total <= config.max_total_bytes, "metadata package exceeds sealed byte bound")
            if pin.path.name == "source-only.tar.gz":
                nested[name] = {n: p.model_dump() for n, p in io.archive_inventory(data).items()}
            files[name] = data
        originals: models.Json = {n: p.model_dump(mode="json") for n, p in config.files.items()}
        report["observed_utc"] = utc()
        io.write(config.output / "report.json", report)
        (config.output / "README.md").write_text(readme(report))
        io.write(config.output / "INPUTS.json", originals)
        # Oracle sources have no original source archive; make an exact portable source subset here.
        oracle_files = {n.removeprefix("provenance/oracle/"): data for n, data in files.items()
                        if n.startswith("provenance/oracle/") and not n.endswith(".tar.gz")}
        oracle_verified = io.pack(config.output / "oracle-source-only.tar.gz", oracle_files)
        files["oracle-source-only.tar.gz"] = (config.output / "oracle-source-only.tar.gz").read_bytes()
        for name in ("report.json", "README.md", "INPUTS.json"):
            files[name] = io.read(config.output / name)
        inventory = io.pack(config.output / "evidence.tar.gz", files)
        verification: models.Json = {"outcome": "passed_complete_physical_metadata_archive", "observed_utc": utc(),
                                    "files": inventory, "source_archives": nested,
                                    "oracle_source_archive_members": oracle_verified,
                                    "archive": io.identity_bytes((config.output / "evidence.tar.gz").read_bytes()).model_dump()}
        io.write(config.output / "archive-verification.json", verification)
        for pin in config.files.values():
            io.verify(pin)
        io.verify(config_pin)
        io.verify(config.queue)
        io.verify(config.plan)
        io.verify(config.audit)
        receipt.update(outcome="passed_metadata_only_pagerank_report_generation", finished_utc=utc(),
                       metadata_inputs_before_after_equal=True, file_count=len(files), total_metadata_bytes=total,
                       archive=verification["archive"], report=io.pin(config.output / "report.json").model_dump(mode="json"))
    except BaseException as error:  # noqa: BLE001 -- all failed packaging evidence remains durable.
        receipt.update(outcome="error", finished_utc=utc(), errors=[repr(error)], traceback=traceback.format_exc())
    io.write(config.output / "generation-receipt.json", receipt)
    print(json.dumps({k: receipt.get(k) for k in ("outcome", "file_count", "archive", "errors")}, allow_nan=False))
    return 0 if receipt["outcome"] == "passed_metadata_only_pagerank_report_generation" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    return run(parser.parse_args().config)


if __name__ == "__main__":
    raise SystemExit(main())
