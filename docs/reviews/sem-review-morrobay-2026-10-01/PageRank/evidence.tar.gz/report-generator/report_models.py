"""Bounded metadata inputs for a native matched PageRank report."""
from __future__ import annotations

import dataclasses
from pathlib import Path
from typing import Literal

import pydantic

Json = dict[str, pydantic.JsonValue]
JSON = pydantic.TypeAdapter(Json)


class Record(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="forbid", frozen=True)


class Identity(Record):
    bytes: int = pydantic.Field(ge=0, le=64 * 2**20)
    sha256: str = pydantic.Field(pattern=r"^[0-9a-f]{64}$")


class Pin(Identity):
    path: Path

    @pydantic.model_validator(mode="after")
    def absolute(self) -> Pin:
        if not self.path.is_absolute():
            raise ValueError("metadata pin must have an absolute path")
        return self


class Configuration(Record):
    campaign: Path
    output: Path
    queue: Pin
    plan: Pin
    audit: Pin
    files: dict[str, Pin]
    max_total_bytes: int = pydantic.Field(default=512 * 2**20, ge=1, le=2**30)

    @pydantic.model_validator(mode="after")
    def paths(self) -> Configuration:
        if not self.campaign.is_absolute() or not self.output.is_absolute():
            raise ValueError("campaign/output paths must be absolute")
        if self.output == self.campaign or self.campaign in self.output.parents:
            raise ValueError("report destination must be outside the original campaign")
        return self


@dataclasses.dataclass(frozen=True, slots=True)
class Cell:
    id: str
    mode: Literal["local", "process-cluster"]
    engine: Literal["graphframes", "pecan"]
    kind: Literal["reference", "warmup", "measured"]
    block: int | None = None
    position: int | None = None

    def as_json(self) -> Json:
        return JSON.validate_python(dataclasses.asdict(self))


def sequence() -> tuple[Cell, ...]:
    cells = [Cell("reference-graphframes", "local", "graphframes", "reference")]
    modes: tuple[Literal["local", "process-cluster"], ...] = ("local", "process-cluster")
    engines: tuple[Literal["graphframes", "pecan"], ...] = ("graphframes", "pecan")
    order: tuple[Literal["graphframes", "pecan"], ...] = ("graphframes", "pecan", "pecan", "graphframes")
    for mode in modes:
        for engine in engines:
            cells.append(Cell(f"{mode}-warmup-{engine}", mode, engine, "warmup"))
        for block in (1, 2):
            for position, engine in enumerate(order, 1):
                cells.append(Cell(f"{mode}-block{block}-step{position}-{engine}", mode,
                                  engine, "measured", block, position))
    return tuple(cells)
