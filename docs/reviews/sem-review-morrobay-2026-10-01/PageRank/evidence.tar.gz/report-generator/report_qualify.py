"""Bind final root metadata; physical graph/result checks belong to the independent audit."""
from __future__ import annotations

import math
from pathlib import Path

import pydantic
import report_io as io
import report_models as models

CONTROLLER = "0d1ef2ca3c3320a1ac9059f09ea4e0bcb7e4fb97"
RUNTIME = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
GRAPHFRAMES = "b4da56dabe20bba8e29563e06acc5179b2113ce3"
DOMAIN = 3_774_768


def at(record: models.Json, key: str) -> models.Json:
    return io.obj(record.get(key), key)


def same_pin(value: pydantic.JsonValue, pin: models.Pin, context: str) -> None:
    io.equal(value, pin.model_dump(mode="json"), context)


def lookup(config: models.Configuration, name: str) -> models.Json:
    io.require(name in config.files, "missing sealed report input: " + name)
    return models.JSON.validate_json(io.verify(config.files[name]))


def final_inputs(config: models.Configuration) -> tuple[models.Json, models.Json, models.Json]:
    audit = models.JSON.validate_json(io.verify(config.audit))
    io.equal(audit.get("outcome"), "passed_independent_native_pagerank_campaign_audit", "root audit not passed")
    io.true(audit, ("all_owned_pid_and_group_absent", "shared_locks_absent", "source_input_client_closure"))
    io.equal(audit.get("owned_processes_remaining"), [], "owned process remains")
    io.equal(audit.get("matching_native_servers_remaining"), [], "matching native server remains")
    same_pin(audit.get("queue_pin"), config.queue, "audit binds another queue")
    same_pin(audit.get("plan_pin"), config.plan, "audit binds another plan")
    queue = models.JSON.validate_json(io.verify(config.queue))
    plan = models.JSON.validate_json(io.verify(config.plan))
    io.equal(queue.get("outcome"), "qualified_native_pagerank_local_and_process_cluster_pairs", "queue not qualified")
    io.equal(queue.get("errors"), [], "queue errors retained")
    io.equal(queue.get("forced_parent_cancellation"), False, "queue forced cancellation")
    io.require(isinstance(queue.get("finished_utc"), str) and bool(queue["finished_utc"]), "unfinished queue")
    same_pin(queue.get("plan_before"), config.plan, "queue before plan differs")
    same_pin(queue.get("plan_after"), config.plan, "queue after plan differs")
    io.equal(queue.get("source_before"), queue.get("source_after"), "queue source changed")
    io.equal(queue.get("source_before"), plan.get("source"), "queue source differs from plan")
    same_pin(plan.get("source"), config.files["campaign/root-queue01.py"], "root queue source not sealed")
    same_pin(audit.get("source_pin"), config.files["campaign/root-audit-source01.py"], "root audit source not sealed")
    same_pin(plan.get("template"), config.files["campaign/template01.json"], "template not sealed")
    return queue, plan, audit


def intended(cell: models.Cell) -> models.Json:
    result = cell.as_json()
    result["contrast_mode"] = result.pop("mode")
    return result


def contract(engine: models.Json, cell: models.Cell) -> None:
    for key, expected in {"engine": cell.engine, "algorithm": "pagerank", "method": "pregel_delta",
                          "reset_probability": 0.15, "tolerance": 0.01, "max_iterations": 10,
                          "normalize": True, "vote_to_halt": False, "snapshot_inputs": False,
                          "partitions": 16, "native_quota": 268_435_456}.items():
        io.equal(engine.get(key), expected, "engine contract differs: " + key)
    cluster = cell.engine == "pecan" and cell.mode == "process-cluster"
    io.equal(engine.get("mode"), "process-cluster" if cluster else "local", "engine mode differs")
    io.equal(engine.get("pool_bytes"), (10 if cluster else 30) * 2**30, "software pool differs")


def physical_schemas(oracle: models.Json, proof: models.Json) -> None:
    schemas = at(oracle, "physical_schemas")
    candidate = io.array(schemas.get("candidate"), "candidate schemas")
    files = at(proof, "raw_files")
    names: set[str] = set()
    rows = 0
    for raw in candidate:
        schema = io.obj(raw, "physical schema")
        name = schema.get("file")
        io.require(isinstance(name, str) and name not in names and name in files, "physical footer file mismatch")
        if not isinstance(name, str):
            raise TypeError("physical schema name missing")
        names.add(name)
        fields = [io.obj(v, "field") for v in io.array(schema.get("fields"), "fields")]
        io.require(len(fields) == 2 and {f.get("name") for f in fields} == {"id", "pagerank"}, "wrong field names")
        for field in fields:
            io.equal(field.get("arrow_type"), "int64" if field.get("name") == "id" else "double", "raw type differs")
        count = schema.get("footer_rows")
        io.require(type(count) is int and io.number(count, "footer_rows") >= 0, "invalid footer count")
        rows += int(io.number(count, "footer_rows"))
    io.require(names == {n for n in files if n.endswith(".parquet")} and rows == DOMAIN, "full footer coverage differs")


def qualify_cell(config: models.Configuration, cell: models.Cell, state: models.Json,
                 audit: models.Json, reference: pydantic.JsonValue) -> models.Json:
    cid = cell.id
    prefix = "campaign/cells/" + cid + "/"
    cfg = lookup(config, prefix + "configuration.json")
    parent = lookup(config, prefix + "receipt.json")
    child = lookup(config, prefix + "raw-output/engine-receipt.json")
    oracle = lookup(config, prefix + "correctness.json")
    proof = lookup(config, prefix + "engine-exited.json")
    sampler = lookup(config, prefix + "sampler-receipt.json")
    retention = lookup(config, prefix + "retention-index.json")
    for name in ("child.log", "native-memory.jsonl"):
        io.require(prefix + name in config.files, "missing complete cell log: " + name)
    io.require("campaign/logs/" + cid + ".log" in config.files, "missing parent launch log")
    for name, raw_identity in retention.items():
        io.relative(name)
        if io.permitted(Path(name)):
            pin = config.files.get(prefix + "raw-output/" + name)
            io.require(pin is not None, "missing retained raw metadata/log: " + name)
            if pin is None:
                raise ValueError("missing metadata pin")
            io.equal(pin.model_dump(exclude={"path"}), raw_identity, "retained raw metadata identity differs")
    io.equal(lookup(config, prefix + "oracle/receipt.json"), oracle, "two oracle copies differ")
    io.equal(lookup(config, prefix + "child-config.json"), at(cfg, "engine"), "child config differs")
    io.equal(parent.get("config"), cfg, "parent config differs")
    io.equal(parent.get("child"), child, "parent child copy differs")
    io.equal(parent.get("correctness"), oracle, "parent correctness differs")
    io.equal(parent.get("sampler"), sampler, "sampler copy differs")
    io.equal(parent.get("retention_files"), retention, "retention index differs")
    expected = "reference_prepared" if cell.kind == "reference" else "passed_matched_pr_diagnostic"
    for record in (parent, state):
        io.equal(record.get("outcome"), expected, "cell outcome not qualified")
        io.equal(record.get("returncode"), 0, "nonzero engine/parent exit")
    queue_config = config.files["campaign/configs/" + cid + ".json"]
    io.equal(models.JSON.validate_json(io.verify(queue_config)), cfg, "sealed queue/cell config copies differ")
    same_pin(state.get("configuration"), queue_config, "queue config pin differs")
    same_pin(state.get("receipt"), config.files[prefix + "receipt.json"], "queue receipt pin differs")
    same_pin(audit.get("config_pin"), queue_config, "audit config pin differs")
    same_pin(audit.get("receipt_pin"), config.files[prefix + "receipt.json"], "audit receipt pin differs")
    io.equal(state.get("launch_to_exit_seconds"), parent.get("launch_to_exit_seconds"), "queue timer differs")
    duration = io.number(parent.get("launch_to_exit_seconds"), "actual primary timer")
    io.require(math.isfinite(duration) and duration > 0, "invalid primary timer")
    io.true(parent, ("child_group_absent", "server_group_absent", "worker_processes_absent",
                     "matching_server_absent", "retention_verified", "locks_released"))
    io.true(audit, ("source_client_identity_closure", "full_output_retention_qualified", "full_physical_domain_passed"))
    io.equal(parent.get("errors"), [], "parent errors")
    io.equal(child.get("outcome"), "passed", "child not passed")
    io.equal(child.get("cleanup_errors"), [], "child cleanup error")
    io.equal(child.get("error"), None, "child error")
    io.equal(parent.get("before"), parent.get("after"), "identity closure changed")
    io.equal(parent.get("source_before"), parent.get("source_after"), "source closure changed")
    source = at(parent, "source_after")
    for key, expected_source in {"commit": CONTROLLER, "compiled_runtime": RUNTIME,
                                 "graphframes_commit": GRAPHFRAMES,
                                 "compiled_runtime_paths_parity": "empty diff"}.items():
        io.equal(source.get(key), expected_source, "source identity differs: " + key)
    engine = at(cfg, "engine")
    contract(engine, cell)
    io.equal(cfg.get("run_id"), cid, "run ID differs")
    io.equal(cfg.get("contrast_mode"), cell.mode, "contrast mode differs")
    io.equal(cfg.get("reference_preparation_only"), cell.kind == "reference", "reference mode differs")
    if cell.kind != "reference":
        io.equal(cfg.get("reference"), reference, "candidate binds another GF reference")
    io.equal(lookup(config, prefix + "oracle-config.json"), at(oracle, "config"), "oracle config differs")
    same_pin(parent.get("engine_exited"), config.files[prefix + "engine-exited.json"], "parent exit proof pin differs")
    io.true(proof, ("wait_completed", "child_group_absent", "server_group_absent"))
    io.equal(proof.get("returncode"), 0, "producer nonzero return")
    io.equal(proof.get("run_id"), cid, "producer run ID differs")
    io.equal(proof.get("engine"), cell.engine, "producer engine differs")
    io.equal(proof.get("child_pid"), parent.get("child_pid"), "producer child differs")
    candidate = at(at(oracle, "config"), "candidate")
    same_pin(at(candidate, "exit").get("producer_receipt"), config.files[prefix + "engine-exited.json"], "oracle producer differs")
    io.equal(candidate.get("files"), proof.get("raw_files"), "oracle raw inventory differs")
    io.equal(candidate.get("directory"), proof.get("raw_directory"), "oracle raw directory differs")
    io.equal(audit.get("raw_result_files"), proof.get("raw_files"), "audit raw result inventory differs")
    io.equal(audit.get("retained_files"), retention, "audit retention inventory differs")
    raw = {n.removeprefix("result/"): value for n, value in retention.items() if n.startswith("result/")}
    io.equal(raw, proof.get("raw_files"), "retained result inventory differs")
    total = sum(int(io.number(io.obj(v, "file").get("bytes"), "file bytes")) for v in retention.values())
    io.equal(audit.get("retained_total_bytes"), total, "audit retained total differs")
    for key in ("child_pid", "server_pid"):
        io.equal(audit.get(key), parent.get(key), "audit ownership differs: " + key)
    io.equal(audit.get("parent_pid"), state.get("parent_pid"), "audit parent differs")
    io.equal(audit.get("workers"), sampler.get("owned_workers"), "audit workers differ")
    io.require(sampler.get("error") is None and sampler.get("thread_alive") is False
               and io.number(sampler.get("execution_samples"), "execution_samples") > 0, "sampler failed")
    if cell.engine == "pecan" and cell.mode == "process-cluster":
        io.require(io.number(sampler.get("max_simultaneous_workers"), "workers") >= 2
                   and len(io.array(sampler.get("owned_workers"), "workers")) >= 2, "workers not observed")
    io.true(oracle, ("own_identity_closure_passed", "full_physical_domain_passed"))
    io.equal(oracle.get("identity_before"), oracle.get("identity_after"), "oracle identity changed")
    io.equal(oracle.get("error"), None, "oracle error")
    io.equal(oracle.get("integrity_errors"), [], "oracle closure errors")
    for key in ("expected_domain_rows", "reference_rows", "candidate_rows", "unique_candidate_rows"):
        io.equal(oracle.get(key), DOMAIN, "full domain differs: " + key)
    for key in ("numeric_mismatches",):
        io.equal(oracle.get(key), 0, "numeric mismatch")
        io.equal(audit.get(key), 0, "audit numeric mismatch")
    reference_only = cell.kind == "reference"
    io.equal(oracle.get("outcome"), "reference_prepared" if reference_only else "passed_full_physical_pagerank", "oracle verdict differs")
    io.equal(oracle.get("absolute_bound"), 1e-12, "numerical envelope differs")
    io.equal(oracle.get("absolute_bound_hex"), "0x1.19799812dea11p-40", "numerical binary64 bound differs")
    for record in (oracle, audit):
        io.equal(record.get("compared_rows"), 0 if reference_only else DOMAIN, "comparison count differs")
        io.equal(record.get("full_numeric_comparison_passed"), not reference_only, "numeric self-comparison/unqualified output")
    io.equal(audit.get("reference_preparation_only"), reference_only, "audit reference mode differs")
    io.equal(audit.get("full_domain_rows"), DOMAIN, "audit domain differs")
    for key in ("max_absolute_error", "max_relative_error"):
        io.equal(audit.get(key), oracle.get(key), "audit numeric diagnostic differs")
    physical_schemas(oracle, proof)
    return {**cell.as_json(), "outcome": expected, "launch_to_exit_seconds": duration,
            "configuration": config.files[prefix + "configuration.json"].model_dump(mode="json"),
            "receipt": config.files[prefix + "receipt.json"].model_dump(mode="json"),
            "full_domain_rows": DOMAIN, "compared_rows": 0 if reference_only else DOMAIN,
            "numeric_mismatches": 0, "maximum_absolute_error": oracle.get("max_absolute_error"),
            "maximum_relative_error": oracle.get("max_relative_error"), "retained_total_bytes": total,
            "sampled_rss_sum_bytes": sampler.get("max_sampled_rss_sum_bytes"),
            "observed_workers": sampler.get("owned_workers"), "full_output_retention_qualified": True}


def qualify(config: models.Configuration) -> models.Json:
    queue, plan, audit = final_inputs(config)
    cells = models.sequence()
    planned = io.array(plan.get("cells"), "plan cells")
    states = io.array(queue.get("cells"), "queue cells")
    audits = io.array(audit.get("cells"), "audit cells")
    io.require(len(planned) == len(states) == len(audits) == 21, "all21 outcomes required")
    actual: list[pydantic.JsonValue] = []
    for cell, p, s, a in zip(cells, planned, states, audits, strict=True):
        state, audited = io.obj(s, "state"), io.obj(a, "cell audit")
        io.equal(p, intended(cell), "plan changes original exact order")
        io.equal(state.get("cell"), p, "queue order differs")
        for key, expected in (("id", cell.id), ("kind", cell.kind), ("mode", cell.mode), ("engine", cell.engine)):
            io.equal(audited.get(key), expected, "audit cell order/binding differs")
        actual.append(qualify_cell(config, cell, state, audited, queue.get("reference")))
    contrasts: models.Json = {}
    summaries = at(audit, "summary")
    io.require(set(summaries) == {"local", "process-cluster"}, "both contrasts required")
    for mode in ("local", "process-cluster"):
        summary = io.obj(summaries[mode], "summary")
        io.equal(summary.get("n_per_engine"), 4, "exact four measured per engine required")
        measured = [io.obj(c, "cell") for c in actual if io.obj(c, "cell").get("mode") == mode
                    and io.obj(c, "cell").get("kind") == "measured"]
        times = {str(c["id"]): io.number(c.get("launch_to_exit_seconds"), "timer") for c in measured}
        ratios: list[pydantic.JsonValue] = []
        for block in (1, 2):
            ratios.extend((times[f"{mode}-block{block}-step2-pecan"] / times[f"{mode}-block{block}-step1-graphframes"],
                           times[f"{mode}-block{block}-step3-pecan"] / times[f"{mode}-block{block}-step4-graphframes"]))
        io.equal(summary.get("paired_ratios"), ratios, "adjacent paired ratios differ")
        mean = math.exp(sum(math.log(io.number(v, "ratio")) for v in ratios) / 4)
        io.equal(summary.get("geometric_mean_ratio"), mean, "geometric mean differs")
        maximum = max(io.number(io.obj(c, "cell").get("maximum_absolute_error"), "max error") for c in actual
                      if io.obj(c, "cell").get("mode") == mode and io.obj(c, "cell").get("engine") == "pecan")
        io.equal(summary.get("maximum_absolute_error"), maximum, "maximum numeric error differs")
        contrasts[mode] = summary
    return {"schema_version": 1, "outcome": "qualified_native_pagerank_shared_host_report",
            "cells": actual, "contrasts": contrasts, "independent_audit": config.audit.model_dump(mode="json"),
            "original_queue": config.queue.model_dump(mode="json"), "original_plan": config.plan.model_dump(mode="json"),
            "source": {"controller": CONTROLLER, "compiled_runtime": RUNTIME, "graphframes": GRAPHFRAMES,
                       "harness": "6ae2e43a903c2cee02da170465c922c72b76198e", "rust_paths_parity": "empty diff"},
            "scope": {"shared_host_ratios_only": True, "native_macos": True, "snapshot_inputs": False,
                      "os_resource_caps": False, "equal_cpu_envelope": False,
                      "pss_cgroups_steal_observed": False, "generic_ldbc_pagerank_qualification": False,
                      "timing_boundary": "Popen through waited child exit including lifecycle, full raw export and cleanup; oracle/retention afterward",
                      "absolute_comparison_bound": 1e-12}}
