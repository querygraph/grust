"""Typed publication plan and metadata adapters; no native or payload imports."""
from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Annotated, Literal, Self

import pr_native_models as native
from pydantic import BaseModel, ConfigDict, Field, model_validator

PREFIX = "docs/reviews/sem-review-morrobay-2026-10-01"
SOURCE = native.SOURCE
RUNTIME = native.RUNTIME
GF_SOURCE = native.GF_SOURCE
HARNESS = native.HARNESS
ROWS = native.ROWS
MODEL_HASHES = {
    "pr_native_models.py": "331ad63bcdf2be2efc04dceb9e0a71fed37c924fb272ac796b8093e33187a9af",
    "pr_oracle_models.py": "fbb694b8f13e18a91d99f8d6464edee9bed126be926b5cfa0521d556dd6c57f8",
    "f0_models.py": "37cbed1265b13c0c134bfb7ba8a4b28e4eae590497ac8e94f9474fcfb80f528d",
}


class Record(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Identity(Record):
    bytes: int = Field(strict=True, ge=0, le=128 * 2**20)
    sha256: str = Field(strict=True, pattern=r"^[0-9a-f]{64}$")


class Revision(Record):
    head: str = Field(pattern=r"^[0-9a-f]{40}$")
    tree: str = Field(pattern=r"^[0-9a-f]{40}$")
    parent: str = Field(pattern=r"^[0-9a-f]{40}$")


class State(Revision):
    status: str
    detached: bool


def relative(name: str) -> str:
    path = PurePosixPath(name)
    if not name or path.is_absolute() or path.as_posix() != name or any(p in {".", ".."} for p in path.parts):
        raise ValueError("canonical safe relative metadata path required")
    return name


class FileRef(Record):
    kind: Literal["file"] = "file"
    file: str


class MemberRef(Record):
    kind: Literal["member"] = "member"
    file: str
    member: str


Evidence = Annotated[FileRef | MemberRef, Field(discriminator="kind")]


class PageRankPaths(Record):
    plan: Evidence
    queue: Evidence
    audit: Evidence
    report: Evidence


class F0Paths(Record):
    build: Evidence
    receipt: Evidence
    audit: Evidence
    report: Evidence


class Plan(Record):
    schema_version: Literal[1] = 1
    candidate: Revision
    committed: Revision | None = None
    files: dict[str, Identity]
    archives: dict[str, dict[str, Identity]]
    coordination_append: str
    append_only: dict[str, str] = Field(default_factory=dict)
    origins: dict[str, Evidence]
    pagerank: PageRankPaths
    f0: F0Paths
    deadline_seconds: int = Field(default=300, ge=30, le=900)

    @model_validator(mode="after")
    def scope(self) -> Self:
        historical = {f"{PREFIX}/A2/README.md", f"{PREFIX}/A3/README.md"}
        allowed = (f"{PREFIX}/F0/", f"{PREFIX}/PageRank/")
        if not self.coordination_append or "codex-to-codex.md" not in self.files:
            raise ValueError("exact nonempty coordination append required")
        if set(self.append_only) != set(self.files) & historical:
            raise ValueError("every changed historical README needs an exact append")
        if sum(p.bytes for p in self.files.values()) > 128 * 2**20 or len(self.files) > 2048:
            raise ValueError("bounded portable publication inventory exceeded")
        for name in self.files:
            relative(name)
            if name != "codex-to-codex.md" and name not in historical and not name.startswith(allowed):
                raise ValueError("publication file outside exact task scope")
        for prefix in allowed:
            if prefix + "README.md" not in self.files:
                raise ValueError("both standalone reports required")
        if len(self.archives) > 16:
            raise ValueError("bounded archive count exceeded")
        if sum(p.bytes for members in self.archives.values() for p in members.values()) > 128 * 2**20:
            raise ValueError("cumulative portable metadata archive expansion exceeded")
        for name, members in self.archives.items():
            if name not in self.files or not members or len(members) > 32768:
                raise ValueError("archive must be a pinned publication file with a full bounded inventory")
            if sum(p.bytes for p in members.values()) > 128 * 2**20:
                raise ValueError("bounded metadata archive expansion exceeded")
            for member in members:
                relative(member)
        references = [*self.origins.values(), *self.pagerank.__dict__.values(), *self.f0.__dict__.values()]
        for ref in references:
            if ref.file not in self.files:
                raise ValueError("evidence file missing from exact file pins")
            if isinstance(ref, MemberRef) and ref.member not in self.archives.get(ref.file, {}):
                raise ValueError("evidence member missing from complete archive pins")
        for original in self.origins:
            if not Path(original).is_absolute() or ".." in Path(original).parts:
                raise ValueError("original metadata pin mapping must use canonical absolute paths")
        if self.committed and (self.committed.tree, self.committed.parent) != (self.candidate.tree, self.candidate.parent):
            raise ValueError("committed gate must cover the same exact tree and parent")
        return self


class Cell(Record):
    id: str
    contrast_mode: Literal["local", "process-cluster"]
    engine: Literal["graphframes", "pecan"]
    kind: Literal["reference", "warmup", "measured"]
    block: int | None = None
    position: int | None = None


class CellState(Record):
    cell: Cell
    outcome: str
    parent_pid: int | None
    returncode: int | None
    configuration: native.Pin | None
    receipt: native.Pin | None
    started_utc: str | None
    finished_utc: str | None
    launch_to_exit_seconds: float | None
    reason: str | None


class QueuePlan(Record):
    root: Path
    helper: Path
    oracle: Path
    template: native.Pin
    source: native.Pin
    graphframes_binary: Path
    pecan_binary: Path
    ssd_root: Path
    cells: list[Cell]


class Queue(Record):
    started_utc: str
    owner_pid: int
    plan_before: native.Pin
    source_before: native.Pin
    outcome: str
    finished_utc: str | None
    plan_after: native.Pin | None
    source_after: native.Pin | None
    reference: native.ResultDataset | None
    cells: list[CellState]
    errors: list[str]
    traceback: str | None
    forced_parent_cancellation: bool


class RatioSummary(Record):
    n_per_engine: Literal[4]
    paired_ratios: tuple[float, float, float, float]
    geometric_mean_ratio: float
    maximum_absolute_error: float


class AuditCell(BaseModel):
    model_config = ConfigDict(extra="allow", allow_inf_nan=False)
    id: str
    kind: str
    mode: str
    engine: str
    parent_pid: int
    child_pid: int
    server_pid: int | None
    workers: list[native.Process]
    config_pin: native.Pin
    receipt_pin: native.Pin
    retained_files: dict[str, native.Identity]
    raw_result_files: dict[str, native.Identity]
    retained_total_bytes: int
    source_client_identity_closure: bool
    full_output_retention_qualified: bool
    full_domain_rows: int
    compared_rows: int
    numeric_mismatches: int
    full_numeric_comparison_passed: bool
    reference_preparation_only: bool
    max_absolute_error: float | None = None
    max_relative_error: float | None = None
    full_physical_domain_passed: bool


class RootAudit(BaseModel):
    model_config = ConfigDict(extra="allow", allow_inf_nan=False)
    outcome: Literal["passed_independent_native_pagerank_campaign_audit"]
    observed_utc: str
    queue_pin: native.Pin
    plan_pin: native.Pin
    all_owned_pid_and_group_absent: bool
    shared_locks_absent: bool
    owned_processes_remaining: list[str]
    matching_native_servers_remaining: list[str]
    source_input_client_closure: bool
    cells: list[AuditCell]
    summary: dict[str, RatioSummary]
