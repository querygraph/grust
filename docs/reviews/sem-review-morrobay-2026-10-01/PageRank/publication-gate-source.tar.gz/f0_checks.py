"""Exact checksum-guarded F0 diagnostic, compiler and retained closure checks."""
from __future__ import annotations

from typing import cast

import f0_models as frozen
from publication_io import Store, identity, obj, require, rows
from publication_models import Plan
from pydantic import JsonValue

SOURCE_PINS = {
    "Cargo.toml": (366, "a34793a74084ed31ea2b950e98403df542c501f68aefba73d3103c3aaf7ab672"),
    "Cargo.lock": (20599, "53211a0a5e2c1972ade3f97dab33e00f8cec249b142d5214676895d9a41c2136"),
    "src/main.rs": (9538, "9789d0e4912f0334e157f9f4273e56fd6de1ab89f7b092b784e2c6173180573a"),
}


def f0(store: Store, plan: Plan) -> dict[str, JsonValue]:
    build = store.model(plan.f0.build, frozen.RootBuild)
    receipt = store.model(plan.f0.receipt, frozen.Receipt)
    require(bool(build.finished_utc) and not build.errors and build.source_before == build.source_after,
            "F0 native optimized build/source closure failed")
    require(build.cargo_version.startswith("cargo 1.98.1 ") and "release: 1.98.1\n" in build.rustc_verbose,
            "F0 actual compiler differs from declared1.98.1")
    required_environment = {"CARGO_PROFILE_RELEASE_OPT_LEVEL": "3", "CARGO_PROFILE_RELEASE_DEBUG": "0",
                            "CARGO_PROFILE_RELEASE_CODEGEN_UNITS": "1", "CARGO_PROFILE_RELEASE_STRIP": "true",
                            "CARGO_INCREMENTAL": "0", "CARGO_PROFILE_RELEASE_LTO": "thin", "CARGO_BUILD_JOBS": "8"}
    require(all(build.environment.get(k) == v for k, v in required_environment.items()), "F0 exact optimization profile differs")
    require(build.command == ("/Users/alexy/.cargo/bin/cargo", "build", "--locked", "--release", "--manifest-path",
                              str(receipt.config.source_root / "csr-floor/Cargo.toml")), "F0 actual release build command differs")
    require(set(build.source_before) == set(SOURCE_PINS), "F0 three exact compiled source files required")
    for name, (size, sha) in SOURCE_PINS.items():
        pin = build.source_before[name]
        require((pin.bytes, pin.sha256) == (size, sha), "F0 frozen source pin differs")
        store.pin_data(pin.path, pin.bytes, pin.sha256)
    require(receipt.outcome == "completed_internal_guards" and bool(receipt.finished_utc) and not receipt.errors
            and receipt.locks_released is True and receipt.before == receipt.after and bool(receipt.before),
            "F0 diagnostic/source/owned closure did not finalize")
    require(receipt.config.source_commit == frozen.SOURCE and receipt.binary is None and receipt.config.binary == build.binary,
            "F0 selected source/build/binary binding differs")
    require(receipt.config.build_receipt is not None and identity(store.data(plan.f0.build)).model_dump()
            == receipt.config.build_receipt.model_dump(exclude={"path"}), "F0 immutable build receipt pin differs")
    require(receipt.before == {str(p.path): frozen.Identity(bytes=p.bytes, sha256=p.sha256)
                              for p in (*receipt.config.pins(), receipt.config_pin)},
            "F0 full actual source/tool/config/input pin set differs")
    config_data = store.pin_data(receipt.config_pin.path, receipt.config_pin.bytes, receipt.config_pin.sha256)
    require(frozen.Config.model_validate_json(config_data) == receipt.config, "F0 original configuration byte binding differs")
    require(str(receipt.config.cargo.path) == "/Users/alexy/.rustup/toolchains/stable-x86_64-apple-darwin/bin/cargo"
            and str(receipt.config.rustc.path) == "/Users/alexy/.rustup/toolchains/stable-x86_64-apple-darwin/bin/rustc",
            "F0 concrete cell tool identities differ from observed dispatcher build")
    for pin in (*receipt.config.source_files, *receipt.config.helper_files):
        store.pin_data(pin.path, pin.bytes, pin.sha256)
    audit = store.object(plan.f0.audit)
    require(audit.get("outcome") == "passed_independent_F0_receipt_artifact_and_process_closure_audit"
            and bool(audit.get("observed_utc")) and audit.get("remaining_pid_or_group_rows") == []
            and audit.get("before_after_pins_equal") is True and audit.get("all_four_returncode0_internal_guards") is True
            and audit.get("shared_locks_absent") is True, "F0 independent closure audit failed")
    require([c.id for c in receipt.children] == list(frozen.ORDER)
            and audit.get("parent_and_child_ids") == [receipt.parent_pid, *[c.pid for c in receipt.children]],
            "F0 all four actual child IDs/observed closure differ")
    inventory: dict[str, JsonValue] = {"receipt.json": cast(JsonValue, identity(store.data(plan.f0.receipt)).model_dump())}
    for index, child in enumerate(receipt.children):
        require(child.outcome == "passed_internal_guard" and child.returncode == 0 and child.forced_cleanup is False
                and child.timed_out is False and child.group_remaining == () and child.error is None
                and bool(child.finished_utc) and child.result is not None, "F0 actual checksum guard or natural closure failed")
        result = cast(frozen.NativeResult, child.result)
        dataset = receipt.config.datasets[index // 2]
        require(result.vertices == dataset.vertex_rows and result.edges == dataset.edge_rows
                and result.arcs == dataset.edge_rows * (2 if index % 2 else 1) and result.undirected is bool(index % 2)
                and result.target_bits == 32 and result.id_mapping == "direct table" and result.threads == 4,
                "F0 original count/layout guard contract differs")
        require(result.csr_bytes == (result.vertices + 1) * 8 + result.arcs * 4 + result.vertices * 8,
                "F0 declared CSR layout arithmetic differs")
        for name, artifact in (("stdout.txt", child.stdout), ("stderr.txt", child.stderr), ("time.txt", child.time_record)):
            require(artifact is not None, "F0 every raw output/time/stderr pin required")
            raw = store.pin_data(receipt.config.output / child.id / name, cast(frozen.Identity, artifact).bytes,
                                 cast(frozen.Identity, artifact).sha256)
            inventory[child.id + "/" + name] = cast(JsonValue, identity(raw).model_dump())
            if name == "stdout.txt":
                require(frozen.NativeResult.model_validate_json(raw) == result, "F0 original stdout differs from receipt")
    require(audit.get("files") == inventory and audit.get("total_bytes") == sum(cast(int, obj(v)["bytes"]) for v in inventory.values()),
            "F0 complete13 artifact byte/hash audit binding differs")
    report = store.object(plan.f0.report)
    qualification = obj(report.get("qualification"))
    require(report.get("source_commit") == frozen.SOURCE and report.get("outcome") == "completed_checksum_guarded_native_F0_diagnostic"
            and qualification.get("checksum_guarded_diagnostic") is True and qualification.get("actual_compiler") == "1.98.1"
            and all(qualification.get(k) is False for k in ("full_topology_oracle", "reusable_csr", "cold_cache_qualified",
                                                            "performance_comparison", "cross_host_or_Capitola_ratio", "prior_compiler_matched")),
            "F0 published scope overclaims checksum diagnostic")
    published = rows(report.get("cells"))
    require(len(published) == 4 and [(obj(c).get("id"), obj(c).get("outcome"), obj(c).get("returncode")) for c in published]
            == [(c.id, c.outcome, c.returncode) for c in receipt.children], "F0 all four published outcomes differ")
    return {"cells": 4, "full_topology_oracle": False, "performance_comparison": False,
            "actual_compiler": "1.98.1", "lto": "thin", "artifact_count": 13}
