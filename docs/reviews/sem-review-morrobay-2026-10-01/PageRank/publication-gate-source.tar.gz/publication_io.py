"""Bounded metadata reads and safe complete archive verification."""
from __future__ import annotations

import hashlib
import json
import stat
import subprocess
import tarfile
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import BinaryIO, TypeVar, cast

from publication_models import Evidence, Identity, MemberRef, Plan, State, relative
from pydantic import BaseModel, JsonValue, TypeAdapter

T = TypeVar("T", bound=BaseModel)
JSON = TypeAdapter(dict[str, JsonValue])


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def utc() -> str:
    return datetime.now(UTC).isoformat()


class Deadline:
    def __init__(self, seconds: int) -> None:
        self.end = time.monotonic() + seconds

    def remaining(self) -> float:
        remaining = self.end - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("publication metadata deadline")
        return remaining


def identity(data: bytes) -> Identity:
    return Identity(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path: Path, deadline: Deadline) -> bytes:
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= 128 * 2**20,
            "bounded regular metadata file required")
    parts: list[bytes] = []
    size = 0
    with path.open("rb") as stream:
        while True:
            deadline.remaining()
            block = stream.read(2**20)
            if not block:
                break
            size += len(block)
            require(size <= before.st_size, "metadata grew during read")
            parts.append(block)
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) and size == before.st_size,
            "metadata file identity changed during read")
    return b"".join(parts)


def command(repo: Path, deadline: Deadline, *arguments: str) -> str:
    result = subprocess.run(["/usr/bin/git", "-C", str(repo), *arguments], capture_output=True,
                            timeout=min(30.0, deadline.remaining()), check=False)
    require(result.returncode == 0 and len(result.stdout) <= 16 * 2**20, "bounded Git metadata command failed")
    return result.stdout.decode()


def state(repo: Path, deadline: Deadline) -> State:
    named = subprocess.run(["/usr/bin/git", "-C", str(repo), "symbolic-ref", "-q", "HEAD"],
                           capture_output=True, timeout=min(30.0, deadline.remaining()), check=False)
    require(named.returncode in {0, 1}, "cannot establish detached state")
    return State(head=command(repo, deadline, "rev-parse", "HEAD").strip(),
                 tree=command(repo, deadline, "rev-parse", "HEAD^{tree}").strip(),
                 parent=command(repo, deadline, "rev-parse", "HEAD^").strip(),
                 status=command(repo, deadline, "status", "--porcelain", "--untracked-files=all"),
                 detached=named.returncode == 1)


class Store:
    def __init__(self, repo: Path, plan: Plan, deadline: Deadline) -> None:
        self.repo, self.plan, self.deadline = repo, plan, deadline
        self.files: dict[str, bytes] = {}
        self.members: dict[tuple[str, str], bytes] = {}
        for name, pin in plan.files.items():
            path = repo / name
            require(all(not p.is_symlink() for p in (path, *path.parents) if p.is_relative_to(repo)),
                    "published metadata ancestor is a symlink")
            data = read(path, deadline)
            require(identity(data) == pin, f"publication file pin differs: {name}")
            self.files[name] = data
        for name, members in plan.archives.items():
            self.archive(name, members)

    def archive(self, name: str, expected: dict[str, Identity]) -> None:
        seen: set[str] = set()
        observed: dict[str, Identity] = {}
        with tarfile.open(self.repo / name, "r:gz") as archive:
            for index, member in enumerate(archive):
                self.deadline.remaining()
                require(index < 32768 and relative(member.name) not in seen,
                        "duplicate or excessive archive header")
                seen.add(member.name)
                if member.isdir():
                    continue
                require(member.isfile() and member.name in expected and member.size == expected[member.name].bytes,
                        "archive member type/name/size differs")
                stream = archive.extractfile(member)
                require(stream is not None, "archive member stream unavailable")
                parts: list[bytes] = []
                size = 0
                with cast(BinaryIO, stream) as contents:
                    while True:
                        self.deadline.remaining()
                        block = contents.read(2**20)
                        if not block:
                            break
                        size += len(block)
                        require(size <= member.size, "archive member expansion exceeded exact pin")
                        parts.append(block)
                data = b"".join(parts)
                require(size == member.size, "archive member truncated")
                observed[member.name] = identity(data)
                self.members[name, member.name] = data
        require(observed == expected, "complete archive member bytes/hash inventory differs")

    def data(self, ref: Evidence) -> bytes:
        return self.members[ref.file, ref.member] if isinstance(ref, MemberRef) else self.files[ref.file]

    def model(self, ref: Evidence, model: type[T]) -> T:
        return model.model_validate_json(self.data(ref))

    def object(self, ref: Evidence) -> dict[str, JsonValue]:
        return JSON.validate_json(self.data(ref))

    def json_data(self, data: bytes) -> dict[str, JsonValue]:
        return JSON.validate_json(data)

    def pin_data(self, path: Path, size: int, sha: str) -> bytes:
        ref = self.plan.origins.get(str(path))
        require(ref is not None, f"portable original metadata pin mapping absent: {path}")
        data = self.data(cast(Evidence, ref))
        require(identity(data) == Identity(bytes=size, sha256=sha), f"original metadata pin differs: {path}")
        return data

    def recheck(self) -> None:
        for name, expected in self.plan.files.items():
            require(identity(read(self.repo / name, self.deadline)) == expected,
                    "publication metadata changed during gate")


def obj(value: JsonValue) -> dict[str, JsonValue]:
    require(isinstance(value, dict), "metadata object required")
    return cast(dict[str, JsonValue], value)


def rows(value: JsonValue) -> list[JsonValue]:
    require(isinstance(value, list), "metadata array required")
    return cast(list[JsonValue], value)


def encode(value: object) -> bytes:
    return json.dumps(value, allow_nan=False).encode()
