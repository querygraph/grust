"""Receipt-only campaign qualification and independently recomputed paired ratios."""
from __future__ import annotations

import math
from typing import Literal, cast

import pr_native_models as native
import pr_oracle_models as oracle
from child_admission import check_child
from publication_io import Store, encode, identity, obj, require, rows
from publication_models import (
    GF_SOURCE,
    ROWS,
    RUNTIME,
    SOURCE,
    AuditCell,
    Cell,
    CellState,
    Plan,
    Queue,
    QueuePlan,
    RatioSummary,
    RootAudit,
)
from pydantic import JsonValue

ORACLE_PINS = {
    "pagerank_models.py": "fbb694b8f13e18a91d99f8d6464edee9bed126be926b5cfa0521d556dd6c57f8",
    "pagerank_io.py": "35ca1ed5c72ed6bc69becd4d058fc900f95589a1ca047e078ea73e43ddbda116",
    "pagerank_oracle.py": "4aacb15ce849f4966245150373fd43187100f9f0dc3bb3fd7bc81ce682a03076",
}
NATIVE_PINS = {
    "native_models.py": "331ad63bcdf2be2efc04dceb9e0a71fed37c924fb272ac796b8093e33187a9af",
    "native_io.py": "7e5c90b2c8056bd15b7f433bd3620ab01b71e31d610084238fae69f4f9e4b1ab",
    "supervise_native.py": "795c6b78fddd3c7d9a77eed05276410f8425c62fe9975f7ff94f027a4c3120b5",
}
INPUTS = {
    "vertices": (3861941, oracle.CIT_VERTEX_SHA),
    "edges": (70037384, "70bcba17b5a7762ef5a0c3d16c1dc37a352461b83e338f550ae897d844f0268f"),
}


def pin_model(store: Store, pin: native.Pin, model: type[native.Config]) -> native.Config:
    return model.model_validate_json(store.pin_data(pin.path, pin.bytes, pin.sha256))


def near(actual: float, expected: float) -> None:
    require(math.isfinite(actual) and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12),
            "published numeric claim differs from recomputed receipt value")


def protocol(cells: list[Cell]) -> None:
    require(len(cells) == len({c.id for c in cells}) == 21, "exact unique21-cell protocol required")
    expected: list[tuple[str, str, str, int | None, int | None]] = [("local", "graphframes", "reference", None, None)]
    for mode in ("local", "process-cluster"):
        expected.extend([(mode, "graphframes", "warmup", None, None), (mode, "pecan", "warmup", None, None)])
        for block in (1, 2):
            for position, engine in enumerate(("graphframes", "pecan", "pecan", "graphframes"), 1):
                expected.append((mode, engine, "measured", block, position))
    require([(c.contrast_mode, c.engine, c.kind, c.block, c.position) for c in cells] == expected,
            "reference/warmup/two ABBA block order differs")


def client_closure(receipt: native.Receipt) -> None:
    if receipt.client_before is None or receipt.client_after is None:
        raise ValueError("actual native client before/after observations absent")
    before, after = receipt.client_before, receipt.client_after
    require(before.model_dump(exclude={"observed_utc"}) == after.model_dump(exclude={"observed_utc"})
            and before.extensions == [] and before.python_version == "3.12.6",
            "native client ABI/lock/zero-extension closure differs")


def provenance(store: Store, config: native.Config, receipt: native.Receipt) -> None:
    admission = store.json_data(store.pin_data(config.source_admission.path, config.source_admission.bytes,
                                              config.source_admission.sha256))
    require(admission.get("controller") == SOURCE and admission.get("compiled_runtime") == RUNTIME
            and admission.get("tree") == config.source_tree and admission.get("source") == str(config.engine.repo),
            "actual root controller/runtime admission differs")
    manifest = store.json_data(store.pin_data(config.support_manifest.path, config.support_manifest.bytes,
                                             config.support_manifest.sha256))
    require(manifest.get("source") == SOURCE and manifest.get("compiled_runtime_source") == RUNTIME,
            "actual engine support source declaration differs")
    build = store.json_data(store.pin_data(config.build.path, config.build.bytes, config.build.sha256))
    require(build.get("outcome") == "passed_optimized_native_binaries" and bool(build.get("finished_utc"))
            and build.get("sources_before") == build.get("sources_after"), "actual optimized native build closure differs")
    release = obj(build.get("release_environment"))
    require(all(release.get(k) == v for k, v in {"RUSTUP_TOOLCHAIN": "1.97.1", "CARGO_INCREMENTAL": "0",
            "CARGO_PROFILE_RELEASE_OPT_LEVEL": "3", "CARGO_PROFILE_RELEASE_DEBUG": "0",
            "CARGO_PROFILE_RELEASE_STRIP": "true", "CARGO_PROFILE_RELEASE_CODEGEN_UNITS": "1",
            "CARGO_PROFILE_RELEASE_LTO": "true"}.items()), "actual native release profile differs")
    selected = "sail" if config.engine.engine == "pecan" else "graphframes"
    steps = [obj(step) for step in rows(build.get("steps")) if obj(step).get("name") == selected]
    require(len(steps) == 1, "one actual selected native build step required")
    step = steps[0]
    source = obj(obj(build.get("sources_before")).get(selected))
    binary = obj(step.get("binary"))
    require(step.get("returncode") == 0 and obj(step.get("probe")).get("returncode") == 0
            and step.get("source_after") == source and source.get("commit") == (RUNTIME if selected == "sail" else GF_SOURCE)
            and binary.get("path") == str(config.engine.binary)
            and receipt.before.get(str(config.engine.binary))
            == native.Identity.model_validate({"bytes": binary.get("bytes"), "sha256": binary.get("sha256")}),
            "selected compiled runtime/binary/probe closure differs")


def oracle_check(result: oracle.OracleReceipt, reference_only: bool) -> None:
    wanted = "reference_prepared" if reference_only else "passed_full_physical_pagerank"
    require(result.outcome == wanted and bool(result.finished_utc) and result.error is None
            and result.traceback is None and not result.integrity_errors and not result.witnesses,
            "full physical PageRank oracle did not finalize cleanly")
    require(result.own_identity_closure_passed is True and result.full_physical_domain_passed is True
            and result.identity_before == result.identity_after and bool(result.identity_before),
            "oracle source/raw/exit-proof identity closure failed")
    require(result.expected_domain_rows == result.reference_rows == result.candidate_rows
            == result.unique_candidate_rows == ROWS and result.numeric_mismatches == 0,
            "complete finite unique original vertex domain failed")
    require(result.absolute_bound == 1e-12 and result.absolute_bound_hex == 1e-12.hex()
            and result.config.dataset == "cit-Patents" and result.config.reference_preparation_only == reference_only,
            "exact matched numerical/domain contract differs")
    require(result.compared_rows == (0 if reference_only else ROWS)
            and result.full_numeric_comparison_passed is (not reference_only),
            "reference preparation must remain distinct from full numeric qualification")
    if not reference_only:
        require(result.max_absolute_error is not None and 0 <= result.max_absolute_error <= 1e-12,
                "per-vertex absolute PageRank error exceeds bound")
    require(set(result.physical_schemas) == {"input", "reference", "candidate"}, "complete raw physical schemas absent")
    for role, files in result.physical_schemas.items():
        require(bool(files) and sum(f.footer_rows for f in files) == ROWS, "all part footer rows must cover domain")
        required = {"id": "int64"} if role == "input" else {"id": "int64", "pagerank": "double"}
        for file in files:
            require(len(file.fields) == len(required) and {f.name: f.arrow_type for f in file.fields} == required,
                    "raw physical schema was rewritten or differs")


def verify_audit(audit: AuditCell, state: CellState, receipt: native.Receipt,
                 proof: oracle.ExitProof, result: oracle.OracleReceipt) -> None:
    require((audit.id, audit.kind, audit.mode, audit.engine)
            == (state.cell.id, state.cell.kind, state.cell.contrast_mode, state.cell.engine), "root audited cell identity differs")
    require(audit.parent_pid == state.parent_pid and audit.child_pid == receipt.child_pid
            and audit.server_pid == receipt.server_pid and audit.workers == receipt.sampler.owned_workers,
            "root observed owned process identities differ")
    require(audit.config_pin == state.configuration and audit.receipt_pin == state.receipt,
            "root actual config/receipt byte pins differ")
    require(audit.source_client_identity_closure is True and audit.full_output_retention_qualified is True
            and audit.full_physical_domain_passed is True, "root complete physical/identity audit failed")
    require(audit.retained_files == receipt.retention_files and audit.raw_result_files
            == {k: native.Identity(**v.model_dump()) for k, v in proof.raw_files.items()}
            and audit.retained_total_bytes == sum(v.bytes for v in audit.retained_files.values()),
            "root full retained/raw inventory binding differs")
    require(audit.full_domain_rows == ROWS and audit.compared_rows == result.compared_rows
            and audit.numeric_mismatches == 0 and audit.full_numeric_comparison_passed
            is result.full_numeric_comparison_passed and audit.reference_preparation_only
            is result.config.reference_preparation_only, "root full vector/domain scope differs")
    require(audit.max_absolute_error == result.max_absolute_error
            and audit.max_relative_error == result.max_relative_error, "root maximum error diagnostics differ")


def check_cell(store: Store, state: CellState, root: AuditCell, reference: native.ResultDataset,
               queue_plan: QueuePlan) -> tuple[native.Receipt, oracle.OracleReceipt]:
    if state.configuration is None or state.receipt is None or state.parent_pid is None:
        raise ValueError("launched cell config/parent/receipt absent")
    config = pin_model(store, state.configuration, native.Config)
    receipt = native.Receipt.model_validate_json(store.pin_data(state.receipt.path, state.receipt.bytes, state.receipt.sha256))
    wanted = "reference_prepared" if state.cell.kind == "reference" else "passed_matched_pr_diagnostic"
    require(state.outcome == receipt.outcome == wanted and state.returncode == receipt.returncode == 0
            and state.reason is None and bool(state.started_utc) and bool(state.finished_utc)
            and bool(receipt.finished_utc) and not receipt.errors, "failed/unfinalized cell cannot qualify")
    require(receipt.config == config and config.run_id == state.cell.id
            and config.contrast_mode == state.cell.contrast_mode and config.engine.engine == state.cell.engine,
            "actual immutable cell config differs")
    require(config.output == queue_plan.root / "cells" / state.cell.id
            and config.engine.output == queue_plan.ssd_root / state.cell.id,
            "actual parent/SSD fresh run binding differs")
    require(config.engine.binary == (queue_plan.pecan_binary if state.cell.engine == "pecan" else queue_plan.graphframes_binary),
            "actual selected native binary path differs")
    require(all((receipt.child_group_absent, receipt.server_group_absent, receipt.worker_processes_absent,
                 receipt.matching_server_absent, receipt.retention_verified, receipt.locks_released))
            and receipt.before == receipt.after and bool(receipt.before)
            and receipt.source_before == receipt.source_after, "cell final ownership/source/retention closure failed")
    source = receipt.source_before
    require(source.get("commit") == SOURCE and source.get("compiled_runtime") == RUNTIME
            and source.get("graphframes_commit") == GF_SOURCE and source.get("tree") == config.source_tree
            and source.get("compiled_runtime_paths_parity") == "empty diff", "controller/compiled-runtime scoped parity differs")
    client_closure(receipt)
    provenance(store, config, receipt)
    for role, (size, sha) in INPUTS.items():
        pin = config.originals[cast(Literal["vertices", "edges"], role)]
        require((pin.bytes, pin.sha256) == (size, sha)
                and receipt.before.get(str(pin.path)) == native.Identity(bytes=size, sha256=sha), "exact original graph input pin differs")
    for name, sha in ORACLE_PINS.items():
        pin = config.oracle_helpers[name]
        require(pin.sha256 == sha, "frozen full oracle source changed")
        store.pin_data(pin.path, pin.bytes, pin.sha256)
    require(set(config.helpers) == set(NATIVE_PINS)
            and all(config.helpers[k].sha256 == sha for k, sha in NATIVE_PINS.items()),
            "actual frozen native parent/helpers changed")
    for pin in (config.client, config.build, config.retirement, config.preservation, config.reference_receipt,
                config.support_manifest, config.source_admission, *config.helpers.values()):
        store.pin_data(pin.path, pin.bytes, pin.sha256)
    require(receipt.sampler.error is None and receipt.sampler.thread_alive is False
            and receipt.sampler.execution_samples > 0 and receipt.sampler.samples >= receipt.sampler.execution_samples,
            "sampler execution coverage or final closure failed")
    if receipt.child is None or receipt.correctness is None or receipt.engine_exited is None:
        raise ValueError("actual child/physical oracle/exited proof absent")
    server_pid = check_child(config, receipt.child, receipt.sampler)
    require(server_pid == receipt.server_pid, "actual runtime PID differs")
    result = oracle.OracleReceipt.model_validate_json(encode(receipt.correctness))
    oracle_check(result, state.cell.kind == "reference")
    for path in (config.output / "correctness.json", result.config.output / "receipt.json"):
        ref = store.plan.origins.get(str(path))
        require(ref is not None and store.model(ref, oracle.OracleReceipt) == result,
                "standalone retained full oracle receipt differs from parent")
    proof_pin = receipt.engine_exited
    proof = oracle.ExitProof.model_validate_json(store.pin_data(proof_pin.path, proof_pin.bytes, proof_pin.sha256))
    require(proof.engine == state.cell.engine and proof.run_id == config.run_id
            and proof.child_pid == receipt.child_pid and proof.raw_directory == config.engine.output / "result",
            "sealed actual child exit binding differs")
    raw_config = store.pin_data(proof.configuration.path, proof.configuration.bytes, proof.configuration.sha256)
    require(native.EngineConfig.model_validate_json(raw_config) == config.engine, "sealed actual child configuration differs")
    require(store.json_data(store.pin_data(proof.child_receipt.path, proof.child_receipt.bytes,
                                         proof.child_receipt.sha256)) == receipt.child,
            "standalone child receipt differs from parent embedded bytes")
    candidate = result.config.candidate
    require(candidate.directory == proof.raw_directory and candidate.files == proof.raw_files
            and candidate.exit.producer_receipt.model_dump() == proof_pin.model_dump()
            and result.exit_proofs.get("candidate") == proof, "full oracle actual raw inventory/exit binding differs")
    require(result.config.input_vertices.model_dump() == config.originals["vertices"].model_dump(), "oracle original input changed")
    if state.cell.kind == "reference":
        require(config.reference is None and config.reference_preparation_only is True
                and candidate.model_dump() == reference.model_dump(), "separate GF reference preparation differs")
    else:
        require(config.reference == reference and config.reference_preparation_only is False
                and result.config.graphframes_reference.model_dump() == reference.model_dump(), "fixed closed GF reference changed")
    for name, raw_identity in proof.raw_files.items():
        require(receipt.retention_files.get("result/" + name) == native.Identity(**raw_identity.model_dump()),
                "complete raw result is not bound to full retained index")
    index_path = config.output / "retention-index.json"
    index_ref = store.plan.origins.get(str(index_path))
    require(index_ref is not None and store.object(index_ref)
            == {k: v.model_dump() for k, v in receipt.retention_files.items()}, "standalone full retention index differs")
    verify_audit(root, state, receipt, proof, result)
    require(receipt.launch_to_exit_seconds is not None and receipt.launch_to_exit_seconds > 0
            and receipt.launch_to_exit_seconds == state.launch_to_exit_seconds, "raw launch/wait duration binding differs")
    return receipt, result


def compare_summary(actual: RatioSummary, expected: RatioSummary) -> None:
    require(actual.n_per_engine == 4, "each engine needs four matched measured calls")
    for value, wanted in zip(actual.paired_ratios, expected.paired_ratios, strict=True):
        near(value, wanted)
    near(actual.geometric_mean_ratio, expected.geometric_mean_ratio)
    require(actual.maximum_absolute_error == expected.maximum_absolute_error,
            "maximum absolute error claim differs from exact raw oracle diagnostic")


def campaign(store: Store, plan: Plan) -> dict[str, JsonValue]:
    queued_plan = store.model(plan.pagerank.plan, QueuePlan)
    queue = store.model(plan.pagerank.queue, Queue)
    audit = store.model(plan.pagerank.audit, RootAudit)
    protocol(queued_plan.cells)
    require([s.cell for s in queue.cells] == queued_plan.cells and len(audit.cells) == 21,
            "every planned/actual/audited cell must remain visible")
    require(queue.outcome == "qualified_native_pagerank_local_and_process_cluster_pairs"
            and bool(queue.finished_utc) and not queue.errors and queue.traceback is None
            and queue.forced_parent_cancellation is False and queue.plan_before == queue.plan_after
            and queue.source_before == queue.source_after and queue.reference is not None,
            "final serial campaign did not qualify with unchanged source/plan")
    if queue.reference is None:
        raise ValueError("closed separate GF reference absent")
    require(identity(store.data(plan.pagerank.plan)).model_dump() == queue.plan_before.model_dump(exclude={"path"})
            and identity(store.data(plan.pagerank.queue)).model_dump() == audit.queue_pin.model_dump(exclude={"path"})
            and audit.plan_pin == queue.plan_before, "actual queue/plan/root-audit pins differ")
    require(audit.all_owned_pid_and_group_absent is True and audit.shared_locks_absent is True
            and audit.source_input_client_closure is True and audit.owned_processes_remaining == []
            and audit.matching_native_servers_remaining == [] and bool(audit.observed_utc), "root final campaign closure failed")
    store.pin_data(queue.source_before.path, queue.source_before.bytes, queue.source_before.sha256)
    require(queue.source_before == queued_plan.source, "actual serial queue source pin differs")
    store.pin_data(queued_plan.template.path, queued_plan.template.bytes, queued_plan.template.sha256)
    qualified = [check_cell(store, state, root, queue.reference, queued_plan)
                 for state, root in zip(queue.cells, audit.cells, strict=True)]
    calculated: dict[str, RatioSummary] = {}
    for mode in ("local", "process-cluster"):
        measured = [(state.cell, receipt, result) for state, (receipt, result) in zip(queue.cells, qualified, strict=True)
                    if state.cell.contrast_mode == mode and state.cell.kind == "measured"]
        require(len(measured) == 8, "reference and warmups must be excluded from ratios")
        pairs: list[float] = []
        for offset in (0, 2, 4, 6):
            pair = measured[offset:offset + 2]
            gf = next(r for c, r, _ in pair if c.engine == "graphframes")
            pecan = next(r for c, r, _ in pair if c.engine == "pecan")
            pairs.append(cast(float, pecan.launch_to_exit_seconds) / cast(float, gf.launch_to_exit_seconds))
        calculated[mode] = RatioSummary(n_per_engine=4, paired_ratios=tuple(pairs),  # type: ignore[arg-type]
                                       geometric_mean_ratio=math.exp(sum(math.log(p) for p in pairs) / 4),
                                       maximum_absolute_error=max(cast(float, result.max_absolute_error)
                                           for state, (_, result) in zip(queue.cells, qualified, strict=True)
                                           if state.cell.contrast_mode == mode and state.cell.engine == "pecan"))
    require(set(audit.summary) == set(calculated), "both topology root summaries required")
    report = store.object(plan.pagerank.report)
    claims = obj(report.get("publication_gate_claims", report))
    summaries = obj(claims.get("contrasts"))
    require(set(summaries) == set(calculated), "both topology publication summaries required")
    for mode, expected in calculated.items():
        compare_summary(audit.summary[mode], expected)
        compare_summary(RatioSummary.model_validate(summaries[mode]), expected)
    published_cells = rows(claims.get("cells"))
    require(len(published_cells) == 21 and [(obj(v).get("id"), obj(v).get("kind"), obj(v).get("outcome")) for v in published_cells]
            == [(s.cell.id, s.cell.kind, s.outcome) for s in queue.cells], "every actual outcome must be published exactly")
    return {mode: cast(JsonValue, value.model_dump()) for mode, value in calculated.items()}
