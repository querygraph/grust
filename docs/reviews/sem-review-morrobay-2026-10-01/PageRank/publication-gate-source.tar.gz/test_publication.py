"""Small finalized-metadata and adversarial archive/protocol controls."""
from __future__ import annotations

import io
import tarfile
import tempfile
import unittest
from pathlib import Path
from typing import cast

import pr_native_models as native
import pr_oracle_models as oracle
from child_admission import check_child
from f0_checks import f0
from pagerank_checks import oracle_check, protocol
from publication_io import JSON, Deadline, Store, encode, identity
from publication_models import F0Paths, FileRef, Plan, Queue, RootAudit
from pydantic import JsonValue

FIXTURES = Path(__file__).parent / "fixtures"


class Controls(unittest.TestCase):
    def test_actual_protocol_and_missing_or_reordered_call(self) -> None:
        queue = Queue.model_validate_json((FIXTURES / "queue.json").read_bytes())
        cells = [s.cell for s in queue.cells]
        protocol(cells)
        with self.assertRaises(ValueError):
            protocol(cells[:-1])
        wrong = cells.copy()
        wrong[3], wrong[4] = wrong[4], wrong[3]
        with self.assertRaises(ValueError):
            protocol(wrong)

    def test_actual_root_schema(self) -> None:
        audit = RootAudit.model_validate_json((FIXTURES / "root-audit.json").read_bytes())
        self.assertEqual(len(audit.cells), 21)
        self.assertTrue(audit.shared_locks_absent)

    def test_actual_reference_not_numeric_self_comparison(self) -> None:
        parent = native.Receipt.model_validate_json((FIXTURES / "reference-parent.json").read_bytes())
        original = oracle.OracleReceipt.model_validate_json(encode(parent.correctness))
        oracle_check(original, True)
        for update in ({"compared_rows": 3774768}, {"full_numeric_comparison_passed": True}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                oracle_check(original.model_copy(update=update), True)

    def test_actual_full_numeric_oracle_and_incomplete_or_error(self) -> None:
        parent = native.Receipt.model_validate_json((FIXTURES / "pecan-parent.json").read_bytes())
        original = oracle.OracleReceipt.model_validate_json(encode(parent.correctness))
        oracle_check(original, False)
        for update in ({"compared_rows": 3774767}, {"max_absolute_error": 2e-12},
                       {"full_physical_domain_passed": False}, {"outcome": "error"}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                oracle_check(original.model_copy(update=update), False)

    def test_unchanged_actual_child_guards_and_escalation(self) -> None:
        for name in ("gf-parent.json", "pecan-parent.json"):
            parent = native.Receipt.model_validate_json((FIXTURES / name).read_bytes())
            if parent.child is None:
                raise AssertionError("fixture child absent")
            self.assertEqual(check_child(parent.config, parent.child, parent.sampler), parent.server_pid)
            if name == "pecan-parent.json":
                changed = parent.child.copy()
                shutdown = [dict(row) for row in cast(list[dict[str, object]], changed["shutdown"])]
                shutdown[0]["sigkill_escalated"] = True
                changed["shutdown"] = cast(JsonValue, shutdown)
            else:
                changed = parent.child.copy()
                changed["command"] = []
            with self.assertRaises(ValueError):
                check_child(parent.config, changed, parent.sampler)

    def test_actual_f0_adapter_and_topology_overclaim(self) -> None:
        report = JSON.validate_json((FIXTURES / "f0-report.json").read_bytes())
        origins = cast(dict[str, dict[str, object]], report["evidence_origins"])
        store = Store.__new__(Store)
        store.files = {"f0-report.json": (FIXTURES / "f0-report.json").read_bytes()}
        store.members = {}
        mapping: dict[str, FileRef] = {}
        for name, origin in origins.items():
            store.files[name] = (FIXTURES / "f0" / name).read_bytes()
            mapping[cast(str, origin["original_path"])] = FileRef(file=name)
        prefix = "evidence/"
        fake_plan = {"origins": mapping, "f0": {
            "build": FileRef(file=prefix + "F0-native-build01/receipt.json"),
            "receipt": FileRef(file=prefix + "F0-native-run01/receipt.json"),
            "audit": FileRef(file=prefix + "F0-native-supervisor01/root-closure-audit01.json"),
            "report": FileRef(file="f0-report.json")}}
        # This fixture store only exercises semantic adapters; detached plan is separately validated.
        plan = Plan.model_construct(origins=mapping, f0=F0Paths.model_validate(fake_plan["f0"]))
        store.plan = plan
        self.assertEqual(f0(store, plan)["cells"], 4)
        report["qualification"] = {**cast(dict[str, JsonValue], report["qualification"]), "full_topology_oracle": True}
        store.files["f0-report.json"] = encode(report)
        with self.assertRaises(ValueError):
            f0(store, plan)

    def test_unsafe_duplicate_or_hash_substituted_archive(self) -> None:
        for kind in ("symlink", "duplicate", "wrong-hash"):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / "evidence.tar.gz"
                with tarfile.open(path, "w:gz") as archive:
                    header = tarfile.TarInfo("x.json")
                    header.size = 2
                    if kind == "symlink":
                        header.type = tarfile.SYMTYPE
                        header.linkname = "outside"
                        archive.addfile(header)
                    else:
                        archive.addfile(header, io.BytesIO(b"{}"))
                        if kind == "duplicate":
                            archive.addfile(header, io.BytesIO(b"{}"))
                expected = identity(b"[]") if kind == "wrong-hash" else identity(b"{}")
                store = Store.__new__(Store)
                store.repo, store.deadline, store.members = Path(tmp), Deadline(30), {}
                with self.assertRaises(ValueError):
                    store.archive(path.name, {"x.json": expected})


if __name__ == "__main__":
    unittest.main()
