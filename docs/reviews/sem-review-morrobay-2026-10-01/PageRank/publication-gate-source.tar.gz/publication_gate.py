"""Exact detached PageRank/F0 publication metadata gate; no native or payload actions."""
from __future__ import annotations

import argparse
import ast
import json
import os
import re
import signal
import traceback
from pathlib import Path
from types import FrameType
from typing import Literal, cast

import child_admission
import f0_models
import pr_native_models
import pr_oracle_models
from f0_checks import f0
from pagerank_checks import campaign
from publication_io import Deadline, Store, command, identity, read, require, state, utc
from publication_models import MODEL_HASHES, PREFIX, Plan, Revision
from pydantic import JsonValue


def model_sources(deadline: Deadline) -> None:
    for module in (pr_native_models, pr_oracle_models, f0_models):
        path = Path(cast(str, module.__file__))
        require(path.parent == Path(__file__).parent and identity(read(path, deadline)).sha256 == MODEL_HASHES[path.name],
                "frozen actual receipt model source/import identity changed")


def child_predicate_guard(store: Store) -> None:
    expected = "795c6b78fddd3c7d9a77eed05276410f8425c62fe9975f7ff94f027a4c3120b5"
    originals = [store.data(ref) for original, ref in store.plan.origins.items()
                 if original.endswith("/supervise_native.py") and identity(store.data(ref)).sha256 == expected]
    require(bool(originals), "exact frozen parent source must be retained")
    actual = ast.parse(Path(child_admission.__file__).read_text())
    original = ast.parse(originals[0].decode())
    for name in ("check_child", "graphframes_command"):
        def body(module: ast.Module, name: str) -> str:
            functions = [n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == name]
            require(len(functions) == 1, "exact frozen admission function absent")
            return ast.dump(functions[0], include_attributes=False)
        require(body(actual, name) == body(original, name), "frozen child-admission/CLI predicates changed")


def text_checks(store: Store, revision: Revision) -> None:
    for name, suffix in {"codex-to-codex.md": store.plan.coordination_append, **store.plan.append_only}.items():
        old = command(store.repo, store.deadline, "show", revision.parent + ":" + name).encode()
        require(store.files[name] == old + suffix.encode(), "historical/coordination prefix or exact own append differs")
    for name, data in store.files.items():
        if not name.endswith(".md"):
            continue
        require(not re.search(rb"^(<<<<<<<|=======|>>>>>>>)( |$)", data, re.MULTILINE), "conflict marker in publication")
        text = (store.plan.coordination_append if name == "codex-to-codex.md" else store.plan.append_only.get(name, data.decode()))
        for reference in re.findall(r"\]\(([^)]+)\)", text):
            target = reference.strip("<>").split("#", 1)[0]
            if not target or target.startswith(("https://", "http://")):
                continue
            path = (store.repo / name).parent / target
            require(not Path(target).is_absolute() and path.resolve().is_relative_to(store.repo.resolve())
                    and path.is_file(), "published relative Markdown link missing/unsafe")
    disclosures = {
        "PageRank": ("shared", "ratio", "reference", "warmup", "ABBA", "30", "48", "snapshot", "1e-12"),
        "F0": ("shared", "checksum", "topology", "teardown", "cache", "1.98.1", "thin"),
    }
    for item, words in disclosures.items():
        text = store.files[f"{PREFIX}/{item}/README.md"].decode().lower()
        require(all(word.lower() in text for word in words), "publication scope disclosure absent")


def gate(repo: Path, plan: Plan, mode: Literal["candidate", "committed"], deadline: Deadline) -> dict[str, JsonValue]:
    expected = plan.candidate if mode == "candidate" else plan.committed
    require(expected is not None, "exact committed revision absent from plan")
    revision = cast(Revision, expected)
    before = state(repo, deadline)
    require(before.detached and before.status == "" and before.model_dump(exclude={"status", "detached"}) == revision.model_dump(),
            "exact clean detached HEAD/tree/parent required")
    require(set(command(repo, deadline, "diff", "--name-only", revision.parent, before.head).splitlines()) == set(plan.files),
            "changed path set differs from exact publication allowlist")
    model_sources(deadline)
    store = Store(repo, plan, deadline)
    text_checks(store, revision)
    child_predicate_guard(store)
    ratios = campaign(store, plan)
    diagnostic = f0(store, plan)
    store.recheck()
    require(state(repo, deadline) == before, "detached publication state changed during gate")
    return {"before": cast(JsonValue, before.model_dump()), "after": cast(JsonValue, before.model_dump()),
            "pagerank_recomputed": ratios, "f0_checked": diagnostic,
            "scope": "Exact detached publication metadata, all21 natural-exit/full-oracle/root-retention receipts and four F0 guards; bounded safe portable archives. Large output/input/binary identities are bound original audit metadata, never reread. No engine rerun, dedicated-host absolute result, A2 envelope parity or F0 topology/performance qualification."}


def expired(_signal: int, _frame: FrameType | None) -> None:
    raise TimeoutError("publication metadata deadline")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--mode", choices=("candidate", "committed"), required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    require(not args.receipt.exists() and not args.receipt.is_symlink(), "fresh external receipt required")
    require(not args.receipt.resolve().is_relative_to(args.worktree.resolve()), "gate receipt must be outside detached candidate")
    bootstrap = Deadline(30)
    plan_bytes = read(args.plan, bootstrap)
    plan = Plan.model_validate_json(plan_bytes)
    deadline = Deadline(plan.deadline_seconds)
    sources = {p.name: identity(read(p, deadline)) for p in Path(__file__).parent.glob("*.py")}
    result: dict[str, JsonValue] = {"started_utc": utc(), "outcome": "error", "mode": args.mode}
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(plan.deadline_seconds)
    try:
        result.update(gate(args.worktree, plan, cast(Literal["candidate", "committed"], args.mode), deadline))
        require(identity(read(args.plan, deadline)) == identity(plan_bytes), "publication plan changed during gate")
        require({p.name: identity(read(p, deadline)) for p in Path(__file__).parent.glob("*.py")} == sources,
                "gate helper source set/bytes changed during gate")
        result["outcome"] = "passed_exact_native_PageRank_F0_publication_metadata"
    except (ValueError, OSError, TypeError, KeyError, TimeoutError) as error:
        result.update(error=repr(error), traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
    result.update(finished_utc=utc(), plan=cast(JsonValue, identity(plan_bytes).model_dump()),
                  sources={name: cast(JsonValue, pin.model_dump()) for name, pin in sources.items()})
    with args.receipt.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    print(result["outcome"])
    return 0 if result["outcome"] == "passed_exact_native_PageRank_F0_publication_metadata" else 1


if __name__ == "__main__":
    raise SystemExit(main())
