"""Unchanged frozen parent child-admission predicates, with metadata-only IO."""
from __future__ import annotations

from typing import cast

import publication_io as io
from pr_native_models import (
    GF_SOURCE,
    HARNESS,
    RUNTIME,
    SOURCE,
    Config,
    EngineConfig,
    Sampler,
)
from pydantic import JsonValue


def object_field(raw: dict[str, JsonValue], name: str) -> dict[str, JsonValue]:
    return io.obj(raw.get(name))

def graphframes_command(config: EngineConfig) -> list[str]:
    return [str(config.binary), "page-rank", "--vertices", str(config.vertices), "--edges", str(config.edges),
            "--output", (config.output / "result").as_uri(), "--format", "parquet", "--id-col-name", "id",
            "--src-col-name", "source", "--dst-col-name", "target", "--max-memory", "30G",
            "--num-workers", "16", "--checkpoint-dir", str(config.output / "work"),
            "--max-temp-file", "200G", "--tol", "0.01", "--reset-prob", "0.15", "--max-iter", "10"]

def check_child(config: Config, raw: dict[str, JsonValue], sampler: Sampler) -> int:
    io.require(raw.get("outcome") == "passed" and bool(raw.get("finished_utc")), "child did not pass")
    io.require(EngineConfig.model_validate(raw.get("config")) == config.engine, "child config mismatch")
    expected_runtime = RUNTIME if config.engine.engine == "pecan" else GF_SOURCE
    io.require(raw.get("declared_controller_pin") == SOURCE and raw.get("declared_runtime_pin") == expected_runtime
               and raw.get("declared_harness_pin") == HARNESS, "child source declarations mismatch")
    phases = raw.get("phases")
    io.require(isinstance(phases, list), "missing child phases")
    origins = object_field(raw, "origins")
    if config.engine.engine == "pecan":
        io.require(raw.get("cleanup_errors") == [] and raw.get("staging_payload_after_shutdown") == []
                   and raw.get("incomplete_rounds") == [], "child cleanup/round closure failed")
        io.require(raw.get("before") is None and raw.get("after") is None and raw.get("guest_steal_fraction") is None,
                   "native child must not invent Linux observations")
        shutdown = raw.get("shutdown")
        io.require(isinstance(shutdown, list) and bool(shutdown) and all(isinstance(r, dict)
                   and r.get("pid") == raw.get("driver_pid") and r.get("outcome") == "closed"
                   and r.get("sigkill_escalated") is False and r.get("error") is None
                   and r.get("sigint") in {"sent", "already_absent"} for r in shutdown),
                   "server shutdown escalated, failed, or lacks evidence")
        result = object_field(raw, "result")
        io.require(result.get("algorithm") == "pagerank-pregel-delta" and result.get("method") == "pregel_delta"
                   and result.get("seed") is None and result.get("iterations") == 10 and result.get("converged") is None,
                   "actual fixed-step PageRank result contract mismatch")
        io.require(raw.get("output_projection") == ["id", "pagerank"], "raw export projection changed")
        io.require(raw.get("pecan_snapshot_inputs") is False and raw.get("snapshots_in_engine_boundary") is False,
                   "matched PageRank requires snapshot bypass")
        required = {"server_startup", "session_startup", "input_handles", "input_snapshot", "public_algorithm",
                    "result_export", "result_close", "session_stop", "server_shutdown"}
        expected = {"algorithms": config.engine.repo / "examples/extensions/graph-algorithms/src/pyspark_pecan/algorithms.py",
                    "runtime": config.engine.harness_repo / "examples/extensions/benchmarks/runtime.py",
                    "measurement": config.engine.harness_repo / "examples/extensions/benchmarks/measurement.py",
                    "shutdown": config.support_manifest.path.parent / "support/shutdown.py",
                    "python_executable": config.python}
        io.require(set(origins) == set(expected) | {"python_version"}, "unknown child import origin")
        io.require(isinstance(origins.get("python_version"), str) and str(origins["python_version"]).startswith("3.12.6 "), "child Python version changed")
        io.require(raw.get("worker_count") == (2 if config.engine.mode == "process-cluster" else 0)
                   and raw.get("threads_per_process") == 16 and raw.get("worker_task_slots") == 64,
                   "declared runtime topology changed")
        if config.engine.mode == "process-cluster":
            io.require(sampler.max_simultaneous_workers == 2 and len(sampler.owned_workers) == 2,
                       "two owned process-cluster workers were not actually observed")
        else:
            io.require(not sampler.owned_workers, "unexpected local workers")
    else:
        io.require(raw.get("returncode") == 0 and raw.get("forced_cleanup") is False
                   and raw.get("error") is None and raw.get("traceback") is None and raw.get("cleanup_errors") == [], "native CLI did not finish naturally")
        io.require(raw.get("command") == graphframes_command(config.engine), "actual graphframes command changed")
        required = {"public_algorithm"}
        expected = {"native_models": config.helpers["native_models.py"].path, "python_executable": config.python}
        io.require(set(origins) == set(expected), "unknown graphframes child origin")
        io.require(not sampler.owned_workers, "graphframes must remain one local CLI process")
    io.require("wcc_profile" not in raw and "profile_wcc" not in origins, "unexpected profiler metadata")
    io.require(all(origins.get(k) == str(v.resolve() if k != "python_executable" else v) for k, v in expected.items()),
               "child import/python origin mismatch")
    ended = {p.get("name") for p in cast(list[JsonValue], phases)
             if isinstance(p, dict) and p.get("status") == "end"}
    io.require(ended == required, "full engine phase/cleanup coverage missing")
    io.require(all(isinstance(p, dict) and p.get("name") in required and p.get("status") in {"start", "end"}
                   for p in cast(list[JsonValue], phases)), "unknown or failed child phase")
    io.require(raw.get("inherited_library_path") == str(config.library_path), "child native library path differs")
    pid = raw.get("driver_pid")
    io.require(isinstance(pid, int) and not isinstance(pid, bool) and pid > 1, "missing native runtime identity")
    server_pid = cast(int, pid)
    io.require({p.pid for p in sampler.owned_servers} == {server_pid}, "runtime ownership not independently observed")
    return server_pid
