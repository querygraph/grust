# A2/A3 receipt comparison

Status: **incomplete**. Observed UTC: 2026-10-01T23:57:42.026136+00:00.

Ratios on Morrobay, a shared host. Raw seconds are diagnostics; no absolute-performance, multihost, generic signed-ID WCC, rebuilt-runtime, PageRank or larger-scale claim.

Retained host, bootstrap, container and cell JSON only; no Parquet/input reads, no independent rehash of payloads, no raw-sampler recomputation, no Docker or engine execution. Correctness is retained full-oracle receipt evidence, not a new physical-output audit.

## Shared-host ratios

Pecan / graphframes; values have three significant digits. All raw seconds below are diagnostics. graphframes is always a single CLI process with 16 workers; A3 changes Pecan to driver + two workers on one host.

| Execution class | Algorithm | Median ratio | ABBA block 1 | ABBA block 2 | Qualification |
| --- | --- | ---: | ---: | ---: | --- |
| local | wcc-randomized | 3.77 | 3.79 | 3.84 | 4 measured samples/engine; both ABBA blocks |
| local | wcc-min-label | 9.49 | 9.16 | 9.53 | 4 measured samples/engine; both ABBA blocks |
| local | bfs | 2.51 | 2.59 | 2.49 | 4 measured samples/engine; both ABBA blocks |
| process-cluster | wcc-randomized | 4.74 | 4.73 | 4.77 | 4 measured samples/engine; both ABBA blocks |
| process-cluster | wcc-min-label | 12.1 | 12.2 | 12.0 | 4 measured samples/engine; both ABBA blocks |
| process-cluster | bfs | — | — | — | missing, incomplete or failed measured cell; measured source/helper/binary/input/reference identities do not match |

n=4 per engine and two ordered blocks limit inference. Warmups are retained and excluded from statistics; failed and known-mismatch cells cannot qualify. Input cache warming is retained in the boundary. No phases are subtracted.

## Every planned cell

| Run ID | Role / block | Host / cell | Diagnostic launch→exit seconds | Engine sampled PSS GiB | Final container lifetime peak GiB | Guest steal | Qualified |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| a2-wcc-randomized-01-graphframes | warmup / — | passed / passed | 16.6076 | 1.49864 | 1.75328 | 0 | True |
| a2-wcc-randomized-02-pecan | warmup / — | passed / passed | 51.9824 | 2.19628 | 2.5059 | 0 | True |
| a2-wcc-randomized-03-graphframes | measured / 1 | passed / passed | 13.3241 | 1.44763 | 1.70669 | 0 | True |
| a2-wcc-randomized-04-pecan | measured / 1 | passed / passed | 52.0008 | 2.24849 | 2.53343 | 0 | True |
| a2-wcc-randomized-05-pecan | measured / 1 | passed / passed | 50.4168 | 2.27433 | 2.61649 | 0 | True |
| a2-wcc-randomized-06-graphframes | measured / 1 | passed / passed | 13.6773 | 1.47566 | 1.73265 | 0 | True |
| a2-wcc-randomized-07-graphframes | measured / 2 | passed / passed | 13.9012 | 1.46794 | 1.72668 | 0 | True |
| a2-wcc-randomized-08-pecan | measured / 2 | passed / passed | 51.6794 | 2.2555 | 2.56068 | 0 | True |
| a2-wcc-randomized-09-pecan | measured / 2 | passed / passed | 54.7216 | 2.19326 | 2.54265 | 0 | True |
| a2-wcc-randomized-10-graphframes | measured / 2 | passed / passed | 13.8311 | 1.48879 | 1.74414 | 0 | True |
| a2-wcc-min-label-01-graphframes | warmup / — | passed / passed | 14.0603 | 1.48115 | 1.73931 | 0 | True |
| a2-wcc-min-label-02-pecan | warmup / — | passed / passed | 123.781 | 3.28611 | 3.46241 | 0 | True |
| a2-wcc-min-label-03-graphframes | measured / 1 | passed / passed | 14.152 | 1.48815 | 1.74599 | 0 | True |
| a2-wcc-min-label-04-pecan | measured / 1 | passed / passed | 122.975 | 3.41454 | 3.64478 | 0 | True |
| a2-wcc-min-label-05-pecan | measured / 1 | passed / passed | 128.882 | 3.33245 | 3.53957 | 0 | True |
| a2-wcc-min-label-06-graphframes | measured / 1 | passed / passed | 13.3524 | 1.48302 | 1.73648 | 0 | True |
| a2-wcc-min-label-07-graphframes | measured / 2 | passed / passed | 13.6589 | 1.49242 | 1.74702 | 0 | True |
| a2-wcc-min-label-08-pecan | measured / 2 | passed / passed | 127.411 | 2.94652 | 3.22822 | 0 | True |
| a2-wcc-min-label-09-pecan | measured / 2 | passed / passed | 129.421 | 3.18729 | 3.3642 | 0 | True |
| a2-wcc-min-label-10-graphframes | measured / 2 | passed / passed | 13.2975 | 1.46518 | 1.71891 | 0 | True |
| a2-bfs-01-graphframes | warmup / — | passed / passed | 8.69079 | 0.974318 | 1.22538 | 0 | True |
| a2-bfs-02-pecan | warmup / — | passed / passed | 22.1991 | 1.11136 | 1.34332 | 0 | True |
| a2-bfs-03-graphframes | measured / 1 | passed / passed | 8.70511 | 0.991308 | 1.24212 | 0 | True |
| a2-bfs-04-pecan | measured / 1 | passed / passed | 22.2311 | 1.1003 | 1.38624 | 0 | True |
| a2-bfs-05-pecan | measured / 1 | passed / passed | 22.8799 | 1.06516 | 1.33352 | 0 | True |
| a2-bfs-06-graphframes | measured / 1 | passed / passed | 8.72825 | 0.974142 | 1.22427 | 0 | True |
| a2-bfs-07-graphframes | measured / 2 | passed / passed | 8.22347 | 1.03159 | 1.28163 | 0 | True |
| a2-bfs-08-pecan | measured / 2 | passed / passed | 21.5168 | 1.06593 | 1.32551 | 0 | True |
| a2-bfs-09-pecan | measured / 2 | passed / passed | 21.5271 | 1.09696 | 1.36037 | 0 | True |
| a2-bfs-10-graphframes | measured / 2 | passed / passed | 9.11661 | 1.11754 | 1.36884 | 0 | True |
| a3-wcc-randomized-01-graphframes | warmup / — | passed / passed | 14.0209 | 1.5114 | 1.76956 | 0 | True |
| a3-wcc-randomized-02-pecan | warmup / — | passed / passed | 63.609 | 2.41148 | 2.99494 | 0 | True |
| a3-wcc-randomized-03-graphframes | measured / 1 | passed / passed | 13.3149 | 1.48157 | 1.74119 | 0 | True |
| a3-wcc-randomized-04-pecan | measured / 1 | passed / passed | 66.7914 | 2.39443 | 2.95218 | 0 | True |
| a3-wcc-randomized-05-pecan | measured / 1 | passed / passed | 61.9199 | 2.47855 | 3.04531 | 0 | True |
| a3-wcc-randomized-06-graphframes | measured / 1 | passed / passed | 13.8605 | 1.46164 | 1.71587 | 0 | True |
| a3-wcc-randomized-07-graphframes | measured / 2 | passed / passed | 13.1083 | 1.52375 | 1.7812 | 0 | True |
| a3-wcc-randomized-08-pecan | measured / 2 | passed / passed | 60.9996 | 2.44853 | 3.02315 | 0 | True |
| a3-wcc-randomized-09-pecan | measured / 2 | passed / passed | 67.5952 | 2.3439 | 2.90543 | 0 | True |
| a3-wcc-randomized-10-graphframes | measured / 2 | passed / passed | 13.8174 | 1.44732 | 1.70431 | 0 | True |
| a3-wcc-min-label-01-graphframes | warmup / — | passed / passed | 13.2627 | 1.4974 | 1.75289 | 0 | True |
| a3-wcc-min-label-02-pecan | warmup / — | passed / passed | 164.17 | 3.36299 | 3.97539 | 0 | True |
| a3-wcc-min-label-03-graphframes | measured / 1 | passed / passed | 13.3077 | 1.45669 | 1.71538 | 0 | True |
| a3-wcc-min-label-04-pecan | measured / 1 | passed / passed | 163.363 | 3.66425 | 4.16745 | 0 | True |
| a3-wcc-min-label-05-pecan | measured / 1 | passed / passed | 164.068 | 3.47403 | 4.02282 | 0 | True |
| a3-wcc-min-label-06-graphframes | measured / 1 | passed / passed | 13.5461 | 1.42664 | 1.68249 | 0 | True |
| a3-wcc-min-label-07-graphframes | measured / 2 | passed / passed | 13.1632 | 1.445 | 1.70371 | 0 | True |
| a3-wcc-min-label-08-pecan | measured / 2 | passed / passed | 160.216 | 3.24526 | 3.87771 | 0 | True |
| a3-wcc-min-label-09-pecan | measured / 2 | passed / passed | 162.335 | 3.70345 | 4.22034 | 0 | True |
| a3-wcc-min-label-10-graphframes | measured / 2 | passed / passed | 13.6829 | 1.49501 | 1.75187 | 0 | True |
| a3-bfs-01-graphframes | warmup / — | passed / passed | 8.31688 | 0.949787 | 1.2001 | 0 | True |
| a3-bfs-02-pecan | warmup / — | passed / passed | 25.8442 | 1.83849 | 2.42024 | 0 | True |
| a3-bfs-03-graphframes | measured / 1 | passed / passed | 8.63935 | 0.959162 | 1.21016 | 0 | True |
| a3-bfs-04-pecan | measured / 1 | checking / missing | — | — | — | — | False |
| a3-bfs-05-pecan | measured / 1 | missing / missing | — | — | — | — | False |
| a3-bfs-06-graphframes | measured / 1 | missing / missing | — | — | — | — | False |
| a3-bfs-07-graphframes | measured / 2 | missing / missing | — | — | — | — | False |
| a3-bfs-08-pecan | measured / 2 | missing / missing | — | — | — | — | False |
| a3-bfs-09-pecan | measured / 2 | missing / missing | — | — | — | — | False |
| a3-bfs-10-graphframes | measured / 2 | missing / missing | — | — | — | — | False |

## Phase and memory boundaries

The comparison timer spans engine launch through completed exit, including input, snapshots, algorithm, export and engine cleanup. Parent identity hashing, full oracle and final ownership checks are outside. JSON retains each cell's exact recorded boundary, supervisor phases, Pecan phases/rounds, coverage, steal and host admission observations. Pecan input_snapshot is nested inside public_algorithm: these durations are not additive. External phase breakdown and rounds are unavailable when the CLI emits no structured receipt; they are never inferred.

Sampled engine PSS excludes supervisor/PID 1. Whole-container execute PSS includes them. Cgroup peaks include page cache and prior identity reads; the final lifetime peak also includes parent oracle/final observation. Peaks and sampling coverage remain separate.

## Retained attempts and prerequisite phases

- compatibility04: compatibility; host passed_with_known_mismatch, producer passed_with_known_mismatch; accepted closure True; known mismatches ['b9-signed-isolate'].
- stage04: stage; host passed, producer passed; accepted closure True; known mismatches [].
- validation04: validation; host passed, producer passed; accepted closure True; known mismatches [].

## Withheld cells

- a3-bfs-04-pecan: incomplete; cell: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-04-pecan/container/artifacts/receipt.json'; container: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-04-pecan/container-record.json'; bootstrap: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-04-pecan/container/artifacts/bootstrap-receipt.json'; host outcome is 'checking'; cell outcome is None; bootstrap outcome is None; host producer/run identity mismatch; cell configuration differs from planned contrast; host exact configured cell differs or missing; completed verified engine exit missing; positive finite launch-to-exit time missing; before/after source/input/helper identities differ or missing; source or external binary differs from planned pin; passed reference/zero-isolate scope missing; validated BFS source differs from declared plan source; full physical output oracle pass evidence missing; directed BFS source differs from validated reference; actual engine method missing or mislabelled; Pecan convergence or engine cleanup did not pass; complete execute-phase engine PSS observation missing; producer 16CPU/32GiB/no-swap envelope differs; retained container limits differ
- a3-bfs-05-pecan: missing; host: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-05-pecan/result.json'; cell: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-05-pecan/container/artifacts/receipt.json'; container: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-05-pecan/container-record.json'; bootstrap: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-05-pecan/container/artifacts/bootstrap-receipt.json'; configuration: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-05-pecan/configuration.json'; host outcome is None; cell outcome is None; bootstrap outcome is None; host producer/run identity mismatch; cell configuration differs from planned contrast; host exact configured cell differs or missing; completed verified engine exit missing; positive finite launch-to-exit time missing; before/after source/input/helper identities differ or missing; source or external binary differs from planned pin; passed reference/zero-isolate scope missing; validated BFS source differs from declared plan source; full physical output oracle pass evidence missing; directed BFS source differs from validated reference; actual engine method missing or mislabelled; Pecan convergence or engine cleanup did not pass; complete execute-phase engine PSS observation missing; producer 16CPU/32GiB/no-swap envelope differs; retained container limits differ
- a3-bfs-06-graphframes: missing; host: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-06-graphframes/result.json'; cell: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-06-graphframes/container/artifacts/receipt.json'; container: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-06-graphframes/container-record.json'; bootstrap: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-06-graphframes/container/artifacts/bootstrap-receipt.json'; configuration: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-06-graphframes/configuration.json'; host outcome is None; cell outcome is None; bootstrap outcome is None; host producer/run identity mismatch; cell configuration differs from planned contrast; host exact configured cell differs or missing; completed verified engine exit missing; positive finite launch-to-exit time missing; before/after source/input/helper identities differ or missing; source or external binary differs from planned pin; passed reference/zero-isolate scope missing; validated BFS source differs from declared plan source; full physical output oracle pass evidence missing; directed BFS source differs from validated reference; actual engine method missing or mislabelled; complete execute-phase engine PSS observation missing; producer 16CPU/32GiB/no-swap envelope differs; retained container limits differ
- a3-bfs-07-graphframes: missing; host: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-07-graphframes/result.json'; cell: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-07-graphframes/container/artifacts/receipt.json'; container: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-07-graphframes/container-record.json'; bootstrap: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-07-graphframes/container/artifacts/bootstrap-receipt.json'; configuration: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-07-graphframes/configuration.json'; host outcome is None; cell outcome is None; bootstrap outcome is None; host producer/run identity mismatch; cell configuration differs from planned contrast; host exact configured cell differs or missing; completed verified engine exit missing; positive finite launch-to-exit time missing; before/after source/input/helper identities differ or missing; source or external binary differs from planned pin; passed reference/zero-isolate scope missing; validated BFS source differs from declared plan source; full physical output oracle pass evidence missing; directed BFS source differs from validated reference; actual engine method missing or mislabelled; complete execute-phase engine PSS observation missing; producer 16CPU/32GiB/no-swap envelope differs; retained container limits differ
- a3-bfs-08-pecan: missing; host: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-08-pecan/result.json'; cell: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-08-pecan/container/artifacts/receipt.json'; container: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-08-pecan/container-record.json'; bootstrap: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-08-pecan/container/artifacts/bootstrap-receipt.json'; configuration: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-08-pecan/configuration.json'; host outcome is None; cell outcome is None; bootstrap outcome is None; host producer/run identity mismatch; cell configuration differs from planned contrast; host exact configured cell differs or missing; completed verified engine exit missing; positive finite launch-to-exit time missing; before/after source/input/helper identities differ or missing; source or external binary differs from planned pin; passed reference/zero-isolate scope missing; validated BFS source differs from declared plan source; full physical output oracle pass evidence missing; directed BFS source differs from validated reference; actual engine method missing or mislabelled; Pecan convergence or engine cleanup did not pass; complete execute-phase engine PSS observation missing; producer 16CPU/32GiB/no-swap envelope differs; retained container limits differ
- a3-bfs-09-pecan: missing; host: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-09-pecan/result.json'; cell: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-09-pecan/container/artifacts/receipt.json'; container: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-09-pecan/container-record.json'; bootstrap: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-09-pecan/container/artifacts/bootstrap-receipt.json'; configuration: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-09-pecan/configuration.json'; host outcome is None; cell outcome is None; bootstrap outcome is None; host producer/run identity mismatch; cell configuration differs from planned contrast; host exact configured cell differs or missing; completed verified engine exit missing; positive finite launch-to-exit time missing; before/after source/input/helper identities differ or missing; source or external binary differs from planned pin; passed reference/zero-isolate scope missing; validated BFS source differs from declared plan source; full physical output oracle pass evidence missing; directed BFS source differs from validated reference; actual engine method missing or mislabelled; Pecan convergence or engine cleanup did not pass; complete execute-phase engine PSS observation missing; producer 16CPU/32GiB/no-swap envelope differs; retained container limits differ
- a3-bfs-10-graphframes: missing; host: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-10-graphframes/result.json'; cell: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-10-graphframes/container/artifacts/receipt.json'; container: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-10-graphframes/container-record.json'; bootstrap: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-10-graphframes/container/artifacts/bootstrap-receipt.json'; configuration: [Errno 2] No such file or directory: '/Volumes/Apo/graph-tests/results/sem-review-20261001/A2-run04/a3-bfs-10-graphframes/configuration.json'; host outcome is None; cell outcome is None; bootstrap outcome is None; host producer/run identity mismatch; cell configuration differs from planned contrast; host exact configured cell differs or missing; completed verified engine exit missing; positive finite launch-to-exit time missing; before/after source/input/helper identities differ or missing; source or external binary differs from planned pin; passed reference/zero-isolate scope missing; validated BFS source differs from declared plan source; full physical output oracle pass evidence missing; directed BFS source differs from validated reference; actual engine method missing or mislabelled; complete execute-phase engine PSS observation missing; producer 16CPU/32GiB/no-swap envelope differs; retained container limits differ
