"""Bounded mock physical/delegation controls; no native imports, probes or engines."""
from __future__ import annotations

import tempfile
import unittest
from collections.abc import Callable
from pathlib import Path
from unittest.mock import patch

import control
import models as m
from pydantic import ValidationError


def case(root: Path, canonical: bool = True) -> m.Control:
    output = root / "raw"
    output.mkdir()
    (output / "part.parquet").write_bytes(b"bounded mock physical file, not an actual Parquet")
    expected = [m.Row(id=i, component=m.ISOLATE if i == m.ISOLATE else 1) for i in sorted(m.IDS)] if canonical else None
    return m.Control(canonical_labels=canonical, output=output, expected_rows=expected)


def physical(rows: list[m.Row], name: str = "part.parquet") -> m.Physical:
    return m.Physical(file=name, fields=[m.Field(name=n, arrow_type="int64", nullable=True)
                       for n in ("id", "component")], footer_rows=len(rows), rows=rows)


def reader(rows: list[m.Row]) -> Callable[[Path, str], m.Physical]:
    def read(_path: Path, name: str) -> m.Physical:
        return physical(rows, name)
    return read


def configured(root: Path) -> m.Config:
    root = root.resolve()
    def item(name: str, digest: str = "a"*64, size: int = 1) -> m.Pin:
        return m.Pin(path=root / name, bytes=size, sha256=digest)
    names: tuple[m.HelperName, ...] = ("control.py", "models.py", "runtime.py", "measurement.py")
    helpers = {n: item(n, m.FROZEN.get(n, "a"*64)) for n in
               names}
    return m.Config(repo=root / "repo", output=root / "output", python=root / "python",
                    library_path=root / "lib", binary=item("sail"), build=item("build.json"),
                    client=item("client.json"), source_admission=item("admission.json"),
                    historical_control=item("historical.json", m.HISTORICAL_SHA, 4284), helpers=helpers)


class Controls(unittest.TestCase):
    def test_canonical_exact_rows_with_highbit_isolate(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            actual = case(Path(directory))
            rows = [m.Row(id=1, component=1), m.Row(id=2, component=1), m.Row(id=m.ISOLATE, component=m.ISOLATE)]
            control.check(actual, lambda _path, name: physical(rows, name))
            self.assertEqual(actual.outcome, "passed")
            self.assertEqual(actual.raw_rows, actual.expected_rows)
            self.assertTrue(actual.full_coverage and actual.full_partition)
            self.assertEqual(actual.files_before, actual.files_after)

    def test_noncanonical_partition_without_invented_expected_labels(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            actual = case(Path(directory), False)
            rows = [m.Row(id=1, component=-10), m.Row(id=2, component=-10), m.Row(id=m.ISOLATE, component=7)]
            control.check(actual, lambda _path, name: physical(rows, name))
            self.assertIsNone(actual.expected_rows)
            self.assertEqual(actual.expected_groups, ((1, 2), (m.ISOLATE,)))
            self.assertEqual(actual.raw_rows[0].component, 7)
            self.assertEqual(actual.outcome, "passed")

    def test_false_merge_and_split_preserve_all_actual_rows(self) -> None:
        for labels in ((7, 7, 7), (1, 2, -10)):
            with self.subTest(labels=labels), tempfile.TemporaryDirectory() as directory:
                actual = case(Path(directory), False)
                rows = [m.Row(id=i, component=c) for i, c in zip(m.IDS, labels, strict=True)]
                with self.assertRaisesRegex(control.Mismatch, "full partition"):
                    control.check(actual, reader(rows))
                self.assertEqual(len(actual.raw_rows), 3)
                self.assertTrue(actual.full_coverage)
                self.assertFalse(actual.full_partition)
                self.assertEqual(actual.files_before, actual.files_after)

    def test_canonical_wrong_member_label_refused(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            actual = case(Path(directory))
            rows = [m.Row(id=1, component=2), m.Row(id=2, component=2), m.Row(id=m.ISOLATE, component=m.ISOLATE)]
            with self.assertRaisesRegex(control.Mismatch, "canonical exact"):
                control.check(actual, lambda _path, name: physical(rows, name))
            self.assertEqual(actual.raw_rows[1].component, 2)

    def test_duplicate_omitted_extra_and_unknown_vertices(self) -> None:
        for ids in ((1, 1, m.ISOLATE), (1, 2), (1, 2, m.ISOLATE, 99), (1, 2, 99)):
            with self.subTest(ids=ids), tempfile.TemporaryDirectory() as directory:
                actual = case(Path(directory), False)
                rows = [m.Row(id=i, component=7 if i != m.ISOLATE else 8) for i in ids]
                with self.assertRaisesRegex(ValueError, "domain|footer"):
                    control.check(actual, reader(rows))
                self.assertFalse(actual.full_partition)
                self.assertEqual(len(actual.raw_rows), len(ids))

    def test_null_values_preserved_and_refused(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            actual = case(Path(directory), False)
            rows = [m.Row(id=1, component=None), m.Row(id=2, component=1), m.Row(id=m.ISOLATE, component=2)]
            with self.assertRaisesRegex(control.Mismatch, "null raw"):
                control.check(actual, lambda _path, name: physical(rows, name))
            self.assertIsNone(actual.raw_rows[1].component)

    def test_float_bool_and_signed_overflow_refused_without_coercion(self) -> None:
        for value in (True, 1.0, 2**63, -(2**63)-1, "1"):
            with self.subTest(value=value), self.assertRaises(ValidationError):
                m.Row.model_validate({"id": value, "component": 1})

    def test_wrong_physical_schema_and_footer_retained_before_values(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            actual = case(Path(directory))
            wrong = physical([]).model_copy(update={"fields": [m.Field(name="id", arrow_type="double", nullable=True)],
                                                    "footer_rows": 3})
            with self.assertRaisesRegex(ValueError, "before adaptation"):
                control.check(actual, lambda _path, _name: wrong)
            self.assertEqual(actual.physical, [wrong])
            self.assertEqual(actual.raw_rows, [])
            self.assertTrue(actual.files_before)

    def test_output_mutation_cannot_pass(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            actual = case(Path(directory))
            rows = [m.Row(id=i, component=m.ISOLATE if i == m.ISOLATE else 1) for i in m.IDS]
            def changed(path: Path, name: str) -> m.Physical:
                path.write_bytes(b"changed while checking")
                return physical(rows, name)
            with self.assertRaisesRegex(ValueError, "changed during"):
                control.check(actual, changed)
            self.assertNotEqual(actual.files_before, actual.files_after)

    def test_owned_cleanup_failure_retained_and_later_cleanup_attempted(self) -> None:
        sink = m.Sink()
        calls: list[str] = []
        def fail() -> None:
            calls.append("first")
            raise RuntimeError("original cleanup failure")
        with patch("control.signal.alarm"):
            self.assertFalse(control.cleanup("result", fail, sink))
            self.assertTrue(control.cleanup("session", lambda: calls.append("second"), sink))
        self.assertEqual(calls, ["first", "second"])
        self.assertEqual(sink.records[0].operation, "result")
        self.assertIn("original cleanup failure", sink.records[0].error)

    def test_model_requires_same_historical_resource_settings_and_helpers(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = configured(Path(directory))
            for change in ({"partitions": 3}, {"threads": 4}, {"native_quota": 1}, {"pool_bytes": 1},
                           {"historical_control": config.historical_control.model_copy(update={"sha256": "b"*64})}):
                with self.subTest(change=change), self.assertRaises(ValidationError):
                    m.Config.model_validate({**config.model_dump(), **change})
            m.Receipt(config=config, started_utc="fixture").model_dump_json()

    def test_run_failure_receipt_keeps_original_error_and_cleanup(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = configured(Path(directory))
            configuration = config.build
            def failed(_config: m.Config, receipt: m.Receipt, _path: Path, sink: m.Sink) -> None:
                sink.append({"operation": "session_stop", "error": "cleanup failure"})
                receipt.controls.append(m.Control(canonical_labels=True, output=config.output / "raw"))
                raise RuntimeError("original engine failure")
            with (patch("control.platform.system", return_value="Darwin"),
                  patch("control.platform.machine", return_value="x86_64"),
                  patch.object(control, "identities", return_value={}),
                  patch.object(control, "execute", side_effect=failed), patch("control.signal.alarm")):
                self.assertEqual(control.run(config, configuration), 1)
            receipt = m.Receipt.model_validate_json((config.output / "receipt.json").read_bytes())
            self.assertIn("original engine failure", receipt.error or "")
            self.assertEqual(receipt.cleanup_errors[0].operation, "session_stop")
            self.assertFalse(receipt.independent_process_group_absence)
            self.assertFalse(receipt.performance_comparison)

    def test_identity_closure_mutation_overrides_mock_pass(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = configured(Path(directory))
            def passed(_config: m.Config, receipt: m.Receipt, _path: Path, _sink: m.Sink) -> None:
                receipt.controls.extend(m.Control(canonical_labels=c, output=config.output / str(c),
                    outcome="passed", full_coverage=True, full_partition=True) for c in (True, False))
                receipt.runtime_shutdown_completed = True
            with (patch("control.platform.system", return_value="Darwin"),
                  patch("control.platform.machine", return_value="x86_64"),
                  patch.object(control, "identities", side_effect=[{}, {"changed": config.binary}]),
                  patch.object(control, "execute", side_effect=passed), patch("control.signal.alarm")):
                self.assertEqual(control.run(config, config.build), 1)
            receipt = m.Receipt.model_validate_json((config.output / "receipt.json").read_bytes())
            self.assertEqual(receipt.outcome, "error")
            self.assertIn("closure differs", receipt.integrity_errors[0])


if __name__ == "__main__":
    unittest.main()
