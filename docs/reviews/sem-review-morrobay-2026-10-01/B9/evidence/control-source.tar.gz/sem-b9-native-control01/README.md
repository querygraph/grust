# Native B9 signed-isolate control — source-only freeze

Observed UTC: 2026-10-02T10:51:16.607306+00:00

## Scope

Two complete three-vertex controls use controller b522bf3a9c38d3861a114bf672abe7f7d6c7c491,
compiled native Sail 9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3 and frozen Python
runtime/measurement 6ae2e43a903c2cee02da170465c922c72b76198e. This is a focused
regression witness and supplies no generic signed-ID qualification or performance
comparison. Existing historical receipts remain unchanged.

Logical vertices [1,2,-7694170072594669674], edge 1->2. Fresh typed Spark Connect
LocalRelations have schema id long and src long,dst long; original historical
source/target Parquet is retained separately and is not consumed or rewritten.
Both canonical_labels=True and False run with seed42, max_iterations100,
snapshot_inputs=True, repartition_checkpoints=True, partitions16, softwarethreads16,
greedy pool32212254720 bytes and configured native quota268435456 bytes. These are
software settings, not OS resource caps or measured reservations.

CanonicalTrue requires exactly 1:1,2:1,isolate:isolate. CanonicalFalse requires
complete unique domain, labels[1]==labels[2] and labels[isolate]!=labels[1]; it
records no invented expected hashed labels. Both record actual metadata, raw
physical schema/footer, every raw row, all raw file identities before/after and
independent expected partition. A wrong partition/null/duplicate/omission or
canonical label is a failure. Outputs are not cast or rewritten.

## Correct isolated launcher

Direct `python -I control.py` omits the sibling models module from sys.path.
Use an isolated bootstrap that adds the exact admitted helper directory first:

```text
DYLD_LIBRARY_PATH=/Users/alexy/.asdf/installs/python/3.12.6/lib PYTHONDONTWRITEBYTECODE=1 <admitted-venv>/bin/python -I -B -c 'import runpy,sys; sys.path.insert(0,sys.argv[1]); sys.argv=[sys.argv[1]+"/control.py","--config",sys.argv[2]]; runpy.run_path(sys.argv[0],run_name="__main__")' <pinned-helper-directory> <fresh-config.json>
```

Use exactly the admitted native client Python path, not another interpreter alias.
The illustrative config is computed from existing small metadata receipts only;
its binary pin comes from root's actual build receipt and was not independently
rehash-qualified by this agent. Root must copy frozen helpers to a durable Apo
namespace, replace the two control/models helper paths with the actual absolute
resolved copies, and seal the final fresh config before launch. Helper bytes must
match freeze.json; do not modify them to change paths. The configured native SSD
output must be absent. There is no resume/retry/force-cleanup option.

## Boundaries and evidence

Each public wcc call is clocked separately; raw Parquet export is a second clock.
Result close precedes the full bounded physical oracle, outside the public-call
clock. No components count, input-validation job or extra collect action is
added to the algorithm. The oracle reads actual exported physical files locally
and records all three rows. Diagnostic times are not a benchmark comparison.

The source/controller clean detached HEAD/tree and Rust paths/Cargo parity with
9f are checked before/after. Config, root source-admission/build/client proof,
binary, historical control, all actual helpers and selected client/ABI/module
pins are hashed before/after. Actual imported origins are recorded/pinned and
checked after execution. The admitted client has Python3.12.6 and zero pysail
extension entrypoints. No new ABI/native import probe was run by this agent.

Frozen runtime.server owns native server startup and shutdown. Result close,
Spark session stop and server exit are attempted separately; every cleanup
failure is retained and prevents passed_control. The child records runtime
shutdown completion and remaining staging payload; root must independently
check waited helper exit, helper/server process-group absence and all matching
native Sail servers, then retain/hash complete physical output. Child fields
independent_process_group_absence and outer_retention_qualified remain false.

Receipt outcome passed_control requires both modes, full coverage/partition,
converged actual randomized/seed42 metadata, no cleanup errors, no remaining
staging payload and exact immutable before/after identities. Any error,
timeout, interruption, mismatch or mutation returns1 with receipt/traceback;
no failed output is removed automatically.

## Historical witness

Original control:
BASE/A2-run04/compatibility04/container/artifacts/controls/b9-signed-isolate/control-receipt.json,
4284 bytes SHA ce74bca2399cfd0957bbab9d779b0ce7443b6237b15d887e7269072b24229f6b.
Original canonicalTrue Linux outcome was known_mismatch with all three labels
equal to isolate. Engine-config669 bytes SHA
4fe17095a7e0464423e122a8db35af8ae9bb4fdffb81999be1bddb9ccc239a6c
records the same16 partition/thread/software pool settings. It stays historical;
this new native controller/runtime execution must be recorded separately.

## Source controls and limitations

13 bounded mock controls passed with repo Ruff and strict mypy; source hashes
are identical before/after the exact final gate. They check canonical/noncanonical
partition, false merge/split, null/duplicate/omit/extra/domain, wrong signed
integer values/types, raw schema/footer before adaptation, physical mutation,
cleanup continuation/error retention, immutable closure and matching historical
resource settings. Mock bytes are not actual Parquet and no engine/native/Spark/
Arrow imports or probes were exercised by these controls.

No actual B9 run, source/native admission probe, payload scan, engine/build,
Docker/VM/lock/Git mutation or production-output check was performed by this
agent. Root owns macOS execution and final process/resource/physical retention
observations. No Linux cgroups/PSS are fabricated.
