"""Root-run native signed-isolate control; imports engines only in actual execution."""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
import platform
import signal
import subprocess
import sys
import time
import traceback
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType, ModuleType
from typing import Any, Protocol, cast

import models as m
from pydantic import JsonValue, TypeAdapter

OBJECT = TypeAdapter(dict[str, JsonValue])


class Frame(Protocol):
    @property
    def write(self) -> Any: ...
    def select(self, *columns: str) -> Frame: ...


class Session(Protocol):
    def createDataFrame(self, rows: list[tuple[int, ...]], schema: str) -> Frame: ...
    def stop(self) -> None: ...


class Result(Protocol):
    algorithm: str
    method: str | None
    seed: int | None
    iterations: int
    converged: bool | None
    @property
    def frame(self) -> Frame: ...
    def close(self) -> None: ...


class Graph(Protocol):
    def wcc(self, vertices: Frame, edges: Frame, *, method: str, seed: int,
            canonical_labels: bool, max_iterations: int, partitions: int) -> Result: ...


class Mismatch(ValueError):
    """Physical output or full three-row witness is wrong."""


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def pin(path: Path) -> m.Pin:
    require(path.is_file() and not path.is_symlink(), f"unsafe/missing pin: {path}")
    before = path.stat()
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_ino, after.st_size, after.st_mtime_ns), f"changed while hashing: {path}")
    return m.Pin(path=path, bytes=after.st_size, sha256=digest)


def verify(item: m.Pin) -> m.Pin:
    require(pin(item.path) == item, f"pin mismatch: {item.path}")
    return item


def load(path: Path) -> dict[str, JsonValue]:
    require(path.stat().st_size <= 2**20, "metadata exceeds bound")
    return OBJECT.validate_json(path.read_bytes())


def save(path: Path, receipt: m.Receipt) -> None:
    temporary = path.with_suffix(".tmp")
    with temporary.open("w") as stream:
        stream.write(receipt.model_dump_json(indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["/usr/bin/git", "-C", str(repo), *args], text=True,
                                   timeout=10).strip()


def identities(config: m.Config, configuration: m.Pin) -> dict[str, m.Pin]:
    items = [configuration, config.binary, config.build, config.client, config.source_admission,
             config.historical_control, *config.helpers.values()]
    client = load(config.client.path)
    modules = client.get("modules")
    require(isinstance(modules, dict), "actual client admission modules absent")
    items.extend(m.Pin.model_validate(x) for x in cast(dict[str, JsonValue], modules).values())
    items.extend(m.Pin.model_validate(client.get(n)) for n in ("executable", "libpython", "lock"))
    require(client.get("python") == str(config.python) and client.get("python_version") == "3.12.6"
            and client.get("extensions") == [], "actual native client/zero-entrypoint admission required")
    require(config.python.resolve() == m.Pin.model_validate(client.get("executable")).path
            and sys.executable == str(config.python) and platform.python_version() == "3.12.6",
            "actual admitted interpreter differs")
    observed = {str(item.path): verify(item) for item in items}
    require(git(config.repo, "rev-parse", "HEAD") == m.CONTROLLER
            and git(config.repo, "rev-parse", "HEAD^{tree}") == m.TREE
            and not git(config.repo, "status", "--porcelain=v1", "--untracked-files=all"),
            "exact clean controller source required")
    branch = subprocess.run(["/usr/bin/git", "-C", str(config.repo), "symbolic-ref", "-q", "HEAD"],
                            capture_output=True, timeout=10, check=False)
    require(branch.returncode == 1, "controller must be detached")
    require(not git(config.repo, "diff", m.CONTROLLER, m.RUNTIME, "--", "crates", "Cargo.toml",
                    "Cargo.lock", "rust-toolchain.toml"), "compiled Rust/runtime parity differs")
    admission = load(config.source_admission.path)
    require(admission.get("controller") == m.CONTROLLER and admission.get("tree") == m.TREE
            and admission.get("compiled_runtime") == m.RUNTIME
            and admission.get("source") == str(config.repo), "root source admission differs")
    build = load(config.build.path)
    steps = build.get("steps")
    require(build.get("outcome") == "passed_optimized_native_binaries" and bool(build.get("finished_utc"))
            and isinstance(steps, list), "completed native optimized build required")
    sails = [s for s in cast(list[JsonValue], steps) if isinstance(s, dict) and s.get("name") == "sail"]
    require(len(sails) == 1, "one compiled Sail identity required")
    step = sails[0]
    require(m.Pin.model_validate(step.get("binary")) == config.binary and step.get("returncode") == 0,
            "actual native binary differs")
    source = step.get("source_after")
    require(isinstance(source, dict) and source.get("commit") == m.RUNTIME,
            "compiled runtime source differs")
    require(Path(__file__).resolve() == config.helpers["control.py"].path
            and Path(m.__file__).resolve() == config.helpers["models.py"].path,
            "actual helper origins differ")
    return observed


def inventory(root: Path) -> dict[str, m.Identity]:
    require(root.is_dir() and not root.is_symlink(), "missing/unsafe result directory")
    output: dict[str, m.Identity] = {}
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), "result symlink refused")
        if path.is_file():
            actual = pin(path)
            output[str(path.relative_to(root))] = m.Identity(bytes=actual.bytes, sha256=actual.sha256)
        else:
            require(path.is_dir(), "special result file refused")
    require(len(output) <= 128 and sum(p.bytes for p in output.values()) <= 16*2**20,
            "tiny output exceeds admission")
    return output


def read_physical(path: Path, name: str) -> m.Physical:
    module = importlib.import_module("pyarrow.parquet")
    with cast(Any, module).ParquetFile(path) as parquet:
        fields = [m.Field(name=f.name, arrow_type=str(f.type), nullable=f.nullable)
                  for f in parquet.schema_arrow]
        admissible = ([(f.name, f.arrow_type) for f in fields] == [("id", "int64"), ("component", "int64")]
                      and parquet.metadata.num_rows <= 3)
        rows = ([m.Row.model_validate(r) for r in parquet.read(columns=["id", "component"]).to_pylist()]
                if admissible else [])
        return m.Physical(file=name, fields=fields, footer_rows=parquet.metadata.num_rows, rows=rows)


def check(case: m.Control, reader: Callable[[Path, str], m.Physical] = read_physical) -> None:
    case.files_before = inventory(case.output)
    names = [n for n in case.files_before if n.endswith(".parquet")]
    require(bool(names), "no physical Parquet output")
    for name in names:
        physical = reader(case.output / name, name)
        case.physical.append(physical)
        case.raw_rows.extend(physical.rows)
        require([(f.name, f.arrow_type) for f in physical.fields] == [("id", "int64"), ("component", "int64")]
                and physical.footer_rows <= 3 and len(physical.rows) == physical.footer_rows,
                "raw schema/footer differs before adaptation")
    case.raw_rows.sort(key=lambda r: (r.id is None, r.id or 0))
    case.files_after = inventory(case.output)
    require(case.files_before == case.files_after, "physical output changed during full tiny oracle")
    ids = [r.id for r in case.raw_rows]
    if any(r.id is None or r.component is None for r in case.raw_rows):
        raise Mismatch("null raw vertex/component")
    if len(ids) != 3 or len(set(ids)) != 3 or set(ids) != set(m.IDS):
        raise Mismatch("complete unique three-vertex domain differs")
    case.full_coverage = True
    labels = {r.id: r.component for r in case.raw_rows}
    if labels[1] != labels[2] or labels[m.ISOLATE] == labels[1]:
        raise Mismatch("full partition must be {1,2}/{signed isolate}")
    if case.canonical_labels and case.raw_rows != case.expected_rows:
        raise Mismatch("canonical exact original-ID labels differ")
    case.full_partition = True
    case.outcome = "passed"


def cleanup(name: str, action: Callable[[], object], sink: m.Sink) -> bool:
    try:
        signal.alarm(30)
        action()
        return True
    except BaseException as error:  # noqa: BLE001 -- preserve original failure and perform later cleanup.
        sink.append({"operation": name, "error": repr(error)})
        return False
    finally:
        signal.alarm(0)


def imported(config: m.Config, receipt: m.Receipt, name: str, expected: Path) -> ModuleType:
    module = importlib.import_module(name)
    actual = pin(Path(cast(str, module.__file__)).resolve())
    require(actual.path == expected.resolve(), f"wrong actual import origin: {name}")
    receipt.imports[name] = actual
    return module


def execute(config: m.Config, receipt: m.Receipt, path: Path, sink: m.Sink) -> None:
    sys.path[:0] = [str(config.repo / "examples/extensions/graph-algorithms/src"),
                   str(config.helpers["runtime.py"].path.parent)]
    runtime = imported(config, receipt, "runtime", config.helpers["runtime.py"].path)
    imported(config, receipt, "measurement", config.helpers["measurement.py"].path)
    algorithms = imported(config, receipt, "pyspark_pecan.algorithms",
                          config.repo / "examples/extensions/graph-algorithms/src/pyspark_pecan/algorithms.py")
    client = load(config.client.path)
    modules = cast(dict[str, JsonValue], client["modules"])
    for name, item in modules.items():
        imported(config, receipt, name, m.Pin.model_validate(item).path)
    session_module = importlib.import_module("pyspark.sql.connect.session")
    retries = importlib.import_module("pyspark.sql.connect.client.retries")
    for name in tuple(os.environ):
        if name.startswith("SAIL_"):
            del os.environ[name]
    os.environ.update(SPARK_CONNECT_MODE_ENABLED="1", PYTHONDONTWRITEBYTECODE="1",
                      SAIL_BENCHMARK_RUST_LOG="warn")
    server = cast(Any, runtime).server(config.binary.path, config.output, "local", 16, 16,
                                    config.native_quota, sink, worker_task_slots=64,
                                    sail_pool_bytes=config.pool_bytes, http2_keepalive_timeout=120)
    spark: Session | None = None
    entered = False
    try:
        signal.alarm(config.timeout_seconds)
        endpoint, receipt.server_pid = server.__enter__()
        entered = True
        spark = cast(Session, cast(Any, session_module).SparkSession.builder.remote(endpoint).create())
        cast(Any, spark).client.set_retry_policies([cast(Any, retries).DefaultPolicy(
            max_retries=1, initial_backoff=100, max_backoff=100, jitter=0)])
        graph = cast(Graph, cast(Any, algorithms).GraphAlgorithms(spark, record_plans=False,
                     repartition_checkpoints=True, snapshot_inputs=True))
        for canonical in (True, False):
            signal.alarm(config.timeout_seconds)
            expected = [m.Row(id=i, component=m.ISOLATE if i == m.ISOLATE else 1) for i in sorted(m.IDS)] if canonical else None
            case = m.Control(canonical_labels=canonical, output=config.output / f"canonical-{str(canonical).lower()}",
                             expected_rows=expected)
            receipt.controls.append(case)
            save(path, receipt)
            result: Result | None = None
            try:
                vertices = spark.createDataFrame([(i,) for i in m.IDS], "id long")
                edges = spark.createDataFrame(list(m.EDGES), "src long, dst long")
                began = time.perf_counter()
                result = graph.wcc(vertices, edges, method="randomized", seed=42,
                                   canonical_labels=canonical, max_iterations=100, partitions=16)
                case.algorithm_seconds = time.perf_counter()-began
                case.actual_algorithm, case.actual_method, case.actual_seed = result.algorithm, result.method, result.seed
                case.iterations, case.converged = result.iterations, result.converged
                require((result.algorithm, result.method, result.seed, result.converged) ==
                        ("wcc-randomized-contraction", "randomized", 42, True)
                        and 0 < result.iterations <= 100, "actual algorithm did not converge as declared")
                began = time.perf_counter()
                result.frame.select("id", "component").write.mode("error").parquet(case.output.as_uri())
                case.export_seconds = time.perf_counter()-began
            except BaseException as error:  # Preserve the actual failed control.
                case.outcome, case.error = "error", repr(error)
                save(path, receipt)
                raise
            finally:
                if result is not None:
                    cleanup(f"result_close_canonical_{canonical}", result.close, sink)
            try:
                check(case)
            except BaseException as error:  # Actual raw rows remain in durable failure receipt.
                case.outcome, case.error = "error", repr(error)
                raise
            finally:
                save(path, receipt)
    finally:
        active_error = sys.exc_info()
        if spark is not None:
            cleanup("session_stop", spark.stop, sink)
        if entered:
            receipt.runtime_shutdown_completed = cleanup("server_shutdown", lambda: server.__exit__(*active_error), sink)


def interrupted(signum: int, _frame: FrameType | None) -> None:
    raise TimeoutError("owned native control deadline") if signum == signal.SIGALRM else InterruptedError(f"signal {signum}")


def run(config: m.Config, configuration: m.Pin) -> int:
    require(platform.system() == "Darwin" and platform.machine() == "x86_64", "native macOS x86_64 required")
    require(not config.output.exists() and not config.output.is_symlink()
            and not any(p.is_symlink() for p in config.output.parents), "fresh SSD output without symlink ancestry required")
    config.output.mkdir(parents=True, exist_ok=False)
    receipt = m.Receipt(config=config, started_utc=utc())
    path, sink = config.output / "receipt.json", m.Sink()
    save(path, receipt)
    try:
        receipt.before = identities(config, configuration)
        execute(config, receipt, path, sink)
        require(len(receipt.controls) == 2 and [c.canonical_labels for c in receipt.controls] == [True, False]
                and all(c.outcome == "passed" and c.full_coverage and c.full_partition for c in receipt.controls),
                "both full controls must pass")
        require(receipt.runtime_shutdown_completed and not sink.records, "owned runtime cleanup incomplete")
        receipt.outcome = "passed_control"
    except BaseException as error:  # noqa: BLE001 -- retain interruption and original execution failure.
        receipt.outcome, receipt.error, receipt.traceback = "error", repr(error), traceback.format_exc()
    finally:
        signal.alarm(config.timeout_seconds)
        try:
            receipt.after = identities(config, configuration)
            require(receipt.before == receipt.after, "input/source/binary/helper/client closure differs")
            require(all(pin(p.path) == p for p in receipt.imports.values()), "actual imported source changed")
            staging = config.output / "staging"
            receipt.staging_payload_after_shutdown = [str(p.relative_to(staging)) for p in staging.rglob("*")
                                                       if p.is_symlink() or not p.is_dir()]
            require(not receipt.staging_payload_after_shutdown, "owned staging payload remains")
        except BaseException as error:  # noqa: BLE001 -- closure uncertainty cannot preserve pass.
            receipt.outcome = "error"
            receipt.integrity_errors.append(repr(error))
        receipt.cleanup_errors = sink.records
        receipt.finished_utc = utc()
        save(path, receipt)
        signal.alarm(0)
    print(json.dumps({"outcome": receipt.outcome, "receipt": str(path)}), flush=True)
    return 0 if receipt.outcome == "passed_control" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    configuration = pin(args.config.resolve())
    config = m.Config.model_validate_json(args.config.read_bytes())
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM):
        signal.signal(signum, interrupted)
    return run(config, configuration)


if __name__ == "__main__":
    raise SystemExit(main())
