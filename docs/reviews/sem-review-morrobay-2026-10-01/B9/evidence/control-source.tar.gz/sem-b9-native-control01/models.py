"""Focused signed-isolate witness records; no native imports or runtime verdict."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Final, Literal, Self

import pydantic

CONTROLLER: Final = "b522bf3a9c38d3861a114bf672abe7f7d6c7c491"
TREE = "92430b914bbb3cb50aa5ea8ab111adabeaae6eaa"
RUNTIME: Final = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
HARNESS: Final = "6ae2e43a903c2cee02da170465c922c72b76198e"
ISOLATE = -7694170072594669674
IDS = (1, 2, ISOLATE)
EDGES = ((1, 2),)
HISTORICAL_SHA = "ce74bca2399cfd0957bbab9d779b0ce7443b6237b15d887e7269072b24229f6b"
HelperName = Literal["control.py", "models.py", "runtime.py", "measurement.py"]
FROZEN: dict[HelperName, str] = {"runtime.py": "27a76460792bac9668e18c8e32961f34a936060dc15cd3fe06f115124757b6e4",
          "measurement.py": "e9945063c793890a47d9e4da0b0cae4eae7b96f44d7672549932cc61df9c7127"}


class Record(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="forbid", allow_inf_nan=False)


class Identity(Record):
    bytes: int = pydantic.Field(ge=0)
    sha256: str = pydantic.Field(pattern=r"^[0-9a-f]{64}$")


class Pin(Identity):
    path: Path

    @pydantic.model_validator(mode="after")
    def absolute(self) -> Self:
        if not self.path.is_absolute() or ".." in self.path.parts:
            raise ValueError("absolute pin path without parent traversal required")
        return self


class Config(Record):
    repo: Path
    output: Path
    python: Path
    library_path: Path
    binary: Pin
    build: Pin
    client: Pin
    source_admission: Pin
    historical_control: Pin
    helpers: dict[HelperName, Pin]
    partitions: Literal[16] = 16
    threads: Literal[16] = 16
    pool_bytes: Literal[32212254720] = 32212254720
    native_quota: Literal[268435456] = 268435456
    timeout_seconds: int = pydantic.Field(default=180, ge=60, le=600)

    @pydantic.model_validator(mode="after")
    def focused(self) -> Self:
        if any(not p.is_absolute() or ".." in p.parts for p in
               (self.repo, self.output, self.python, self.library_path)):
            raise ValueError("absolute paths without parent traversal required")
        if str(self.output).startswith("/Volumes/"):
            raise ValueError("fresh native SSD output required")
        if set(self.helpers) != {"control.py", "models.py", "runtime.py", "measurement.py"}:
            raise ValueError("all four actual helper pins required")
        if self.helpers["runtime.py"].path.parent != self.helpers["measurement.py"].path.parent:
            raise ValueError("frozen harness modules must share a directory")
        if any(self.helpers[n].sha256 != v for n, v in FROZEN.items()):
            raise ValueError("exact frozen6ae runtime/measurement bytes required")
        if self.historical_control.sha256 != HISTORICAL_SHA or self.historical_control.bytes != 4284:
            raise ValueError("exact retained original known_mismatch witness required")
        return self


class Row(Record):
    id: int | None = pydantic.Field(strict=True, ge=-(2**63), le=2**63-1)
    component: int | None = pydantic.Field(strict=True, ge=-(2**63), le=2**63-1)


class Field(Record):
    name: str
    arrow_type: str
    nullable: bool


class Physical(Record):
    file: str
    fields: list[Field]
    footer_rows: int = pydantic.Field(ge=0)
    rows: list[Row]


class Control(Record):
    canonical_labels: bool
    output: Path
    seed: Literal[42] = 42
    max_iterations: Literal[100] = 100
    snapshot_inputs: Literal[True] = True
    outcome: Literal["checking", "passed", "error"] = "checking"
    actual_algorithm: str | None = None
    actual_method: str | None = None
    actual_seed: int | None = None
    iterations: int | None = None
    converged: bool | None = None
    algorithm_seconds: float | None = None
    export_seconds: float | None = None
    raw_rows: list[Row] = pydantic.Field(default_factory=list)
    expected_rows: list[Row] | None = None
    expected_groups: tuple[tuple[int, ...], ...] = ((1, 2), (ISOLATE,))
    physical: list[Physical] = pydantic.Field(default_factory=list)
    files_before: dict[str, Identity] = pydantic.Field(default_factory=dict)
    files_after: dict[str, Identity] = pydantic.Field(default_factory=dict)
    full_coverage: bool = False
    full_partition: bool = False
    error: str | None = None


class CleanupError(Record):
    operation: str
    error: str


class Fixture(Record):
    vertices: tuple[int, ...] = IDS
    edges: tuple[tuple[int, int], ...] = EDGES
    vertex_schema: Literal["id long"] = "id long"
    edge_schema: Literal["src long, dst long"] = "src long, dst long"
    origin: str = "Fresh Spark Connect LocalRelation with exact original logical rows; original historical source/target Parquet bytes are retained separately and are not rewritten or consumed here."


@dataclass(slots=True)
class Sink:
    records: list[CleanupError] = field(default_factory=list)

    def append(self, item: Mapping[str, str]) -> None:
        self.records.append(CleanupError(operation=item["operation"], error=item["error"]))


class Receipt(Record):
    config: Config
    started_utc: str
    finished_utc: str | None = None
    outcome: Literal["checking", "passed_control", "error"] = "checking"
    execution_class: Literal["native-macOS-x86_64-local"] = "native-macOS-x86_64-local"
    controller: Literal["b522bf3a9c38d3861a114bf672abe7f7d6c7c491"] = CONTROLLER
    compiled_runtime: Literal["9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"] = RUNTIME
    harness: Literal["6ae2e43a903c2cee02da170465c922c72b76198e"] = HARNESS
    fixture: Fixture = pydantic.Field(default_factory=Fixture)
    before: dict[str, Pin] = pydantic.Field(default_factory=dict)
    after: dict[str, Pin] = pydantic.Field(default_factory=dict)
    imports: dict[str, Pin] = pydantic.Field(default_factory=dict)
    server_pid: int | None = None
    controls: list[Control] = pydantic.Field(default_factory=list)
    cleanup_errors: list[CleanupError] = pydantic.Field(default_factory=list)
    staging_payload_after_shutdown: list[str] = pydantic.Field(default_factory=list)
    error: str | None = None
    traceback: str | None = None
    integrity_errors: list[str] = pydantic.Field(default_factory=list)
    runtime_shutdown_completed: bool = False
    independent_process_group_absence: Literal[False] = False
    outer_retention_qualified: Literal[False] = False
    performance_comparison: Literal[False] = False
    generic_signed_ID_qualification: Literal[False] = False
    scope: str = "Two full three-vertex witness checks only; root independently verifies native owned process-group absence and retained physical bytes. Software16threads/16partitions/30GiB pool; no OS caps/PSS/cgroup claims. Public-call clocks exclude export, tiny oracle and cleanup."
