"""Bounded configuration and diagnostic controls; no native imports or work."""

import json
import unittest

from pydantic import ValidationError

from f2a_models import NativeStatus, Plan, Span


def valid() -> dict[str, object]:
    return {
        "dataset": "tiny",
        "vertices": "/original/v.parquet",
        "edges": "/original/e.parquet",
        "output_root": "/new/result",
        "receipt": "/evidence/receipt.json",
        "ids": "int64",
        "calls": 3,
        "binary": "/native/sail",
        "venv": "/new/venv",
        "python_home": "/python/home",
        "python_purelib": "/new/venv/lib/python3.12/site-packages",
        "python_library_directory": "/python/home/lib",
    }


class Controls(unittest.TestCase):
    def test_accepted_contract(self) -> None:
        plan = Plan.model_validate_json(json.dumps(valid()))
        self.assertEqual((plan.workers, plan.calls, plan.ids), (16, 3, "int64"))

    def test_rejected_parameters(self) -> None:
        for name, value in (
            ("calls", 2),
            ("calls", True),
            ("workers", 8),
            ("sail_pool_bytes", 1),
            ("native_quota_bytes", 1),
            ("timeout_seconds", 1),
            ("ids", "u32"),
        ):
            body = valid() | {name: value}
            with (
                self.subTest(name=name, value=value),
                self.assertRaises(ValidationError),
            ):
                Plan.model_validate_json(json.dumps(body))

    def test_rejected_path_and_unknown(self) -> None:
        for extra in (
            {"output_root": "/original"},
            {"vertices": "v.parquet"},
            {"python_purelib": "/old/venv/lib"},
            {"unexpected": True},
        ):
            with self.subTest(extra=extra), self.assertRaises(ValidationError):
                Plan.model_validate_json(json.dumps(valid() | extra))

    def test_negative_clock(self) -> None:
        with self.assertRaises(ValidationError):
            Span(started_ns=2, ended_ns=1)

    def test_cache_requires_one_actual_build(self) -> None:
        status = NativeStatus.model_validate_json(
            json.dumps(
                {
                    "memory": {
                        "limit_bytes": 1,
                        "used_bytes": 0,
                        "peak_bytes": 0,
                        "staged_bytes": 0,
                    },
                    "graphs": [
                        {
                            "name": "g",
                            "node_count": 4,
                            "edge_count": 2,
                            "revision": 1,
                            "projections": 1,
                            "staged_bytes": 0,
                            "projection_builds": [],
                        }
                    ],
                    "reads": [],
                }
            )
        )
        self.assertFalse(status.one_cached_projection())


if __name__ == "__main__":
    unittest.main()
