"""Run one approved native Parquet WCC series; every output needs a parent oracle."""

import argparse
import hashlib
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
import traceback
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from types import FrameType
from typing import Literal, TypeVar

from pydantic import JsonValue, TypeAdapter
from pyspark.sql.connect import functions as F
from pyspark.sql.connect.session import SparkSession
from sail_nutmeg.client import Nutmeg

from f2a_models import (
    Error,
    FilePin,
    NativeStatus,
    OutputAttempt,
    Phase,
    Plan,
    Receipt,
    ServerExit,
    Span,
)

T = TypeVar("T")
JSON = TypeAdapter(JsonValue)


def utc() -> str:
    return datetime.now(UTC).isoformat()


def pin(path: Path) -> FilePin:
    raw = path.read_bytes()
    return FilePin(
        path=path.resolve(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()
    )


def save(receipt: Receipt) -> None:
    receipt.observed_utc = utc()
    path = receipt.configuration.receipt
    with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False) as file:
        temporary = Path(file.name)
        file.write(receipt.model_dump_json(indent=2) + "\n")
        file.flush()
        os.fsync(file.fileno())
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def interrupted(number: int, _frame: FrameType | None) -> None:
    if number == signal.SIGALRM:
        raise TimeoutError("native worker's execution or cleanup budget expired")
    raise InterruptedError(f"native worker interrupted by signal {number}")


def environment(plan: Plan) -> dict[str, str]:
    return {
        "PYTHONHOME": str(plan.python_home),
        "PYTHONPATH": str(plan.python_purelib),
        "DYLD_LIBRARY_PATH": str(plan.python_library_directory),
        "SAIL_EXPERIMENTAL_EXTENSIONS": "1",
        "SAIL_MODE": "local",
        "SAIL_EXECUTION__DEFAULT_PARALLELISM": str(plan.workers),
        "SAIL_RUNTIME__MEMORY_POOL__TYPE": "greedy",
        "SAIL_RUNTIME__MEMORY_POOL__GREEDY__MAX_SIZE": str(plan.sail_pool_bytes),
        "SAIL_NUTMEG_MEMORY_BYTES": str(plan.native_quota_bytes),
        "NUTMEG_MEMORY_BYTES": str(plan.native_quota_bytes),
        "NUTMEG_WORKERS": str(plan.workers),
        "SAIL_GRAPH_UTILS_ROOT": (plan.output_root / "staging").as_uri(),
        "TOKIO_WORKER_THREADS": str(plan.workers),
        "RAYON_NUM_THREADS": str(plan.workers),
        "TMPDIR": str(plan.output_root / "temporary"),
        "RUST_LOG": "warn",
    }


def timed(
    receipt: Receipt,
    name: Literal["read_and_stage", "projection_stats_action", "wcc_and_parquet_write"],
    action: Callable[[], T],
    call: int | None = None,
) -> T:
    started = time.perf_counter_ns()
    completed = False
    try:
        value = action()
        completed = True
        return value
    finally:
        receipt.phases.append(
            Phase(
                name=name,
                call=call,
                completed=completed,
                span=Span(started_ns=started, ended_ns=time.perf_counter_ns()),
            )
        )


def read_and_stage(spark: SparkSession, nutmeg: Nutmeg, plan: Plan) -> JsonValue:
    kind = "long" if plan.ids == "int64" else "string"
    mapping = {"ids": "int64"} if plan.ids == "int64" else None
    vertices = spark.read.parquet(plan.vertices.as_uri()).select(
        F.col(plan.vertex_id_column).cast(kind).alias("node_id")
    )
    edges = spark.read.parquet(plan.edges.as_uri()).select(
        F.col(plan.edge_source_column).cast(kind).alias("source"),
        F.col(plan.edge_target_column).cast(kind).alias("target"),
    )
    row = nutmeg.stage(
        "g",
        vertices,
        edges,
        node_mapping=mapping,
        edge_mapping=mapping,
        order="asStaged",
    )
    return JSON.validate_python(row.asDict(recursive=True), strict=True)


def write_wcc(nutmeg: Nutmeg, plan: Plan, path: Path) -> None:
    frame = nutmeg.run("g", "wcc", concurrency=plan.workers)
    frame.select(
        F.col("nodeId").cast("long").alias("id"),
        F.col("componentId").cast("long").alias("component"),
    ).write.mode("error").parquet(path.as_uri())


def pipeline(spark: SparkSession, nutmeg: Nutmeg, receipt: Receipt) -> None:
    plan = receipt.configuration
    started = time.perf_counter_ns()
    try:
        receipt.stage_receipt = timed(
            receipt, "read_and_stage", lambda: read_and_stage(spark, nutmeg, plan)
        )
        row = timed(
            receipt,
            "projection_stats_action",
            lambda: nutmeg.run("g", "projectionStats").first(),
        )
        if row is None:
            raise ValueError("projectionStats did not return its one-row receipt")
        receipt.projection_receipt = JSON.validate_python(
            row.asDict(recursive=True), strict=True
        )
        for call in range(1, plan.calls + 1):
            output = OutputAttempt(
                call=call, path=plan.output_root / f"result-call{call}"
            )
            receipt.outputs.append(output)
            timed(
                receipt,
                "wcc_and_parquet_write",
                lambda: write_wcc(nutmeg, plan, output.path),
                call,
            )
            output.completed = True
        receipt.pipeline_completed = True
    finally:
        ended = (
            receipt.phases[-1].span.ended_ns
            if receipt.pipeline_completed
            else time.perf_counter_ns()
        )
        receipt.pipeline = Span(started_ns=started, ended_ns=ended)
        receipt.pipeline_seconds = receipt.pipeline.seconds


def ready(server: subprocess.Popen[bytes], port: int) -> None:
    while True:
        if server.poll() is not None:
            raise RuntimeError(
                f"native server exited before readiness: rc={server.returncode}"
            )
        with socket.socket() as connection:
            connection.settimeout(0.2)
            if connection.connect_ex(("127.0.0.1", port)) == 0:
                return
        time.sleep(0.01)


def close_server(server: subprocess.Popen[bytes], receipt: Receipt) -> None:
    proof = receipt.server
    if proof is None:
        raise RuntimeError("native process lacks its launch record")
    if server.poll() is None:
        proof.termination_requested = True
        server.terminate()
    try:
        proof.returncode = server.wait(timeout=120)
    except subprocess.TimeoutExpired:
        proof.forced_kill = True
        server.kill()
        proof.returncode = server.wait(timeout=30)
        raise RuntimeError(
            "native server required forced kill after graceful wait expired"
        ) from None
    finally:
        proof.closed_utc = utc()
        proof.wait_completed = server.returncode is not None
    if not proof.termination_requested and proof.returncode != 0:
        raise RuntimeError(f"native server exited unexpectedly: rc={proof.returncode}")


def record_error(receipt: Receipt, phase: str) -> None:
    receipt.errors.append(Error(phase=phase, detail=traceback.format_exc()))
    if receipt.outcome != "timeout":
        receipt.outcome = "failed"


def execute(plan_file: Path) -> int:
    plan_pin = pin(plan_file)
    plan = Plan.model_validate_json(plan_file.read_bytes())
    if sys.version_info[:3] != (3, 12, 6):
        raise ValueError("worker interpreter must be the admitted Python 3.12.6 venv")
    if Path(sys.prefix).resolve() != plan.venv.resolve():
        raise ValueError("worker interpreter does not belong to the declared venv")
    plan.output_root.mkdir(parents=True, exist_ok=False)
    (plan.output_root / "staging").mkdir()
    (plan.output_root / "temporary").mkdir()
    plan.receipt.parent.mkdir(parents=True, exist_ok=True)
    with plan.receipt.open("x"):
        pass
    receipt = Receipt(
        observed_utc=utc(),
        started_utc=utc(),
        outcome="running",
        configuration=plan,
        configuration_pin=plan_pin,
        worker_source=pin(Path(__file__)),
        models_source=pin(Path(__file__).with_name("f2a_models.py")),
        owner_pid=os.getpid(),
        python_version=sys.version,
        python_executable=Path(sys.executable),
        environment=environment(plan),
    )
    save(receipt)
    server: subprocess.Popen[bytes] | None = None
    spark: SparkSession | None = None
    nutmeg: Nutmeg | None = None
    for number in (signal.SIGALRM, signal.SIGINT, signal.SIGTERM):
        signal.signal(number, interrupted)
    signal.alarm(plan.timeout_seconds)
    try:
        with socket.socket() as reservation:
            reservation.bind(("127.0.0.1", 0))
            port = reservation.getsockname()[1]
        argv = [
            str(plan.binary),
            "spark",
            "server",
            "--ip",
            "127.0.0.1",
            "--port",
            str(port),
        ]
        inherited = {
            key: value
            for key, value in os.environ.items()
            if not key.startswith("SAIL_")
        }
        inherited.update(receipt.environment)
        with (plan.output_root / "server.log").open("xb") as log:
            launched = utc()
            server = subprocess.Popen(
                argv,
                env=inherited,
                cwd=plan.output_root,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            receipt.server = ServerExit(
                pid=server.pid, pgid=server.pid, argv=argv, launched_utc=launched
            )
            receipt.server.pgid = os.getpgid(server.pid)
            if receipt.server.pgid != server.pid:
                raise RuntimeError(
                    "owned server did not start in its declared fresh process group"
                )
            save(receipt)
        ready(server, port)
        spark = SparkSession.builder.remote(f"sc://127.0.0.1:{port}").create()
        nutmeg = Nutmeg(spark)
        pipeline(spark, nutmeg, receipt)
        receipt.native_status = JSON.validate_python(nutmeg.status(), strict=True)
        status = NativeStatus.model_validate(receipt.native_status)
        receipt.projection_reused = status.one_cached_projection()
        if not receipt.projection_reused:
            raise ValueError(
                "expected exactly one cached projection build for this WCC series"
            )
        receipt.outcome = "completed_unvalidated"
    except TimeoutError:
        receipt.outcome = "timeout"
        record_error(receipt, "execution")
    except BaseException:
        record_error(receipt, "execution")
    finally:
        signal.alarm(0)
        for number in (signal.SIGINT, signal.SIGTERM):
            signal.signal(number, signal.SIG_IGN)
        if nutmeg is not None:
            try:
                signal.alarm(30)
                nutmeg.drop("g")
                receipt.graph_dropped = True
            except BaseException:
                record_error(receipt, "graph_drop")
            finally:
                signal.alarm(0)
        if spark is not None:
            try:
                signal.alarm(30)
                spark.stop()
                receipt.spark_stopped = True
            except BaseException:
                record_error(receipt, "spark_stop")
            finally:
                signal.alarm(0)
        if server is not None:
            try:
                close_server(server, receipt)
            except BaseException:
                record_error(receipt, "native_server_wait")
        try:
            if pin(plan_file) != plan_pin:
                raise ValueError("approved plan changed during run")
            if (
                pin(Path(__file__)) != receipt.worker_source
                or pin(Path(__file__).with_name("f2a_models.py"))
                != receipt.models_source
            ):
                raise ValueError("worker source changed during run")
        except BaseException:
            record_error(receipt, "source_and_configuration")
        save(receipt)
    print(receipt.model_dump_json(), flush=True)
    return 0 if receipt.outcome == "completed_unvalidated" else 1


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True, type=Path)
    args = parser.parse_args()
    raise SystemExit(execute(args.plan.resolve()))


if __name__ == "__main__":
    main()
