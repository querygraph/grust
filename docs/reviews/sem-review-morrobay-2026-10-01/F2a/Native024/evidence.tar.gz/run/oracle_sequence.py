"""Wait every separate physical oracle; no engine execution or performance clock."""
import json
import os
import signal
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType

from pydantic import BaseModel, ConfigDict, Field

ROOT = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/F2a-native-024-run01')
PYTHON = ROOT.parent / 'F2a-native-int64-build01/venv/bin/python'


class Record(BaseModel):
    model_config = ConfigDict(extra='forbid')


class Call(Record):
    plan: str
    argv: list[str]
    pid: int
    started_utc: str
    finished_utc: str | None = None
    returncode: int | None = None
    wait_completed: bool = False
    group_absent: bool = False
    wall_seconds: float | None = None


class Receipt(Record):
    owner_pid: int
    outcome: str = 'running'
    started_utc: str
    finished_utc: str | None = None
    calls: list[Call] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def save(record: Receipt) -> None:
    temporary = ROOT / 'oracle-sequence-receipt01.partial'
    temporary.write_text(record.model_dump_json(indent=2) + '\n')
    temporary.replace(ROOT / 'oracle-sequence-receipt01.json')


def interrupted(number: int, _frame: FrameType | None) -> None:
    raise InterruptedError(f"oracle sequence interrupted by signal {number}")


def main() -> int:
    assert not (ROOT / 'oracle-sequence-receipt01.json').exists()
    record = Receipt(owner_pid=os.getpid(), started_utc=utc())
    save(record)
    process: subprocess.Popen[bytes] | None = None
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(number, interrupted)
    try:
        plans = json.loads((ROOT / 'oracle-sequence-plan01.json').read_bytes())['plans']
        assert len(plans) == 8
        for index, plan in enumerate(plans, 1):
            argv = [str(PYTHON), '-I', '-B', str(ROOT / 'f2a_oracle.py'), '--config', plan]
            with (ROOT / f'oracle-call{index}-01.log').open('xb') as log:
                started = time.monotonic()
                process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                call = Call(plan=plan, argv=argv, pid=process.pid, started_utc=utc())
                record.calls.append(call)
                save(record)
                call.returncode = process.wait(timeout=650)
                call.wall_seconds = time.monotonic() - started
                call.wait_completed = True
                call.finished_utc = utc()
                rows = subprocess.run(['/bin/ps', '-axo', 'pid=,pgid='], capture_output=True, text=True, check=True).stdout
                call.group_absent = not any(int(line.split()[1]) == process.pid for line in rows.splitlines() if len(line.split()) == 2)
                assert call.returncode == 0 and call.group_absent
                config = json.loads(Path(plan).read_bytes())
                result = json.loads((Path(config['output']) / 'receipt.json').read_bytes())
                assert result['outcome'] == 'passed_full_physical_wcc' and result['full_output_oracle_passed']
                save(record)
                process = None
        record.outcome = 'passed_eight_waited_physical_oracles'
    except BaseException as error:  # noqa: BLE001 - persist interruption/failure and close direct child.
        record.outcome = 'error'
        record.errors.append(f'{type(error).__name__}: {error}')
        if process is not None and process.poll() is None:
            try:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
                record.calls[-1].returncode = process.returncode
                record.calls[-1].wait_completed = True
                record.calls[-1].finished_utc = utc()
            except Exception as cleanup:  # noqa: BLE001 - failed cleanup stays an error.
                record.errors.append(f'owned cleanup {type(cleanup).__name__}: {cleanup}')
    finally:
        record.finished_utc = utc()
        save(record)
    return 0 if not record.errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
