# F2a metadata report writer

Source only. No report, engine, native import, process probe or Parquet scan
was executed during preparation. `f2a_report.py` is under 250 lines; typed
metadata parsing and acceptance live in `f2a_report_support.py`.

## Invocation and configuration

```sh
/ABS/report-venv/bin/python -B \
  /Volumes/Apo/graph-tests/results/sem-review-20261001/F2a-native-024-run01/f2a_report.py \
  --config /ABS/report-plan.json
```

Config contains `campaign`, `campaign_exit` and exactly eight ordered `oracles`
(all `{path,bytes,sha256}` pins), plus a fresh absolute `output_root`. Oracle
order matches the producer's ordered series. Every oracle's metadata_pins must
contain the exact worker receipt and series plan; original vertices and output
directories also bind directly. These are metadata files; no raw result or
binary is opened. Root must fill actual closed pins. The report schema/template
are preparation, never an admission of their placeholder files.

## Required proof and artifacts

Positive producer and actual waited-launcher receipts, unchanged complete
source/input/client/helper pin lists, locks released, all producer groups absent,
and eight successful worker/cache series are required. Each output requires
complete unique original-domain coverage, labels in that domain and identical
full canonical WCC partitions. Reference preparations remain separate and have
no numerical self-comparison. Root separately supplies the reference provenance,
actual final live closure and raw-output retention proof.

Output paths are `<dataset>-<string|int64>-calls<1|3>/benchmark.json`; eight
reports contain all required Sem top keys. `runs[0].wall_time_s` is the parent's
actual launch-through-wait interval; `worker.phases_s.wall_in_process_s` is the
worker's continuous input-plan-through-last-write pipeline. Its four exclusive
phase fields are null. Named observed spans remain recorded, without subtraction.
Both clocks are distinct and checked for nesting. Single-sample stats are n=1
and std=null. RSS component observations are kept separately; no total OS peak,
disk peak, capacity or Sem resource/CSR-work parity is claimed. Warmup count 0
means no explicit warmup; no cache was flushed. Size class is native_unclassified.

`report.json` is `ReportReceipt`: outcome passed_metadata_reports, series_count8,
qualified_output_count16, n_per_condition1, exclusive_sem_phases_unavailableTrue,
configuration FilePin, equal source_before/source_after, metadata_inputs pins,
and exactly eight generated benchmark FilePins. Metadata inputs and report
source are rechecked before its positive write. Partial failed outputs remain.
Tiny integrated smoke and release build qualification are separate root proofs.

Final source gates are report-source-gates04: isolated Ruff and strict mypy on
the two report files. Earlier failed source checks and source snapshots remain;
the intermediate gate03 is unsealed draft evidence and is not the final freeze.
No synthetic benchmark fixtures or new test framework were added.
