"""Metadata-only Sem-format F2a reports after eight closed, oracle-qualified series."""

import argparse
from datetime import UTC, datetime
from pathlib import Path

from pydantic import JsonValue

from f2a_campaign import Config as CampaignConfig
from f2a_campaign import Receipt as CampaignReceipt
from f2a_campaign_launch import Receipt as CampaignExit
from f2a_models import Receipt as WorkerReceipt
from f2a_report_support import (
    JSON,
    Benchmark,
    Config,
    Oracle,
    ReportReceipt,
    capture,
    load,
    raw,
    require,
    summary,
    validate_series,
    value,
)


def generate(path: Path) -> None:
    config_pin = capture(path)
    config_bytes = raw(config_pin)
    source_paths = [
        Path(__file__).with_name(name)
        for name in (
            "f2a_report.py",
            "f2a_report_support.py",
            "f2a_models.py",
            "f2a_campaign.py",
            "f2a_campaign_launch.py",
        )
    ]
    source_before = [capture(p) for p in source_paths]
    config = Config.model_validate_json(config_bytes)
    require(
        config.output_root.is_absolute()
        and ".." not in config.output_root.parts
        and not config.output_root.exists(),
        "fresh absolute report destination required",
    )
    campaign = load(config.campaign, CampaignReceipt)
    closed = load(config.campaign_exit, CampaignExit)
    admitted = load(campaign.configuration, CampaignConfig)
    require(
        campaign.outcome == "completed_unvalidated_campaign"
        and not campaign.errors
        and not campaign.skipped_plans,
        "campaign incomplete",
    )
    require(
        campaign.all_owned_groups_absent
        and campaign.locks_released
        and campaign.before == campaign.after == admitted.pins()
        and campaign.source_before == campaign.source_after,
        "campaign closure failed",
    )
    require(
        closed.outcome == "completed_unvalidated_waited_campaign"
        and closed.owner_pid == campaign.owner_pid
        and closed.configuration == campaign.configuration
        and closed.returncode == 0
        and closed.wait_completed
        and closed.owner_group_absent
        and not closed.forced_cleanup
        and not closed.errors
        and closed.producer_receipt == config.campaign,
        "waited campaign exit differs",
    )
    require(
        len(campaign.series) == len(admitted.plans) == 8
        and len({p.path for p in config.oracles}) == 8,
        "eight unique series/oracles required",
    )
    outputs: list[tuple[str, Benchmark]] = []
    seen: set[tuple[str, str, int]] = set()
    files = [
        config.campaign,
        config.campaign_exit,
        campaign.configuration,
        *config.oracles,
    ]
    for series, oracle_pin in zip(campaign.series, config.oracles, strict=True):
        if series.worker_receipt is None or series.launch_to_wait is None:
            raise ValueError("series proof missing")
        files.extend([series.plan, series.worker_receipt])
        worker = load(series.worker_receipt, WorkerReceipt)
        plan = worker.configuration
        oracle, stage, wall, pipeline = validate_series(
            series, worker, oracle_pin, admitted
        )
        key = (plan.dataset, plan.ids, plan.calls)
        require(key not in seen, "repeated condition")
        seen.add(key)
        spans: list[JsonValue] = [
            {
                "name": p.name,
                "call": p.call,
                "seconds": p.span.seconds,
                "completed": p.completed,
            }
            for p in worker.phases
        ]
        phases: dict[str, JsonValue] = {
            "read_parquet_s": None,
            "csr_and_graph_s": None,
            "algorithm_s": None,
            "write_parquet_s": None,
            "wall_in_process_s": pipeline,
        }
        report = Benchmark(
            dataset=plan.dataset,
            params={
                "ids": plan.ids,
                "calls": plan.calls,
                "order": "asStaged",
                "kernel": "wcc",
                "workers": plan.workers,
                "concurrency": 16,
                "runs": 1,
            },
            graph={
                "vertices": oracle.config.expected_rows,
                "edges_reported_by_stage": stage.get("edgeCount"),
                "vertices_path": str(plan.vertices),
                "edges_path": str(plan.edges),
            },
            warmup={"count": 0, "performed": False, "cache_flush": False},
            monitor={
                "rss_interval_s": 0.5,
                "samples": series.rss_samples,
                "observed_worker_peak_rss_kib": series.observed_worker_peak_rss_kib,
                "observed_server_peak_rss_kib": series.observed_server_peak_rss_kib,
                "errors": JSON.validate_python(series.rss_errors),
                "scope": "Sampled direct PID RSS; OS peak and capacity were not measured.",
            },
            runs=[
                {
                    "index": 0,
                    "wall_time_s": wall,
                    "returncode": series.returncode,
                    "peak_rss_kb": None,
                    "peak_disk_bytes": None,
                    "worker": {
                        "algorithm": "wcc",
                        "phases_s": phases,
                        "observed_spans": spans,
                        "calls": plan.calls,
                        "full_outputs": len(oracle.outputs),
                    },
                }
            ],
            stats={
                "parent_launch_to_wait_s": summary(wall),
                "continuous_pipeline_s": summary(pipeline),
            },
            series={
                "parent_launch_to_wait_s": [wall],
                "continuous_pipeline_s": [pipeline],
            },
            raw_series={
                "worker": value(worker),
                "parent_series": value(series),
                "physical_oracle": JSON.validate_json(raw(oracle_pin)),
            },
            environment={
                "python": worker.python_version,
                "python_executable": str(worker.python_executable),
                "extension_source": plan.extension_source_commit,
                "native_runtime_source": plan.native_runtime_commit,
                "binary": value(admitted.binary),
                "wheel": value(admitted.wheel),
                "controlled_environment": JSON.validate_python(worker.environment),
                "scope": "Shared uncapped native host, n=1 per condition; no Sem resource/CSR-work parity. Exclusive four phases unavailable; observed spans are not a subtractive decomposition.",
            },
        )
        outputs.append((f"{plan.dataset}-{plan.ids}-calls{plan.calls}", report))
    require(
        seen
        == {
            (d, ids, n)
            for d in ("cit-Patents", "graph500-24")
            for ids in ("string", "int64")
            for n in (1, 3)
        },
        "eight-condition contract differs",
    )
    require(
        sum(len(load(p, Oracle).outputs) for p in config.oracles) == 16,
        "sixteen qualified outputs required",
    )
    for item in files:
        raw(item)
    require(path.read_bytes() == config_bytes, "report plan changed")
    config.output_root.mkdir(parents=True, exist_ok=False)
    for name, report in outputs:
        destination = config.output_root / name
        destination.mkdir()
        (destination / "benchmark.json").write_text(
            report.model_dump_json(indent=2) + "\n"
        )
    source_after = [capture(p) for p in source_paths]
    require(source_before == source_after, "report/helper source changed")
    for item in files:
        raw(item)
    require(capture(path) == config_pin, "report plan changed")
    receipt = ReportReceipt(
        observed_utc=datetime.now(UTC).isoformat(),
        configuration=config_pin,
        source_before=source_before,
        source_after=source_after,
        metadata_inputs=files,
        reports=[
            capture(config.output_root / name / "benchmark.json") for name, _ in outputs
        ],
    )
    (config.output_root / "report.json").write_text(
        receipt.model_dump_json(indent=2) + "\n"
    )
    print("F2A_METADATA_REPORT PASSED eight series / sixteen full outputs", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    generate(parser.parse_args().config.resolve())


if __name__ == "__main__":
    main()
