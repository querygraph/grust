# Campaign v2 bootstrap correction

Only f2a_campaign.py BOOT's target basename changes from f2a_models.py to
f2a_worker.py. Launcher and all models/guards/lifecycle/timing/resource/outcome
predicates remain byte-identical. Configuration/schema/isolated waited-launch
recipe remain as CAMPAIGN-HANDOFF.md. Root must create new configuration/helper
pins and fresh run IDs; never reuse the failed smoke output, receipts or locks.

Frozen v1 sources, original freeze/HANDOFF and source archive are preserved
under frozen-campaign-v1; campaign-freeze01.json and archive01 are unchanged.
The first actual smoke launched the models script, returned rc0 without a
worker receipt, and failed campaign acceptance. No engine ran; root retains
that negative attempt and independently closes its ownership/locks.

campaign-source-gates03 retains final Ruff/strict-mypy PASS plus an actual
bootstrap-delegation control: BOOT is parsed from source and evaluated with
runpy intercepted. The control requires exact f2a_worker.py/__main__/--plan
argv, proves the entire source differs solely at the target basename and
proves launcher bytes unchanged. The worker/native modules were not executed.
Root owns actual integrated smoke and all engines/process/payload actions.
