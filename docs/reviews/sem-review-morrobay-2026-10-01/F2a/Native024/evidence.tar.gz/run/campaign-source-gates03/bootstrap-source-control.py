import ast
import runpy
import sys
from pathlib import Path

root = Path(sys.argv[1])
new_source = (root / "f2a_campaign.py").read_text()
old_source = (root / "frozen-campaign-v1/f2a_campaign.py").read_text()
assert new_source == old_source.replace('r+"/f2a_models.py"', 'r+"/f2a_worker.py"')
assert (root / "f2a_campaign_launch.py").read_bytes() == (root / "frozen-campaign-v1/f2a_campaign_launch.py").read_bytes()
assignment = next(n for n in ast.parse(new_source).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "BOOT" for t in n.targets))
bootstrap = ast.literal_eval(assignment.value)
observed = []
def capture(path: str, *, run_name: str):
    observed.append((path, run_name, sys.argv.copy()))
    return {}
runpy.run_path = capture
sys.argv = ["-c", str(root), "--plan", "/ABS/fresh-series-plan.json"]
exec(compile(bootstrap, "actual-frozen-BOOT", "exec"), {})
expected = str(root / "f2a_worker.py")
assert observed == [(expected, "__main__", [expected, "--plan", "/ABS/fresh-series-plan.json"])]
print("PASS actual BOOT delegates to worker with exact --plan argv; only basename diff; launcher unchanged; worker not executed")
