"""Typed metadata models and validation for the native F2a report writer."""

import hashlib
from pathlib import Path
from typing import Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field, JsonValue, TypeAdapter

from f2a_campaign import Config as CampaignConfig
from f2a_campaign import Series
from f2a_models import FilePin, Record
from f2a_models import Receipt as WorkerReceipt

M = TypeVar("M", bound=BaseModel)
JSON: TypeAdapter[JsonValue] = TypeAdapter(JsonValue)


class Config(Record):
    campaign: FilePin
    campaign_exit: FilePin
    oracles: list[FilePin] = Field(min_length=8, max_length=8)
    output_root: Path


class Subset(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True, allow_inf_nan=False)


class Identity(Subset):
    bytes: int
    sha256: str


class RawDataset(Subset):
    directory: Path


class RawOutput(RawDataset):
    number: int


class OracleConfig(Subset):
    vertices: FilePin
    expected_rows: int
    reference: RawDataset
    outputs: list[RawOutput]
    metadata_pins: list[FilePin]


class Checked(Subset):
    number: int
    rows: int
    unique_rows: int
    components: int
    canonical_member_mismatches: int | None
    full_original_domain_passed: bool
    labels_in_original_domain: bool
    full_partition_equivalence_passed: bool
    physical_schemas: list[JsonValue]


class Oracle(Subset):
    outcome: Literal["passed_full_physical_wcc"]
    config: OracleConfig
    reference: Checked
    outputs: list[Checked]
    identities_before: dict[str, Identity]
    identities_after: dict[str, Identity]
    own_identity_closure_passed: Literal[True]
    full_output_oracle_passed: Literal[True]
    errors: list[str]


class Benchmark(Record):
    algorithm: Literal["wcc"] = "wcc"
    dataset: str
    size_class: Literal["native_unclassified"] = "native_unclassified"
    engine: Literal["Banda / registry Grust 0.24.0"] = "Banda / registry Grust 0.24.0"
    params: JsonValue
    graph: JsonValue
    warmup: JsonValue
    monitor: JsonValue
    runs: list[JsonValue]
    stats: JsonValue
    series: JsonValue
    raw_series: JsonValue
    environment: JsonValue


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def raw(pin: FilePin) -> bytes:
    require(
        pin.path.suffix == ".json" and pin.bytes <= 16 * 2**20,
        "bounded JSON metadata only",
    )
    require(
        pin.path.is_file() and not pin.path.is_symlink(),
        "regular sealed metadata required",
    )
    data = pin.path.read_bytes()
    require(
        len(data) == pin.bytes and hashlib.sha256(data).hexdigest() == pin.sha256,
        "metadata pin differs",
    )
    return data


def load(pin: FilePin, model: type[M]) -> M:
    return model.model_validate_json(raw(pin))


def value(record: BaseModel) -> JsonValue:
    return JSON.validate_json(record.model_dump_json())


def summary(seconds: float) -> JsonValue:
    return {
        "n": 1,
        "mean": seconds,
        "median": seconds,
        "min": seconds,
        "max": seconds,
        "std": None,
    }


def validate_series(
    series: Series, worker: WorkerReceipt, oracle_pin: FilePin, admitted: CampaignConfig
) -> tuple[Oracle, dict[str, JsonValue], float, float]:
    plan = worker.configuration
    if series.worker_receipt is None or series.launch_to_wait is None:
        raise ValueError("parent spans and worker pin required")
    require(
        worker.configuration_pin == series.plan
        and worker.owner_pid == series.pid
        and plan == load(series.plan, type(plan)),
        "worker configuration binding differs",
    )
    require(
        series.outcome == "completed_unvalidated"
        and series.returncode == 0
        and series.wait_completed
        and series.driver_group_absent
        and series.server_group_absent
        and not series.forced_cleanup,
        "series did not close",
    )
    require(
        worker.outcome == "completed_unvalidated"
        and not worker.errors
        and worker.pipeline_completed
        and worker.projection_reused is True
        and worker.graph_dropped
        and worker.spark_stopped
        and worker.pipeline is not None,
        "worker execution failed",
    )
    if worker.pipeline is None or worker.pipeline_seconds is None:
        raise ValueError("worker continuous clock missing")
    require(
        worker.pipeline_seconds == worker.pipeline.seconds
        and worker.pipeline_seconds > 0,
        "worker clock differs",
    )
    require(
        [(p.name, p.call, p.completed) for p in worker.phases]
        == [
            ("read_and_stage", None, True),
            ("projection_stats_action", None, True),
            *[("wcc_and_parquet_write", n, True) for n in range(1, plan.calls + 1)],
        ],
        "raw phase order/completion differs",
    )
    require(
        all(
            a.span.ended_ns <= b.span.started_ns
            for a, b in zip(worker.phases, worker.phases[1:])
        ),
        "raw phases overlap",
    )
    oracle = load(oracle_pin, Oracle)
    require(
        not oracle.errors and oracle.identities_before == oracle.identities_after,
        "oracle closure failed",
    )
    require(
        oracle.config.vertices.path == plan.vertices
        and oracle.config.vertices in admitted.expected_inputs
        and series.worker_receipt in oracle.config.metadata_pins
        and series.plan in oracle.config.metadata_pins,
        "oracle original/producer binding differs",
    )
    require(
        len(worker.outputs)
        == len(oracle.outputs)
        == len(oracle.config.outputs)
        == plan.calls,
        "call count differs",
    )
    for output, physical, checked in zip(
        worker.outputs, oracle.config.outputs, oracle.outputs, strict=True
    ):
        require(
            output.call == physical.number == checked.number
            and output.path == physical.directory
            and output.completed,
            "output binding differs",
        )
        require(
            physical.directory != oracle.config.reference.directory,
            "output self-comparison forbidden",
        )
        require(
            checked.rows == checked.unique_rows == oracle.config.expected_rows
            and checked.full_original_domain_passed
            and checked.labels_in_original_domain
            and checked.full_partition_equivalence_passed
            and checked.canonical_member_mismatches == 0
            and bool(checked.physical_schemas),
            "full output oracle did not pass",
        )
    require(
        oracle.reference.rows
        == oracle.reference.unique_rows
        == oracle.config.expected_rows
        and oracle.reference.full_original_domain_passed
        and oracle.reference.labels_in_original_domain
        and oracle.reference.canonical_member_mismatches is None,
        "full reference preparation missing or self-compared",
    )
    if not isinstance(worker.stage_receipt, dict):
        raise ValueError("staging receipt missing")
    stage = worker.stage_receipt
    require(
        stage.get("nodeCount") == oracle.config.expected_rows,
        "staged vertex count differs",
    )
    wall = series.launch_to_wait.seconds
    pipeline = worker.pipeline_seconds
    require(
        wall > 0
        and series.launch_to_wait.started_ns
        <= worker.pipeline.started_ns
        <= worker.pipeline.ended_ns
        <= series.launch_to_wait.ended_ns,
        "parent/worker clock nesting differs",
    )
    return oracle, stage, wall, pipeline
