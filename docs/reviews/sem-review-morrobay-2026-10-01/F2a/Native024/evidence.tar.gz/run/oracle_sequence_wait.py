"""Own and wait the separately detached physical-oracle sequence."""
import hashlib
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, Field

ROOT = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/F2a-native-024-run01')


class Receipt(BaseModel):
    observed_utc: str
    launcher_pid: int
    owner_pid: int | None = None
    owner_pgid: int | None = None
    owner_returncode: int | None = None
    wait_completed: bool = False
    owner_group_absent: bool = False
    source_sha256: str
    errors: list[str] = Field(default_factory=list)
    scope: str = 'Actual wait of physical checker sequence, outside benchmark clocks.'


def main() -> int:
    source = ROOT / 'oracle_sequence.py'
    receipt = Receipt(observed_utc=datetime.now(timezone.utc).isoformat(), launcher_pid=os.getpid(), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    process: subprocess.Popen[bytes] | None = None
    try:
        with (ROOT / 'oracle-sequence-owner01.log').open('xb') as log:
            process = subprocess.Popen([str(ROOT.parent/'F2a-native-int64-build01/venv/bin/python'), '-I', '-B', str(source)], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            receipt.owner_pid = receipt.owner_pgid = process.pid
            receipt.owner_returncode = process.wait(timeout=5500)
            receipt.wait_completed = True
        rows = subprocess.run(['/bin/ps', '-axo', 'pid=,pgid='], capture_output=True, text=True, check=True).stdout
        receipt.owner_group_absent = not any(int(line.split()[1]) == process.pid for line in rows.splitlines() if len(line.split()) == 2)
        assert receipt.owner_returncode == 0 and receipt.owner_group_absent
        assert hashlib.sha256(source.read_bytes()).hexdigest() == receipt.source_sha256
    except BaseException as error:  # noqa: BLE001 - retain actual wait and cleanup errors.
        receipt.errors.append(f'{type(error).__name__}: {error}')
        if process is not None and process.poll() is None:
            try:
                process.terminate()
                receipt.owner_returncode = process.wait(timeout=30)
                receipt.wait_completed = True
            except Exception as cleanup:  # noqa: BLE001 - preserve unresolved direct child.
                receipt.errors.append(f'owned cleanup {type(cleanup).__name__}: {cleanup}')
    receipt.observed_utc = datetime.now(timezone.utc).isoformat()
    with (ROOT/'oracle-sequence-wait01.json').open('x') as stream:
        stream.write(receipt.model_dump_json(indent=2)+'\n')
    return 0 if not receipt.errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
