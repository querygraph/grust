# Final native F2a audit: source-only handoff

Config is exactly `{report:FilePin,oracles:[eight ordered FilePin],tiny_oracle:FilePin,output:Path}`.
Each FilePin is `{path,bytes,sha256}`. Use reports01/report.json and the ordered
oracles from report-plan01.json. Tiny oracle is oracle-tiny-int64-c3-01/receipt.json.
`output` must be a fresh direct child of this ROOT, e.g. ROOT/root-audit01.
ROOT/raw must not exist; partial copies are retained on failure, never deleted.

Fixed build01/main-campaign02/smoke-campaign02/failed-smoke01 metadata is bound.
The helper checks current source HEAD/tree/detached cleanliness, all main/smoke
admitted original/helper/client/binary/wheel/plan pins, native release build
and waited owner, exact installed wheel and rc0 install, main report and eight
full physical WCC oracles, three tiny outputs, projectionStats id1 then exactly
WCC ids2..calls+1 all finished. Failed model-only smoke stays negative history.
Waited physical-checker sequence is pinned and its owner/launcher/eight children
are included in independent numeric PID/PGID snapshots. No historical signals.

All nine whole SSD output directories are recursively copied, including logs,
staging/temporary regular files and all raw outputs. Symlinks/nonregulars fail.
Each file is hashed before copying, on Apo and on SSD afterward; result identities
also match sealed physical-oracle output identities. No Parquet is decoded.
Raw destinations are ROOT/raw/<dataset>-<ids>-c<call-count>, including tiny-int64-c3.
The complete durable identity inventory is output/raw-inventory.json.

Receipt positive outcome is passed_independent_F2a_native024_audit with
qualified_series8, qualified_main_outputs16, qualified_tiny_outputs3;
all_owned_pids_and_groups_absent, shared_locks_absent,
source_input_client_closure, full_raw_retention_verified all true; errors[].
It preserves configuration/source/wheel/evidence/raw_inventory FilePins,
source observations, known PID/PGID lists and numeric ps snapshots.
Copy or closure failure remains error with partial outputs preserved.
The helper has a fixed7200s alarm, performs no graph queries and sends no signals.
Its qualified scope is physical output/retention/ownership, not OS capacity,
exclusive Sem phase parity or publishable absolute performance on the shared host.

Invocation must expose both pure helper directories, without native imports:

```sh
/tmp/sem-output-oracle-venv/bin/python -I -B -c \
 'import runpy,sys;r=sys.argv[1];b=sys.argv[2];sys.path[:0]=[r,b];sys.argv=[r+"/f2a_root_audit.py"]+sys.argv[3:];runpy.run_path(sys.argv[0],run_name="__main__")' \
 /Volumes/Apo/graph-tests/results/sem-review-20261001/F2a-native-024-run01 \
 /Volumes/Apo/graph-tests/results/sem-review-20261001/F2a-native-int64-build01 \
 --config /ABS/final-audit-plan.json
```

Author ran Ruff/strict mypy/syntax only. Initial mypy None-narrowing findings
were corrected; no synthetic tests, process probes, actual audits, payload
hashes, copies, engines or native imports ran during source preparation.
Root owns actual execution after all owners and oracles have closed.
