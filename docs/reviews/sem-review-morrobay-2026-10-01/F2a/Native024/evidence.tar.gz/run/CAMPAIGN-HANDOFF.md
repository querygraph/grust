# Native F2a serial owner and waited launcher

Source preparation only. Root owns actual admission, tiny smoke, build/loader
qualification, main launch, full output oracles and retention. No worker,
native module, graph payload, process probe, build or engine was run by the author.

## Sources and contract

- `f2a_campaign.py`: `Config`, `Receipt`, `Series`, `run(configuration)`.
- `f2a_campaign_launch.py`: waited-launch `Receipt`, `run(configuration)`.
- Both import only pure `f2a_models`; the launcher imports the campaign too.
- Worker/models are the unchanged `worker-freeze01.json` versions: worker
  b829b93c23f7ffd6447c5bec8e54012dc82370191210593cb148c428a6a76812,
  models4423dd873f359ac96c91a01422c0a7a7f2b97009cb4840319350e9c9507e14ca.

`Config` fields are required unless a default is shown:

| Field | Meaning |
| --- | --- |
| root | Fresh metadata directory directly under campaign BASE, distinct from worker directory |
| worker | Absolute frozen f2a_worker.py path |
| python | New extension venv/bin/python, retain its symlink and venv identity |
| repo, tree | Exact clean detached 4b88c8fb4504ab1d2a896c9e49e4a09df4905bbb checkout and tree |
| plans | Ordered absolute JSON paths; one smoke or eight main plans |
| expected_plans | FilePin for every plan, each exactly once |
| expected_source | Nonempty source/admission FilePin list |
| expected_helpers | FilePins including campaign, launcher, frozen worker and models |
| expected_inputs | Original vertices/edges FilePins, each path once |
| expected_client | Selected installed wheel/code/native ABI/loader/discovery and real Python/libPython pins admitted by root |
| binary, wheel | Separate FilePins, compiled native9f declared independently of extension4b |
| timeout_seconds | Total owner bound, 300..21600; suggest smoke3000/main18000 |
| series_seconds | Default2050, allowed2010..2400, includes worker execution+cleanup allowance |
| minimum_free_bytes | Default/minimum64GiB, checked on metadata and timed-output volumes before each series |

Each FilePin is `{path,bytes,sha256}`. All are absolute regular files with
unique paths across categories; do not pin the venv Python symlink as a file.
Instead expected_client must include `config.python.resolve()` as its real
regular executable. Every worker plan uses this same venv and declared binary.
Root's nine current flat plans remain unchanged. Series receipt paths may be
under Config.root or exactly the frozen worker directory's `series/` directory.
Main plans must cover both datasets × text/integer IDs × one/three calls.
The configuration can live in Config.root or the frozen worker directory.

The owner refuses reused output/receipt paths or existing shared locks. It
holds BASE/gate.lock and BASE/serial-queue.lock throughout execution and
immutable closure. It keeps attempted outputs and logs, never retries, stops
on the first error, records remaining plan skips and retains owned failed
locks for root review. It never signals historical PID/PGIDs. Cancellation
signals only a still-live direct Popen child with the observed fresh group,
waits it, and remains an error; a server left alive requires root closure.

## Outcomes and boundaries

Campaign positive outcome is `completed_unvalidated_campaign`; waited launcher
positive is `completed_unvalidated_waited_campaign`. These qualify natural
worker execution and observed ownership closure only. They do not qualify
physical graph outputs or claim that 32GiB can accommodate a graph.

Each Series binds the plan, actual driver PID/PGID, Popen argv, UTCs, actual
wait/returncode, and `launch_to_wait` monotonic Span. It binds the worker
receipt, actual server PID/PGID, driver/server absence, and forced-cleanup flag.
The worker's separately retained continuous pipeline starts before read plans
and ends at the last Parquet write. Parent launch→wait includes interpreter,
session setup, diagnostics and cleanup. Never describe parent wall as kernel
time or fabricate four exclusive Sem phases; the worker's null fields remain.

Success requires worker rc0, `completed_unvalidated`, complete writes, cache
reuse, graph drop/session stop, no errors, and actual native wait with no forced
kill. Native rc0 or requested normal SIGTERM(-15) is accepted; other native
codes fail. All driver/server groups are observed absent after each series and
again at final closure, before owned locks are released. Source HEAD/tree/clean
state and source/helper/input/client/binary/wheel/plan bytes are bound before
and after; launcher independently checks final owner result and immutable pins.

RSS JSONL samples UTC, monotonic time and driver/server PID RSS in KiB every
500ms using ps pid/rss fields only. Per-Series observed peaks may be null,
particularly for a short smoke. Raw file pins, sampler closure and errors are
retained. An observed sample peak is not an OS maximum, memory cap, physical
allocation total or proof of native quota prepayment. Sampling errors stay
explicit; output/native resource qualification remains external.

## Root launch recipe

Use a short Python invocation to detach the *waited launcher* through Popen;
a bare background shell initialization previously vanished here. Replace
CONFIG and fresh INITIAL_LOG with root's admitted paths. The config and all
source pins must be frozen before launching. This recipe is not executed by
the author:

```python
import pathlib
import subprocess

python = '/tmp/sem-output-oracle-venv/bin/python'
support = '/Volumes/Apo/graph-tests/results/sem-review-20261001/F2a-native-024-run01'
configuration = 'CONFIG'
bootstrap = ('import runpy,sys;r=sys.argv[1];sys.path.insert(0,r);'
             'sys.argv=[r+"/f2a_campaign_launch.py"]+sys.argv[2:];'
             'runpy.run_path(sys.argv[0],run_name="__main__")')
with pathlib.Path('INITIAL_LOG').open('xb') as log:
    detached = subprocess.Popen(
        ['/usr/bin/nohup', python, '-I', '-B', '-c', bootstrap,
         support, '--config', configuration],
        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        start_new_session=True,
    )
print(detached.pid)
```

The launcher creates root/launch-receipt.json and owner.log, actually waits
for the owner, then records its observed return code and group absence. The
owner creates root/receipt.json, series-N.log and series-N-rss.jsonl. The worker
creates its distinct series receipt/output. Physical output oracles run after
engine exit and remain separate root-owned actions.

## Source gates

`campaign-source-gates02/receipt.json` binds final source bytes, Ruff, strict
mypy and syntax gates. Gate01 snapshots are preserved. Earlier development
Ruff unused-import and mypy alias/null-narrowing failures are recorded in the
session tool transcript; they were corrected before gate01. No behavioral or
engine test was run; root review and integrated tiny smoke are still required.
