"""Observe the newly installed native client; no graph or host binding."""
import argparse
import hashlib
import importlib
import importlib.metadata
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, ConfigDict, JsonValue, TypeAdapter

JSON = TypeAdapter(dict[str, JsonValue])


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FilePin(Model):
    path: Path
    bytes: int
    sha256: str


class Entry(Model):
    name: str
    value: str
    group: str


class Observation(Model):
    observed_utc: str
    python_version: str
    executable: str
    prefix: Path
    platform: str
    modules: dict[str, Path]
    distribution: str
    entrypoints: list[Entry]
    manifests: dict[str, dict[str, JsonValue]]
    installed_files: list[FilePin]
    native_file_observation: str
    package_versions: dict[str, str]
    scope: str = "Native module import and installed client/discovery origins; no Sail engine, native host binding, algorithm or performance verdict."


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    prefix = Path(sys.prefix).resolve()
    modules: dict[str, Path] = {}
    for name in ("sail_nutmeg", "sail_nutmeg._native", "sail_nutmeg.client", "sail_nutmeg.argentea_factory"):
        module = importlib.import_module(name)
        assert module.__file__ is not None
        path = Path(module.__file__).resolve()
        assert path.is_relative_to(prefix), (name, path, prefix)
        modules[name] = path
    manifests: dict[str, dict[str, JsonValue]] = {}
    for name in ("sail_nutmeg", "sail_nutmeg.argentea_factory"):
        manifest = JSON.validate_python(importlib.import_module(name).extension().manifest())
        assert manifest["datafusion_version"] == "55.1.0"
        assert manifest["arrow_version"] == "59.3.0"
        manifests[name] = manifest
    files: list[FilePin] = []
    dist = importlib.metadata.distribution("sail-nutmeg")
    for package_path in sorted(dist.files or []):
        path = Path(str(dist.locate_file(package_path))).resolve()
        if path.is_file() and "__pycache__" not in path.parts:
            assert path.is_relative_to(prefix)
            with path.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            files.append(FilePin(path=path, bytes=path.stat().st_size, sha256=digest))
    native = subprocess.run(["/usr/bin/file", str(modules["sail_nutmeg._native"])], capture_output=True, text=True, check=True)
    assert "Mach-O 64-bit" in native.stdout and "x86_64" in native.stdout
    entries = [Entry(name=e.name, value=e.value, group=e.group) for e in dist.entry_points]
    assert {(e.name, e.value) for e in entries} >= {("nutmeg", "sail_nutmeg:extension"), ("argentea", "sail_nutmeg.argentea_factory:extension")}
    record = Observation(observed_utc=datetime.now(timezone.utc).isoformat(), python_version=sys.version, executable=sys.executable, prefix=prefix, platform=platform.platform(), modules=modules, distribution=dist.version, entrypoints=entries, manifests=manifests, installed_files=files, native_file_observation=native.stdout.strip(), package_versions={n: importlib.metadata.version(n) for n in ("sail-nutmeg", "pyspark", "pyarrow", "numpy", "pydantic", "maturin")})
    with args.output.open("x") as stream:
        stream.write(record.model_dump_json(indent=2) + "\n")
    print(record.observed_utc + " " + native.stdout.strip())


if __name__ == "__main__":
    main()
