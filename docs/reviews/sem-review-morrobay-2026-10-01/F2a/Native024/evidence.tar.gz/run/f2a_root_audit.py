"""Independent native F2a metadata/process closure and full raw-byte retention."""
from __future__ import annotations

import argparse
import os
import shutil
import signal
import subprocess
from pathlib import Path
from typing import Literal

import build_native as build
import f2a_campaign as campaign
import f2a_campaign_launch as waited
import f2a_models as worker
import f2a_report_support as meta
import wait_launch as build_waited
from pydantic import Field

ROOT = campaign.BASE / 'F2a-native-024-run01'
MAIN = campaign.BASE / 'F2a-native-024-main-campaign02'
SMOKE = campaign.BASE / 'F2a-native-024-smoke-campaign02'
FAILED = campaign.BASE / 'F2a-native-024-smoke-campaign01'
SSD = Path('/Users/alexy/src/grust-benchmark-runs')


class Config(worker.Record):
    report: worker.FilePin
    oracles: list[worker.FilePin] = Field(min_length=8, max_length=8)
    tiny_oracle: worker.FilePin
    output: Path


class Process(worker.Record):
    pid: int
    pgid: int


class Launch(meta.Subset):
    launcher_pid: int
    launcher_pgid: int


class Install(meta.Subset):
    pid: int
    pgid: int
    returncode: Literal[0]
    wait_completed: Literal[True]
    wheel: worker.FilePin
    argv: list[str]
    finished_utc: str


class OracleCall(meta.Subset):
    plan: Path
    pid: int
    returncode: Literal[0]
    wait_completed: Literal[True]
    group_absent: Literal[True]


class OracleSequence(meta.Subset):
    owner_pid: int
    outcome: Literal['passed_eight_waited_physical_oracles']
    finished_utc: str
    calls: list[OracleCall] = Field(min_length=8, max_length=8)
    errors: list[str]


class OracleWait(meta.Subset):
    launcher_pid: int
    owner_pid: int
    owner_pgid: int
    owner_returncode: Literal[0]
    wait_completed: Literal[True]
    owner_group_absent: Literal[True]
    source_sha256: str
    errors: list[str]


class Read(meta.Subset):
    id: int
    algorithm: str
    graph: Literal['g']
    state: Literal['finished']
    rows: int
    message: None


class RawDataset(meta.Subset):
    directory: Path
    files: dict[str, meta.Identity]


class RawOutput(RawDataset):
    number: int


class RawOracleConfig(meta.Subset):
    outputs: list[RawOutput]


class OracleConfigurationBinding(meta.Subset):
    configuration: worker.FilePin


class RawOracle(meta.Subset):
    config: RawOracleConfig


class Copy(worker.Record):
    source_before: worker.FilePin
    destination: Path
    destination_after: worker.FilePin | None = None
    source_after: worker.FilePin | None = None
    verified: bool = False


class Inventory(worker.Record):
    files: list[Copy] = Field(default_factory=list)
    directories: dict[str, str] = Field(default_factory=dict)


class Receipt(worker.Record):
    outcome: Literal['checking', 'passed_independent_F2a_native024_audit', 'error'] = 'checking'
    observed_utc: str
    finished_utc: str | None = None
    configuration: worker.FilePin
    source: worker.FilePin
    qualified_series: int = 0
    qualified_main_outputs: int = 0
    qualified_tiny_outputs: int = 0
    all_owned_pids_and_groups_absent: bool = False
    shared_locks_absent: bool = False
    source_input_client_closure: bool = False
    full_raw_retention_verified: bool = False
    evidence: list[worker.FilePin] = Field(default_factory=list)
    wheel: worker.FilePin | None = None
    source_observations: dict[str, dict[str, str]] = Field(default_factory=dict)
    owned_pids: list[int] = Field(default_factory=list)
    owned_pgids: list[int] = Field(default_factory=list)
    process_snapshots: list[list[Process]] = Field(default_factory=list)
    raw_inventory: worker.FilePin | None = None
    errors: list[str] = Field(default_factory=list)
    scope: str = 'Whole closed native F2a campaign: eight series/sixteen main outputs and three tiny controls. Physical partitions are qualified by pinned full oracles; this audit independently binds metadata, immutable source/input/client/binary/wheel bytes, current process closure and complete raw copies. No new graph queries or performance/resource-capacity claim.'


def capture(path: Path, receipt: Receipt) -> worker.FilePin:
    result = meta.capture(path)
    receipt.evidence.append(result)
    return result


def snapshot(receipt: Receipt) -> None:
    result = subprocess.run(['/bin/ps', '-axo', 'pid=,pgid='], capture_output=True, text=True, timeout=10, check=False)
    meta.require(result.returncode == 0, 'numeric process observation failed')
    observed = [Process(pid=int(a), pgid=int(b)) for a, b in (row.split() for row in result.stdout.splitlines())]
    receipt.process_snapshots.append(observed)
    meta.require(not any(p.pid in receipt.owned_pids or p.pgid in receipt.owned_pgids for p in observed), 'known owned PID or process group remains live')
    meta.require(all(not p.exists() for p in build.LOCKS), 'shared locks remain present')


def read_campaign(directory: Path, receipt: Receipt, positive: bool) -> tuple[campaign.Receipt, campaign.Config]:
    producer_pin = capture(directory / 'receipt.json', receipt)
    producer = meta.load(producer_pin, campaign.Receipt)
    exit_pin = capture(directory / 'launch-receipt.json', receipt)
    closed = meta.load(exit_pin, waited.Receipt)
    launch = meta.load(capture(directory / 'launcher-admission.json', receipt), Launch)
    admitted = meta.load(producer.configuration, campaign.Config)
    receipt.evidence.append(producer.configuration)
    meta.require(launch.launcher_pid == closed.launcher_pid and closed.owner_pid == producer.owner_pid and closed.configuration == producer.configuration and closed.owner_pgid == producer.owner_pid and closed.wait_completed and closed.owner_group_absent and not closed.forced_cleanup, 'campaign launcher/owner binding differs')
    receipt.owned_pids.extend([closed.launcher_pid, producer.owner_pid])
    receipt.owned_pgids.extend([launch.launcher_pgid, producer.owner_pid])
    if positive:
        meta.require(producer.outcome == 'completed_unvalidated_campaign' and closed.outcome == 'completed_unvalidated_waited_campaign' and closed.returncode == 0 and closed.producer_receipt == producer_pin and not producer.errors and not closed.errors and producer.finished_utc is not None and producer.locks_released and producer.all_owned_groups_absent and not producer.skipped_plans and producer.before == producer.after == admitted.pins() and producer.source_before == producer.source_after and len(producer.series) == len(admitted.plans), 'positive campaign failed closure')
        meta.require([campaign.pin(p.path) for p in admitted.pins()] == admitted.pins(), 'current original/helper/client/binary/wheel/plan pins differ')
        current = campaign.source(admitted)
        meta.require(current == producer.source_after, 'current exact detached source differs')
        receipt.source_observations[directory.name] = current
    else:
        meta.require(producer.outcome == closed.outcome == 'error' and closed.returncode == 1 and bool(producer.errors) and bool(closed.errors), 'initial failed smoke history changed')
        closure = meta.JSON.validate_json(meta.raw(capture(directory / 'manual-closure01.json', receipt)))
        meta.require(isinstance(closure, dict) and closure.get('outcome') == 'closed_failed_smoke_initialization' and closure.get('engine_worker_receipt_absent') is True and closure.get('timed_output_root_absent') is True and closure.get('known_owned_pid_groups_absent') is True and closure.get('locks_released') is True, 'negative smoke closure proof differs')
    for series in producer.series:
        receipt.owned_pids.append(series.pid)
        receipt.owned_pgids.append(series.pgid)
        if series.server_pid is not None and series.server_pgid is not None:
            receipt.owned_pids.append(series.server_pid)
            receipt.owned_pgids.append(series.server_pgid)
    return producer, admitted


def retain(plan: worker.Plan, oracle_pin: worker.FilePin, inventory: Inventory, config: Config) -> None:
    source = plan.output_root
    expected_source = SSD / 'F2a-native-024-smoke01' if plan.dataset == 'tiny' else SSD / 'F2a-native-024-run01' / f'{plan.dataset}-{plan.ids}-c{plan.calls}'
    meta.require(source.is_dir() and not source.is_symlink() and source == source.resolve() and source == expected_source, 'raw source scope differs')
    destination = ROOT / 'raw' / f'{plan.dataset}-{plan.ids}-c{plan.calls}'
    destination.mkdir(parents=True, exist_ok=False)
    inventory.directories[str(source)] = str(destination)
    sealed = meta.load(oracle_pin, RawOracle)
    expected = {str(o.directory / name): identity for o in sealed.config.outputs for name, identity in o.files.items()}
    paths = sorted(source.rglob('*'))
    meta.require(all(not p.is_symlink() and (p.is_dir() or p.is_file()) for p in paths), 'nonregular or symlink in whole raw directory')
    for path in paths:
        copied = destination / path.relative_to(source)
        if path.is_dir():
            copied.mkdir(parents=True, exist_ok=True)
            continue
        copied.parent.mkdir(parents=True, exist_ok=True)
        before = campaign.pin(path)
        if str(path) in expected:
            meta.require(before.bytes == expected[str(path)].bytes and before.sha256 == expected[str(path)].sha256, 'raw result differs from physical oracle identity')
        item = Copy(source_before=before, destination=copied)
        inventory.files.append(item)
        campaign.save(config.output / 'raw-inventory.json', inventory)
        with path.open('rb') as input_stream, copied.open('xb') as output_stream:
            shutil.copyfileobj(input_stream, output_stream, length=1024 * 1024)
            output_stream.flush()
            os.fsync(output_stream.fileno())
        item.destination_after, item.source_after = campaign.pin(copied), campaign.pin(path)
        meta.require(item.source_after == before and item.destination_after.bytes == before.bytes and item.destination_after.sha256 == before.sha256, 'raw source/copy/source closure differs')
        item.verified = True
        campaign.save(config.output / 'raw-inventory.json', inventory)
    actual = {str(p) for p in paths if p.is_file()}
    meta.require(set(expected) <= actual and set(paths) == set(source.rglob('*')), 'raw result set or whole source inventory changed')


def run(path: Path) -> int:
    configuration = meta.capture(path)
    config = meta.load(configuration, Config)
    meta.require(config.output.parent == ROOT and not config.output.exists() and not (ROOT / 'raw').exists(), 'fresh scoped audit/raw destinations required')
    config.output.mkdir()
    receipt = Receipt(observed_utc=campaign.utc(), configuration=configuration, source=meta.capture(Path(__file__).resolve()))
    campaign.save(config.output / 'receipt.json', receipt)
    inventory = Inventory()
    try:
        signal.signal(signal.SIGALRM, campaign.interrupted)
        signal.alarm(7200)
        meta.require(all(not p.exists() for p in build.LOCKS), 'shared locks prevent audit admission')
        compiled = meta.load(capture(build.ROOT / 'receipt.json', receipt), build.Receipt)
        build_exit = meta.load(capture(build.ROOT / 'launch-receipt.json', receipt), build_waited.Receipt)
        build_launch = meta.load(capture(build.ROOT / 'launcher-admission02.json', receipt), Launch)
        build_plan = build.Plan.model_validate_json(meta.raw(worker.FilePin(**compiled.plan.model_dump())))
        meta.require(compiled.outcome == 'passed_release_native_wheel_build' and not compiled.errors and compiled.finished_utc is not None and compiled.locks_released and compiled.all_owned_groups_absent and compiled.immutable_pins_before_after_equal and compiled.source_before == compiled.source_after and compiled.wheel is not None, 'release wheel build failed')
        meta.require(build_exit.outcome == 'passed_waited_native_wheel_build' and build_exit.owner_pid == compiled.owner.pid and build_exit.owner_pgid == compiled.owner.pid and build_launch.launcher_pid == build_exit.launcher_pid and build_exit.returncode == 0 and build_exit.wait_completed and build_exit.owner_group_absent and not build_exit.errors and build_exit.owner_receipt is not None and build_exit.owner_receipt.model_dump() == build.pin(build.ROOT / 'receipt.json').model_dump() and build_exit.plan == compiled.plan, 'build waited exit differs')
        meta.require(compiled.source_before == build.Source(commit=build_plan.commit, tree=build_plan.tree, status='', detached=True), 'built extension source observation differs')
        build.immutable(build_plan, compiled.plan)
        receipt.evidence.append(worker.FilePin(**compiled.plan.model_dump()))
        receipt.owned_pids.extend([compiled.owner.pid, build_exit.launcher_pid])
        receipt.owned_pgids.extend([compiled.owner.pid, build_launch.launcher_pgid])
        for step in compiled.steps:
            meta.require(step.returncode == 0 and step.wait_completed and step.finished_utc is not None and not step.forced_cleanup and not step.remaining_owned_pids, 'one build step failed')
            receipt.owned_pids.append(step.pid)
            receipt.owned_pgids.append(step.pgid)
        installed = meta.load(capture(build.ROOT / 'install01.json', receipt), Install)
        receipt.owned_pids.append(installed.pid)
        receipt.owned_pgids.append(installed.pgid)
        if compiled.wheel is None:
            raise ValueError('wheel missing')
        receipt.wheel = worker.FilePin(**compiled.wheel.model_dump())
        meta.require(installed.wheel == receipt.wheel and str(receipt.wheel.path) in installed.argv, 'installed wheel origin differs')
        main, admitted = read_campaign(MAIN, receipt, True)
        smoke, smoke_config = read_campaign(SMOKE, receipt, True)
        read_campaign(FAILED, receipt, False)
        meta.require(admitted.wheel == smoke_config.wheel == receipt.wheel and len(main.series) == 8 and len(smoke.series) == 1, 'build/campaign wheel or series counts differ')
        report = meta.load(config.report, meta.ReportReceipt)
        report_config = meta.load(report.configuration, meta.Config)
        meta.require(report.series_count == 8 and report.qualified_output_count == 16 and report.source_before == report.source_after and len(report.reports) == 8 and report_config.campaign == meta.capture(MAIN / 'receipt.json') and report_config.campaign_exit == meta.capture(MAIN / 'launch-receipt.json') and report_config.oracles == config.oracles, 'metadata report binding differs')
        receipt.evidence.extend([config.report, report.configuration, *report.metadata_inputs, *report.source_before, *report.reports, config.tiny_oracle])
        oracle_sequence = meta.load(capture(ROOT / 'oracle-sequence-receipt01.json', receipt), OracleSequence)
        oracle_wait = meta.load(capture(ROOT / 'oracle-sequence-wait01.json', receipt), OracleWait)
        oracle_source = capture(ROOT / 'oracle_sequence.py', receipt)
        meta.require(not oracle_sequence.errors and not oracle_wait.errors and oracle_wait.owner_pid == oracle_wait.owner_pgid == oracle_sequence.owner_pid and oracle_wait.source_sha256 == oracle_source.sha256, 'waited oracle sequence closure/source differs')
        oracle_launch = meta.load(capture(ROOT / 'oracle-sequence-launch-admission01.json', receipt), Launch)
        meta.require(oracle_launch.launcher_pid == oracle_wait.launcher_pid, 'oracle launcher admission differs')
        receipt.owned_pids.extend([oracle_sequence.owner_pid, oracle_wait.launcher_pid, *[c.pid for c in oracle_sequence.calls]])
        receipt.owned_pgids.extend([oracle_wait.owner_pgid, oracle_launch.launcher_pgid, *[c.pid for c in oracle_sequence.calls]])
        meta.require([c.plan for c in oracle_sequence.calls] == [meta.load(p, OracleConfigurationBinding).configuration.path for p in config.oracles], 'oracle sequence order/plan binding differs')
        snapshot(receipt)
        series_inputs = [(s, p, admitted) for s, p in zip(main.series, config.oracles, strict=True)] + [(smoke.series[0], config.tiny_oracle, smoke_config)]
        for series, oracle_pin, parent in series_inputs:
            if series.worker_receipt is None:
                raise ValueError('worker receipt missing')
            item = meta.load(series.worker_receipt, worker.Receipt)
            campaign.accept(parent, item.configuration, series)
            oracle, _, _, _ = meta.validate_series(series, item, oracle_pin, parent)
            meta.require(item.native_status is not None, 'native status missing')
            status = worker.NativeStatus.model_validate(item.native_status)
            reads = [Read.model_validate(v) for v in status.reads]
            meta.require(status.one_cached_projection() and [(r.id, r.algorithm, r.rows) for r in reads] == [(1, 'projectionStats', 1), *[(n + 1, 'wcc', oracle.config.expected_rows) for n in range(1, item.configuration.calls + 1)]], 'native read history/cache differs')
            receipt.evidence.extend([series.worker_receipt, series.plan, oracle_pin])
            retain(item.configuration, oracle_pin, inventory, config)
        meta.require(sum(len(meta.load(p, meta.Oracle).outputs) for p in config.oracles) == 16 and len(meta.load(config.tiny_oracle, meta.Oracle).outputs) == 3 and all(f.verified for f in inventory.files), 'qualified output/retention count differs')
        for evidence in receipt.evidence:
            meta.require(campaign.pin(evidence.path) == evidence, 'current metadata/source evidence changed')
        for parent in (admitted, smoke_config):
            meta.require([campaign.pin(p.path) for p in parent.pins()] == parent.pins() and campaign.source(parent) == receipt.source_observations[parent.root.name], 'final original/source/client closure differs')
        build.immutable(build_plan, compiled.plan)
        meta.require(meta.capture(Path(__file__).resolve()) == receipt.source and meta.capture(path) == configuration, 'root audit source/configuration changed')
        snapshot(receipt)
        receipt.owned_pids, receipt.owned_pgids = sorted(set(receipt.owned_pids)), sorted(set(receipt.owned_pgids))
        receipt.raw_inventory = campaign.pin(config.output / 'raw-inventory.json')
        receipt.qualified_series, receipt.qualified_main_outputs, receipt.qualified_tiny_outputs = 8, 16, 3
        receipt.all_owned_pids_and_groups_absent = receipt.shared_locks_absent = receipt.source_input_client_closure = receipt.full_raw_retention_verified = True
        receipt.outcome = 'passed_independent_F2a_native024_audit'
    except BaseException as error:  # noqa: BLE001 - preserve partial copies and every independent audit failure.
        receipt.errors.append(f'{type(error).__name__}: {error}')
        receipt.outcome = 'error'
    finally:
        signal.alarm(0)
        receipt.finished_utc = campaign.utc()
        campaign.save(config.output / 'receipt.json', receipt)
    print(receipt.outcome + ' ' + str(config.output / 'receipt.json'), flush=True)
    return 0 if receipt.outcome == 'passed_independent_F2a_native024_audit' else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, type=Path)
    return run(parser.parse_args().config.resolve())


if __name__ == '__main__':
    raise SystemExit(main())
