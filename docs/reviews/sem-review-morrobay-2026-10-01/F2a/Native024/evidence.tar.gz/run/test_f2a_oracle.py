"""Bounded WCC oracle controls with an explicit four-vertex partition."""

import collections.abc
import dataclasses
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import f2a_oracle as oracle
import pyarrow as pa
import pyarrow.parquet as pq


@dataclasses.dataclass(slots=True)
class Fixture:
    config: oracle.Config
    configuration: oracle.FilePin
    root: Path


def pin(path: Path) -> oracle.FilePin:
    return oracle.FilePin(
        path=path, **oracle.identity(path, oracle.Deadline(60)).model_dump()
    )


def data(directory: Path) -> oracle.ResultDataset:
    files = oracle.actual_files(oracle.ResultDataset(directory=directory, files={}))
    return oracle.ResultDataset(
        directory=directory,
        files={
            name: oracle.identity(path, oracle.Deadline(60))
            for name, path in files.items()
        },
    )


def table(
    ids: list[int],
    labels: collections.abc.Sequence[int | None],
    kind: pa.DataType | None = None,
) -> pa.Table:
    return pa.table(
        {
            "id": pa.array(ids, type=pa.int64()),
            "component": pa.array(labels, type=kind or pa.int64()),
        }
    )


def fixture(
    root: Path,
    *,
    calls: int = 1,
    ids: list[int] | None = None,
    reference: list[int] | None = None,
    candidate: list[int] | None = None,
) -> Fixture:
    vertices = ids if ids is not None else [-8, 0, 2, 5]
    expected = reference if reference is not None else [-8, 0, -8, -8]
    vertices_file = root / "vertices.parquet"
    pq.write_table(pa.table({"id": pa.array(vertices, type=pa.int64())}), vertices_file)
    refdir = root / "reference"
    refdir.mkdir()
    pq.write_table(table(vertices, expected), refdir / "part.parquet")
    outputs = []
    for number in range(1, calls + 1):
        target = root / f"call{number}"
        target.mkdir()
        labels = candidate if candidate is not None else [2, 0, 2, 2]
        pq.write_table(table(vertices, labels), target / "part.parquet")
        observed = data(target)
        outputs.append(oracle.Output(number=number, **observed.model_dump()))
    config = oracle.Config(
        vertices=pin(vertices_file),
        expected_rows=len(vertices),
        reference=data(refdir),
        outputs=tuple(outputs),
        output=root / "oracle",
        batch_rows=2,
    )
    configuration = root / "configuration.json"
    configuration.write_text(config.model_dump_json(indent=2) + "\n")
    return Fixture(config=config, configuration=pin(configuration), root=root)


def refresh(item: Fixture) -> None:
    outputs = tuple(
        oracle.Output(number=o.number, **data(o.directory).model_dump())
        for o in item.config.outputs
    )
    item.config = oracle.Config.model_validate(
        {**item.config.model_dump(), "outputs": outputs}
    )
    item.configuration.path.write_text(item.config.model_dump_json(indent=2) + "\n")
    item.configuration = pin(item.configuration.path)


class OracleControls(unittest.TestCase):
    def test_three_calls_keep_full_four_vertex_partition_with_arbitrary_member_labels(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as directory:
            item = fixture(Path(directory), calls=3)
            # Three independent physical outputs; no fixture-derived engine comparison.
            pq.write_table(
                table([-8, 0, 2, 5], [5, 0, 5, 5]),
                item.config.outputs[1].directory / "part.parquet",
            )
            refresh(item)
            receipt = oracle.run(item.config, item.configuration)
            self.assertEqual(receipt.outcome, "passed_full_physical_wcc")
            self.assertEqual(receipt.identities_before, receipt.identities_after)
            for output in receipt.outputs:
                self.assertEqual(
                    (output.rows, output.unique_rows, output.components), (4, 4, 2)
                )
                self.assertEqual(output.canonical_member_mismatches, 0)
                self.assertTrue(output.full_partition_equivalence_passed)
            self.assertEqual([o.number for o in receipt.outputs], [1, 2, 3])

    def test_false_merge_and_false_split_are_each_rejected(self) -> None:
        for labels in ([2, 2, 2, 2], [2, 0, 2, 5]):
            with (
                self.subTest(labels=labels),
                tempfile.TemporaryDirectory() as directory,
            ):
                item = fixture(Path(directory), candidate=labels)
                receipt = oracle.run(item.config, item.configuration)
                self.assertEqual(receipt.outcome, "error")
                self.assertEqual(receipt.outputs[0].canonical_member_mismatches, 1)
                self.assertTrue(receipt.own_identity_closure_passed)

    def test_duplicate_in_batch_or_across_files_is_rejected(self) -> None:
        for across_files in (False, True):
            with (
                self.subTest(across_files=across_files),
                tempfile.TemporaryDirectory() as directory,
            ):
                item = fixture(Path(directory))
                output = item.config.outputs[0].directory
                if across_files:
                    pq.write_table(table([-8, 0], [2, 0]), output / "part.parquet")
                    pq.write_table(table([2, 0], [2, 0]), output / "part2.parquet")
                else:
                    pq.write_table(
                        table([-8, 0, 2, 2], [2, 0, 2, 2]), output / "part.parquet"
                    )
                refresh(item)
                receipt = oracle.run(item.config, item.configuration)
                self.assertEqual(receipt.outcome, "error")
                self.assertTrue(
                    any("duplicate output" in error for error in receipt.errors)
                )

    def test_missing_unknown_null_or_nonmember_label_is_rejected(self) -> None:
        cases = [
            table([-8, 0, 2], [2, 0, 2]),
            table([-8, 0, 2, 9], [2, 0, 2, 2]),
            table([-8, 0, 2, 5], [2, 0, None, 2]),
            table([-8, 0, 2, 5], [9, 0, 9, 9]),
        ]
        for candidate in cases:
            with (
                self.subTest(candidate=candidate.to_pydict()),
                tempfile.TemporaryDirectory() as directory,
            ):
                item = fixture(Path(directory))
                pq.write_table(
                    candidate, item.config.outputs[0].directory / "part.parquet"
                )
                refresh(item)
                self.assertEqual(
                    oracle.run(item.config, item.configuration).outcome, "error"
                )

    def test_wrong_type_extra_or_duplicate_fields_are_retained_and_rejected(
        self,
    ) -> None:
        ids = pa.array([-8, 0, 2, 5], type=pa.int64())
        labels = pa.array([2, 0, 2, 2], type=pa.int64())
        cases = [
            table([-8, 0, 2, 5], [2, 0, 2, 2], pa.int32()),
            pa.table({"id": ids, "component": labels, "extra": labels}),
            pa.Table.from_arrays(
                [ids, labels, labels], names=["id", "component", "component"]
            ),
        ]
        for candidate in cases:
            with (
                self.subTest(schema=str(candidate.schema)),
                tempfile.TemporaryDirectory() as directory,
            ):
                item = fixture(Path(directory))
                pq.write_table(
                    candidate, item.config.outputs[0].directory / "part.parquet"
                )
                refresh(item)
                receipt = oracle.run(item.config, item.configuration)
                self.assertEqual(receipt.outcome, "error")
                self.assertTrue(receipt.outputs[0].physical_schemas)

    def test_signed_extremes_use_ordinal_arrays_not_maximum_id(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            low, high = -(2**63), 2**63 - 1
            item = fixture(
                Path(directory),
                ids=[low, -8, 0, high],
                reference=[low, low, 0, high],
                candidate=[-8, -8, 0, high],
            )
            receipt = oracle.run(item.config, item.configuration)
            self.assertEqual(receipt.outcome, "passed_full_physical_wcc")
            self.assertEqual(receipt.outputs[0].components, 3)

    def test_late_raw_mutation_downgrades_prior_correct_partition(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            item = fixture(Path(directory))
            original = oracle.partition

            def changed(
                config: oracle.Config,
                raw: oracle.ResultDataset,
                ids: oracle.I64,
                checked: oracle.CheckedOutput,
                deadline: oracle.Deadline,
            ) -> oracle.I64:
                result = original(config, raw, ids, checked, deadline)
                if checked.number == 1:
                    pq.write_table(
                        table([-8, 0, 2, 5], [2, 2, 2, 2]),
                        raw.directory / "part.parquet",
                    )
                return result

            with mock.patch.object(oracle, "partition", side_effect=changed):
                receipt = oracle.run(item.config, item.configuration)
            self.assertEqual(receipt.outputs[0].canonical_member_mismatches, 0)
            self.assertEqual(receipt.outcome, "error")
            self.assertFalse(receipt.own_identity_closure_passed)

    def test_sealed_hash_and_member_inventory_mismatches_are_rejected(self) -> None:
        for extra in (False, True):
            with self.subTest(extra=extra), tempfile.TemporaryDirectory() as directory:
                item = fixture(Path(directory))
                target = item.config.outputs[0].directory
                if extra:
                    (target / "unexpected.txt").write_text("unexpected")
                else:
                    pq.write_table(
                        table([-8, 0, 2, 5], [5, 0, 5, 5]), target / "part.parquet"
                    )
                receipt = oracle.run(item.config, item.configuration)
                self.assertEqual(receipt.outcome, "error")
                self.assertTrue(receipt.errors)
                self.assertTrue((item.config.output / "receipt.json").is_file())

    def test_timeout_receipt_is_durable_and_existing_output_is_not_retried(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as directory:
            item = fixture(Path(directory))
            item.config = oracle.Config.model_validate(
                {**item.config.model_dump(), "work_seconds": 1e-9}
            )
            item.configuration.path.write_text(item.config.model_dump_json() + "\n")
            item.configuration = pin(item.configuration.path)
            receipt = oracle.run(item.config, item.configuration)
            self.assertEqual(receipt.outcome, "error")
            self.assertTrue(any("TimeoutError" in error for error in receipt.errors))
            self.assertEqual(
                json.loads((item.config.output / "receipt.json").read_text())[
                    "outcome"
                ],
                "error",
            )
            with self.assertRaises(FileExistsError):
                oracle.run(item.config, item.configuration)


if __name__ == "__main__":
    unittest.main()
