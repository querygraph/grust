# Native F2a WCC worker

This is source preparation, not a benchmark result. Root owns source/input/
binary/client admission, launch, all output oracles and process-group closure.
Source: exact Sail extension `4b88c8fb4504ab1d2a896c9e49e4a09df4905bbb`,
Grust registry crates `=0.24.0`; admitted native Sail runtime
`9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3` is declared separately.

## Invocation

Use the freshly built extension venv's Python 3.12.6, with `sys.prefix` equal
to `plan.venv`:

```sh
/ABS/new-venv/bin/python -B \
  /Volumes/Apo/graph-tests/results/sem-review-20261001/F2a-native-024-run01/f2a_worker.py \
  --plan /ABS/approved-series-plan.json
```

`f2a-plan-schema.json` and `f2a-plan-template.json` are source-only schema and
template. Replace every `/ABS` path before admission. Run one fresh directory
and receipt per approved series. The worker refuses existing outputs or
receipts and never removes attempted outputs. `tiny` is allowed for root's
integrated smoke; this is not a graph benchmark.

The worker stages original Parquet once, `asStaged`, preserving signed Int64
inputs or casting them to text as selected. Both mappings use `ids=int64` only
in integer mode. The ordinary `wcc` kernel and projectionStats receive no
orientation argument. ProjectionStats builds the default cache key once;
every one or three WCC calls uses exactly `concurrency=16` and writes both
columns `id:int64, component:int64` via native Parquet. Each output lives at
`output_root/result-callN`.

## Clocks and qualification

The primary continuous monotonic span begins before input-read plans and ends
at the last completed Parquet write. Nonoverlapping raw spans are
`read_and_stage`, `projection_stats_action` and each `wcc_and_parquet_write`.
No count, status query or physical oracle runs inside that pipeline. There is
one post-pipeline status query; its original JSON is retained and a typed
check requires one graph named g and exactly one cached projection/build.

All four exclusive Sem fields are null and marked unavailable. Reading and
normalization are included in staging; the lazy WCC executes during its
write. The raw spans do not manufacture separate algorithm/write timings.
Session creation, diagnostics, graph/session teardown and native shutdown
are outside the primary clock. There is no claim of OS memory fit or speed.

`outcome=completed_unvalidated` and worker rc0 require no errors, completed
writes and the cache check. Root must additionally require full physical
original-domain and WCC partition oracles. Compare canonical partitions,
not identical raw labels across text/integer modes or staging orders.

The native server starts in a new session. Its actual PID/observed PGID,
argv, requested termination, actual waited return code and UTC are recorded.
Normal requested SIGTERM can produce -15; it is separate from query outcomes.
Forced kill downgrades the series to failed. Parent must independently close
and verify driver/server groups; worker only proves the direct server wait.

Execution has a 1800-second alarm. Cleanup has separate bounded budgets:
graph drop 30 seconds, session stop 30, graceful direct-server wait 120 and
forced wait 30. Parent should allow about 2050 seconds before its own timeout.
All cleanup errors remain errors; retained writes do not make a failed series
successful. Both quota environment spellings are controlled at 22 GiB so an
inherited NUTMEG_MEMORY_BYTES cannot override the plan; the Sail pool is 30 GiB.

## Source checks

`source-gates03/receipt.json` binds the production sources and exact gates:
isolated Ruff, strict mypy with missing libraries ignored/imports silent,
and five bounded model controls. These gates never imported the worker or
native extension or read graph payloads. Failed source attempts 01/02 keep
their source snapshots, errors and logs. No new benchmark or build ran.
