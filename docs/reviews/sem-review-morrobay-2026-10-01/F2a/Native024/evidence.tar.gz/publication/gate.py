"""Exact detached F2a documentation and sealed small-evidence gate."""

import argparse
import hashlib
import re
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Literal

import pack_metadata as metadata
import pydantic as pyd

ROOT = "docs/reviews/sem-review-morrobay-2026-10-01/F2a/Native024/"
SOURCE = "4b88c8fb4504ab1d2a896c9e49e4a09df4905bbb"
RUNTIME = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
LIMIT, TOTAL = 32 * 1024**2, 512 * 1024**2
JSON: pyd.TypeAdapter[pyd.JsonValue] = pyd.TypeAdapter(pyd.JsonValue)
OBJECT: pyd.TypeAdapter[dict[str, pyd.JsonValue]] = pyd.TypeAdapter(dict[str, pyd.JsonValue])
ARRAY: pyd.TypeAdapter[list[pyd.JsonValue]] = pyd.TypeAdapter(list[pyd.JsonValue])
require, safe = metadata.require, metadata.safe


class Identity(metadata.Record):
    bytes: int = pyd.Field(ge=0, le=TOTAL)
    sha256: str = pyd.Field(pattern=r"^[0-9a-f]{64}$")


class Index(metadata.Record):
    observed_utc: str
    files: dict[str, Identity]
    sources: dict[str, metadata.Member]
    count: int
    total_bytes: int
    archive: Identity


class Plan(metadata.Record):
    parent_commit: str = pyd.Field(pattern=r"^[0-9a-f]{40}$")
    expected_tree: str = pyd.Field(pattern=r"^[0-9a-f]{40}$")
    files: dict[str, Identity]
    archive: str
    archive_inventory: str
    proofs: dict[str, str]
    required_members: tuple[str, ...]


class RootAudit(pyd.BaseModel):
    model_config = pyd.ConfigDict(extra="ignore", strict=True)
    outcome: Literal["passed_independent_F2a_native024_audit"]
    observed_utc: str
    qualified_series: Literal[8]
    qualified_main_outputs: Literal[16]
    qualified_tiny_outputs: Literal[3]
    all_owned_pids_and_groups_absent: Literal[True]
    shared_locks_absent: Literal[True]
    source_input_client_closure: Literal[True]
    full_raw_retention_verified: Literal[True]
    errors: list[str]


def obj(value: pyd.JsonValue) -> dict[str, pyd.JsonValue]:
    return OBJECT.validate_python(value, strict=True)


def array(value: pyd.JsonValue) -> list[pyd.JsonValue]:
    return ARRAY.validate_python(value, strict=True)


def aware(stamp: str) -> None:
    offset = datetime.fromisoformat(stamp).utcoffset()
    require(offset is not None and offset.total_seconds() == 0, "aware UTC required")


def check(raw: bytes, identity: Identity) -> None:
    require(
        len(raw) == identity.bytes and hashlib.sha256(raw).hexdigest() == identity.sha256,
        "physical identity differs",
    )


def read(path: Path, identity: Identity, *, archive: bool = False) -> bytes:
    require(
        path.is_file()
        and not path.is_symlink()
        and path.stat().st_size == identity.bytes
        and identity.bytes <= (TOTAL if archive else LIMIT),
        "bounded regular evidence required",
    )
    raw = path.read_bytes()
    check(raw, identity)
    return raw


def git(worktree: Path, *args: str) -> bytes:
    return subprocess.run(["git", "-C", str(worktree), *args], check=True, capture_output=True, timeout=30).stdout


def revision(worktree: Path, commit: str, plan: Plan) -> None:
    require(
        git(worktree, "rev-parse", "HEAD").decode().strip() == commit
        and git(worktree, "rev-parse", "HEAD^{tree}").decode().strip() == plan.expected_tree
        and git(worktree, "rev-parse", "HEAD^").decode().strip() == plan.parent_commit,
        "revision differs",
    )
    branch = subprocess.run(
        ["git", "-C", str(worktree), "symbolic-ref", "-q", "HEAD"],
        check=False,
        capture_output=True,
        timeout=30,
    )
    require(
        branch.returncode == 1 and not git(worktree, "status", "--porcelain"),
        "clean detached HEAD required",
    )
    names = set(git(worktree, "diff-tree", "--no-commit-id", "--name-only", "-r", commit).decode().splitlines())
    require(
        names == set(plan.files)
        and "codex-to-codex.md" in names
        and all(name == "codex-to-codex.md" or name.startswith(ROOT) for name in names),
        "docs-only path scope",
    )
    for name in names:
        safe(name)
    require(
        {ROOT + "README.md", ROOT + "report.json", plan.archive, plan.archive_inventory} <= names,
        "report/evidence paths missing",
    )
    require(
        plan.archive.startswith(ROOT) and plan.archive.endswith(".tar.gz") and plan.archive_inventory.startswith(ROOT),
        "archive path scope",
    )
    git(worktree, "diff", "--check", plan.parent_commit, commit)


def members(raw: bytes, index: Index) -> dict[str, bytes]:
    require(
        index.count == len(index.files) == len(index.sources)
        and set(index.files) == set(index.sources)
        and index.total_bytes == sum(i.bytes for i in index.files.values()) <= TOTAL,
        "archive inventory cardinality",
    )
    for name, source in index.sources.items():
        metadata.admitted(source.path, name, source.kind, source.bytes)
        require(
            source.bytes == index.files[name].bytes and source.sha256 == index.files[name].sha256,
            "archive source identity differs",
        )
    return metadata.inventory(
        raw, {name: metadata.Identity.model_validate(i.model_dump()) for name, i in index.files.items()}
    )


def origin(pin: dict[str, pyd.JsonValue], index: Index, bodies: dict[str, bytes]) -> bytes:
    identity = Identity.model_validate({"bytes": pin["bytes"], "sha256": pin["sha256"]})
    matches = [
        name
        for name, item in index.sources.items()
        if str(item.path) == pin["path"] and item.bytes == identity.bytes and item.sha256 == identity.sha256
    ]
    require(bool(matches), "portable metadata origin missing: " + str(pin["path"]))
    return bodies[matches[0]]


def oracle(raw: dict[str, pyd.JsonValue], count: int, rows: int) -> None:
    require(
        raw["outcome"] == "passed_full_physical_wcc"
        and raw["errors"] == []
        and raw["own_identity_closure_passed"] is True
        and raw["full_output_oracle_passed"] is True
        and raw["identities_before"] == raw["identities_after"],
        "physical oracle did not close",
    )
    reference = obj(raw["reference"])
    require(
        reference["rows"] == reference["unique_rows"] == rows
        and reference["full_original_domain_passed"] is True
        and reference["labels_in_original_domain"] is True,
        "full reference domain missing",
    )
    outputs = array(raw["outputs"])
    require(len(outputs) == count, "output count differs")
    for number, value in enumerate(outputs, 1):
        checked = obj(value)
        require(
            checked["number"] == number
            and checked["rows"] == checked["unique_rows"] == rows
            and checked["canonical_member_mismatches"] == 0
            and checked["full_original_domain_passed"] is True
            and checked["labels_in_original_domain"] is True
            and checked["full_partition_equivalence_passed"] is True
            and bool(checked["physical_schemas"]),
            "full partition verdict",
        )


def qualify(report: dict[str, pyd.JsonValue], index: Index, bodies: dict[str, bytes], plan: Plan) -> None:
    require(
        report["outcome"] == "passed_metadata_reports"
        and report["series_count"] == 8
        and report["qualified_output_count"] == 16
        and report["n_per_condition"] == 1
        and report["exclusive_sem_phases_unavailable"] is True
        and report["source_before"] == report["source_after"],
        "report qualification differs",
    )
    for field_name in ("source_before", "metadata_inputs"):
        for item in array(report[field_name]):
            origin(obj(item), index, bodies)
    origin(obj(report["configuration"]), index, bodies)
    seen: set[tuple[str, str, int]] = set()
    for pin in array(report["reports"]):
        benchmark = obj(JSON.validate_json(origin(obj(pin), index, bodies)))
        params, env = obj(benchmark["params"]), obj(benchmark["environment"])
        require(
            benchmark["algorithm"] == "wcc"
            and params["workers"] == params["concurrency"] == 16
            and params["order"] == "asStaged"
            and env["extension_source"] == SOURCE
            and env["native_runtime_source"] == RUNTIME,
            "algorithm/source/worker contract",
        )
        build_wheel = obj(obj(JSON.validate_json(bodies[plan.proofs["build"]]))["wheel"])
        require(env["wheel"] == build_wheel, "reported wheel differs from actual build")
        calls = params["calls"]
        require(type(calls) is int and calls in (1, 3), "call count")
        assert isinstance(calls, int)
        key = (str(benchmark["dataset"]), str(params["ids"]), calls)
        require(key not in seen, "duplicate condition")
        seen.add(key)
        runs = array(benchmark["runs"])
        require(
            len(runs) == 1 and obj(runs[0])["returncode"] == 0,
            "single completed observation",
        )
        phases = obj(obj(obj(runs[0])["worker"])["phases_s"])
        require(
            all(
                phases[k] is None
                for k in (
                    "read_parquet_s",
                    "csr_and_graph_s",
                    "algorithm_s",
                    "write_parquet_s",
                )
            ),
            "exclusive phases must be null",
        )
        for stat in obj(benchmark["stats"]).values():
            require(
                obj(stat)["n"] == 1 and obj(stat)["std"] is None,
                "no statistical dispersion",
            )
        physical = obj(obj(benchmark["raw_series"])["physical_oracle"])
        vertices = 3_774_768 if key[0] == "cit-Patents" else 8_870_942
        oracle(physical, calls, vertices)
    require(
        seen == {(d, ids, n) for d in ("cit-Patents", "graph500-24") for ids in ("string", "int64") for n in (1, 3)},
        "eight exact conditions required",
    )
    require(
        {
            "build",
            "build_wait",
            "tiny_oracle",
            "root_audit",
            "failed_smoke",
            "failed_smoke_closure",
            "v1_campaign_source",
        }
        <= set(plan.proofs),
        "producer/history aliases missing",
    )
    proof = {
        role: obj(JSON.validate_json(bodies[name]))
        for role, name in plan.proofs.items()
        if role != "v1_campaign_source"
    }
    metadata.closed_build(proof["build"], proof["build_wait"], bodies[plan.proofs["build"]], SOURCE)
    oracle(proof["tiny_oracle"], 3, 4)
    require(not RootAudit.model_validate(proof["root_audit"]).errors, "root audit errors")
    aware(str(proof["root_audit"]["observed_utc"]))
    require(
        proof["failed_smoke"].get("outcome") not in ("completed_unvalidated_campaign", "passed"),
        "failed history relabelled",
    )


def validate(worktree: Path, commit: str, plan: Plan) -> None:
    revision(worktree, commit, plan)
    data = {
        name: read(worktree / name, identity, archive=name == plan.archive) for name, identity in plan.files.items()
    }
    index = Index.model_validate_json(data[plan.archive_inventory])
    check(data[plan.archive], index.archive)
    bodies = members(data[plan.archive], index)
    require(set(plan.required_members) <= set(bodies), "required original evidence missing")
    require(
        all(name in bodies for name in plan.proofs.values()),
        "proof archive alias missing",
    )
    qualify(obj(JSON.validate_json(data[ROOT + "report.json"])), index, bodies, plan)
    previous = git(worktree, "show", plan.parent_commit + ":codex-to-codex.md")
    require(data["codex-to-codex.md"].startswith(previous), "coordination prefix changed")
    append = data["codex-to-codex.md"][len(previous) :].decode()
    require(
        append.count("\n## ") == 1
        and re.search(r"(?:F2a\s+DONE|DONE\s+F2a)", append) is not None
        and "F2a/Native024/README.md" in append,
        "one scoped DONE append required",
    )
    stamp = re.search(r"## ([^ ]+) —", append)
    require(stamp is not None, "append timestamp")
    assert stamp is not None
    aware(stamp.group(1))
    for name, raw in data.items():
        if name != plan.archive:
            require(
                not re.search(rb"^(<<<<<<<|=======|>>>>>>>)( |$)", raw, re.MULTILINE),
                "conflict marker",
            )
    text = data[ROOT + "README.md"].decode()
    require(
        all(term in text.lower() for term in ("shared", "n=1", "null", "sampled")),
        "report scope prose missing",
    )
    for target in re.findall(r"\]\(([^)]+)\)", text):
        if not target.startswith(("http:", "https:")):
            require(
                not target.startswith("/") and (worktree / ROOT / target.split("#", 1)[0]).resolve().is_file(),
                "report link missing",
            )
    revision(worktree, commit, plan)
    print("F2A_NATIVE024_DOCUMENTATION PASSED " + commit)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--expected-commit", required=True)
    parser.add_argument("--plan", type=Path, required=True)
    args = parser.parse_args()
    validate(
        args.worktree,
        args.expected_commit,
        Plan.model_validate_json(args.plan.read_bytes()),
    )


if __name__ == "__main__":
    main()
