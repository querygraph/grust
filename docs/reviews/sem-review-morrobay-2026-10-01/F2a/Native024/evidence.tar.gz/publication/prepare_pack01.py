"""Seal an explicit pruned list of already closed small F2a evidence."""

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import cast

import pack_metadata as pack
import pydantic as pyd

BASE = Path("/Volumes/Apo/graph-tests/results/sem-review-20261001")
PUB = BASE / "F2a-native-024-publication01"
RUN = BASE / "F2a-native-024-run01"
BUILD = BASE / "F2a-native-int64-build01"
SKIP = {
    ".git",
    ".mypy_cache",
    ".ruff_cache",
    "__pycache__",
    "target",
    "venv",
    ".venv",
    "tmp",
    "wheels",
    "uv-cache",
    "cargo-cache",
    "cache",
    "raw",
    "tiny-reference01",
    "packed01",
}
JSON = pyd.TypeAdapter(dict[str, pyd.JsonValue])


def load(path: Path) -> dict[str, pyd.JsonValue]:
    pack.require(path.is_file() and not path.is_symlink() and path.stat().st_size <= pack.LIMIT, "small JSON")
    return JSON.validate_json(path.read_bytes())


def pin(path: Path) -> dict[str, pyd.JsonValue]:
    pack.require(path.is_file() and not path.is_symlink() and path.stat().st_size <= pack.LIMIT, "small regular pin")
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    pack.require(
        (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
        == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
        "metadata changed",
    )
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def write(path: Path, value: pyd.JsonValue) -> None:
    pack.require(not path.exists(), "fresh metadata only")
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def main() -> None:
    pack.require(
        pin(PUB / "pack_metadata.py")["sha256"] == "04f143f2cdf9d1140545926f200b44adfdaff77aa20d443a9be82f09b20ced19",
        "frozen packer",
    )
    report = load(RUN / "reports01/report.json")
    audit = load(RUN / "root-audit02/receipt.json")
    pack.require(audit["outcome"] == "passed_independent_F2a_native024_audit" and audit["errors"] == [], "final audit")
    members: dict[str, pack.Member] = {}
    skipped: list[str] = []

    def add(path: Path, name: str, kind: str = "metadata", expected: dict[str, pyd.JsonValue] | None = None) -> None:
        pack.admitted(path, name, kind, path.lstat().st_size)
        identity = pin(path)
        if expected is not None:
            pack.require(identity == {k: expected[k] for k in ("path", "bytes", "sha256")}, "sealed source differs")
        item = pack.Member.model_validate({**identity, "kind": kind})
        pack.require(name not in members, "duplicate alias")
        members[name] = item

    roots = {
        "build": BUILD,
        "run": RUN,
        "smoke-failed01": BASE / "F2a-native-024-smoke-campaign01",
        "smoke02": BASE / "F2a-native-024-smoke-campaign02",
        "main02": BASE / "F2a-native-024-main-campaign02",
        "publication": PUB,
    }
    for prefix, root in roots.items():
        for directory, names, files in os.walk(root, followlinks=False):
            current = Path(directory)
            names[:] = sorted(n for n in names if n not in SKIP and not (current / n).is_symlink())
            for filename in sorted(files):
                path = current / filename
                name = prefix + "/" + path.relative_to(root).as_posix()
                if path.suffix in pack.SUFFIXES or path.name in pack.SPECIAL:
                    add(path, name)
                elif path.name.endswith(".tar.gz") and "source" in path.name:
                    add(path, name, "source_archive")
                else:
                    skipped.append(str(path))

    for field in ("source_before", "metadata_inputs", "reports"):
        for value in cast(list[dict[str, pyd.JsonValue]], report[field]):
            path = Path(str(value["path"]))
            matches = [m for m in members.values() if m.path == path]
            pack.require(bool(matches), "report origin not collected: " + str(path))
            pack.require(pin(path) == value, "report origin changed")
    configuration = cast(dict[str, pyd.JsonValue], report["configuration"])
    pack.require(pin(Path(str(configuration["path"]))) == configuration, "report configuration changed")
    pack.require(any(str(m.path) == configuration["path"] for m in members.values()), "report config origin")

    build_plan = load(BUILD / "plan.json")
    source_files = cast(dict[str, dict[str, pyd.JsonValue]], build_plan["source_files"])
    for relative, identity in source_files.items():
        path = Path(str(build_plan["repo"])) / relative
        add(path, "source4b/" + relative, expected={"path": str(path), **identity})
    reference_receipt = BASE / "A5-native-fable-exact-post-result01/receipt.json"
    add(reference_receipt, "reference/a5-full-physical-receipt.json")
    add(BASE / "native-optimized-build01/receipt.json", "reference/native-sail-build-receipt.json")

    tiny_plan = load(RUN / "oracle-tiny-int64-c3-plan01.json")
    tiny_inputs = load(RUN / "input-admission01.json")
    for value in cast(list[dict[str, pyd.JsonValue]], tiny_inputs["pins"]):
        path = Path(str(value["path"]))
        if path.parent.name == "F2a-native-024-smoke01-inputs":
            add(path, "tiny/inputs/" + path.name, "tiny", value)
    tiny_reference = cast(dict[str, pyd.JsonValue], tiny_plan["reference"])
    for relative, identity in cast(dict[str, dict[str, pyd.JsonValue]], tiny_reference["files"]).items():
        path = Path(str(tiny_reference["directory"])) / relative
        add(path, "tiny/reference/" + relative, "tiny", {"path": str(path), **identity})
    raw_inventory = load(Path(str(cast(dict[str, pyd.JsonValue], audit["raw_inventory"])["path"])))
    directories = cast(dict[str, str], raw_inventory["directories"])
    for value in cast(list[dict[str, pyd.JsonValue]], tiny_plan["outputs"]):
        original = Path(str(value["directory"]))
        retained_root = next(
            (
                Path(d) / original.relative_to(Path(s))
                for s, d in directories.items()
                if original.is_relative_to(Path(s))
            ),
            None,
        )
        pack.require(retained_root is not None, "tiny retained directory missing")
        assert retained_root is not None
        for relative, identity in cast(dict[str, dict[str, pyd.JsonValue]], value["files"]).items():
            path = retained_root / relative
            add(
                path,
                "tiny/output-call" + str(value["number"]) + "/" + relative,
                "tiny",
                {"path": str(path), **identity},
            )

    proofs = {
        "build": "build/receipt.json",
        "build_wait": "build/launch-receipt.json",
        "tiny_oracle": "run/oracle-tiny-int64-c3-01/receipt.json",
        "root_audit": "run/root-audit02/receipt.json",
        "failed_smoke": "smoke-failed01/receipt.json",
        "failed_smoke_closure": "smoke-failed01/manual-closure01.json",
        "v1_campaign_source": "run/frozen-campaign-v1/f2a_campaign.py",
    }
    pack.require(set(proofs.values()) <= set(members), "producer/history role aliases")
    references = {
        d: load(RUN / ("oracle-" + d + "-int64-c1-plan01.json"))["reference"] for d in ("cit-Patents", "graph500-24")
    }
    catalog: dict[str, pyd.JsonValue] = {
        "format": "F2a Native024 input/evidence catalog v1",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "sources": load(RUN / "source-host-admission01.json"),
        "source_files": cast(pyd.JsonValue, source_files),
        "original_inputs": tiny_inputs["pins"],
        "native_binary": load(RUN / "main-campaign-plan02.json")["binary"],
        "wheel": audit["wheel"],
        "client_admission": pin(RUN / "client-admission01.json"),
        "full_reference_producer": pin(reference_receipt),
        "full_wcc_references": cast(pyd.JsonValue, references),
        "raw_inventory": audit["raw_inventory"],
        "final_audit": pin(RUN / "root-audit02/receipt.json"),
        "proof_aliases": cast(pyd.JsonValue, proofs),
        "physical_output_schema": [{"name": "id", "arrow_type": "int64"}, {"name": "component", "arrow_type": "int64"}],
        "adapter": "Timed server select casts native UTF8 decimal nodeId/componentId to signed long id/component before Parquet export. Full oracle validates actual Int64 files; labels normalized by minimum original member solely outside timing.",
        "scope": "Native shared host, one observed series per condition; exclusive Sem phases null. Software pools/threads and sampled RSS do not establish a 32-GiB OS limit or peak fit. Main input/binary/wheel/raw Parquet payloads are pinned, not embedded. Tiny signed/isolate Parquet files are explicitly embedded.",
    }
    write(PUB / "INPUTS.json", catalog)
    add(PUB / "INPUTS.json", "publication/INPUTS.json")
    write(PUB / "gate-proof-aliases01.json", cast(pyd.JsonValue, proofs))
    write(PUB / "required-members01.json", cast(pyd.JsonValue, sorted(members)))
    write(
        PUB / "pack-discovery01.json",
        {
            "observed_utc": datetime.now(timezone.utc).isoformat(),
            "roots": {k: str(v) for k, v in roots.items()},
            "pruned_names": cast(pyd.JsonValue, sorted(SKIP)),
            "skipped_regular_files": cast(pyd.JsonValue, skipped),
            "count": len(members),
            "total_bytes": sum(m.bytes for m in members.values()),
        },
    )
    plan = pack.Config(output=PUB / "packed01", members=members)
    write(PUB / "pack-plan01.json", plan.model_dump(mode="json"))
    print(
        json.dumps(
            {
                "count": len(members),
                "total_bytes": sum(m.bytes for m in members.values()),
                "plan": pin(PUB / "pack-plan01.json"),
            }
        )
    )


if __name__ == "__main__":
    main()
