# F2a publication helpers: source-only

Root owns actual packing, candidate creation, conditional commit, committed
detached gate and normal atomic push. These helpers execute no benchmark,
container, VM, process probe, native import, original data scan or Git mutation.
No synthetic tests were added; Ruff, strict mypy and format check pass.

## Packer

`pack_metadata.py --config /absolute/config.json`

Configuration: `{output: fresh_absolute_directory, members: {safe_relative_name:
{path: absolute_file, bytes: actual_size, sha256: actual_SHA, kind: metadata}}}`.
`kind` defaults to `metadata`; alternatives are `tiny` (only <=1MiB Parquet under
`tiny/`) and `source_archive` (bounded named source-only tar.gz, whose expanded
members are checked). Maximum leaf32MiB, total512MiB, 5000 explicitly listed
members. No directory walk. Binary/wheel/non-tiny Parquet are refused before
open, including renamed aliases. Source tar members must be regular safe named
source/metadata. Cache/target/venv archive namespaces are refused.

Actual outputs are `evidence.tar.gz`, `inventory.json`, `receipt.json`.
Inventory contains `observed_utc,files,sources,count,total_bytes,archive`.
`files` maps relative members to bytes/SHA; `sources` maps the same members to
original absolute path/bytes/SHA/kind, providing portable origin aliases.
USTAR uses exact original bytes. Every physical member is verified, all originals
are rechecked, and failures keep incomplete archive/receipt without overwrite.
Root copies `inventory.json` byte-exact to final `archive-verification.json`.
Source/binary/wheel/original-Parquet inventory pins remain metadata; their actual
large payloads are not embedded. Failed smoke01, manual closure and frozen
campaign v1 must be explicit members alongside the successful smoke/main/build.

## Detached documentation gate

The gate imports its sibling `pack_metadata.py`. Use the existing isolated
bootstrap recipe that inserts this exact helper directory, then runpy runs
`gate.py` with `--worktree --expected-commit --plan`; direct `python -I gate.py`
excludes the sibling path. Both helper hashes belong in root launch provenance.

Plan JSON:

- `parent_commit`, `expected_tree`: exact Git identities.
- `files`: every changed repo-relative path -> `{bytes,sha256}`. Only final
  `docs/reviews/sem-review-morrobay-2026-10-01/F2a/Native024/` and append-only
  `codex-to-codex.md` are allowed. README/report/archive/inventory are mandatory.
- `archive`: repo-relative evidence.tar.gz; `archive_inventory`: repo-relative
  archive-verification.json (actual packer inventory bytes).
- `proofs`: roles -> archived relative member. Required roles are `build`,
  `build_wait`, `tiny_oracle`, `root_audit`, `failed_smoke`,
  `failed_smoke_closure`, `v1_campaign_source`. The v1 source role is a raw source
  file; other roles contain JSON. Keep exactly these roles unless additional
  JSON proof roles are desired.
- `required_members`: all explicitly required original sources/logs/JSON,
  including failed smoke/closure/v1 sources and exact producer/report inputs.

Published report.json is unchanged ReportReceipt from reports01: eight series,
16 main full outputs, n1, unavailable exclusive phases, before==after sources,
all original metadata and eight benchmark pins resolved via inventory origins.
The gate verifies each full benchmark oracle, exact dataset/ID/call matrix,
source4b88/runtime9f, workers/concurrency16, all four exclusive phase fields null
and n1/stdnull; actual wheel matches closed waited build. Tiny3 is checked
separately at four vertices. Root independent audit requires exact agreed outcome,
counts8/16/3, process/lock/source/client/full-retention positives and errors[].
Original failed smoke is preserved without relabelling success. The gate
requires one F2a DONE append, expected README path, aware UTC and unchanged
parent log; README needs shared/n=1/null/sampled scopes and valid relative links.

The exact clean detached HEAD/tree/parent/path set and whitespace are checked
before/after. Gate verdict: `F2A_NATIVE024_DOCUMENTATION PASSED <exact SHA>`.
Root runs candidate gate && commit, then gates the actual committed detached
revision before normal atomic push. No source identity or timing is changed.
