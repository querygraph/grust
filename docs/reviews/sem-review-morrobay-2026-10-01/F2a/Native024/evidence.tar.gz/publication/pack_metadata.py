"""Explicit small F2a evidence allowlist; no directory recursion or native payload."""

import argparse
import hashlib
import io
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Literal

import pydantic as pyd

LIMIT = 32 * 1024**2
TOTAL = 512 * 1024**2
SUFFIXES = {
    ".py",
    ".rs",
    ".sh",
    ".md",
    ".json",
    ".jsonl",
    ".log",
    ".txt",
    ".toml",
    ".lock",
    ".csv",
    ".tsv",
    ".yml",
    ".yaml",
    ".ini",
    ".cfg",
    ".patch",
    ".diff",
}
SPECIAL = {"Dockerfile", "LICENSE", "NOTICE", ".gitignore", ".gitattributes"}


class Record(pyd.BaseModel):
    model_config = pyd.ConfigDict(extra="forbid")


class Identity(Record):
    bytes: int = pyd.Field(ge=0, le=LIMIT)
    sha256: str = pyd.Field(pattern=r"^[0-9a-f]{64}$")


class Member(Identity):
    path: Path
    kind: Literal["metadata", "tiny", "source_archive"] = "metadata"


class Config(Record):
    output: Path
    members: dict[str, Member]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe(name: str) -> None:
    path = PurePosixPath(name)
    require(
        not path.is_absolute()
        and path.as_posix() == name
        and bool(path.parts)
        and not any(p in (".", "..") for p in path.parts)
        and "\\" not in name,
        "unsafe relative archive name",
    )
    require(
        not any(p in {"target", "cache", "venv", ".venv", "cargo-cache", "uv-cache"} for p in path.parts),
        "cache/target/venv archive namespace refused",
    )


def admitted(path: Path, name: str, kind: str, size: int) -> None:
    safe(name)
    if kind == "tiny":
        require(
            name.startswith("tiny/") and path.suffix == ".parquet" and name.endswith(".parquet") and size <= 1024**2,
            "only explicit small tiny Parquet",
        )
    elif kind == "source_archive":
        require(
            path.name.endswith(".tar.gz")
            and name.endswith(".tar.gz")
            and "source" in path.name
            and "source" in PurePosixPath(name).name,
            "only named bounded source archives",
        )
    else:
        require(
            (path.suffix in SUFFIXES or path.name in SPECIAL)
            and (PurePosixPath(name).suffix in SUFFIXES or PurePosixPath(name).name in SPECIAL),
            "binary/wheel/raw Parquet archive member refused before open",
        )


def digest(raw: bytes) -> Identity:
    return Identity(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def original(item: Member, name: str) -> bytes:
    require(
        item.path.is_absolute() and item.path.is_file() and not item.path.is_symlink(),
        "regular absolute sealed file required",
    )
    admitted(item.path, name, item.kind, item.bytes)
    before = item.path.stat()
    require(
        before.st_size == item.bytes and before.st_size <= LIMIT,
        "sealed small size differs",
    )
    raw = item.path.read_bytes()
    after = item.path.stat()
    require(
        (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
        == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
        "source changed while read",
    )
    require(
        digest(raw) == Identity(bytes=item.bytes, sha256=item.sha256),
        "source pin differs",
    )
    if item.kind == "source_archive":
        validate_source(raw)
    return raw


def validate_source(raw: bytes) -> None:
    seen: set[str] = set()
    expanded = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        for member in archive:
            safe(member.name)
            require(
                member.isreg() and member.name not in seen and member.size <= LIMIT,
                "unsafe source archive member",
            )
            require(
                not member.pax_headers or set(member.pax_headers) <= {"mtime"},
                "source PAX scope",
            )
            if member.pax_headers:
                float(member.pax_headers["mtime"])
            admitted(Path(member.name), member.name, "metadata", member.size)
            seen.add(member.name)
            expanded += member.size
            require(
                expanded <= TOTAL and len(seen) <= 5000,
                "bounded source archive inventory",
            )
            stream = archive.extractfile(member)
            require(stream is not None, "source archive body absent")
            assert stream is not None
            require(len(stream.read(LIMIT + 1)) == member.size, "source archive body length")
    require(bool(seen), "empty source archive")


def inventory(path: Path | bytes, expected: dict[str, Identity]) -> dict[str, bytes]:
    seen: set[str] = set()
    bodies: dict[str, bytes] = {}
    expanded = 0
    with tarfile.open(
        name=path if isinstance(path, Path) else None,
        fileobj=io.BytesIO(path) if isinstance(path, bytes) else None,
        mode="r:gz",
    ) as archive:
        for member in archive:
            safe(member.name)
            require(
                member.isreg()
                and not member.pax_headers
                and member.name not in seen
                and member.name in expected
                and member.size <= LIMIT,
                "unsafe/unexpected physical member",
            )
            stream = archive.extractfile(member)
            require(stream is not None, "archive body absent")
            assert stream is not None
            raw = stream.read(LIMIT + 1)
            require(
                len(raw) == member.size and digest(raw) == expected[member.name],
                "archive body differs",
            )
            seen.add(member.name)
            bodies[member.name] = raw
            expanded += member.size
            require(expanded <= TOTAL, "archive expansion limit")
    require(seen == set(expected), "archive members missing")
    return bodies


def pack(configuration: Path) -> None:
    require(
        configuration.is_file() and not configuration.is_symlink() and configuration.stat().st_size <= LIMIT,
        "small config required",
    )
    config_raw = configuration.read_bytes()
    config = Config.model_validate_json(config_raw)
    require(
        config.output.is_absolute() and 0 < len(config.members) <= 5000,
        "output/member admission",
    )
    require(
        sum(m.bytes for m in config.members.values()) <= TOTAL,
        "total metadata admission",
    )
    for name, item in config.members.items():
        safe(name)
        require(
            not item.path.resolve().is_relative_to(config.output.resolve()),
            "archive output contains source",
        )
        admitted(item.path, name, item.kind, item.bytes)
    config.output.mkdir(parents=True, exist_ok=False)
    receipt: dict[str, pyd.JsonValue] = {
        "observed_utc": utc(),
        "outcome": "packing",
        "errors": [],
    }
    destination = config.output / "receipt.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    expected = {name: Identity(bytes=item.bytes, sha256=item.sha256) for name, item in config.members.items()}
    target = config.output / "evidence.tar.gz"
    try:
        with tarfile.open(target, "w:gz", format=tarfile.USTAR_FORMAT) as archive:
            for name, item in sorted(config.members.items()):
                raw = original(item, name)
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
        inventory(target, expected)
        for name, item in config.members.items():
            original(item, name)
        require(configuration.read_bytes() == config_raw, "packer config changed")
        require(target.stat().st_size <= TOTAL, "compressed metadata archive limit")
        archive_identity: dict[str, pyd.JsonValue] = {
            "bytes": target.stat().st_size,
            "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        }
        index = {
            "observed_utc": utc(),
            "files": {name: item.model_dump() for name, item in expected.items()},
            "sources": {name: item.model_dump(mode="json") for name, item in config.members.items()},
            "count": len(expected),
            "total_bytes": sum(m.bytes for m in expected.values()),
            "archive": archive_identity,
        }
        (config.output / "inventory.json").write_text(json.dumps(index, indent=2) + "\n")
        receipt.update(
            outcome="passed_exact_small_evidence_archive",
            archive_verified=True,
            originals_before_after_equal=True,
            configuration_sha256=digest(config_raw).sha256,
            archive=archive_identity,
        )
    except Exception as error:
        receipt.update(outcome="error", errors=[type(error).__name__ + ": " + str(error)])
        raise
    finally:
        receipt["finished_utc"] = utc()
        destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print("F2A_SMALL_EVIDENCE_ARCHIVE PASSED " + str(target))


def object_value(value: pyd.JsonValue) -> dict[str, pyd.JsonValue]:
    return pyd.TypeAdapter(dict[str, pyd.JsonValue]).validate_python(value, strict=True)


def closed_build(
    build: dict[str, pyd.JsonValue], waited: dict[str, pyd.JsonValue], build_raw: bytes, expected_source: str
) -> dict[str, pyd.JsonValue]:
    require(
        build["outcome"] == "passed_release_native_wheel_build"
        and build["errors"] == []
        and build["immutable_pins_before_after_equal"] is True
        and build["all_owned_groups_absent"] is True
        and build["locks_released"] is True
        and build["source_before"] == build["source_after"],
        "closed release build",
    )
    require(
        waited["outcome"] == "passed_waited_native_wheel_build"
        and waited["returncode"] == 0
        and waited["wait_completed"] is True
        and waited["owner_group_absent"] is True
        and waited["errors"] == []
        and object_value(waited["owner_receipt"])["sha256"] == hashlib.sha256(build_raw).hexdigest(),
        "actual waited build",
    )
    for step in pyd.TypeAdapter(list[pyd.JsonValue]).validate_python(build["steps"], strict=True):
        item = object_value(step)
        require(
            item["returncode"] == 0
            and item["wait_completed"] is True
            and item["forced_cleanup"] is False
            and item["remaining_owned_pids"] == [],
            "build step closure",
        )
    wheel = object_value(build["wheel"])
    require(isinstance(wheel["bytes"], int) and wheel["bytes"] > 0, "actual wheel identity")
    source = object_value(build["source_before"])
    require(
        source["commit"] == expected_source and source["status"] == "" and source["detached"] is True,
        "exact clean detached extension source required",
    )
    return wheel


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    pack(parser.parse_args().config.resolve())


if __name__ == "__main__":
    main()
