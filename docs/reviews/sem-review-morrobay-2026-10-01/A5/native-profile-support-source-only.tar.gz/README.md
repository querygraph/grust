# Native A5 WCC profiling support

Frozen source preparation only. No build, server, benchmark, full payload read or oracle execution was performed by this agent. Root owns native release-build/source/input admission, launch, process closure and the external oracle.

The child profiles exact Pecan `9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3`, randomized WCC, seed42, canonical labels, max100 rounds,16 partitions, owned input snapshots on, checkpoint repartitioning on, plan capture off. It uses copied `runtime.py` and `measurement.py` source from frozen harness `6ae2e43a903c2cee02da170465c922c72b76198e`; the child records the two source roles separately. The native compiled binary is root's pending optimized9f0 build.

## Root launch recipe

`native-cell-config.json` gives concrete proposed paths. Admit the built binary and clean exact controller; create a fresh CPython3.12.6 native client with PySpark[connect]4.0.1, protobuf7.36.1..<8, Pydantic2.11..<3, NumPy/PyArrow for the separate oracle; verify zero installed `pysail.extensions` entry points. The exact9f0 Rust discovery loops over those entries and loads factories only inside the loop. No Nutmeg/Sedona wheels or native-package identity guard are needed for this builtin Pecan SQL/GraphUtils cell. Record actual distribution versions and binary/helper/controller/input hashes before and after. Relocate exact original vertices/edges/WCC-reference bytes without rewriting the retained A2 receipt.

Once these root prerequisites pass, launch the child in an owned process group with the same3.12.6 client Python and the environment below (root records actual argv/env/UTC/PID and complete process launch-to-exit time):

```sh
PYTHONDONTWRITEBYTECODE=1 SPARK_CONNECT_MODE_ENABLED=1 PYTHONPATH=/tmp/sem-a5-native-profile01/support:/tmp/sem-a5-native-profile01/frozen-harness/examples/extensions/benchmarks:/Volumes/Apo/graph-tests/workspaces/sem-review-20261001/a5-native-9f0aa7d2a/examples/extensions/graph-algorithms/src /Volumes/Apo/graph-tests/results/sem-review-20261001/native-client-venv/bin/python -B /tmp/sem-a5-native-profile01/support/engine_pecan.py --config /tmp/sem-a5-native-profile01/native-cell-config.json
```

The fresh native client path is proposed and requires root admission. Root may create a NEW config for its final admitted paths and retain this original unchanged. No Linux A2 supervisor is part of this command. Frozen `runtime.server` owns the Sail group and records cleanup errors; root independently verifies process closure and output before declaring success.

## External result oracle

After the engine exits and root closure checks pass, use unchanged `output_oracle.load_wcc_reference(wcc_pairs_path, "b07f8665c87f94286da7beb1ac5a9d13c4932fea31d8f1a382f9ecb1d3c0c8dc", rows=3774768, maximum=6009554)` then `output_oracle.verify_wcc_output(cell_output / "result", reference)`. Preserve its model as a separate correctness receipt. This checks every raw BIGINT id/component, exact canonical minimum ID, full coverage and physical schemas. The reference loader receives the explicitly relocated native path; original receipt guest paths remain unchanged. No new graph validation or reference construction runs inside the child.

## Timing and scope

Fable's write/remove/touch/count wrappers delegate once, preserve original results/errors and restore method objects on success/failure. Write denotes `StagingRun.materialize`, which includes staging touch in this pinned source; it is not an exclusive physical write phase. Every raw call retains round0, positive current iteration or negative completed iteration, elapsed time and outcome. Nested samples overlap; do not sum them into exclusive phases. The observer retains edge counts and raw round events.

The diagnostic includes an extra distinct-component count used by Fable, separately named `profile_component_count`, then the complete raw result export and cleanup. Profiling and retained journal overhead are inside root launch-to-exit. These are one-cell diagnostic observations, not an absolute performance result or a paired comparison to historical Linux A2. Snapshot timing delegates current9f0 `_snapshot` once, including all new keyword arguments.

Native macOS has no Linux cgroup, sampled PSS or guest-steal observation here. Those receipt fields are null. Software configuration retains threads16/partitions16/greedy pool30GiB/configured native quota256MiB; it does not establish a container16CPU32GiB/noSwap envelope or actual native reservation/prepayment. All algorithm/pool parameters stay unchanged from this declared diagnostic.

## Offline controls

Ruff, strict mypy and8 tiny controls passed; exact source hashes/commands/logs are in `offline-controls.json`. Mypy ignores unavailable external-module imports explicitly; the5 owned support files are checked, while unchanged frozen untyped runtime/measurement sources are hash-pinned. No installed PySpark/controller/native import or runtime behavior is qualified by these controls. The independent source review found no concrete blocker after clarifying compiled-runtime versus harness pins. The earlier Linux preparation remains preserved at `/tmp/sem-a5-profile01` and is unexecuted.
