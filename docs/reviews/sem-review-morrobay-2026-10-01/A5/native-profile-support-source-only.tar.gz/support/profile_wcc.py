"""Fable's four method timers with typed retained calls and owned patch lifetime.

Each wrapper delegates once and preserves its result or exception. Durations
may overlap across nested staging calls; sums are diagnostics, not exclusive phases.
The clock brackets delegation and excludes the append that retains the sample.
"""
from __future__ import annotations

import contextlib
import time
from collections.abc import Callable, Iterator
from typing import Any, Concatenate, Literal, ParamSpec, Protocol, TypeVar, cast

from pydantic import BaseModel, ConfigDict, Field

Kind = Literal["write", "remove", "touch", "count"]
P = ParamSpec("P")
R = TypeVar("R")


class Event(Protocol):
    @property
    def kind(self) -> str: ...

    @property
    def iteration(self) -> int: ...

    @property
    def edges_before(self) -> int | None: ...

    @property
    def edges_after(self) -> int | None: ...


class Call(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    sequence: int
    round: int
    kind: Kind
    seconds: float = Field(ge=0)
    outcome: Literal["returned", "raised"]
    error_type: str | None


class EdgeCounts(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    iteration: int
    before: int | None
    after: int | None


class ProfileReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    snapshot_inputs: Literal[True] = True
    partitions: Literal[16] = 16
    seed: Literal[42] = 42
    canonical_labels: Literal[True] = True
    record_plans: Literal[False] = False
    calls: list[Call] = Field(default_factory=list)
    edges_by_round: list[EdgeCounts] = Field(default_factory=list)
    patches_restored: bool = False
    component_count: int | None = None
    scope: str = (
        "Each write/remove/touch/count invocation during the owned engine execution; "
        "round 0 precedes iteration 1, negative round follows that iteration end. "
        "Nested durations can overlap; materialize includes staging touch in the pinned source. Public-call, component-count, "
        "export and teardown boundaries remain separate engine phases. This adds Fable's "
        "explicit component distinct count plus profiling overhead to original A2 launch-to-exit."
    )


class Profile:
    def __init__(self, clock: Callable[[], float] = time.perf_counter) -> None:
        self.receipt = ProfileReceipt()
        self.round = 0
        self.clock = clock

    def observe(self, event: Event) -> None:
        if event.kind == "iteration_start":
            self.round = event.iteration
        elif event.kind == "iteration_end":
            self.round = -event.iteration
            self.receipt.edges_by_round.append(EdgeCounts(
                iteration=event.iteration, before=event.edges_before, after=event.edges_after))

    def timed(self, kind: Kind, original: Callable[Concatenate[Any, P], R]) -> Callable[Concatenate[Any, P], R]:
        def wrapper(owner: Any, /, *args: P.args, **kwargs: P.kwargs) -> R:
            began = self.clock()
            current_round = self.round
            outcome: Literal["returned", "raised"] = "returned"
            error_type: str | None = None
            try:
                return original(owner, *args, **kwargs)
            except BaseException as error:  # same original exception propagates.
                outcome, error_type = "raised", type(error).__name__
                raise
            finally:
                seconds = self.clock() - began
                self.receipt.calls.append(Call(sequence=len(self.receipt.calls) + 1,
                    round=current_round, kind=kind, seconds=seconds,
                    outcome=outcome, error_type=error_type))
        return wrapper


@contextlib.contextmanager
def instrument(profile: Profile, *, staging_class: type[Any],
               dataframe_class: type[Any]) -> Iterator[None]:
    originals: list[tuple[type[Any], str, Callable[..., Any]]] = []
    try:
        for cls, name, kind in ((staging_class, "materialize", "write"),
                                (staging_class, "remove", "remove"),
                                (staging_class, "touch", "touch"),
                                (dataframe_class, "count", "count")):
            original = cast(Callable[..., Any], getattr(cls, name))
            originals.append((cls, name, original))
            setattr(cls, name, profile.timed(cast(Kind, kind), original))
        yield
    finally:
        for cls, name, original in reversed(originals):
            setattr(cls, name, original)
        profile.receipt.patches_restored = len(originals) == 4
