"""Tiny delegation and restoration controls; no Spark, native library or server."""
from __future__ import annotations

import ast
import contextlib
import copy
import unittest
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import profile_wcc


class Clock:
    def __init__(self) -> None:
        self.value = 0.0

    def __call__(self) -> float:
        self.value += 1
        return self.value


class Frame:
    def __init__(self) -> None:
        self.calls = 0

    def count(self) -> int:
        self.calls += 1
        return 17


class Stage:
    def __init__(self) -> None:
        self.calls: list[tuple[str, object, bool]] = []

    def materialize(self, value: object, *, flag: bool) -> object:
        self.calls.append(("write", value, flag))
        return value

    def remove(self, value: object) -> None:
        self.calls.append(("remove", value, False))

    def touch(self, frame: Frame) -> int:
        self.calls.append(("touch", frame, False))
        return frame.count()


@dataclass
class Event:
    kind: str
    iteration: int
    edges_before: int | None = None
    edges_after: int | None = None


class Controls(unittest.TestCase):
    def test_each_method_delegates_once_and_preserves_arguments_result(self) -> None:
        profile = profile_wcc.Profile(Clock())
        stage, frame, value = Stage(), Frame(), object()
        with profile_wcc.instrument(profile, staging_class=Stage, dataframe_class=Frame):
            self.assertIs(stage.materialize(value, flag=True), value)
            stage.remove(value)
            self.assertEqual(stage.touch(frame), 17)
            self.assertEqual(frame.count(), 17)
        self.assertEqual(stage.calls, [("write", value, True), ("remove", value, False), ("touch", frame, False)])
        self.assertEqual(frame.calls, 2)
        self.assertEqual([r.kind for r in profile.receipt.calls], ["write", "remove", "count", "touch", "count"])
        self.assertTrue(profile.receipt.patches_restored)

    def test_same_exception_and_one_call_for_each_kind(self) -> None:
        for kind in ("write", "remove", "touch", "count"):
            error = ValueError("exact original exception")
            calls: list[tuple[object, tuple[object, ...], dict[str, object]]] = []

            def failing(saved_calls: list[tuple[object, tuple[object, ...], dict[str, object]]],
                        saved_error: Exception) -> Callable[..., None]:
                def fail(receiver: object, /, *args: object, **kwargs: object) -> None:
                    saved_calls.append((receiver, args, kwargs))
                    raise saved_error
                return fail

            profile = profile_wcc.Profile(Clock())
            owner = object()
            with self.subTest(kind=kind), self.assertRaises(ValueError) as caught:
                profile.timed(kind, failing(calls, error))(owner, 3, flag=True)
            self.assertIs(caught.exception, error)
            self.assertEqual(calls, [(owner, (3,), {"flag": True})])
            self.assertEqual(len(profile.receipt.calls), 1)
            self.assertEqual(profile.receipt.calls[0].outcome, "raised")
            self.assertEqual(profile.receipt.calls[0].error_type, "ValueError")

    def test_nested_touch_count_is_retained_as_overlap(self) -> None:
        profile = profile_wcc.Profile(Clock())
        with profile_wcc.instrument(profile, staging_class=Stage, dataframe_class=Frame):
            Stage().touch(Frame())
        count, touch = profile.receipt.calls
        self.assertEqual((count.kind, count.seconds), ("count", 1))
        self.assertEqual((touch.kind, touch.seconds), ("touch", 3))
        self.assertIn("overlap", profile.receipt.scope)

    def test_all_method_objects_restore_on_body_error(self) -> None:
        originals = (Stage.materialize, Stage.remove, Stage.touch, Frame.count)
        error = RuntimeError("same body error")
        profile = profile_wcc.Profile()
        with self.assertRaises(RuntimeError) as caught, profile_wcc.instrument(
                profile, staging_class=Stage, dataframe_class=Frame):
            raise error
        self.assertIs(caught.exception, error)
        self.assertEqual((Stage.materialize, Stage.remove, Stage.touch, Frame.count), originals)
        self.assertTrue(profile.receipt.patches_restored)

    def test_partial_patch_failure_restores_earlier_methods(self) -> None:
        class Incomplete:
            materialize = Stage.materialize
            remove = Stage.remove

        originals = (Incomplete.materialize, Incomplete.remove, Frame.count)
        profile = profile_wcc.Profile()
        with self.assertRaises(AttributeError), profile_wcc.instrument(
                profile, staging_class=Incomplete, dataframe_class=Frame):
            self.fail("body must not execute")
        self.assertEqual((Incomplete.materialize, Incomplete.remove, Frame.count), originals)
        self.assertFalse(profile.receipt.patches_restored)

    def test_round_and_tail_assignment_matches_fable(self) -> None:
        profile = profile_wcc.Profile(Clock())
        operation = profile.timed("count", Frame.count)
        operation(Frame())
        profile.observe(Event("iteration_start", 1))
        operation(Frame())
        profile.observe(Event("iteration_end", 1, 90, 20))
        operation(Frame())
        profile.observe(Event("iteration_start", 2))
        operation(Frame())
        self.assertEqual([r.round for r in profile.receipt.calls], [0, 1, -1, 2])
        self.assertEqual(profile.receipt.edges_by_round[0].model_dump(),
                         {"iteration": 1, "before": 90, "after": 20})

    def test_snapshot_hook_forwards_new_keywords_once_and_restores(self) -> None:
        source = Path(__file__).with_name("engine_pecan.py").read_text()
        node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == "snapshot_phase")
        calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
        result = (object(), object(), None)

        def snapshot(*args: object, **kwargs: object) -> tuple[object, object, None]:
            calls.append((args, kwargs))
            return result

        class Algorithms:
            _snapshot = staticmethod(snapshot)

        class Journal:
            def __init__(self) -> None:
                self.phases: list[str] = []

            @contextlib.contextmanager
            def phase(self, name: str) -> Iterator[None]:
                self.phases.append(name)
                yield

        namespace: dict[str, Any] = {"algorithms": Algorithms, "Journal": Journal,
            "StagingRun": object, "DataFrame": object, "Iterator": Iterator,
            "contextlib": contextlib, "cast": cast}
        code = ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(node)], type_ignores=[]))
        exec(compile(code, "<owned-A5-snapshot-hook>", "exec"), namespace)  # noqa: S102
        hook = cast(Callable[[Journal], contextlib.AbstractContextManager[None]], namespace["snapshot_phase"])
        run, vertices, edges = object(), object(), object()
        with hook(Journal()):
            self.assertIs(Algorithms._snapshot(run, vertices, edges, ("src", "dst"),
                vertex_columns=("id", "property"), count_vertices=False, snapshot=False), result)
        self.assertEqual(calls, [((run, vertices, edges, ("src", "dst")),
            {"vertex_columns": ("id", "property"), "count_vertices": False, "snapshot": False})])
        self.assertIs(Algorithms._snapshot, snapshot)

    def test_native_scope_has_no_linux_sampler_or_emulated_cgroup(self) -> None:
        source = Path(__file__).with_name("engine_pecan.py").read_text()
        self.assertNotIn("measurement.cgroup_snapshot", source)
        self.assertNotIn("measurement.cpu_ticks", source)
        self.assertNotIn("measurement.steal_fraction", source)
        self.assertIn('sys.platform != "darwin"', source)
        self.assertIn('snapshot_inputs=True', source)
        self.assertIn('canonical_labels=True', source)
        self.assertIn('profile_component_count', source)
        self.assertIn('frame.write.mode("error").parquet', source)


if __name__ == "__main__":
    unittest.main()
