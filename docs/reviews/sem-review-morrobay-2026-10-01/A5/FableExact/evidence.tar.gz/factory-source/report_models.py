"""Pinned small inputs; the final process observations belong to root."""

from pathlib import Path
from typing import Literal

import post_models as post
from pydantic import Field

POST_MODELS_SHA = "14b838c361059aae4d71eed8eb5ac783ea5870d7482798aa26a4d4acf82817e7"
POST_FREEZE_SHA = "7d980c8413cc080eb1e8c5c38b63c83e9af650bbd64a9cb7a16da93a322bbddd"


class State(post.Model):
    dataset: post.Dataset
    outcome: Literal["completed_script_pending_physical_audit"]
    parent_pid: post.Positive
    pgid: post.Positive
    returncode: Literal[0]
    started_utc: str
    closed_utc: str
    recipe: post.Pin
    closure: post.Pin
    records: post.Pin


class Queue(post.Model):
    started_utc: str
    owner_pid: post.Positive
    configuration: post.Pin
    outcome: Literal["completed_exact_Fable_scripts_pending_physical_audit"]
    finished_utc: str
    states: list[State]
    errors: list[str]
    traceback: str | None
    immutable_pins_before_after_equal: Literal[True]
    source_repositories_before_after_equal: Literal[True]
    all_owned_process_groups_absent: Literal[True]
    locks_released: Literal[True]
    forced_cancellation: Literal[False]
    scope: str


class RootAudit(post.Model):
    outcome: Literal["passed_independent_exact_Fable_native_closure_and_metadata_audit"]
    observed_utc: str
    queue_pin: post.Pin
    plan_pin: post.Pin
    post_audit_pin: post.Pin
    owner_pid: post.Positive
    owner_pid_absent: Literal[True]
    owned_parent_pids: list[int]
    owned_parent_pids_and_pgids_absent: Literal[True]
    owned_processes_remaining: list[int]
    matching_native_servers_remaining: list[int]
    shared_locks_absent: Literal[True]
    immutable_source_input_client_closure: Literal[True]
    source_pin: post.Pin
    all48_outputs_retained_and_qualified: Literal[True]
    primary_median_ratios: dict[str, float]


class Repository(post.Model):
    path: Path
    commit: str
    tree: str
    status: Literal[""]


class CampaignPlan(post.Model):
    root: Path
    source: post.Pin
    recipes: list[post.Pin]
    immutable_pins: list[post.Pin]
    repositories: list[Repository]
    locks: tuple[Path, Path]


class Launch(post.Model):
    observed_utc: str
    pid: post.Positive
    command: list[str]
    scope: str


class Configuration(post.Model):
    factory_freeze: post.Pin
    queue: post.Pin
    plan: post.Pin
    launch: post.Pin
    post_audit: post.Pin
    post_configuration: post.Pin
    root_audit: post.Pin
    post_models: post.Pin
    output: Path
    files: dict[str, post.Pin]
    max_file_bytes: int = Field(default=32 * 2**20, ge=1, le=32 * 2**20)
    max_total_bytes: int = Field(default=256 * 2**20, ge=1, le=256 * 2**20)
    max_members: int = Field(default=5000, ge=1, le=5000)


class FactoryFreeze(post.Model):
    observed_utc: str
    outcome: Literal["frozen_source_only_exact_Fable_report_factory"]
    production_helpers: dict[str, post.Identity]
    controls_passed: int
    source_gates: post.Pin
    engine_jobs_launched: Literal[False] = False
    native_import_probes: Literal[False] = False
    payload_reads: Literal[False] = False


class Generation(post.Model):
    observed_utc: str
    outcome: Literal["passed_metadata_only_exact_Fable_package"]
    configuration: post.Pin
    archive: post.Pin
    archive_members: dict[str, post.Identity]
    report: post.Pin
    readme: post.Pin
    evidence_origins: dict[str, str]
    native_payloads_read: Literal[False] = False
    process_probes_run: Literal[False] = False
