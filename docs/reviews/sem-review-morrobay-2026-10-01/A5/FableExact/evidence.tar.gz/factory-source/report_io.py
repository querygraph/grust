"""Bounded metadata/source reads; classify and refuse payloads before opening."""

import hashlib
import io
import stat
import tarfile
from pathlib import Path, PurePosixPath

import post_models as post

SUFFIXES = {
    ".json",
    ".jsonl",
    ".py",
    ".md",
    ".log",
    ".txt",
    ".c",
    ".h",
    ".rs",
    ".toml",
    ".lock",
    ".sh",
    ".yaml",
    ".yml",
    ".patch",
}
SPECIAL_NAMES = {"LICENSE", "LICENSE-MIT", "LICENSE-APACHE", "rust-toolchain"}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def relative(name: str, *, archives: bool = True) -> bool:
    path = PurePosixPath(name)
    return (
        bool(name)
        and not path.is_absolute()
        and str(path) == name
        and all(
            item not in {".", "..", "raw", "result", "retired-vm"}
            for item in path.parts
        )
        and "\\" not in name
        and "\n" not in name
        and (
            path.suffix in SUFFIXES
            or path.name in SPECIAL_NAMES
            or (archives and name.endswith(".tar.gz"))
        )
    )


def identity(data: bytes) -> post.Identity:
    return post.Identity(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(expected: post.Pin, limit: int = 32 * 2**20) -> bytes:
    path = expected.path
    require(
        relative(path.name), f"payload/unsupported file refused before open: {path}"
    )
    require(
        path.is_absolute() and not any(p.is_symlink() for p in (path, *path.parents)),
        "absolute nonsymlink metadata path required",
    )
    before = path.stat()
    require(
        stat.S_ISREG(before.st_mode) and before.st_size == expected.bytes <= limit,
        "regular bounded metadata file required",
    )
    data = path.read_bytes()
    after = path.stat()
    require(
        (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
            before.st_ctime_ns,
        )
        == (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ),
        "metadata changed while reading",
    )
    require(
        identity(data) == post.Identity(bytes=expected.bytes, sha256=expected.sha256),
        f"metadata pin differs: {path}",
    )
    return data


def pin(path: Path) -> post.Pin:
    require(relative(path.name), "generated file type refused")
    data = path.read_bytes()
    return post.Pin(path=path, **identity(data).model_dump())


def archive_inventory(
    data: bytes, *, nested: bool, max_file: int, max_total: int, max_members: int
) -> dict[str, post.Identity]:
    result: dict[str, post.Identity] = {}
    total = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode="r|gz") as archive:
        for member in archive:
            require(
                member.isreg() and relative(member.name, archives=nested),
                "unsafe archive member refused",
            )
            require(
                member.name not in result and len(result) < max_members,
                "duplicate/too many archive members",
            )
            total += member.size
            require(
                0 <= member.size <= max_file and total <= max_total,
                "archive decompression admission exceeded",
            )
            stream = archive.extractfile(member)
            require(stream is not None, "archive regular member unreadable")
            assert stream is not None
            raw = stream.read(max_file + 1)
            require(len(raw) == member.size, "archive member physical size differs")
            result[member.name] = identity(raw)
    require(bool(result), "empty archive refused")
    return result


def write_archive(
    path: Path,
    files: dict[str, bytes],
    *,
    max_file: int,
    max_total: int,
    max_members: int,
) -> dict[str, post.Identity]:
    require(
        len(files) <= max_members and sum(map(len, files.values())) <= max_total,
        "package admission exceeded",
    )
    with path.open("xb") as output:
        with tarfile.open(
            fileobj=output, mode="w:gz", format=tarfile.USTAR_FORMAT
        ) as archive:
            for name, raw in sorted(files.items()):
                require(
                    relative(name) and len(raw) <= max_file, "package member refused"
                )
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(raw), 0o644, 0
                archive.addfile(member, io.BytesIO(raw))
    actual = archive_inventory(
        path.read_bytes(),
        nested=True,
        max_file=max_file,
        max_total=max_total,
        max_members=max_members,
    )
    require(
        actual == {name: identity(raw) for name, raw in files.items()},
        "complete physical package members differ",
    )
    return actual
