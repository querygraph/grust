import io
import math
import tarfile
import tempfile
import unittest
from pathlib import Path
from typing import Literal, cast

import post_models as post
import report_io as files
import report_qualify as qualification


def archive(entries: list[tuple[str, bytes, bytes]]) -> bytes:
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as writer:
        for name, data, kind in entries:
            member = tarfile.TarInfo(name)
            member.type = kind
            member.size = len(data)
            if kind == tarfile.SYMTYPE:
                member.linkname = "/outside"
                member.size = 0
            writer.addfile(member, io.BytesIO(data))
    return output.getvalue()


def output() -> tuple[post.OutputAudit, post.DatasetConfig]:
    zero = "0" * 64
    pin = post.Pin(path=Path("/declared/metadata.json"), bytes=0, sha256=zero)
    dataset = post.DatasetConfig(
        dataset="cit-Patents",
        vertices=pin,
        edges=pin,
        expected_rows=3774768,
        source=5795784,
        records=pin,
        results=Path("/declared/results"),
        closure=pin,
    )
    call = post.Call(contrast="wcc", block=0, position=1, engine="pecan", seconds=2.0)
    record = post.OutputAudit(
        dataset="cit-Patents",
        call=call,
        source_directory=dataset.results / call.cell() / "result",
        retained_directory=Path("/declared/retained"),
        reference_cell="wcc-b0-p0-graphframes",
        reference_preparation_only=False,
        raw_files={"part.parquet": post.Identity(bytes=123, sha256=zero)},
        physical_schemas=[
            post.PhysicalFile(
                file="part.parquet",
                footer_rows=3774768,
                fields=(
                    post.PhysicalField(name="id", arrow_type="int64", nullable=True),
                    post.PhysicalField(
                        name="component", arrow_type="int64", nullable=True
                    ),
                ),
            )
        ],
        rows=3774768,
        original_domain_complete_unique=True,
        canonical_labels_passed=True,
        components=3627,
        false_merge_groups=0,
        false_split_groups=0,
        numeric_comparison_performed=True,
        compared_rows=3774768,
        mismatches=0,
        retained_copy_and_ssd_rehash_passed=True,
        qualified=True,
    )
    return record, dataset


class Controls(unittest.TestCase):
    def test_primary_median_distinct_from_secondary_geomean(self) -> None:
        calls = [
            post.Call(
                contrast=algorithm,
                block=block,
                position=cast(Literal[0, 1, 2, 3], position),
                engine=engine,
                seconds=value,
            )
            for algorithm in post.ORDER
            for block in (0, 1)
            for position, (engine, value) in enumerate(
                zip(
                    post.ENGINES,
                    ((1.0, 8.0, 2.0, 4.0) if block == 0 else (4.0, 3.0, 5.0, 1.0)),
                    strict=True,
                )
            )
        ]
        for ratio in qualification.ratios("cit-Patents", calls):
            self.assertEqual(ratio.fable_ratio_of_engine_medians, 1.6)
            self.assertEqual(len(ratio.adjacent_pair_ratios), 4)
            self.assertAlmostEqual(
                ratio.adjacent_pair_geometric_mean, math.pow(15.0, 0.25)
            )
            self.assertNotEqual(
                ratio.fable_ratio_of_engine_medians, ratio.adjacent_pair_geometric_mean
            )

    def test_complete_physical_metadata_accepted(self) -> None:
        record, dataset = output()
        qualification.require_output(record, dataset)

    def test_partial_domain_refused(self) -> None:
        record, dataset = output()
        record.rows -= 1
        with self.assertRaisesRegex(ValueError, "physical output"):
            qualification.require_output(record, dataset)

    def test_false_merge_refused(self) -> None:
        record, dataset = output()
        record.false_merge_groups = 1
        with self.assertRaisesRegex(ValueError, "partition directions"):
            qualification.require_output(record, dataset)

    def test_wrong_physical_type_refused(self) -> None:
        record, dataset = output()
        record.physical_schemas[0].fields[1].arrow_type = "double"
        with self.assertRaisesRegex(ValueError, "schema names/types"):
            qualification.require_output(record, dataset)

    def test_payload_refused_before_missing_file_open(self) -> None:
        expected = post.Pin(
            path=Path("/never-open/result.parquet"), bytes=0, sha256="0" * 64
        )
        with self.assertRaisesRegex(ValueError, "before open"):
            files.read(expected)

    def test_safe_archive_and_complete_member_identity(self) -> None:
        raw = archive([("metadata/a.json", b"{}", tarfile.REGTYPE)])
        actual = files.archive_inventory(
            raw, nested=False, max_file=100, max_total=100, max_members=5
        )
        self.assertEqual(actual, {"metadata/a.json": files.identity(b"{}")})

    def test_archive_bad_names_links_and_duplicates_refused(self) -> None:
        cases = [
            [("../outside.json", b"{}", tarfile.REGTYPE)],
            [("alias.json", b"", tarfile.SYMTYPE)],
            [("a.json", b"1", tarfile.REGTYPE), ("a.json", b"2", tarfile.REGTYPE)],
            [("part.parquet", b"not metadata", tarfile.REGTYPE)],
        ]
        for entries in cases:
            with self.subTest(entries=entries), self.assertRaises(ValueError):
                files.archive_inventory(
                    archive(entries),
                    nested=False,
                    max_file=100,
                    max_total=100,
                    max_members=5,
                )

    def test_archive_size_admission_refused(self) -> None:
        raw = archive([("a.json", b"12345", tarfile.REGTYPE)])
        with self.assertRaisesRegex(ValueError, "admission"):
            files.archive_inventory(
                raw, nested=False, max_file=4, max_total=100, max_members=5
            )

    def test_changed_metadata_pin_refused(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory).resolve() / "receipt.json"
            path.write_bytes(b"{}")
            expected = files.pin(path)
            path.write_bytes(b"[]")
            with self.assertRaisesRegex(ValueError, "pin differs"):
                files.read(expected)


if __name__ == "__main__":
    unittest.main()
