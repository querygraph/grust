"""Recheck small completed proof bindings and recompute Fable's summaries."""

import math
import statistics
from dataclasses import dataclass
from pathlib import Path

import post_models as post
import report_io as io
import report_models as models
from pydantic import TypeAdapter


@dataclass(frozen=True, slots=True)
class Qualified:
    queue: models.Queue
    root: models.RootAudit
    audit: post.Receipt
    config: post.Config
    ratios: list[post.Ratios]
    required_files: dict[str, post.Pin]


def ratios(dataset: post.Dataset, calls: list[post.Call]) -> list[post.Ratios]:
    result: list[post.Ratios] = []
    for algorithm in post.ORDER:
        selected = [c for c in calls if c.contrast == algorithm]
        io.require(len(selected) == 8, "eight original calls per contrast required")
        gf = statistics.median(c.seconds for c in selected if c.engine == "graphframes")
        pecan = statistics.median(c.seconds for c in selected if c.engine == "pecan")
        paired = tuple(
            value
            for i in (0, 4)
            for value in (
                selected[i + 1].seconds / selected[i].seconds,
                selected[i + 2].seconds / selected[i + 3].seconds,
            )
        )
        result.append(
            post.Ratios(
                dataset=dataset,
                algorithm=algorithm,
                graphframes_median_seconds=gf,
                pecan_median_seconds=pecan,
                fable_ratio_of_engine_medians=pecan / gf,
                adjacent_pair_ratios=paired,
                adjacent_pair_geometric_mean=math.exp(
                    statistics.mean(math.log(r) for r in paired)
                ),
            )
        )
    return result


def require_output(output: post.OutputAudit, dataset: post.DatasetConfig) -> None:
    call = output.call
    reference = call.cell() == f"{call.contrast}-b0-p0-graphframes"
    io.require(
        output.qualified
        and not output.errors
        and output.original_domain_complete_unique
        and output.retained_copy_and_ssd_rehash_passed
        and output.rows == dataset.expected_rows
        and bool(output.raw_files),
        "full physical output did not qualify",
    )
    io.require(
        output.reference_preparation_only == reference
        and output.reference_cell == f"{call.contrast}-b0-p0-graphframes"
        and output.source_directory == dataset.results / call.cell() / "result",
        "reference/raw output binding differs",
    )
    io.require(
        output.numeric_comparison_performed == (not reference)
        and output.compared_rows == (0 if reference else dataset.expected_rows)
        and output.mismatches == (None if reference else 0),
        "full comparison/reference counts differ",
    )
    expected = {"id": "int64", "component": "int64"}
    if call.contrast == "pagerank":
        expected = {"id": "int64", "pagerank": "double"}
    elif call.contrast == "bfs":
        expected = (
            {"id": "int64", "distance": "double", "hops": "int64", "parent": "int64"}
            if call.engine == "pecan"
            else {"id": "int64", f"dist_{dataset.source}": "int32"}
        )
    names = [s.file for s in output.physical_schemas]
    io.require(
        len(names) == len(set(names))
        and set(names)
        == {name for name in output.raw_files if name.endswith(".parquet")}
        and bool(names),
        "physical schema inventory differs",
    )
    io.require(
        sum(s.footer_rows for s in output.physical_schemas) == dataset.expected_rows,
        "physical footer coverage differs",
    )
    for schema in output.physical_schemas:
        io.require(
            len(schema.fields) == len(expected)
            and {f.name: f.arrow_type for f in schema.fields} == expected
            and schema.footer_rows >= 0,
            "raw schema names/types differ",
        )
    if call.contrast == "wcc":
        io.require(
            output.canonical_labels_passed is True
            and output.components is not None
            and output.components > 0,
            "canonical WCC member labels unavailable",
        )
        if not reference:
            io.require(
                output.false_merge_groups == output.false_split_groups == 0,
                "WCC partition directions did not pass",
            )
    elif call.contrast == "bfs":
        io.require(
            output.reachable is not None
            and output.reachable > 0
            and output.unreachable is not None
            and output.reachable + output.unreachable == dataset.expected_rows
            and output.maximum_hops is not None
            and output.maximum_hops >= 0,
            "BFS full coverage diagnostics missing",
        )
    elif not reference:
        io.require(
            output.maximum_absolute_error_hex is not None,
            "PageRank numeric diagnostics missing",
        )
        assert output.maximum_absolute_error_hex is not None
        maximum = float.fromhex(output.maximum_absolute_error_hex)
        io.require(
            math.isfinite(maximum) and maximum >= 0, "invalid PageRank diagnostic"
        )


def qualify(configuration: models.Configuration) -> Qualified:
    io.require(
        configuration.post_models.path == Path(str(post.__file__))
        and configuration.post_models.sha256 == models.POST_MODELS_SHA,
        "actual frozen post model origin differs",
    )
    io.read(configuration.post_models)
    queue = models.Queue.model_validate_json(io.read(configuration.queue))
    root = models.RootAudit.model_validate_json(io.read(configuration.root_audit))
    audit = post.Receipt.model_validate_json(io.read(configuration.post_audit))
    config = post.Config.model_validate_json(io.read(configuration.post_configuration))
    io.require(
        not queue.errors
        and queue.traceback is None
        and len(queue.states) == 2
        and tuple(s.dataset for s in queue.states) == tuple(post.SOURCE),
        "whole campaign closure did not qualify",
    )
    io.require(
        root.queue_pin == configuration.queue
        and root.plan_pin == configuration.plan
        and root.post_audit_pin == configuration.post_audit
        and root.owner_pid == queue.owner_pid
        and root.owned_parent_pids == [s.parent_pid for s in queue.states]
        and not root.owned_processes_remaining
        and not root.matching_native_servers_remaining,
        "independent root closure/proof binding differs",
    )
    io.require(
        queue.configuration
        == audit.campaign_configuration
        == config.campaign_configuration
        == configuration.plan
        and audit.configuration == configuration.post_configuration,
        "campaign/audit configuration binding differs",
    )
    io.require(
        audit.outcome == "passed_full_physical_whole_campaign"
        and not audit.errors
        and audit.admission_passed
        and audit.original_vertex_domain_verified == {d: True for d in post.SOURCE}
        and len(audit.outputs) == audit.qualified_outputs == 48
        and audit.references_prepared == 6
        and audit.nonreference_comparisons == 42,
        "all48 full physical audit required",
    )
    required = {
        "metadata/queue.json": configuration.queue,
        "metadata/plan.json": configuration.plan,
        "metadata/launch01.json": configuration.launch,
        "metadata/post-audit.json": configuration.post_audit,
        "metadata/post-configuration.json": configuration.post_configuration,
        "metadata/root-final-audit01.json": configuration.root_audit,
        "sources/post_models.py": configuration.post_models,
        "sources/root-final-audit.py": root.source_pin,
    }
    admission = post.Admission.model_validate_json(io.read(config.admission))
    io.require(
        admission.campaign_configuration == configuration.plan,
        "production source/input admission differs",
    )
    freeze = post.Freeze.model_validate_json(io.read(config.audit_source_freeze))
    io.require(
        config.audit_source_freeze.sha256 == models.POST_FREEZE_SHA,
        "actual frozen post producer version differs",
    )
    io.require(
        freeze.production_helpers.get("post_models.py")
        == post.Identity(
            bytes=configuration.post_models.bytes,
            sha256=configuration.post_models.sha256,
        ),
        "post producer frozen model differs",
    )
    recomputed: list[post.Ratios] = []
    index = 0
    for dataset, state in zip(config.datasets, queue.states, strict=True):
        io.require(
            state.records == dataset.records and state.pgid == state.parent_pid,
            "original records/owned parent binding differs",
        )
        for label, closure_pin in (("owner", state.closure), ("post", dataset.closure)):
            closure = post.Closure.model_validate_json(io.read(closure_pin))
            io.require(
                closure.dataset == state.dataset
                and closure.parent_pid == state.parent_pid
                and closure.pgid == state.pgid
                and closure.campaign_configuration == configuration.plan,
                "waited whole-script closure differs",
            )
            required[f"metadata/{dataset.dataset}-{label}-closure.json"] = closure_pin
        calls = TypeAdapter(list[post.Call]).validate_json(io.read(dataset.records))
        expected = [
            (algorithm, block, position, engine)
            for algorithm in post.ORDER
            for block in (0, 1)
            for position, engine in enumerate(post.ENGINES)
        ]
        io.require(
            len(calls) == 24
            and [(c.contrast, c.block, c.position, c.engine) for c in calls]
            == expected,
            "original24 ABBA order differs",
        )
        for call in calls:
            output = audit.outputs[index]
            index += 1
            io.require(
                output.dataset == dataset.dataset and output.call == call,
                "post audit call differs from original record",
            )
            io.require(
                (call.oracle is None) == (call.position == 0),
                "original inline oracle placement differs",
            )
            require_output(output, dataset)
            io.require(
                output.retained_directory
                == config.output / "raw" / dataset.dataset / call.cell() / "result",
                "retained raw directory binding differs",
            )
        recomputed.extend(ratios(dataset.dataset, calls))
        required[f"metadata/{dataset.dataset}-records.json"] = dataset.records
    io.require(
        recomputed == audit.ratios, "post primary/secondary ratio recomputation differs"
    )
    io.require(
        root.primary_median_ratios
        == {
            f"{r.dataset}-{r.algorithm}": r.fable_ratio_of_engine_medians
            for r in recomputed
        },
        "root primary median ratio recomputation differs",
    )
    for i, expected_pin in enumerate(audit.metadata_pins):
        required[f"metadata/post-proof-{i:03d}{expected_pin.path.suffix}"] = (
            expected_pin
        )
    for name, value in freeze.production_helpers.items():
        required[f"sources/post/{name}"] = post.Pin(
            path=config.audit_source_freeze.path.parent / name, **value.model_dump()
        )
    plan = models.CampaignPlan.model_validate_json(io.read(configuration.plan))
    launch = models.Launch.model_validate_json(io.read(configuration.launch))
    io.require(
        plan.root == configuration.plan.path.parent
        and launch.pid == queue.owner_pid
        and len(plan.recipes) == 2
        and plan.recipes == [s.recipe for s in queue.states],
        "actual plan/launch/source recipe binding differs",
    )
    required["sources/run_campaign.py"] = plan.source
    for i, selected in enumerate(plan.recipes):
        required[f"metadata/recipe-{i + 1}.json"] = selected
    for i, pin in enumerate(plan.immutable_pins):
        if io.relative(pin.path.name):
            required[f"sources/plan-pins/{i:03d}-{pin.path.name}"] = pin
    return Qualified(queue, root, audit, config, recomputed, required)
