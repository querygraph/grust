"""Package completed exact-Fable metadata; never open result/native payloads."""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import cast

import post_models as post
import report_io as io
import report_models as models
import report_qualify as qualification
from pydantic import JsonValue

PRODUCTION = (
    "report_models.py",
    "report_io.py",
    "report_qualify.py",
    "prepare_report.py",
)
BASELINE_SHA = "37a082812a3a37bce2f90fc13000e9d467d740b03b3faa4cd260988a85b612e9"


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def contrasts(qualified: qualification.Qualified) -> dict[str, dict[str, JsonValue]]:
    result: dict[str, dict[str, JsonValue]] = {}
    for ratio in qualified.ratios:
        errors = [
            float.fromhex(o.maximum_absolute_error_hex)
            for o in qualified.audit.outputs
            if o.dataset == ratio.dataset
            and o.call.contrast == ratio.algorithm
            and o.maximum_absolute_error_hex is not None
        ]
        result[f"{ratio.dataset}-{ratio.algorithm}"] = {
            **cast(dict[str, JsonValue], ratio.model_dump(mode="json")),
            "n_per_engine": 4,
            "warmup_calls": 0,
            "maximum_absolute_error": max(errors) if errors else None,
        }
    return result


def markdown(qualified: qualification.Qualified) -> str:
    rows = "\n".join(
        f"| {r.dataset} | {r.algorithm} | {r.fable_ratio_of_engine_medians:.6f} |"
        for r in qualified.ratios
    )
    return f"""# Exact Fable native A2-local results

All 48 original calls completed and passed the separate full physical audit:
six GF reference preparations and 42 full comparisons. The original two
G/P/P/G blocks have four calls per engine and algorithm, with no warmups.
The primary statistic is Pecan median time divided by GF median time.
A ratio below 1 means less Pecan median elapsed time on this shared host.

| Dataset | Algorithm | Pecan/GF ratio of medians |
| --- | --- | ---: |
{rows}

These are ratios on a shared native macOS x86_64 host. Controller and compiled
Sail are `9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3`; GF is
`b4da56dabe20bba8e29563e06acc5179b2113ce3`. The retained optimized build uses
Rust 1.97.1, optimization level 3, full LTO, and one codegen unit. Only the
four original path globals changed; all Fable function bodies, timers,
exports, inline oracles and call order remain unchanged.

Pecan's primary timer excludes its function-local Python imports and includes
server launch, session, inputs, public call, raw export, session stop and
server wait. GF times its CLI subprocess. Local software workers are 16;
Pecan configures a 30-GiB pool and GF receives `--max-memory 30G`.
These settings are not an OS resource cap on the 128-GiB host.
Snapshot inputs are off and repartition checkpoints are on. Whole-script
parent exits and owned groups were observed; per-call PIDs and Sail server
return codes were not recorded by the original script.

Every output has the complete unique original vertex domain. WCC has exact
canonical labels and both partition directions checked. BFS retains all four
Pecan fields; only hops are numerically compared, while distance and parent
have schema and retention checks. PageRank preserves the original strict
inline absolute-error `< 1e-12` checks; the separate full comparison uses the
predeclared `1e-12` binary64 bound. BFS sources are Cit 5795784 and Graph500
798169. Stored directed arcs are used for BFS/PageRank; official Graph500
undirected ground truth is not qualified by this comparison.

[report.json](report.json) preserves all 48 outcomes, raw clocks, diagnostics,
physical schemas and identities. Adjacent-pair geomeans are labelled as
secondary statistics. [evidence.tar.gz](evidence.tar.gz) preserves small
original metadata, logs, configurations, closure proofs, sources and source
archives. Raw Parquet files and binaries remain in the separately audited
SSD/Apo stores and are excluded from this portable metadata package.

The old VM diagnostic was skipped at the user's explicit request. The
original A1 VM was deleted; the exact native script was requested and run.
The original C source is preserved. No causal VM explanation is claimed.

The earlier [MatchedNative report](../MatchedNative/README.md) and
[its source plan](../NATIVE-MATCHED-PLAN.md) retain their separate 70-call d0
controller protocol, Python-inclusive timer and two-field BFS export.
[This exact protocol plan](../FABLE-EXACT-PLAN.md) identifies the new run;
no historical result is relabelled.
"""


def factory_files(config: models.Configuration) -> dict[str, post.Pin]:
    freeze = models.FactoryFreeze.model_validate_json(io.read(config.factory_freeze))
    io.require(
        set(freeze.production_helpers) == set(PRODUCTION)
        and freeze.controls_passed > 0,
        "factory source freeze incomplete",
    )
    directory = Path(__file__).parent
    origins = {
        "report_models.py": models.__file__,
        "report_io.py": io.__file__,
        "report_qualify.py": qualification.__file__,
        "prepare_report.py": __file__,
    }
    result = {
        "sources/factory-freeze.json": config.factory_freeze,
        "sources/factory-source-gates.json": freeze.source_gates,
    }
    for name, expected in freeze.production_helpers.items():
        path = directory / name
        io.require(Path(str(origins[name])) == path, "factory import origin differs")
        result[f"sources/factory/{name}"] = post.Pin(path=path, **expected.model_dump())
    return result


def generate(configuration: Path) -> models.Generation:
    config_pin = io.pin(configuration)
    config = models.Configuration.model_validate_json(io.read(config_pin))
    qualified = qualification.qualify(config)
    files = {**qualified.required_files, **factory_files(config)}
    for name, expected in config.files.items():
        io.require(
            name not in files or files[name] == expected, "archive alias conflict"
        )
        files[name] = expected
    baseline = files.get("original/host-baseline/baseline.c")
    original = files.get("original/A2-local/a2_local.py")
    io.require(
        baseline is not None
        and baseline.bytes == 3551
        and baseline.sha256 == BASELINE_SHA
        and original is not None
        and original.sha256 == post.FABLE_SHA,
        "original source/C baseline missing",
    )
    io.require(
        "metadata/vm-diagnostic-user-decision01.json" in files,
        "explicit user VM diagnostic decision must be preserved",
    )
    paths = {p.path for p in files.values()}
    for output in qualified.audit.outputs:
        log = output.source_directory.parent / (
            "server.log" if output.call.engine == "pecan" else "engine.log"
        )
        io.require(
            log in paths, "complete original cell logs must be packaged: " + str(log)
        )
    io.require(
        config.output.is_absolute()
        and not config.output.exists()
        and not any(p.is_symlink() for p in (config.output, *config.output.parents)),
        "fresh nonsymlink package directory required",
    )
    protected = (
        config.plan.path.parent,
        config.post_audit.path.parent,
        Path(__file__).parent,
    )
    io.require(
        not any(
            config.output == p
            or config.output.is_relative_to(p)
            or p.is_relative_to(config.output)
            for p in protected
        ),
        "package overlaps campaign/audit/source",
    )
    packaged: dict[str, bytes] = {}
    origins: dict[str, str] = {}
    source_archives: dict[str, dict[str, post.Identity]] = {}
    io.require(
        len(files) < config.max_members, "metadata member count exceeds admission"
    )
    for name, expected in sorted(files.items()):
        io.require(io.relative(name), "unsafe/nonmetadata archive alias: " + name)
        raw = io.read(expected, config.max_file_bytes)
        if name.endswith(".tar.gz"):
            source_archives[name] = io.archive_inventory(
                raw,
                nested=False,
                max_file=config.max_file_bytes,
                max_total=config.max_total_bytes,
                max_members=config.max_members,
            )
        packaged[name] = raw
        origins.setdefault(str(expected.path), name)
    packaged["metadata/generation-configuration.json"] = io.read(config_pin)
    origins[str(configuration)] = "metadata/generation-configuration.json"
    summaries = contrasts(qualified)
    report = {
        "outcome": "passed_full_physical_exact_Fable_native_campaign",
        "expected_calls": 48,
        "qualified_calls": 48,
        "references_prepared": 6,
        "nonreference_comparisons": 42,
        "contrasts": summaries,
        "cells": [
            {
                "id": f"{o.dataset}/{o.call.cell()}",
                "outcome": "passed_full_physical",
                **o.model_dump(mode="json"),
            }
            for o in qualified.audit.outputs
        ],
        "source": {
            "controller": post.SAIL,
            "native_runtime": post.SAIL,
            "graphframes": post.GF,
            "original_fable_sha256": post.FABLE_SHA,
        },
        "boundary": {
            "original_functions_unchanged": True,
            "workers": 16,
            "pecan_pool_bytes": 30 * 2**30,
            "graphframes_memory_argument": "30G",
            "snapshot_inputs": False,
            "repartition_checkpoints": True,
            "python_imports_excluded": True,
            "bfs_export_fields": ["id", "distance", "hops", "parent"],
            "bfs_numeric_fields": ["hops"],
            "per_call_pid_claim": False,
            "os_resource_cap_claim": False,
            "official_graph500_gt_qualified": False,
        },
        "vm_baseline": {
            "outcome": "not_run",
            "original_A1_deleted": True,
            "native_only_policy": True,
            "optional_user_selection_pending": False,
            "user_requested_skip": True,
        },
        "proofs": {
            "queue": config.queue.model_dump(mode="json"),
            "post_audit": config.post_audit.model_dump(mode="json"),
            "root_audit": config.root_audit.model_dump(mode="json"),
        },
        "evidence_origins": origins,
        "evidence_files": {
            name: pin.model_dump(mode="json") for name, pin in files.items()
        },
        "source_archive_members": {
            name: {k: v.model_dump() for k, v in values.items()}
            for name, values in source_archives.items()
        },
    }
    config.output.mkdir()
    report_path, readme_path = (
        config.output / "report.json",
        config.output / "README.md",
    )
    report_path.write_bytes(json_bytes(report))
    readme_path.write_text(markdown(qualified))
    archive = config.output / "evidence.tar.gz"
    members = io.write_archive(
        archive,
        packaged,
        max_file=config.max_file_bytes,
        max_total=config.max_total_bytes,
        max_members=config.max_members,
    )
    for expected in files.values():
        io.read(expected, config.max_file_bytes)
    io.read(config_pin)
    receipt = models.Generation(
        observed_utc=datetime.now(timezone.utc).isoformat(),
        outcome="passed_metadata_only_exact_Fable_package",
        configuration=config_pin,
        archive=io.pin(archive),
        archive_members=members,
        report=io.pin(report_path),
        readme=io.pin(readme_path),
        evidence_origins=origins,
    )
    (config.output / "generation-receipt.json").write_text(
        receipt.model_dump_json(indent=2) + "\n"
    )
    (config.output / "archive-verification.json").write_bytes(
        json_bytes(
            {
                "archive": receipt.archive.model_dump(mode="json"),
                "files": {name: value.model_dump() for name, value in members.items()},
                "all_physical_members_verified": True,
                "payloads_included": False,
            }
        )
    )
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    print(generate(parser.parse_args().config).model_dump_json(indent=2))


if __name__ == "__main__":
    main()
