"""Run bounded source-only gates; never launch a graph engine or scan an input."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

GATE = Path('/tmp/sem-output-oracle-venv/bin')
BASE = Path(__file__).parent.resolve()
ORACLE = BASE.with_name('A5-native-matched-oracle01')
BOOT = "import runpy,sys; d=sys.argv[1];sys.path[:0]=[d,sys.argv[2]];sys.argv=[d+'/'+sys.argv[3]];runpy.run_path(sys.argv[0],run_name='__main__')"


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def source_files() -> dict[str, dict[str, int | str]]:
    return {str(path.relative_to(BASE)): {'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in sorted(BASE.rglob('*.py')) if '__pycache__' not in path.parts}


def run(output: Path) -> int:
    output.mkdir(exist_ok=False)
    receipt: dict[str, Any] = {'started_utc':utc(), 'scope':'bounded source-only mock/AST gates; no engine/build/probe/input scan',
                             'before':source_files(), 'steps':[], 'outcome':'checking'}
    sources=[str(path) for path in sorted(BASE.rglob('*.py')) if '__pycache__' not in path.parts]
    calls: list[tuple[str, list[str]]] = [
        ('ruff',[str(GATE/'ruff'),'check','--isolated','--no-cache','--select','E4,E7,E9,F,I','--target-version','py312',str(BASE)]),
        ('mypy',[str(GATE/'mypy'),'--strict','--ignore-missing-imports','--follow-imports=silent',
                 '--cache-dir',str(output/'mypy-cache'),*sources])]
    calls += [(name,[str(GATE/'python'),'-I','-B','-c',BOOT,str(BASE),str(ORACLE),name])
              for name in ['test_native.py','test_graphframes.py','test_shutdown.py','support/test_engine_pecan.py']]
    env=dict(os.environ,MYPYPATH=str(ORACLE),PYTHONDONTWRITEBYTECODE='1')
    for index,(name,argv) in enumerate(calls):
        log=output/f'{index:02d}.log'
        with log.open('xb') as stream:
            completed=subprocess.run(argv,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180,check=False)
        receipt['steps'].append({'name':name,'command':argv,'returncode':completed.returncode,'log':str(log)})
    receipt['after']=source_files()
    receipt['outcome']='passed' if all(step['returncode']==0 for step in receipt['steps']) and receipt['before']==receipt['after'] else 'failed'
    receipt['finished_utc']=utc()
    (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'outcome':receipt['outcome'],'receipt':str(output/'receipt.json')}))
    return 0 if receipt['outcome']=='passed' else 1


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    return run(parser.parse_args().output)


if __name__=='__main__':
    raise SystemExit(main())
