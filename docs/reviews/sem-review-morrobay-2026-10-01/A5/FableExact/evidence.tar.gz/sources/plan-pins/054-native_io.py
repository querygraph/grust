"""Bounded identity, native client admission and portable retention primitives."""
from __future__ import annotations

import hashlib
import json
import os
import signal
import stat
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import TypeVar, cast

from native_models import (
    GF_SOURCE,
    HARNESS,
    RUNTIME,
    SOURCE,
    Client,
    Config,
    Identity,
    InputAdmission,
    Pin,
    Process,
    Record,
)
from pydantic import BaseModel, JsonValue, TypeAdapter

T = TypeVar("T", bound=BaseModel)
JSON_OBJECT = TypeAdapter(dict[str, JsonValue])
FROZEN: dict[str, str] = {'engine_pecan.py': '405dd51a483a6f3f06f248bf68415f2ad98ccc2c8905cbede86b173d98bb79e7', 'engine_graphframes.py': '4c7702027cbba970259bcc6531fcb01166b313c972bf2d1a64b39962c3b65e8f', 'shutdown.py': '4a2a35d610bedd31bf7e1ff08ac9f64339d493e9af55c580da902098e552319e'}
ORACLE_FROZEN: dict[str, str] = {'matched_compare.py': 'ecbf2f7aab15406765b424659716dba09551be4ec4859d78147d1066afd7b861', 'matched_io.py': '26dc39b562c171e4722eb55b7ccf654ac53b5238570c3e652053bc62ec776a25', 'matched_models.py': '71dee1d9c8dc69a98f45157a67af3c23e6c819378b8becc91e56e3f443ba2622', 'matched_numeric.py': '5beaab5fd339cce176185d14b278992b99f2b4d5f0da31f0c8d8d78eb03fcb6a', 'matched_oracle.py': 'c2f29fbdf46f74a98f5268e99ff3c4bab55a6b674ab90f541fd1c2b70de9b120', 'matched_readers.py': 'e6bd758527dcf28a1ce1eadfe750022ca6953a7b413e358a8ab650e4b4bb5b2b'}
CLIENT_PROBE = r'''
import hashlib,importlib,importlib.metadata,json,os,platform,sys,sysconfig
from pathlib import Path
def pin(path):
 p=Path(path).resolve()
 with p.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha}
names=['pydantic','pydantic_core','pydantic_core._pydantic_core','numpy','numpy._core._multiarray_umath','pyarrow','pyarrow.lib','grpc','grpc._cython.cygrpc','pyspark.sql.connect.dataframe','pyspark.sql.connect.session']
modules={n:pin(importlib.import_module(n).__file__) for n in names}
assert platform.system()=='Darwin' and platform.machine()=='x86_64'
print(json.dumps({'python':sys.executable,'python_version':platform.python_version(),'base_prefix':sys.base_prefix,'versions':{d.metadata['Name'].lower().replace('_','-'):d.version for d in importlib.metadata.distributions()},'extensions':sorted(str(e) for e in importlib.metadata.entry_points(group='pysail.extensions')),'modules':modules,'executable':pin(sys.executable),'libpython':pin(Path(sysconfig.get_config_var('LIBDIR'))/sysconfig.get_config_var('LDLIBRARY')),'python_symlink':os.readlink(sys.executable) if Path(sys.executable).is_symlink() else None}))
'''
BOOT = "import json,runpy,sys; from pathlib import Path; c=json.load(open(sys.argv[1])); sys.path[:0]=[sys.argv[2],str(Path(sys.argv[2]).parent),c['repo']+'/examples/extensions/graph-algorithms/src',c['harness_repo']+'/examples/extensions/benchmarks']; sys.argv=[sys.argv[3],'--config',sys.argv[1]]; runpy.run_path(sys.argv[0],run_name='__main__')"


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def identity(path: Path) -> Identity:
    require(path.is_file() and not path.is_symlink(), f"unsafe/missing file: {path}")
    before = path.stat()
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_ino, after.st_size, after.st_mtime_ns), f"file changed while hashing: {path}")
    return Identity(bytes=after.st_size, sha256=digest)


def verify(pin: Pin) -> Identity:
    observed = identity(pin.path)
    require(observed == Identity(bytes=pin.bytes, sha256=pin.sha256), f"pin mismatch: {pin.path}")
    return observed


def write(path: Path, record: BaseModel | dict[str, JsonValue], *, fresh: bool = False) -> None:
    if fresh:
        require(not path.exists() and not path.is_symlink(), f"refusing existing file: {path}")
    text = record.model_dump_json(indent=2) if isinstance(record, BaseModel) else json.dumps(record, indent=2, allow_nan=False)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("x" if fresh else "w") as stream:
        stream.write(text + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def load(path: Path) -> dict[str, JsonValue]:
    require(path.stat().st_size <= 16 * 2**20, "JSON observation exceeds bound")
    return JSON_OBJECT.validate_json(path.read_bytes())


def command(argv: list[str], *, env: dict[str, str] | None = None, seconds: int = 30) -> str:
    child = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, start_new_session=True)
    try:
        stdout, stderr = child.communicate(timeout=seconds)
    except BaseException:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=5)
        raise
    require(child.returncode == 0, f"command failed: {argv[0]}: {stderr[:2000]}")
    require(len(stdout) <= 8 * 2**20, "command output exceeds bound")
    return stdout


def environment(library: Path) -> dict[str, str]:
    result = {k: v for k, v in os.environ.items() if not k.startswith(("SAIL_", "DYLD_"))
              and k not in {"PYTHONHOME", "PYTHONPATH", "RUST_LOG", "LD_LIBRARY_PATH"}}
    result.update(DYLD_LIBRARY_PATH=str(library), PYTHONDONTWRITEBYTECODE="1",
                  OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                  VECLIB_MAXIMUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
    return result


def client(python: Path, library: Path, lock: Pin) -> Client:
    verify(lock)
    raw = JSON_OBJECT.validate_json(command([str(python), "-I", "-B", "-c", CLIENT_PROBE], env=environment(library), seconds=90))
    raw.update(observed_utc=utc(), lock=cast(JsonValue, lock.model_dump(mode="json")))
    observed = Client.model_validate(raw)
    require(observed.python == python and not observed.extensions, "native client origin/extensions mismatch")
    expected = {"pyspark": "4.0.1", "pydantic": "2.11.10", "pydantic-core": "2.33.2",
                "pyarrow": "21.0.0", "numpy": "2.5.3", "protobuf": "7.36.2"}
    require(all(observed.versions.get(k) == v for k, v in expected.items()), "native client locked dependency mismatch")
    allowed = python.parent.parent.resolve()
    require(all(pin.path.is_relative_to(allowed) for pin in observed.modules.values()), "module outside fresh native client")
    verify(lock)
    return observed


def same_client(actual: Client, expected: Client) -> None:
    require(actual.model_dump(exclude={"observed_utc"}) == expected.model_dump(exclude={"observed_utc"}),
            "native client code/ABI/versions changed")


def source(config: Config) -> dict[str, str]:
    repo = config.engine.repo
    head = command(["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"]).strip()
    tree = command(["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD^{tree}"]).strip()
    dirty = command(["/usr/bin/git", "-C", str(repo), "status", "--porcelain=v1", "--untracked-files=all"])
    branch = subprocess.run(["/usr/bin/git", "-C", str(repo), "symbolic-ref", "-q", "HEAD"], capture_output=True, timeout=10, check=False)
    require(head == SOURCE and tree == config.source_tree and not dirty and branch.returncode == 1,
            "requires exact clean detached native d0 controller")
    runtime_tree = command(["/usr/bin/git", "-C", str(repo), "rev-parse", RUNTIME + "^{tree}"]).strip()
    parity = command(["/usr/bin/git", "-C", str(repo), "diff", "--exit-code", "--name-only", RUNTIME, SOURCE,
                      "--", "crates/", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml"])
    require(not parity, "compiled runtime source paths differ from exact d0 controller")
    admission = load(config.source_admission.path)
    require(admission.get("controller") == SOURCE and admission.get("tree") == config.source_tree
            and admission.get("compiled_runtime") == RUNTIME and admission.get("source") == str(repo),
            "root controller/runtime source admission mismatch")
    gf_head = command(["/usr/bin/git", "-C", str(config.graphframes_repo), "rev-parse", "HEAD"]).strip()
    gf_tree = command(["/usr/bin/git", "-C", str(config.graphframes_repo), "rev-parse", "HEAD^{tree}"]).strip()
    gf_dirty = command(["/usr/bin/git", "-C", str(config.graphframes_repo), "status", "--porcelain=v1", "--untracked-files=all"])
    gf_branch = subprocess.run(["/usr/bin/git", "-C", str(config.graphframes_repo), "symbolic-ref", "-q", "HEAD"], capture_output=True, timeout=10, check=False)
    require(gf_head == GF_SOURCE and not gf_dirty and gf_branch.returncode == 1, "exact clean detached graphframes source required")
    return {"graphframes_commit":gf_head, "graphframes_tree":gf_tree, "commit": head, "tree": tree, "compiled_runtime": RUNTIME,
            "compiled_runtime_tree": runtime_tree, "compiled_runtime_paths_parity": "empty diff"}


def guard_files(config: Config) -> dict[str, Identity]:
    pins = [config.client, config.build, config.retirement, config.input_admission,
            config.support_manifest, config.source_admission,
            *config.oracle_helpers.values(),
            *config.originals.values(), *config.helpers.values()]
    require(bool(ORACLE_FROZEN) and set(config.oracle_helpers) == set(ORACLE_FROZEN), "frozen oracle pin inventory incomplete")
    require(all(config.oracle_helpers[k].sha256 == v for k, v in ORACLE_FROZEN.items()), "frozen physical oracle identity changed")
    records = {str(pin.path): verify(pin) for pin in pins}
    admission = InputAdmission.model_validate(load(config.input_admission.path))
    for pin in admission.supporting_receipts:
        records[str(pin.path)] = verify(pin)
    admitted_client = Client.model_validate(load(config.client.path))
    controller_lock = config.engine.repo / "examples/extensions/requirements.lock"
    observed_lock = identity(controller_lock)
    require(observed_lock == Identity(bytes=admitted_client.lock.bytes, sha256=admitted_client.lock.sha256),
            "new controller requirements differ from admitted native client lock")
    records[str(controller_lock)] = observed_lock
    build = load(config.build.path)
    steps = build.get("steps")
    require(isinstance(steps, list), "build steps absent")
    binaries = [s.get("binary") for s in cast(list[JsonValue], steps)
                if isinstance(s, dict) and s.get("name") == ("sail" if config.engine.engine == "pecan" else "graphframes")]
    require(len(binaries) == 1, "exactly one actual selected native binary identity required")
    binary = Pin.model_validate(binaries[0])
    require(binary.path == config.engine.binary, "compiled binary path mismatch")
    records[str(binary.path)] = verify(binary)
    manifest = load(config.support_manifest.path)
    require(manifest.get("source") == SOURCE and manifest.get("harness") == HARNESS
            and manifest.get("compiled_runtime_source") == RUNTIME,
            "frozen support manifest source mismatch")
    support = config.support_manifest.path.parent / "support"
    require(set(FROZEN) == {"engine_pecan.py", "engine_graphframes.py", "shutdown.py"}, "frozen child pin inventory incomplete")
    for name, digest in FROZEN.items():
        observed = identity(support / name)
        require(observed.sha256 == digest, f"frozen helper changed: {name}")
        records[str(support / name)] = observed
    for section, root in (("source_pins", config.engine.repo), ("frozen_harness_files", config.engine.harness_repo / "examples/extensions/benchmarks")):
        raw = manifest.get(section)
        require(isinstance(raw, dict), "missing manifest source section")
        for name, value in cast(dict[str, JsonValue], raw).items():
            require(isinstance(value, dict), "source identity must be object")
            item = cast(dict[str, JsonValue], value)
            path = root / name
            observed = identity(path)
            require(observed.sha256 == item.get("sha256") and observed.bytes == item.get("bytes"), f"source/harness file changed: {path}")
            records[str(path)] = observed
    require(identity(Path(__file__)).sha256 == config.helpers["native_io.py"].sha256,
            "actual parent helper origin changed")
    if config.reference is not None:
        records[str(config.reference.exit.producer_receipt.path)] = verify(config.reference.exit.producer_receipt)
        for name, expected in config.reference.files.items():
            path = config.reference.directory / name
            observed = identity(path)
            require(observed == expected, "closed graphframes reference bytes changed")
            records[str(path)] = observed
    return records


def processes() -> list[tuple[Process, str]]:
    output: list[tuple[Process, str]] = []
    for line in command(["/bin/ps", "-axo", "pid=,ppid=,pgid=,rss=,command="], seconds=5).splitlines():
        fields = line.strip().split(None, 4)
        if len(fields) != 5:
            continue
        pid, ppid, pgid, rss = (int(x) for x in fields[:4])
        text = fields[4]
        output.append((Process(pid=pid, ppid=ppid, pgid=pgid, rss_bytes=rss * 1024,
                               command_sha256=hashlib.sha256(text.encode()).hexdigest()), text))
    return output


def matching_server(text: str, binary: Path) -> bool:
    return text.startswith((str(binary) + " spark server --ip 127.0.0.1 --port ",
                            str(binary) + " page-rank ", str(binary) + " wcc ", str(binary) + " shortest-path "))


def matching_worker(text: str, binary: Path) -> bool:
    return text == str(binary) + " worker"


def group_absent(pgid: int, table: list[tuple[Process, str]]) -> bool:
    return all(row.pgid != pgid for row, _ in table)


def inventory(root: Path) -> dict[str, Identity]:
    require(root.is_dir() and not root.is_symlink(), "missing/unsafe child output")
    result: dict[str, Identity] = {}
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), "child output symlink refused")
        if path.is_file():
            result[str(path.relative_to(root))] = identity(path)
        else:
            require(path.is_dir(), "special child output refused")
    return result


def retain(root: Path, destination: Path) -> dict[str, Identity]:
    before = inventory(root)
    destination.mkdir(parents=True, exist_ok=False)
    for name, expected in before.items():
        source_path, target = root / name, destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with source_path.open("rb") as stream, target.open("xb") as output:
            while block := stream.read(8 * 2**20):
                output.write(block)
            output.flush()
            os.fsync(output.fileno())
        require(identity(target) == expected, f"retained bytes differ: {name}")
    require(inventory(root) == before and inventory(destination) == before, "complete child retention differs")
    return before


def close_group(pgid: int) -> None:
    if group_absent(pgid, processes()):
        return
    for signum, seconds in ((signal.SIGTERM, 10), (signal.SIGKILL, 5)):
        try:
            os.killpg(pgid, signum)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if group_absent(pgid, processes()):
                return
            time.sleep(0.05)
    raise RuntimeError("owned process group remains after cancellation")


class Owner(Record):
    pid: int
    config_sha256: str
    token: str


def acquire(paths: tuple[Path, ...], owner: Owner) -> None:
    require(len(set(paths)) == len(paths) and bool(paths), "distinct shared locks required")
    require(all(not p.exists() and not p.is_symlink() for p in paths), "shared gate/queue lock is occupied")
    for path in paths:
        path.mkdir()  # Exclusive creation; any failure retains earlier owned locks.
        write(path / "owner.json", owner, fresh=True)


def release(paths: tuple[Path, ...], owner: Owner) -> None:
    for path in paths:
        require(Owner.model_validate(load(path / "owner.json")) == owner, "lock owner changed")
        require({p.name for p in path.iterdir()} == {"owner.json"}, "unexpected lock member")
    for path in paths:
        (path / "owner.json").unlink()
        path.rmdir()


def require_regular_mode(path: Path) -> None:
    require(stat.S_ISREG(path.lstat().st_mode), "requires a regular file")
