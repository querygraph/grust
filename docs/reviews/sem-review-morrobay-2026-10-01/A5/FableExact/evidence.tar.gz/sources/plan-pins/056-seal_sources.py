"""Seal staged sources and their declared dependencies; never read data or binaries."""
from __future__ import annotations

import argparse
import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BASE = Path(__file__).parent.resolve()
ORACLE = BASE.with_name('A5-native-matched-oracle01')
PREP = BASE.with_name('A5-native-matched-preparation01')
REPO = Path('/Volumes/Apo/graph-tests/workspaces/sem-review-20261001/a5-matched-d0e4e422a')
HARNESS_ROOT = BASE.with_name('B7-native-preparation01')/'frozen-harness'
SOURCE = 'd0e4e422afdea967126ae7b9506e04c9f1812b97'
RUNTIME = '9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3'
HARNESS = '6ae2e43a903c2cee02da170465c922c72b76198e'


def pin(path: Path) -> dict[str, int | str]:
    if not path.is_file() or path.is_symlink():
        raise ValueError(f'unsafe/missing staged file: {path}')
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def write_new(path: Path, value: dict[str, Any]) -> None:
    with path.open('x') as stream:
        stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')


def seal() -> None:
    oracle=json.loads((ORACLE/'freeze.json').read_text())
    oracle_files=oracle['files']
    production={name:value['sha256'] for name,value in oracle_files.items()
                if name.startswith('matched_') and name.endswith('.py')}
    if set(production)!={'matched_models.py','matched_io.py','matched_numeric.py','matched_readers.py','matched_compare.py','matched_oracle.py'}:
        raise ValueError('independent oracle freeze inventory incomplete')
    for name,digest in production.items():
        if pin(ORACLE/name)['sha256']!=digest:
            raise ValueError('independent oracle changed')
    io_path=BASE/'native_io.py'
    children={name:pin(BASE/'support'/name)['sha256'] for name in ['engine_pecan.py','engine_graphframes.py','shutdown.py']}
    io_source=io_path.read_text().splitlines()
    for index,line in enumerate(io_source):
        if line.startswith('FROZEN:'):
            io_source[index]='FROZEN: dict[str, str] = '+repr(children)
        elif line.startswith('ORACLE_FROZEN:'):
            io_source[index]='ORACLE_FROZEN: dict[str, str] = '+repr(production)
    io_path.write_text('\n'.join(io_source)+'\n')
    source_names=['Cargo.toml','Cargo.lock','examples/extensions/requirements.lock',
                  'examples/extensions/graph-algorithms/pyproject.toml',
                  'crates/sail-execution/src/worker_manager/process.rs',
                  'crates/sail-execution/src/worker_manager/process_command.rs',
                  'crates/sail-session/src/extensions/mod.rs']
    source_names += [str(path.relative_to(REPO)) for path in sorted((REPO/'examples/extensions/graph-algorithms/src/pyspark_pecan').glob('*.py'))]
    sources={name:{**pin(REPO/name),'commit':SOURCE} for name in source_names}
    support={name:pin(BASE/'support'/name) for name in ['engine_pecan.py','engine_graphframes.py','shutdown.py','test_engine_pecan.py']}
    harness={name:pin(HARNESS_ROOT/'examples/extensions/benchmarks'/name) for name in ['runtime.py','measurement.py']}
    write_new(BASE/'support-manifest.json',{'schema_version':1,'observed_utc':datetime.now(timezone.utc).isoformat(),
        'status':'frozen_source_preparation_not_runtime_qualified','source':SOURCE,'compiled_runtime_source':RUNTIME,
        'graphframes_source':'b4da56dabe20bba8e29563e06acc5179b2113ce3','harness':HARNESS,
        'source_tree':'3378fb720ef23d357d7a92ad280e63dce7605edf',
        'source_admission':pin(PREP/'source-admission.json'),'source_pins':sources,'frozen_harness_files':harness,
        'support_files':support,'frozen_helper_pins':children,'physical_oracle':production,
        'scope':['exact d0 Python controller/native9f via scoped empty Rust diff; no new build',
                 'local16threads/partitions16/pools30GiB; software settings, no OS cap',
                 'WCC randomized seed42/canonical/cap100; dynamic PR reset.15/tol.01/ten fixedsteps/normalize; directed frontier BFS cap1000',
                 'BFS raw id/hops only; NULL vs GFINT32MAX unreachable; no scalar casts',
                 'parent Popen through waited child exit incl Python startup/config/imports; oracle/retention outside timer',
                 'reference preparation physical/domain validation only; full candidate comparison after waited closure',
                 'root owns all actual engine jobs; source preparation is not runtime qualification']})


def freeze() -> None:
    names=['native_models.py','native_io.py','supervise_native.py','source_gate.py','seal_sources.py',
           'test_native.py','test_graphframes.py','test_shutdown.py','HANDOFF.txt','support-manifest.json']
    names += ['support/'+name for name in ['engine_pecan.py','engine_graphframes.py','shutdown.py','test_engine_pecan.py']]
    gate_path=BASE/'source-gates03/receipt.json'
    gate=json.loads(gate_path.read_text())
    if gate['outcome']!='passed' or gate['before']!=gate['after']:
        raise ValueError('closed unchanged successful source gate required')
    for name,identity in gate['after'].items():
        observed=pin(BASE/name)
        if observed['sha256']!=identity['sha256'] or observed['bytes']!=identity['bytes']:
            raise ValueError('source changed after final gate')
    names += ['source-controls-attempt01.json','body-readiness01.json']
    for directory in ['source-gates02','source-gates03']:
        names += [str(path.relative_to(BASE)) for path in sorted((BASE/directory).glob('*.log'))]
        names.append(directory+'/receipt.json')
    write_new(BASE/'freeze.json',{'schema_version':1,'observed_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'immutable helper source readiness, closed source gates passed; no actual cell represented',
        'source_gate':pin(gate_path),
        'files':{name:pin(BASE/name) for name in names},'oracle_freeze':pin(ORACLE/'freeze.json')})
    with tarfile.open(BASE/'source-only.tar.gz','x:gz') as archive:
        for name in [*names,'freeze.json']:
            archive.add(BASE/name,arcname=name,recursive=False)
    write_new(BASE/'archive-identity.json',pin(BASE/'source-only.tar.gz'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['seal','freeze'])
    stage=parser.parse_args().stage
    if stage=='seal':
        seal()
    else:
        freeze()
