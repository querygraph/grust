"""Bind actual closed native campaign evidence to the frozen physical audit."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import sys
BASE=Path('/Volumes/Apo/graph-tests/results/sem-review-20261001')
ROOT=BASE/'A5-native-fable-exact-run01'
POST=BASE/'A5-native-fable-exact-post01'
sys.path[:0]=[str(ROOT),str(BASE/'A5-native-fable-exact-preparation01/source-aid'),str(BASE/'A5-native-matched-supervisor01'),str(POST)]
import run_campaign as owner
import post_models as models

def pin(path):
 raw=path.read_bytes()
 return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def fresh(path, value):
 with path.open('x') as f: json.dump(value,f,indent=2); f.write('\n')
q=owner.Receipt.model_validate_json((ROOT/'queue.json').read_bytes())
assert q.outcome=='completed_exact_Fable_scripts_pending_physical_audit' and not q.errors and q.traceback is None
assert all([q.immutable_pins_before_after_equal,q.source_repositories_before_after_equal,q.all_owned_process_groups_absent,q.locks_released]) and not q.forced_cancellation
try: os.kill(q.owner_pid,0)
except ProcessLookupError: pass
else: raise AssertionError('owner remains')
plan=owner.Plan.model_validate_json((ROOT/'plan.json').read_bytes())
assert pin(ROOT/'plan.json')==q.configuration.model_dump(mode='json')
owner.immutable(plan)
assert not any(p.exists() for p in plan.locks)
pre=json.loads((BASE/'A5-native-fable-exact-preparation01/native-admission01.json').read_text())
review=Path('/tmp/sem-native-fable-whole-campaign-independent-source-review01.json')
assert pin(review)['sha256']=='8da56104a56544b226aee7b38123cd11ea56eae12fe55fc7496d60002bba6d1d'
shutil.copyfile(review,ROOT/'physical-audit-source-review01.json')
a=json.loads((POST/'admission-template.json').read_text())
a['campaign_configuration']=pin(ROOT/'plan.json')
a['input_vertices']={d:v['vertices'] for d,v in pre['inputs'].items()}
a['input_edges']={d:v['edges'] for d,v in pre['inputs'].items()}
a['evidence']=[pin(p) for p in [ROOT/'queue.json',BASE/'A5-native-fable-exact-preparation01/native-admission01.json',BASE/'A5-native-fable-exact-preparation01/source-aid/freeze.json',BASE/'A5-native-fable-exact-preparation01/source-aid/generated01/adaptation-proof.json',ROOT/'owner-source-freeze01.json',ROOT/'physical-audit-source-review01.json',pre and Path(pre['build_receipt']['path']),Path(pre['client_receipt']['path'])]]
a['observed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
models.Admission.model_validate_json(json.dumps(a))
fresh(ROOT/'source-input-admission.json',a)
c=json.loads((POST/'config-template.json').read_text())
c['campaign_configuration']=pin(ROOT/'plan.json'); c['admission']=pin(ROOT/'source-input-admission.json')
for d,s in zip(c['datasets'],q.states,strict=True):
 assert d['dataset']==s.dataset and s.returncode==0 and s.outcome=='completed_script_pending_physical_audit'
 assert s.records and s.closure
 assert not owner.group_members(s.pgid)
 d['vertices']=pre['inputs'][s.dataset]['vertices']; d['edges']=pre['inputs'][s.dataset]['edges']
 d['records']=s.records.model_dump(mode='json'); d['closure']=s.closure.model_dump(mode='json')
models.Config.model_validate_json(json.dumps(c))
fresh(ROOT/'post-configuration01.json',c)
print(json.dumps({'outcome':'actual_closed_campaign_bound_to_frozen_physical_audit','configuration':pin(ROOT/'post-configuration01.json')}))
