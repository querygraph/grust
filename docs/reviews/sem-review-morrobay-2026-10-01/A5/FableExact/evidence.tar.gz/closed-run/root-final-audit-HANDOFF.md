# Final whole-campaign closure audit

Source-only preparation. Root executes this once the physical post audit has
finished and its recorded PID is absent. This source has not been executed
against production metadata, native processes or payloads by its author.

Use the isolated bootstrap so all frozen sibling imports have explicit paths:

```sh
/tmp/sem-output-oracle-venv/bin/python -I -B -c 'import runpy,sys; r,p,a,h=sys.argv[1:5]; sys.path[:0]=[r,p,a,h]; sys.argv=[r+"/root_final_audit.py"]+sys.argv[5:]; runpy.run_path(sys.argv[0],run_name="__main__")' /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-fable-exact-run01 /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-fable-exact-post01 /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-fable-exact-preparation01/source-aid /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-matched-supervisor01 --plan /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-fable-exact-run01/plan.json --post-audit /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-fable-exact-post-result01/receipt.json --receipt /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-fable-exact-run01/root-final-audit01.json
```

The final receipt must be fresh. A checking or failed receipt is never accepted
or overwritten by a retry. The positive receipt follows the report builder's
`RootAudit` schema exactly and includes this source's actual byte/hash pin.

The audit binds the owner plan/queue, both waited parent closure receipts,
actual original call records, post configuration and positive 48/6/42 receipt.
Every output's full-domain, raw schema, numeric scope and retention flags must
pass. Six original engine medians and all post summaries are recomputed. The
owner and physical post launch PIDs, both parent PGIDs, configured native
binary commands and shared locks must be absent.

It calls frozen `run_campaign.immutable(plan)`: this performs the owner plan's
prescribed full source/input/client/binary identity closure. It reads no result
Parquet contents, and does not repeat the physical post audit or retention hash
scan. All retained raw-file evidence remains bound through the post receipt.
Closure covers whole dataset campaigns; no per-call exit proof is invented.

Only repository Ruff and strict mypy were run by the author. Failed initial
Ruff output is retained under `root-final-source-gates01`. Actual process and
identity checks, final audit execution and publication remain root-owned.
