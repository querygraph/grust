"""Final metadata/process closure for the original 48-call native Fable campaign.

The owner immutable() check reuses its prescribed full identity closure. No
Parquet contents or retained result payloads are opened by this final audit.
"""

from __future__ import annotations

import argparse
import os
import time
from pathlib import Path
from typing import Literal

import adapt_exact as adapter
import native_io as native
import native_models
import post_audit as physical
import post_io as io
import post_models as post
import run_campaign as owner
from pydantic import TypeAdapter

OWNER_SHA = "8fa24c113e9d7a63cf5b94d9e77075d82df707c4f84bc4c40a7a7b55450e3c39"
POST_FREEZE_SHA = "7d980c8413cc080eb1e8c5c38b63c83e9af650bbd64a9cb7a16da93a322bbddd"
NATIVE_SHA = "d00012699e754c16bba3d38b324881962057caec6fd22093ce0a2aae88046a8e"
BASE = Path("/Volumes/Apo/graph-tests/results/sem-review-20261001")
CALLS = TypeAdapter(list[post.Call])


class RootAudit(post.Model):
    outcome: Literal["passed_independent_exact_Fable_native_closure_and_metadata_audit"]
    observed_utc: str
    queue_pin: post.Pin
    plan_pin: post.Pin
    post_audit_pin: post.Pin
    source_pin: post.Pin
    owner_pid: post.Positive
    owner_pid_absent: Literal[True]
    owned_parent_pids: list[int]
    owned_parent_pids_and_pgids_absent: Literal[True]
    owned_processes_remaining: list[int]
    matching_native_servers_remaining: list[int]
    shared_locks_absent: Literal[True]
    immutable_source_input_client_closure: Literal[True]
    all48_outputs_retained_and_qualified: Literal[True]
    primary_median_ratios: dict[str, float]


class Failure(post.Model):
    outcome: Literal["checking", "failed"]
    observed_utc: str
    source_pin: post.Pin
    plan: Path
    post_audit: Path
    error: str | None = None


class Launch(post.Model):
    observed_utc: str
    pid: post.Positive
    command: list[str]
    scope: str


def save(path: Path, record: RootAudit | Failure) -> None:
    temporary = path.with_name(path.name + ".writing")
    with temporary.open("x") as stream:
        stream.write(record.model_dump_json(indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def same_pin(actual: native_models.Pin, expected: post.Pin) -> bool:
    return (actual.path, actual.bytes, actual.sha256) == (expected.path, expected.bytes, expected.sha256)


def origins(plan: owner.Plan, config: post.Config, deadline: io.Deadline) -> None:
    io.require(Path(str(owner.__file__)) == plan.source.path and plan.source.sha256 == OWNER_SHA,
               "frozen owner import/source differs")
    modules = (native, native_models, adapter)
    pins = {p.path: p for p in plan.immutable_pins}
    for module in modules:
        path = Path(str(module.__file__))
        io.require(path in pins, "owner dependency is outside its immutable source set")
        native.verify(pins[path])
    io.require(pins[Path(str(native.__file__))].sha256 == NATIVE_SHA, "frozen native IO differs")
    io.require(config.audit_source_freeze.sha256 == POST_FREEZE_SHA, "frozen physical audit identity differs")
    freeze = post.Freeze.model_validate_json(io.metadata(config.audit_source_freeze, deadline))
    modules_post = (post, io, physical)
    for module in modules_post:
        path = Path(str(module.__file__))
        io.require(path.parent == config.audit_source_freeze.path.parent and path.name in freeze.production_helpers,
                   "physical audit import origin differs")
    io.require(set(freeze.production_helpers) == set(physical.PRODUCTION), "physical helper set differs")
    for name, identity in freeze.production_helpers.items():
        io.verify(post.Pin(path=config.audit_source_freeze.path.parent / name,
                           bytes=identity.bytes, sha256=identity.sha256), deadline)


def output_closed(record: post.OutputAudit, dataset: post.DatasetConfig,
                  config: post.Config, expected: post.Call) -> None:
    io.require(record.dataset == dataset.dataset and record.call == expected, "physical call/order binding differs")
    preparation = expected.cell() == f"{expected.contrast}-b0-p0-graphframes"
    io.require(record.reference_preparation_only is preparation
               and record.reference_cell == f"{expected.contrast}-b0-p0-graphframes", "reference role differs")
    io.require(record.source_directory == dataset.results / expected.cell() / "result"
               and record.retained_directory == config.output / "raw" / dataset.dataset / expected.cell() / "result",
               "raw source/retention paths differ")
    io.require(record.qualified and not record.errors and record.original_domain_complete_unique
               and record.retained_copy_and_ssd_rehash_passed and record.rows == dataset.expected_rows,
               "full-domain retained output is unqualified")
    parquet = {name for name in record.raw_files if name.endswith(".parquet")}
    io.require(bool(parquet) and {f.file for f in record.physical_schemas} == parquet
               and len(record.physical_schemas) == len(parquet)
               and sum(f.footer_rows for f in record.physical_schemas) == dataset.expected_rows,
               "full physical file/footer coverage differs")
    fields = ({"id": "int64", "component": "int64"} if expected.contrast == "wcc" else
              {"id": "int64", "pagerank": "double"} if expected.contrast == "pagerank" else
              {"id": "int64", "distance": "double", "hops": "int64", "parent": "int64"}
              if expected.engine == "pecan" else {"id": "int64", f"dist_{dataset.source}": "int32"})
    for file in record.physical_schemas:
        io.require(len(file.fields) == len(fields) and {f.name: f.arrow_type for f in file.fields} == fields,
                   "exact raw physical schema differs")
    io.require(record.numeric_comparison_performed is not preparation
               and record.compared_rows == (0 if preparation else dataset.expected_rows)
               and record.mismatches == (None if preparation else 0), "numeric reference/comparison scope differs")
    if expected.contrast == "wcc":
        io.require(record.canonical_labels_passed is True and record.components is not None and record.components > 0,
                   "canonical signed WCC labels unavailable")
        io.require((record.false_merge_groups, record.false_split_groups) ==
                   ((None, None) if preparation else (0, 0)), "full WCC partition comparison differs")
    elif expected.contrast == "bfs":
        io.require(record.reachable is not None and record.reachable > 0 and record.unreachable is not None
                   and record.reachable + record.unreachable == dataset.expected_rows
                   and record.maximum_hops is not None and record.maximum_hops >= 0,
                   "full directed BFS hop domain differs")
    elif not preparation:
        io.require(record.maximum_absolute_error_hex is not None, "full PR difference diagnostic missing")


def processes_closed(plan: owner.Plan, queue: owner.Receipt, post_pid: int) -> None:
    table = native.processes()
    parents = {s.parent_pid for s in queue.states}
    groups = {s.pgid for s in queue.states}
    io.require(all(row.pid not in {queue.owner_pid, post_pid} and row.pid not in parents and row.pgid not in groups
                   for row, _ in table), "recorded owner/parent/process group remains")
    binaries = [p.path for p in plan.immutable_pins if p.path.name in {"sail", "graphframes"}
                and p.path.parent.name == "release"]
    io.require(len(binaries) == 2 and {b.name for b in binaries} == {"sail", "graphframes"},
               "two exact native binaries required")
    io.require(not any(text == str(binary) or text.startswith(str(binary) + " ")
                       for _, text in table for binary in binaries), "matching native binary process remains")
    io.require(plan.locks == (BASE / "gate.lock", BASE / "serial-queue.lock")
               and all(not p.exists() and not p.is_symlink() for p in plan.locks), "shared locks remain/differ")


def audit(plan_path: Path, post_path: Path, source: post.Pin, deadline: io.Deadline) -> RootAudit:
    plan_pin = io.pin(plan_path, deadline)
    plan = owner.Plan.model_validate_json(io.metadata(plan_pin, deadline))
    io.require(plan_path == plan.root / "plan.json" and Path(__file__).parent == plan.root,
               "actual owner plan/root differs")
    queue_pin = io.pin(plan.root / "queue.json", deadline)
    queue = owner.Receipt.model_validate_json(io.metadata(queue_pin, deadline))
    io.require(same_pin(queue.configuration, plan_pin)
               and queue.outcome == "completed_exact_Fable_scripts_pending_physical_audit"
               and queue.finished_utc is not None and not queue.errors and queue.traceback is None
               and queue.immutable_pins_before_after_equal and queue.source_repositories_before_after_equal
               and queue.all_owned_process_groups_absent and queue.locks_released and not queue.forced_cancellation,
               "whole campaign owner is not positively closed")
    io.require([s.dataset for s in queue.states] == ["cit-Patents", "graph500-24"]
               and [s.recipe for s in queue.states] == plan.recipes, "two serial state/recipe bindings differ")
    post_pin = io.pin(post_path, deadline)
    receipt = post.Receipt.model_validate_json(io.metadata(post_pin, deadline))
    config = post.Config.model_validate_json(io.metadata(receipt.configuration, deadline))
    io.require(receipt.outcome == "passed_full_physical_whole_campaign" and receipt.admission_passed
               and not receipt.errors and receipt.expected_calls == receipt.qualified_outputs == len(receipt.outputs) == 48
               and receipt.references_prepared == 6 and receipt.nonreference_comparisons == 42
               and receipt.original_vertex_domain_verified == {"cit-Patents": True, "graph500-24": True}
               and config.campaign_configuration == receipt.campaign_configuration == plan_pin
               and post_path == config.output / "receipt.json", "physical post audit is not positively bound/closed")
    launch_pin = io.pin(plan.root / "launch01.json", deadline)
    launch = Launch.model_validate_json(io.metadata(launch_pin, deadline))
    post_launch_pin = io.pin(plan.root / "post-launch01.json", deadline)
    post_launch = Launch.model_validate_json(io.metadata(post_launch_pin, deadline))
    io.require(launch.pid == queue.owner_pid and launch.command[-2:] == ["--plan", str(plan_path)]
               and post_launch.command[-2:] == ["--config", str(receipt.configuration.path)],
               "observed owner/post launch bindings differ")
    origins(plan, config, deadline)
    owner.immutable(plan)  # Existing prescribed source/input/client/binary hashes; no result payload reads.
    computed: list[post.Ratios] = []
    offset = 0
    for state, dataset in zip(queue.states, config.datasets, strict=True):
        io.require(state.outcome == "completed_script_pending_physical_audit" and state.returncode == 0
                   and state.parent_pid is not None and state.parent_pid == state.pgid
                   and state.records is not None and same_pin(state.records, dataset.records)
                   and state.closure is not None and same_pin(state.closure, dataset.closure),
                   "closed dataset state differs from physical configuration")
        closure = post.Closure.model_validate_json(io.metadata(dataset.closure, deadline))
        io.require(closure.dataset == dataset.dataset and closure.parent_pid == state.parent_pid
                   and closure.pgid == state.pgid and closure.closed_utc == state.closed_utc
                   and closure.campaign_configuration == plan_pin, "whole-parent closure binding differs")
        physical.closed_now(closure)
        calls = CALLS.validate_json(io.metadata(dataset.records, deadline))
        physical.validate_calls(calls, dataset)
        computed.extend(physical.ratios(dataset.dataset, calls))
        for call in calls:
            output_closed(receipt.outputs[offset], dataset, config, call)
            offset += 1
    io.require(offset == 48 and receipt.ratios == computed, "six recomputed original engine median summaries differ")
    for pin in receipt.metadata_pins:
        io.verify(pin, deadline)
    processes_closed(plan, queue, post_launch.pid)
    for pin in (source, plan_pin, queue_pin, post_pin, receipt.configuration, launch_pin, post_launch_pin):
        io.verify(pin, deadline)
    return RootAudit(
        outcome="passed_independent_exact_Fable_native_closure_and_metadata_audit", observed_utc=io.utc(),
        queue_pin=queue_pin, plan_pin=plan_pin, post_audit_pin=post_pin, source_pin=source,
        owner_pid=queue.owner_pid, owner_pid_absent=True,
        owned_parent_pids=[s.parent_pid for s in queue.states if s.parent_pid is not None],
        owned_parent_pids_and_pgids_absent=True, owned_processes_remaining=[], matching_native_servers_remaining=[],
        shared_locks_absent=True, immutable_source_input_client_closure=True,
        all48_outputs_retained_and_qualified=True,
        primary_median_ratios={f"{r.dataset}-{r.algorithm}": r.fable_ratio_of_engine_medians for r in computed},
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--post-audit", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    deadline = io.Deadline(time.monotonic(), 600.0)
    source = io.pin(Path(__file__), deadline)
    io.safe(args.receipt)
    io.require(not args.receipt.exists() and args.receipt.parent == Path(__file__).parent,
               "fresh final receipt directly inside campaign root required")
    save(args.receipt, Failure(outcome="checking", observed_utc=io.utc(), source_pin=source,
                             plan=args.plan, post_audit=args.post_audit))
    try:
        result = audit(args.plan, args.post_audit, source, deadline)
    except Exception as error:  # noqa: BLE001 - preserve a failed final audit receipt.
        save(args.receipt, Failure(outcome="failed", observed_utc=io.utc(), source_pin=source,
                                 plan=args.plan, post_audit=args.post_audit,
                                 error=f"{type(error).__name__}: {error}"))
        print("failed " + str(args.receipt))
        return 1
    save(args.receipt, result)
    print(result.outcome + " " + str(args.receipt))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
