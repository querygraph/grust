"""Bind only closed small source/metadata files to the frozen report factory."""
from pathlib import Path
import hashlib
import json
import os

BASE=Path('/Volumes/Apo/graph-tests/results/sem-review-20261001')
ROOT=BASE/'A5-native-fable-exact-run01'
FACTORY=BASE/'A5-native-fable-exact-report01'
POST=BASE/'A5-native-fable-exact-post01'
SUFFIX={'.json','.jsonl','.py','.md','.log','.txt','.c','.h','.rs','.toml','.lock','.sh','.yaml','.yml','.patch'}

def pin(path):
 assert path.is_absolute() and path.is_file() and not path.is_symlink()
 assert path.suffix in SUFFIX or path.name.endswith('.tar.gz')
 assert path.stat().st_size <= 32*2**20
 raw=path.read_bytes()
 return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

files={}
for directory,prefix in [(ROOT,'closed-run'),(BASE/'A5-native-fable-exact-preparation01','preparation'),(POST,'post-source'),(FACTORY,'factory-source'),(BASE/'A5-native-fable-exact-post-result01','physical-post-metadata')]:
 for current,dirs,names in os.walk(directory):
  dirs[:]=sorted(d for d in dirs if d not in {'raw','__pycache__','.git'})
  for name in sorted(names):
   p=Path(current)/name
   if p.suffix in SUFFIX or p.name.endswith('.tar.gz'):
    files[f'{prefix}/{p.relative_to(directory).as_posix()}']=pin(p)
pre=BASE/'A5-native-fable-exact-preparation01'
files['original/host-baseline/baseline.c']=pin(pre/'original/host-baseline/baseline.c')
files['original/A2-local/a2_local.py']=pin(pre/'original/A2-local/a2_local.py')
files['metadata/vm-diagnostic-user-decision01.json']=pin(ROOT/'vm-diagnostic-user-decision01.json')
audit=json.loads((BASE/'A5-native-fable-exact-post-result01/receipt.json').read_text())
assert audit['outcome']=='passed_full_physical_whole_campaign'
for o in audit['outputs']:
 p=Path(o['source_directory']).parent/('server.log' if o['call']['engine']=='pecan' else 'engine.log')
 files[f'cell-logs/{o["dataset"]}/{p.parent.name}/{p.name}']=pin(p)
for p in (BASE/'native-optimized-build01').iterdir():
 if p.is_file() and (p.suffix in {'.json','.log'}):files[f'optimized-build/{p.name}']=pin(p)
for p in [(BASE/'A5-native-supervisor01/native-client-admission01.json'),*(BASE/'A5-native-matched-preparation01').glob('*-input-admission.json')]:
 files[f'prior-admission/{p.name}']=pin(p)
c={'factory_freeze':pin(FACTORY/'freeze.json'),'queue':pin(ROOT/'queue.json'),'plan':pin(ROOT/'plan.json'),'launch':pin(ROOT/'launch01.json'),'post_audit':pin(BASE/'A5-native-fable-exact-post-result01/receipt.json'),'post_configuration':pin(ROOT/'post-configuration01.json'),'root_audit':pin(ROOT/'root-final-audit01.json'),'post_models':pin(POST/'post_models.py'),'output':str(BASE/'A5-native-fable-exact-package01'),'files':files}
assert not Path(c['output']).exists()
with (ROOT/'report-configuration01.json').open('x') as f:json.dump(c,f,indent=2);f.write('\n')
print(json.dumps({'outcome':'closed_small_metadata_configuration_prepared','files':len(files),'bytes':sum(x['bytes'] for x in files.values()),'configuration':pin(ROOT/'report-configuration01.json')}))
