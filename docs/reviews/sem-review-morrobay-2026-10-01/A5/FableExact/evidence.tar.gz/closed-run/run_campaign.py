"""Serial owner of two unchanged Fable native scripts; whole-process closure only."""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import traceback
import uuid
from pathlib import Path
from types import FrameType
from typing import Literal

import adapt_exact as adapter
import native_io as io
from native_models import Pin, Record
from pydantic import Field

Dataset = Literal["cit-Patents", "graph500-24"]


class Repository(Record):
    path: Path
    commit: str
    tree: str
    status: Literal[""] = ""


class Plan(Record):
    root: Path
    source: Pin
    recipes: list[Pin]
    immutable_pins: list[Pin]
    repositories: list[Repository]
    locks: tuple[Path, Path]


class Exit(Record):
    dataset: Dataset
    parent_pid: int
    pgid: int
    returncode: int
    wait_completed: bool
    closed_utc: str
    owned_processes_remaining: list[int]
    campaign_configuration: Pin


class State(Record):
    dataset: Dataset
    outcome: str = "pending"
    parent_pid: int | None = None
    pgid: int | None = None
    returncode: int | None = None
    started_utc: str | None = None
    closed_utc: str | None = None
    recipe: Pin
    closure: Pin | None = None
    records: Pin | None = None


class Receipt(Record):
    started_utc: str
    owner_pid: int
    configuration: Pin
    outcome: str = "running"
    finished_utc: str | None = None
    states: list[State] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    traceback: str | None = None
    immutable_pins_before_after_equal: bool = False
    source_repositories_before_after_equal: bool = False
    all_owned_process_groups_absent: bool = False
    locks_released: bool = False
    forced_cancellation: bool = False
    scope: str = "Whole-script exit and process-group closure; no per-call PID or Sail return-code observation. Graph outputs qualify only in a later physical audit."


def pin(path: Path) -> Pin:
    return Pin(path=path, **io.identity(path).model_dump())


def command(repo: Path, *args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=repo, text=True, timeout=30
    ).strip()


def immutable(plan: Plan) -> None:
    io.verify(plan.source)
    io.require(plan.source.path == Path(__file__), "owner source path differs")
    for expected in [*plan.recipes, *plan.immutable_pins]:
        io.verify(expected)
    for source in plan.repositories:
        observed = Repository.model_validate(
            {
                "path": source.path,
                "commit": command(source.path, "rev-parse", "HEAD"),
                "tree": command(source.path, "rev-parse", "HEAD^{tree}"),
                "status": command(source.path, "status", "--porcelain"),
            }
        )
        io.require(observed == source, "exact clean source checkout differs")


def group_members(pgid: int) -> list[int]:
    return [row.pid for row, _ in io.processes() if row.pgid == pgid or row.pid == pgid]


def interrupted(signum: int, _frame: FrameType | None) -> None:
    raise InterruptedError(f"native campaign interrupted by signal {signum}")


def run(configuration: Path) -> int:
    configuration_pin = pin(configuration)
    plan = Plan.model_validate_json(configuration.read_bytes())
    io.require(
        plan.root.is_absolute() and configuration.parent == plan.root,
        "campaign/configuration directory differs",
    )
    io.require(len(plan.recipes) == 2, "two serial dataset recipes required")
    immutable(plan)
    launches = [
        adapter.LaunchRecipe.model_validate_json(p.path.read_bytes())
        for p in plan.recipes
    ]
    io.require(
        [r.dataset for r in launches] == ["cit-Patents", "graph500-24"],
        "dataset order differs",
    )
    for launch in launches:
        io.require(
            not launch.root.exists() and not launch.out.exists(),
            "fresh source script destinations required",
        )
        io.require(
            launch.out.parent == plan.root / launch.dataset,
            "original records destination differs",
        )
        io.require(
            launch.expected_calls == 24 and "--no-snapshot" in launch.argv,
            "exact native recipe differs",
        )
    owner = io.Owner(
        pid=os.getpid(), config_sha256=configuration_pin.sha256, token=uuid.uuid4().hex
    )
    receipt = Receipt(
        started_utc=io.utc(),
        owner_pid=os.getpid(),
        configuration=configuration_pin,
        states=[
            State(
                dataset="cit-Patents" if r.dataset == "cit-Patents" else "graph500-24",
                recipe=p,
            )
            for r, p in zip(launches, plan.recipes, strict=True)
        ],
    )
    status_path = plan.root / "queue.json"
    io.require(not status_path.exists(), "fresh campaign receipt required")
    io.write(status_path, receipt, fresh=True)
    acquired = False
    process: subprocess.Popen[bytes] | None = None
    try:
        io.acquire(plan.locks, owner)
        acquired = True
        for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(signum, interrupted)
        for state, launch in zip(receipt.states, launches, strict=True):
            io.verify(state.recipe)
            adapter.require_pin(launch.original)
            adapter.require_pin(launch.adapted)
            io.require(
                not launch.root.exists() and not launch.out.exists(),
                "script would overwrite an earlier attempt",
            )
            output = launch.out.parent
            output.mkdir(exist_ok=False)
            environment = dict(os.environ)
            environment.update(launch.environment)
            for name in ("PYTHONHOME", "PYTHONPATH"):
                environment.pop(name, None)
            state.started_utc = io.utc()
            state.outcome = "running"
            with (
                (output / "stdout.log").open("xb") as stdout,
                (output / "stderr.log").open("xb") as stderr,
            ):
                process = subprocess.Popen(
                    launch.argv,
                    cwd=output,
                    env=environment,
                    stdin=subprocess.DEVNULL,
                    stdout=stdout,
                    stderr=stderr,
                    start_new_session=True,
                )
                state.parent_pid = process.pid
                state.pgid = process.pid
                io.write(status_path, receipt)
                state.returncode = process.wait(timeout=1800)
            state.closed_utc = io.utc()
            remaining = group_members(process.pid)
            closure = Exit(
                dataset=state.dataset,
                parent_pid=process.pid,
                pgid=process.pid,
                returncode=state.returncode,
                wait_completed=True,
                closed_utc=state.closed_utc,
                owned_processes_remaining=remaining,
                campaign_configuration=configuration_pin,
            )
            closure_path = output / "closure.json"
            io.write(closure_path, closure, fresh=True)
            state.closure = pin(closure_path)
            io.require(
                state.returncode == 0,
                "original script failed; preserve logs and partial outputs",
            )
            io.require(not remaining, "owned process group remains after script exit")
            io.require(launch.out.is_file(), "script has no complete original records")
            state.records = pin(launch.out)
            state.outcome = "completed_script_pending_physical_audit"
            process = None
            io.write(status_path, receipt)
        immutable(plan)
        io.verify(configuration_pin)
        receipt.immutable_pins_before_after_equal = True
        receipt.source_repositories_before_after_equal = True
        receipt.all_owned_process_groups_absent = all(
            s.pgid is not None and not group_members(s.pgid) for s in receipt.states
        )
        io.require(
            receipt.all_owned_process_groups_absent, "final owned group closure differs"
        )
        io.release(plan.locks, owner)
        acquired = False
        receipt.locks_released = True
        receipt.outcome = "completed_exact_Fable_scripts_pending_physical_audit"
    except BaseException as error:
        receipt.outcome = "error"
        receipt.errors.append(repr(error))
        receipt.traceback = traceback.format_exc()
        if process is not None:
            remaining = group_members(process.pid)
            if remaining:
                receipt.forced_cancellation = True
                try:
                    io.close_group(process.pid)
                    process.wait(timeout=5)
                except BaseException as cleanup:
                    receipt.errors.append("owned cleanup: " + repr(cleanup))
        for state in receipt.states:
            if state.outcome == "pending":
                state.outcome = "skipped_after_preserved_failure"
            elif state.outcome == "running":
                state.outcome = "error"
        if acquired:
            receipt.errors.append(
                "owned locks preserved; root must audit before releasing"
            )
    receipt.finished_utc = io.utc()
    io.write(status_path, receipt)
    print(receipt.model_dump_json(include={"outcome", "errors", "states"}))
    return (
        0
        if receipt.outcome == "completed_exact_Fable_scripts_pending_physical_audit"
        else 1
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    return run(parser.parse_args().plan)


if __name__ == "__main__":
    raise SystemExit(main())
