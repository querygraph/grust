"""Outside-timer audit of 48 original Fable calls after both campaign parents close."""
from __future__ import annotations

import argparse
import math
import statistics
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import cast

import numpy as np
from pydantic import TypeAdapter

import post_io as io
import post_models as m
import post_readers as readers

PRODUCTION = ("post_models.py", "post_io.py", "post_readers.py", "post_audit.py")


def closed_now(closure: m.Closure) -> None:
    observed = datetime.fromisoformat(closure.closed_utc)
    io.require(observed.tzinfo is not None and observed.utcoffset() == timezone.utc.utcoffset(observed)
               and observed <= datetime.now(timezone.utc), "closed UTC must be observed in the past")
    done = subprocess.run(["/bin/ps", "-axo", "pid=,pgid="], capture_output=True, text=True, timeout=30, check=True)
    for line in done.stdout.splitlines():
        fields = line.split()
        io.require(len(fields) == 2, "unexpected process inventory row")
        pid, pgid = int(fields[0]), int(fields[1])
        io.require(pid != closure.parent_pid and pgid != closure.pgid, "campaign parent/process group remains")


def validate_calls(calls: list[m.Call], dataset: m.DatasetConfig) -> None:
    io.require(len(calls) == 24, "dataset must have all24 original calls")
    index = 0
    for algorithm in m.ORDER:
        for block in (0, 1):
            for position, engine in enumerate(m.ENGINES):
                call = calls[index]
                index += 1
                io.require((call.contrast, call.block, call.position, call.engine) ==
                           (algorithm, block, position, engine), "original algorithm/ABBA record order differs")
                io.require((call.oracle is None) == (position == 0), "original per-pair oracle presence differs")
                if call.oracle is not None:
                    expected = {"wcc": m.WccDeclared, "pagerank": m.PrDeclared, "bfs": m.BfsDeclared}[algorithm]
                    io.require(isinstance(call.oracle, expected) and call.oracle.rows == dataset.expected_rows,
                               "original inline oracle contract/cardinality differs")
                if engine == "pecan":
                    io.require(call.algorithm_seconds is not None and call.iterations is not None,
                               "original Pecan algorithm metadata missing")
                    assert call.iterations is not None
                    io.require(call.iterations <= {"wcc": 100, "bfs": 1000, "pagerank": 10}[algorithm],
                               "Pecan iteration cap exceeded")
                else:
                    io.require(call.algorithm_seconds is None and call.iterations is None,
                               "unexpected GF algorithm-only metadata")


def ratios(dataset: m.Dataset, calls: list[m.Call]) -> list[m.Ratios]:
    output: list[m.Ratios] = []
    for algorithm in m.ORDER:
        selected = [call for call in calls if call.contrast == algorithm]
        gf = statistics.median(call.seconds for call in selected if call.engine == "graphframes")
        pecan = statistics.median(call.seconds for call in selected if call.engine == "pecan")
        adjacent = tuple(ratio for i in (0, 4) for ratio in
                         (selected[i+1].seconds/selected[i].seconds, selected[i+2].seconds/selected[i+3].seconds))
        output.append(m.Ratios(dataset=dataset, algorithm=algorithm, graphframes_median_seconds=gf,
                              pecan_median_seconds=pecan, fable_ratio_of_engine_medians=pecan/gf,
                              adjacent_pair_ratios=adjacent,
                              adjacent_pair_geometric_mean=math.exp(statistics.mean(math.log(r) for r in adjacent))))
    return output


def admit(config: m.Config, receipt: m.Receipt, deadline: io.Deadline) -> None:
    freeze = m.Freeze.model_validate_json(io.metadata(config.audit_source_freeze, deadline))
    io.require(set(freeze.production_helpers) == set(PRODUCTION), "audit source freeze helper set differs")
    source_directory = Path(__file__).parent
    for name, identity in freeze.production_helpers.items():
        io.verify(m.Pin(path=source_directory/name, **identity.model_dump()), deadline)
    admission = m.Admission.model_validate_json(io.metadata(config.admission, deadline))
    io.require(admission.campaign_configuration == config.campaign_configuration, "admission campaign binding differs")
    io.require(bool(admission.evidence) and len(admission.evidence) <= 256, "admission metadata evidence required")
    io.require(set(admission.input_vertices) == set(m.SOURCE) == set(admission.input_edges), "both original input pins required")
    pins: list[tuple[str, m.Pin]] = [("audit-config.json", receipt.configuration),
        ("campaign-config.json", config.campaign_configuration), ("source-freeze.json", config.audit_source_freeze),
        ("source-gate.json", freeze.gate), ("source-input-admission.json", config.admission)]
    for index, evidence in enumerate(admission.evidence):
        pins.append((f"admission-evidence-{index:03d}.json", evidence))
    for dataset in config.datasets:
        io.require(admission.input_vertices[dataset.dataset] == dataset.vertices
                   and admission.input_edges[dataset.dataset] == dataset.edges, "root-admitted original V/E pins differ")
        closure = m.Closure.model_validate_json(io.metadata(dataset.closure, deadline))
        io.require(closure.dataset == dataset.dataset and closure.campaign_configuration == config.campaign_configuration,
                   "whole-campaign closure binding differs")
        closed_now(closure)
        pins.extend([(f"{dataset.dataset}-closure.json", dataset.closure),
                     (f"{dataset.dataset}-records.json", dataset.records)])
    for name, expected in pins:
        io.retain_metadata(expected, config.output, name, deadline)
        receipt.metadata_pins.append(expected)
    receipt.admission_passed = True


def compare(ids: readers.I64, actual: readers.Vector, reference: readers.Vector, record: m.OutputAudit,
            partitions: io.Partitions, numeric: io.Numeric, config: m.Config, deadline: io.Deadline) -> None:
    record.numeric_comparison_performed = True
    mismatches = 0
    maximum = 0.0
    bound = 1e-12
    lower, upper = np.nextafter(bound, -np.inf), np.nextafter(bound, np.inf)
    for start in range(0, len(ids), config.batch_rows):
        deadline.check()
        stop = min(len(ids), start+config.batch_rows)
        a, expected = actual[start:stop], reference[start:stop]
        if record.call.contrast == "pagerank":
            with np.errstate(over="ignore", invalid="ignore"):
                difference = np.abs(a-expected)
            failed = difference > bound
            for offset in np.flatnonzero((difference >= lower) & (difference <= upper)):
                deadline.check()
                failed[offset] = not numeric.within_bound(float(a[offset]), float(expected[offset]))
            maximum = max(maximum, float(difference.max(initial=0)))
        else:
            failed = a != expected
        mismatches += int(np.count_nonzero(failed))
        record.compared_rows += stop-start
    record.mismatches = mismatches
    if record.call.contrast == "pagerank":
        record.maximum_absolute_error_hex = maximum.hex()
    if record.call.contrast == "wcc":
        a64, e64 = cast(readers.I64, actual), cast(readers.I64, reference)
        record.false_merge_groups = partitions.conflicts(ids, a64, e64, deadline)
        record.false_split_groups = partitions.conflicts(ids, e64, a64, deadline)
        io.require(record.false_merge_groups == record.false_split_groups == 0, "WCC false merge/split groups")
    io.require(record.compared_rows == len(ids) and mismatches == 0, "full numeric per-original-vertex mismatch")


def inspect_output(ids: readers.I64 | None, reference: readers.Vector | None, dataset: m.DatasetConfig,
                   config: m.Config, record: m.OutputAudit, partitions: io.Partitions, numeric: io.Numeric,
                   deadline: io.Deadline) -> readers.Vector | None:
    value: readers.Vector | None = None
    try:
        record.raw_files = io.inventory(record.source_directory, deadline)
        io.require(ids is not None, "original domain was not admitted")
        assert ids is not None
        value = readers.values(ids, dataset, config, record, deadline)
        if record.call.contrast == "wcc":
            canonical = partitions.canonical(ids, cast(readers.I64, value), deadline)
            record.components = canonical.components
            record.canonical_labels_passed = canonical.mismatches == 0
            io.require(record.canonical_labels_passed, "WCC labels are not original component minima")
        if not record.reference_preparation_only:
            io.require(reference is not None, "first GF reference did not qualify")
            assert reference is not None
            compare(ids, value, reference, record, partitions, numeric, config, deadline)
    except Exception as error:
        record.errors.append(f"{type(error).__name__}: {error}")
    # Preserve raw bytes even when their physical/numeric contract failed.
    try:
        io.require(bool(record.raw_files), "raw inventory unavailable; no qualified retained copy")
        io.retain(record.source_directory, record.retained_directory, record.raw_files, deadline)
        record.retained_copy_and_ssd_rehash_passed = True
    except Exception as error:
        record.errors.append(f"retention {type(error).__name__}: {error}")
    record.qualified = not record.errors and record.original_domain_complete_unique and record.retained_copy_and_ssd_rehash_passed
    return value if record.qualified else None


def run(config: m.Config, configuration: m.Pin) -> m.Receipt:
    io.safe(config.output)
    protected = [configuration.path, config.campaign_configuration.path, config.admission.path, config.oracle_directory]
    protected.extend(path for d in config.datasets for path in (d.vertices.path, d.edges.path, d.records.path, d.results, d.closure.path))
    io.require(not any(config.output == p or config.output.is_relative_to(p) or p.is_relative_to(config.output)
                       for p in protected), "audit output overlaps protected originals/campaign paths")
    config.output.mkdir()
    started = io.utc()
    receipt = m.Receipt(started_utc=started, observed_utc=started, configuration=configuration,
                        campaign_configuration=config.campaign_configuration)
    path = config.output/"receipt.json"
    io.save(path, receipt)
    deadline = io.Deadline(time.monotonic(), config.deadline_seconds)
    try:
        admit(config, receipt, deadline)
        partitions, numeric = io.primitives(config.oracle_directory, deadline)
        for dataset in config.datasets:
            calls = TypeAdapter(list[m.Call]).validate_json(io.metadata(dataset.records, deadline))
            validate_calls(calls, dataset)
            receipt.ratios.extend(ratios(dataset.dataset, calls))
            ids: readers.I64 | None = None
            try:
                ids = readers.domain(dataset, config, deadline)
                receipt.original_vertex_domain_verified[dataset.dataset] = True
            except Exception as error:
                receipt.original_vertex_domain_verified[dataset.dataset] = False
                receipt.errors.append(f"{dataset.dataset} original domain {type(error).__name__}: {error}")
            for algorithm in m.ORDER:
                reference: readers.Vector | None = None
                reference_cell = f"{algorithm}-b0-p0-graphframes"
                for call in (c for c in calls if c.contrast == algorithm):
                    preparation = call.cell() == reference_cell
                    record = m.OutputAudit(dataset=dataset.dataset, call=call,
                        source_directory=dataset.results/call.cell()/"result",
                        retained_directory=config.output/"raw"/dataset.dataset/call.cell()/"result",
                        reference_cell=reference_cell, reference_preparation_only=preparation)
                    receipt.outputs.append(record)
                    value = inspect_output(ids, reference, dataset, config, record, partitions, numeric, deadline)
                    if preparation:
                        reference = value
                        receipt.references_prepared += int(record.qualified)
                    elif record.qualified:
                        receipt.nonreference_comparisons += 1
                    receipt.qualified_outputs += int(record.qualified)
                    io.save(path, receipt)
        io.require(len(receipt.outputs) == receipt.qualified_outputs == 48
                   and receipt.references_prepared == 6 and receipt.nonreference_comparisons == 42
                   and not receipt.errors, "whole-campaign full physical qualification failed")
        # Close metadata/source identities and whole-process groups a second time.
        for expected in receipt.metadata_pins:
            io.verify(expected, deadline)
        freeze = m.Freeze.model_validate_json(io.metadata(config.audit_source_freeze, deadline))
        for name, identity in freeze.production_helpers.items():
            io.verify(m.Pin(path=Path(__file__).parent/name, **identity.model_dump()), deadline)
        for dataset in config.datasets:
            closed_now(m.Closure.model_validate_json(io.metadata(dataset.closure, deadline)))
        io.primitives(config.oracle_directory, deadline)
        receipt.outcome = "passed_full_physical_whole_campaign"
    except Exception as error:
        receipt.outcome = "failed"
        receipt.errors.append(f"{type(error).__name__}: {error}")
    io.save(path, receipt)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    configuration = io.pin(args.config, io.Deadline(time.monotonic(), 60.0))
    config = m.Config.model_validate_json(io.metadata(configuration, io.Deadline(time.monotonic(), 60.0)))
    receipt = run(config, configuration)
    print(f"{receipt.outcome} qualified={receipt.qualified_outputs}/48 references={receipt.references_prepared}/6 "
          f"comparisons={receipt.nonreference_comparisons}/42 receipt={config.output/'receipt.json'}")
    return 0 if receipt.outcome == "passed_full_physical_whole_campaign" else 1


if __name__ == "__main__":
    raise SystemExit(main())
