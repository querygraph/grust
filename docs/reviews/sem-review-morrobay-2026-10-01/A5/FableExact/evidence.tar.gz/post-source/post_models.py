"""Typed whole-campaign evidence; deliberately no per-call engine exit proof."""
from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

Dataset = Literal["cit-Patents", "graph500-24"]
Algorithm = Literal["wcc", "pagerank", "bfs"]
Engine = Literal["graphframes", "pecan"]
Positive = Annotated[int, Field(gt=0)]
SHA = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
FiniteSeconds = Annotated[float, Field(gt=0, allow_inf_nan=False)]
SOURCE = {"cit-Patents": 5795784, "graph500-24": 798169}
ROWS = {"cit-Patents": 3774768, "graph500-24": 8870942}
SAIL = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
GF = "b4da56dabe20bba8e29563e06acc5179b2113ce3"
FABLE_SHA = "f4f510aea8098b54f0076bc97316a9525d00525ccb853932422796254372540d"
ORDER: tuple[Algorithm, ...] = ("wcc", "pagerank", "bfs")
ENGINES: tuple[Engine, ...] = ("graphframes", "pecan", "pecan", "graphframes")


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class Identity(Model):
    bytes: Annotated[int, Field(ge=0)]
    sha256: SHA


class Pin(Identity):
    path: Path


class DatasetConfig(Model):
    dataset: Dataset
    vertices: Pin
    edges: Pin
    expected_rows: Positive
    source: int
    records: Pin
    results: Path
    closure: Pin

    @model_validator(mode="after")
    def fixed_contract(self) -> DatasetConfig:
        if self.source != SOURCE[self.dataset] or self.expected_rows != ROWS[self.dataset]:
            raise ValueError("fixed production original vertex cardinality/source differs")
        return self


class Config(Model):
    schema_version: Literal[1] = 1
    audit_source_freeze: Pin
    campaign_configuration: Pin
    admission: Pin
    datasets: tuple[DatasetConfig, DatasetConfig]
    output: Path
    oracle_directory: Path
    deadline_seconds: FiniteSeconds = 14400.0
    batch_rows: Annotated[int, Field(ge=1, le=1048576)] = 262144

    @model_validator(mode="after")
    def both_datasets(self) -> Config:
        if tuple(d.dataset for d in self.datasets) != ("cit-Patents", "graph500-24"):
            raise ValueError("exactly Cit then Graph500 required")
        return self


class Closure(Model):
    dataset: Dataset
    parent_pid: Positive
    pgid: Positive
    returncode: Literal[0]
    wait_completed: Literal[True]
    closed_utc: str
    owned_processes_remaining: tuple[int, ...]
    campaign_configuration: Pin

    @model_validator(mode="after")
    def closed(self) -> Closure:
        if self.owned_processes_remaining:
            raise ValueError("whole-campaign owned processes remain")
        return self


class Admission(Model):
    outcome: Literal["passed_native_fable_source_input_admission"]
    campaign_configuration: Pin
    controller_commit: Literal["9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"]
    native_runtime_commit: Literal["9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"]
    graphframes_commit: Literal["b4da56dabe20bba8e29563e06acc5179b2113ce3"]
    original_fable_sha256: Literal["f4f510aea8098b54f0076bc97316a9525d00525ccb853932422796254372540d"]
    workers: Literal[16]
    memory_pool_bytes: Literal[32212254720]
    snapshot_inputs: Literal[False]
    repartition_checkpoints: Literal[True]
    contrasts: tuple[Literal["wcc"], Literal["pagerank"], Literal["bfs"]]
    blocks: Literal[2]
    source_and_inputs_unchanged: Literal[True]
    native_binary_client_module_verified: Literal[True]
    input_vertices: dict[Dataset, Pin]
    input_edges: dict[Dataset, Pin]
    evidence: tuple[Pin, ...]
    observed_utc: str


class Freeze(Model):
    outcome: Literal["frozen_source_only_whole_campaign_post_audit"]
    observed_utc: str
    production_helpers: dict[str, Identity]
    gate: Pin


class WccDeclared(Model):
    rows: Positive
    components: Positive
    label_mismatches: Literal[0]


class BfsDeclared(Model):
    rows: Positive
    reached: Positive
    depth: Annotated[int, Field(ge=0)]
    hop_mismatches: Literal[0]


class PrDeclared(Model):
    rows: Positive
    max_abs_difference: Annotated[float, Field(ge=0, lt=1e-12, allow_inf_nan=False)]
    max_relative_difference: float


class Call(Model):
    contrast: Algorithm
    block: Literal[0, 1]
    position: Literal[0, 1, 2, 3]
    engine: Engine
    seconds: FiniteSeconds
    algorithm_seconds: Annotated[float, Field(ge=0, allow_inf_nan=False)] | None = None
    iterations: Annotated[int, Field(ge=0)] | None = None
    oracle: WccDeclared | BfsDeclared | PrDeclared | None = None

    def cell(self) -> str:
        return f"{self.contrast}-b{self.block}-p{self.position}-{self.engine}"


class PhysicalField(Model):
    name: str
    arrow_type: str
    nullable: bool


class PhysicalFile(Model):
    file: str
    fields: tuple[PhysicalField, ...]
    footer_rows: int


class OutputAudit(Model):
    dataset: Dataset
    call: Call
    source_directory: Path
    retained_directory: Path
    reference_cell: str
    reference_preparation_only: bool
    raw_files: dict[str, Identity] = Field(default_factory=dict)
    physical_schemas: list[PhysicalFile] = Field(default_factory=list)
    rows: int = 0
    original_domain_complete_unique: bool = False
    canonical_labels_passed: bool | None = None
    components: int | None = None
    false_merge_groups: int | None = None
    false_split_groups: int | None = None
    numeric_comparison_performed: bool = False
    compared_rows: int = 0
    mismatches: int | None = None
    maximum_absolute_error_hex: str | None = None
    reachable: int | None = None
    unreachable: int | None = None
    maximum_hops: int | None = None
    retained_copy_and_ssd_rehash_passed: bool = False
    qualified: bool = False
    errors: list[str] = Field(default_factory=list)


class Ratios(Model):
    dataset: Dataset
    algorithm: Algorithm
    graphframes_median_seconds: float
    pecan_median_seconds: float
    fable_ratio_of_engine_medians: float
    adjacent_pair_ratios: tuple[float, ...]
    adjacent_pair_geometric_mean: float
    scope: Literal["ratios_on_shared_native_host"] = "ratios_on_shared_native_host"


class Receipt(Model):
    outcome: Literal["running", "passed_full_physical_whole_campaign", "failed"] = "running"
    started_utc: str
    observed_utc: str
    configuration: Pin
    campaign_configuration: Pin
    closure_scope: str = "Two dataset campaign parents waited and PGIDs closed; no per-call server rc claim."
    bfs_scope: str = "Full four-column Pecan export retained; numeric comparison uses hops only. Distance/parent schema only."
    timing_scope: str = "Original Fable after-import server-launch-through-exit clock; GF CLI launch-through-exit."
    original_vertex_domain_verified: dict[Dataset, bool] = Field(default_factory=dict)
    admission_passed: bool = False
    metadata_pins: list[Pin] = Field(default_factory=list)
    outputs: list[OutputAudit] = Field(default_factory=list)
    ratios: list[Ratios] = Field(default_factory=list)
    expected_calls: Literal[48] = 48
    references_prepared: int = 0
    nonreference_comparisons: int = 0
    qualified_outputs: int = 0
    errors: list[str] = Field(default_factory=list)
