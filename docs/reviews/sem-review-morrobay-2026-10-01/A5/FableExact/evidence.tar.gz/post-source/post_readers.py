"""Read complete original domains and exact physical Fable exports by raw names."""
from __future__ import annotations

from pathlib import Path
from typing import cast

import numpy as np
import numpy.typing as npt
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

import post_io as io
import post_models as m

I64 = npt.NDArray[np.int64]
F64 = npt.NDArray[np.float64]
Vector = I64 | F64


def fields(dataset: m.DatasetConfig, call: m.Call) -> dict[str, pa.DataType]:
    if call.contrast == "wcc":
        return {"id": pa.int64(), "component": pa.int64()}
    if call.contrast == "pagerank":
        return {"id": pa.int64(), "pagerank": pa.float64()}
    if call.engine == "pecan":
        return {"id": pa.int64(), "distance": pa.float64(), "hops": pa.int64(), "parent": pa.int64()}
    return {"id": pa.int64(), f"dist_{dataset.source}": pa.int32()}


def physical(path: Path, name: str, expected: dict[str, pa.DataType], deadline: io.Deadline) -> m.PhysicalFile:
    deadline.check()
    with pq.ParquetFile(path) as parquet:
        schema = parquet.schema_arrow
        description = tuple(m.PhysicalField(name=f.name, arrow_type=str(f.type), nullable=f.nullable) for f in schema)
        io.require(len(schema.names) == len(expected) and len(set(schema.names)) == len(expected)
                   and set(schema.names) == set(expected), "physical raw field names differ: " + name)
        io.require(all(schema.field(key).type == kind for key, kind in expected.items()),
                   "physical raw field types differ: " + name)
        for i in range(parquet.metadata.num_row_groups):
            group = parquet.metadata.row_group(i)
            io.require(sum(group.column(j).total_uncompressed_size for j in range(group.num_columns)) <= 2**29,
                       "uncompressed row-group exceeds512MiB admission")
        return m.PhysicalFile(file=name, fields=description, footer_rows=parquet.metadata.num_rows)


def positions(ids: I64, keys: I64) -> npt.NDArray[np.intp]:
    ordinals = np.searchsorted(ids, keys)
    present = ordinals < len(ids)
    matched = np.zeros(len(keys), dtype=np.bool_)
    matched[present] = ids[ordinals[present]] == keys[present]
    io.require(bool(np.all(matched)), "ID/label outside complete original vertex domain")
    return ordinals


def domain(dataset: m.DatasetConfig, config: m.Config, deadline: io.Deadline) -> I64:
    io.verify(dataset.vertices, deadline)
    descriptor = physical(dataset.vertices.path, dataset.vertices.path.name, {"id": pa.int64()}, deadline)
    io.require(descriptor.footer_rows == dataset.expected_rows, "original footer vertex cardinality differs")
    ids: I64 = np.empty(dataset.expected_rows, dtype=np.int64)
    count = 0
    with pq.ParquetFile(dataset.vertices.path) as parquet:
        for batch in parquet.iter_batches(batch_size=config.batch_rows, columns=["id"], use_threads=False):
            deadline.check()
            column = batch.column(0)
            io.require(column.null_count == 0, "null original vertex ID")
            values = cast(I64, column.to_numpy(zero_copy_only=False))
            io.require(count + len(values) <= len(ids), "original exceeds declared vertex cardinality")
            ids[count:count+len(values)] = values
            count += len(values)
    io.require(count == dataset.expected_rows, "original physical vertex cardinality differs")
    ids.sort()
    io.require(bool(np.all(ids[1:] > ids[:-1])), "duplicate original vertex ID")
    positions(ids, np.array([dataset.source], dtype=np.int64))
    io.verify(dataset.vertices, deadline)
    ids.setflags(write=False)
    return ids


def adapt(column: pa.Array[pa.Scalar[pa.DataType]], call: m.Call) -> Vector:
    if call.contrast == "pagerank":
        io.require(column.null_count == 0, "null raw PageRank")
        scores = cast(F64, column.to_numpy(zero_copy_only=False))
        io.require(bool(np.all(np.isfinite(scores))), "nonfinite raw DOUBLE PageRank")
        return scores
    if call.contrast == "wcc":
        io.require(column.null_count == 0, "null raw WCC label")
        return cast(I64, column.to_numpy(zero_copy_only=False))
    if call.engine == "pecan":
        nulls = column.is_null().to_numpy(zero_copy_only=False)
        filled = cast("pa.Array[pa.Scalar[pa.DataType]]", pc.fill_null(column, pa.scalar(-1, type=pa.int64())))
        hops = cast(I64, filled.to_numpy(zero_copy_only=False))
        io.require(bool(np.all(nulls | ((hops >= 0) & (hops < 2**31 - 1)))), "invalid finite Pecan BFS hop")
        return hops
    io.require(column.null_count == 0, "null raw GF BFS hop")
    hops = column.to_numpy(zero_copy_only=False).astype(np.int64)
    io.require(bool(np.all(hops >= 0)), "negative raw GF BFS hop")
    hops[hops == 2**31 - 1] = -1
    return hops


def values(ids: I64, dataset: m.DatasetConfig, config: m.Config, record: m.OutputAudit,
           deadline: io.Deadline) -> Vector:
    expected = fields(dataset, record.call)
    names = [name for name in record.raw_files if name.endswith(".parquet")]
    io.require(bool(names), "no physical result Parquet")
    record.physical_schemas = [physical(record.source_directory/name, name, expected, deadline) for name in names]
    io.require(sum(d.footer_rows for d in record.physical_schemas) == len(ids), "raw footer cardinality differs")
    value_name = ("component" if record.call.contrast == "wcc" else "pagerank" if record.call.contrast == "pagerank"
                  else "hops" if record.call.engine == "pecan" else f"dist_{dataset.source}")
    seen = np.zeros(len(ids), dtype=np.bool_)
    result: Vector
    if record.call.contrast == "pagerank":
        result = np.empty(len(ids), dtype=np.float64)
    else:
        result = np.empty(len(ids), dtype=np.int64)
    for descriptor in record.physical_schemas:
        file_rows = 0
        with pq.ParquetFile(record.source_directory/descriptor.file) as parquet:
            for batch in parquet.iter_batches(batch_size=config.batch_rows, columns=["id", value_name], use_threads=False):
                deadline.check()
                key_column = batch.column(batch.schema.get_field_index("id"))
                io.require(key_column.null_count == 0, "null raw output vertex ID")
                keys = cast(I64, key_column.to_numpy(zero_copy_only=False))
                ordinals = positions(ids, keys)
                unique = np.unique(ordinals)
                io.require(len(unique) == len(ordinals) and not bool(np.any(seen[unique])),
                           "duplicate raw output ID inside/across files/batches")
                seen[ordinals] = True
                result[ordinals] = adapt(batch.column(batch.schema.get_field_index(value_name)), record.call)
                record.rows += len(keys)
                file_rows += len(keys)
        io.require(file_rows == descriptor.footer_rows, "physical/footer output rows differ")
    io.require(record.rows == len(ids) and bool(np.all(seen)), "missing original vertex in raw output")
    record.original_domain_complete_unique = True
    if record.call.contrast == "wcc":
        positions(ids, cast(I64, result))
    elif record.call.contrast == "bfs":
        source = positions(ids, np.array([dataset.source], dtype=np.int64))[0]
        io.require(int(result[source]) == 0 and int(np.count_nonzero(result == 0)) == 1,
                   "BFS source must be the only zero-hop vertex")
        record.reachable = int(np.count_nonzero(result >= 0))
        record.unreachable = len(ids) - record.reachable
        record.maximum_hops = int(result.max(initial=0))
    result.setflags(write=False)
    return result
