"""Small pinned metadata and one-time immutable full output retention."""
from __future__ import annotations

import hashlib
import importlib
import json
import os
import shutil
import stat
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol, cast

import numpy as np
import numpy.typing as npt

import post_models as m

I64 = npt.NDArray[np.int64]
F64 = npt.NDArray[np.float64]
Vector = I64 | F64
HELPER_SHA = {
    "matched_models.py": "71dee1d9c8dc69a98f45157a67af3c23e6c819378b8becc91e56e3f443ba2622",
    "matched_io.py": "26dc39b562c171e4722eb55b7ccf654ac53b5238570c3e652053bc62ec776a25",
    "matched_readers.py": "e6bd758527dcf28a1ce1eadfe750022ca6953a7b413e358a8ab650e4b4bb5b2b",
    "matched_compare.py": "ecbf2f7aab15406765b424659716dba09551be4ec4859d78147d1066afd7b861",
    "matched_numeric.py": "5beaab5fd339cce176185d14b278992b99f2b4d5f0da31f0c8d8d78eb03fcb6a",
    "matched_oracle.py": "c2f29fbdf46f74a98f5268e99ff3c4bab55a6b674ab90f541fd1c2b70de9b120",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True, slots=True)
class Deadline:
    started: float
    seconds: float

    def check(self) -> None:
        if time.monotonic() - self.started >= self.seconds:
            raise TimeoutError("whole-campaign outside-engine audit deadline elapsed")


class Canonical(Protocol):
    @property
    def components(self) -> int: ...
    @property
    def mismatches(self) -> int: ...


class Partitions(Protocol):
    def canonical(self, ids: I64, labels: I64, deadline: Deadline) -> Canonical: ...
    def conflicts(self, ids: I64, group_labels: I64, member_labels: I64, deadline: Deadline) -> int: ...


class Numeric(Protocol):
    def within_bound(self, actual: float, expected: float) -> bool: ...


def safe(path: Path) -> None:
    require(path.is_absolute() and ".." not in path.parts, "absolute path without .. required")
    require(not any(p.is_symlink() for p in (path, *path.parents)), "symlink path/ancestor refused")


def pin(path: Path, deadline: Deadline) -> m.Pin:
    deadline.check()
    safe(path)
    before = path.stat()
    require(stat.S_ISREG(before.st_mode), "regular file required: " + str(path))
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(2**20):
            deadline.check()
            digest.update(chunk)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "file changed while hashing: " + str(path))
    return m.Pin(path=path, bytes=after.st_size, sha256=digest.hexdigest())


def verify(expected: m.Pin, deadline: Deadline) -> None:
    require(pin(expected.path, deadline) == expected, "immutable pin differs: " + str(expected.path))


def metadata(expected: m.Pin, deadline: Deadline) -> bytes:
    require(expected.bytes <= 16 * 2**20, "metadata exceeds16MiB")
    verify(expected, deadline)
    raw = expected.path.read_bytes()
    require(len(raw) == expected.bytes and hashlib.sha256(raw).hexdigest() == expected.sha256,
            "consumed metadata differs from pin")
    return raw


def inventory(directory: Path, deadline: Deadline) -> dict[str, m.Identity]:
    safe(directory)
    require(directory.is_dir(), "raw result directory missing")
    found: dict[str, m.Identity] = {}
    pending, entries, total = [directory], 0, 0
    while pending:
        deadline.check()
        with os.scandir(pending.pop()) as children:
            for entry in children:
                entries += 1
                require(entries <= 20000 and not entry.is_symlink(), "raw entry limit/symlink refused")
                path = Path(entry.path)
                if entry.is_dir(follow_symlinks=False):
                    pending.append(path)
                else:
                    require(entry.is_file(follow_symlinks=False), "raw special file refused")
                    total += entry.stat(follow_symlinks=False).st_size
                    require(len(found) < 10000 and total <= 2**31, "per-call raw inventory admission exceeded")
                    identity = pin(path, deadline)
                    found[path.relative_to(directory).as_posix()] = m.Identity(bytes=identity.bytes, sha256=identity.sha256)
    return dict(sorted(found.items()))


def retain(source: Path, target: Path, initial: dict[str, m.Identity], deadline: Deadline) -> None:
    safe(target)
    require(not target.exists(), "fresh exclusive raw copy required")
    target.mkdir(parents=True)
    for name in initial:
        deadline.check()
        destination = target/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source/name, destination)
        with destination.open("rb") as stream:
            os.fsync(stream.fileno())
    require(inventory(target, deadline) == initial, "retained copy full hashes differ")
    require(inventory(source, deadline) == initial, "SSD output changed across read/copy")


def primitives(directory: Path, deadline: Deadline) -> tuple[Partitions, Numeric]:
    safe(directory)
    for name, expected in HELPER_SHA.items():
        require(pin(directory/name, deadline).sha256 == expected, "frozen helper hash differs: " + name)
        loaded = sys.modules.get(name.removesuffix(".py"))
        require(loaded is None or Path(str(loaded.__file__)) == directory/name,
                "helper module already loaded from another directory")
    sys.path.insert(0, str(directory))
    partitions = importlib.import_module("matched_compare")
    numeric = importlib.import_module("matched_numeric")
    for name in HELPER_SHA:
        loaded = sys.modules.get(name.removesuffix(".py"))
        require(loaded is None or Path(str(loaded.__file__)) == directory/name,
                "helper dependency module origin differs")
    return cast(Partitions, partitions), cast(Numeric, numeric)


def save(path: Path, record: m.Receipt) -> None:
    record.observed_utc = utc()
    temporary = path.with_suffix(".writing")
    with temporary.open("w") as stream:
        stream.write(record.model_dump_json(indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def retain_metadata(expected: m.Pin, output: Path, name: str, deadline: Deadline) -> None:
    raw = metadata(expected, deadline)
    destination = output/"metadata"/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def decode_object(raw: bytes) -> dict[str, object]:
    value: object = json.loads(raw)
    require(isinstance(value, dict), "JSON object required")
    return cast(dict[str, object], value)
