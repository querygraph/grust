"""Tiny physical negative controls; no original inputs, engine or native imports."""
from __future__ import annotations

import tempfile
import time
import unittest
from pathlib import Path
from typing import Literal, cast
from unittest.mock import patch

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

import post_audit as audit
import post_io as io
import post_models as m
import post_readers as readers


def placeholder(path: Path) -> m.Pin:
    return m.Pin(path=path, bytes=0, sha256="0"*64)


def dataset(directory: Path) -> m.DatasetConfig:
    return m.DatasetConfig(dataset="cit-Patents", vertices=placeholder(directory/"v.parquet"),
        edges=placeholder(directory/"e.parquet"), expected_rows=3774768, source=5795784,
        records=placeholder(directory/"records.json"), results=directory/"results", closure=placeholder(directory/"closure.json"))


def configuration(directory: Path) -> m.Config:
    return m.Config(audit_source_freeze=placeholder(directory/"freeze.json"),
        campaign_configuration=placeholder(directory/"campaign.json"), admission=placeholder(directory/"admission.json"),
        datasets=(dataset(directory), m.DatasetConfig(dataset="graph500-24", vertices=placeholder(directory/"gv"),
            edges=placeholder(directory/"ge"), expected_rows=8870942, source=798169,
            records=placeholder(directory/"gr"), results=directory/"gresults", closure=placeholder(directory/"gc"))),
        output=directory/"output", oracle_directory=directory/"oracle", batch_rows=2)


def calls() -> list[m.Call]:
    output: list[m.Call] = []
    for algorithm in m.ORDER:
        for block in (0, 1):
            for position, engine in enumerate(m.ENGINES):
                declared: m.WccDeclared | m.BfsDeclared | m.PrDeclared | None = None
                if position:
                    if algorithm == "wcc":
                        declared = m.WccDeclared(rows=3774768, components=1, label_mismatches=0)
                    elif algorithm == "bfs":
                        declared = m.BfsDeclared(rows=3774768, reached=1, depth=0, hop_mismatches=0)
                    else:
                        declared = m.PrDeclared(rows=3774768, max_abs_difference=0.0, max_relative_difference=0.0)
                output.append(m.Call(contrast=algorithm, block=block, position=cast(Literal[0,1,2,3], position), engine=engine,
                    seconds=2.0 if engine == "pecan" else 1.0, oracle=declared,
                    algorithm_seconds=0.5 if engine == "pecan" else None,
                    iterations=10 if engine == "pecan" else None))
    return output


class PostControls(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary: tempfile.TemporaryDirectory[str] = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.root = Path(self.temporary.name)
        self.deadline = io.Deadline(time.monotonic(), 120.0)
        self.config = configuration(self.root)
        self.dataset = dataset(self.root)
        self.ids: readers.I64 = np.array([0, 5795784, 9000000], dtype=np.int64)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def record(self, algorithm: m.Algorithm = "wcc", engine: m.Engine = "graphframes") -> m.OutputAudit:
        call = m.Call(contrast=algorithm, block=0, position=0, engine=engine, seconds=1.0)
        source = self.root/call.cell()/"result"
        source.mkdir(parents=True)
        return m.OutputAudit(dataset="cit-Patents", call=call, source_directory=source,
            retained_directory=self.root/"copy"/call.cell(), reference_cell=call.cell(), reference_preparation_only=True)

    def write(self, record: m.OutputAudit, table: pa.Table, name: str = "part.parquet") -> None:
        pq.write_table(table, record.source_directory/name)
        record.raw_files = io.inventory(record.source_directory, self.deadline)

    def test_complete_abba_and_distinct_ratio_labels(self) -> None:
        data = calls()
        audit.validate_calls(data, self.dataset)
        result = audit.ratios("cit-Patents", data)
        self.assertEqual(len(result), 3)
        self.assertTrue(all(r.fable_ratio_of_engine_medians == 2.0 for r in result))
        self.assertTrue(all(r.adjacent_pair_geometric_mean == 2.0 for r in result))

    def test_missing_call_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "all24"):
            audit.validate_calls(calls()[:-1], self.dataset)

    def test_wrong_order_rejected(self) -> None:
        data = calls()
        data[0], data[1] = data[1], data[0]
        with self.assertRaisesRegex(ValueError, "order"):
            audit.validate_calls(data, self.dataset)

    def test_missing_inline_oracle_rejected(self) -> None:
        data = calls()
        data[1].oracle = None
        with self.assertRaisesRegex(ValueError, "presence"):
            audit.validate_calls(data, self.dataset)

    def test_out_of_domain_ids_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "outside"):
            readers.positions(self.ids, np.array([9000001], dtype=np.int64))

    def test_complete_domain_and_null_id_rejected(self) -> None:
        record = self.record()
        self.write(record, pa.table({"id": pa.array([0, 5795784, None], type=pa.int64()),
                                    "component": pa.array([0, 0, 0], type=pa.int64())}))
        with self.assertRaisesRegex(ValueError, "null raw"):
            readers.values(self.ids, self.dataset, self.config, record, self.deadline)

    def test_duplicate_ids_across_batches_rejected(self) -> None:
        record = self.record()
        self.write(record, pa.table({"id": pa.array([0, 5795784, 0], type=pa.int64()),
                                    "component": pa.array([0, 0, 0], type=pa.int64())}))
        with self.assertRaisesRegex(ValueError, "duplicate"):
            readers.values(self.ids, self.dataset, self.config, record, self.deadline)

    def test_nonfinite_rank_rejected(self) -> None:
        record = self.record("pagerank")
        self.write(record, pa.table({"id": pa.array(self.ids), "pagerank": pa.array([1.0, np.inf, 0.0])}))
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            readers.values(self.ids, self.dataset, self.config, record, self.deadline)

    def test_bfs_four_fields_and_schema_only_extras(self) -> None:
        record = self.record("bfs", "pecan")
        self.write(record, pa.table({"id": pa.array(self.ids), "hops": pa.array([1, 0, None], type=pa.int64()),
            "distance": pa.array([None, None, None], type=pa.float64()), "parent": pa.array([None, None, None], type=pa.int64())}))
        value = readers.values(self.ids, self.dataset, self.config, record, self.deadline)
        np.testing.assert_array_equal(value, [1, 0, -1])
        self.assertTrue(record.original_domain_complete_unique)
        self.assertEqual(len(record.physical_schemas[0].fields), 4)

    def test_bfs_wrong_extra_type_rejected(self) -> None:
        record = self.record("bfs", "pecan")
        self.write(record, pa.table({"id": pa.array(self.ids), "hops": pa.array([1, 0, None], type=pa.int64()),
            "distance": pa.array([1, 0, None], type=pa.int64()), "parent": pa.array([0, 0, None], type=pa.int64())}))
        with self.assertRaisesRegex(ValueError, "types"):
            readers.values(self.ids, self.dataset, self.config, record, self.deadline)

    def test_bfs_gf_unreachable_sentinel(self) -> None:
        record = self.record("bfs")
        self.write(record, pa.table({"id": pa.array(self.ids), "dist_5795784": pa.array([1, 0, 2**31-1], type=pa.int32())}))
        np.testing.assert_array_equal(readers.values(self.ids, self.dataset, self.config, record, self.deadline), [1, 0, -1])

    def test_missing_raw_id_footer_rejected(self) -> None:
        record = self.record()
        self.write(record, pa.table({"id": pa.array([0, 5795784], type=pa.int64()),
                                    "component": pa.array([0, 0], type=pa.int64())}))
        with self.assertRaisesRegex(ValueError, "cardinality"):
            readers.values(self.ids, self.dataset, self.config, record, self.deadline)

    def test_wcc_signed_canonical_and_false_merge(self) -> None:
        partitions, numeric = io.primitives(Path("/Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-matched-oracle01"), self.deadline)
        ids: readers.I64 = np.array([-5, 2, 6], dtype=np.int64)
        expected: readers.I64 = np.array([-5, -5, 6], dtype=np.int64)
        merged: readers.I64 = np.array([-5, -5, -5], dtype=np.int64)
        self.assertEqual(partitions.canonical(ids, expected, self.deadline).mismatches, 0)
        self.assertEqual(partitions.canonical(ids, np.array([2, 2, 6], dtype=np.int64), self.deadline).mismatches, 2)
        record = self.record()
        with self.assertRaisesRegex(ValueError, "merge"):
            audit.compare(ids, merged, expected, record, partitions, numeric, self.config, self.deadline)
        self.assertEqual(record.false_merge_groups, 1)

    def test_exact_binary64_bound(self) -> None:
        partitions, numeric = io.primitives(Path("/Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-matched-oracle01"), self.deadline)
        self.assertTrue(numeric.within_bound(1e-12, 0.0))
        self.assertFalse(numeric.within_bound(float(np.nextafter(1e-12, np.inf)), 0.0))
        record = self.record("pagerank")
        actual: readers.F64 = np.array([1e-12, 0.0, 0.0], dtype=np.float64)
        audit.compare(self.ids, actual, np.zeros(3, dtype=np.float64), record, partitions, numeric, self.config, self.deadline)
        self.assertEqual(record.mismatches, 0)

    def test_reference_preparation_never_self_compares(self) -> None:
        partitions, numeric = io.primitives(Path("/Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-matched-oracle01"), self.deadline)
        record = self.record()
        self.write(record, pa.table({"id": pa.array(self.ids), "component": pa.array([0, 0, 0], type=pa.int64())}))
        with patch("post_audit.compare") as comparison:
            value = audit.inspect_output(self.ids, None, self.dataset, self.config, record, partitions, numeric, self.deadline)
        self.assertIsNotNone(value)
        self.assertTrue(record.qualified)
        self.assertFalse(record.numeric_comparison_performed)
        self.assertEqual(record.compared_rows, 0)
        comparison.assert_not_called()

    def test_mutated_ssd_output_refuses_retention(self) -> None:
        source = self.root/"raw"
        source.mkdir()
        (source/"data").write_bytes(b"old")
        initial = io.inventory(source, self.deadline)
        (source/"data").write_bytes(b"new")
        with self.assertRaisesRegex(ValueError, "hashes"):
            io.retain(source, self.root/"copy", initial, self.deadline)

    def test_raw_symlink_rejected(self) -> None:
        source = self.root/"raw"
        source.mkdir()
        (source/"link").symlink_to(self.root/"outside")
        with self.assertRaisesRegex(ValueError, "symlink"):
            io.inventory(source, self.deadline)

    def test_closed_parent_pid_checked_without_rc_invention(self) -> None:
        closure = m.Closure(dataset="cit-Patents", parent_pid=12345, pgid=99999, returncode=0,
            wait_completed=True, closed_utc=io.utc(), owned_processes_remaining=(), campaign_configuration=placeholder(self.root/"config"))
        done = subprocess_result("12345 67890\n")
        with patch("post_audit.subprocess.run", return_value=done), self.assertRaisesRegex(ValueError, "remains"):
            audit.closed_now(closure)


class subprocess_result:
    def __init__(self, stdout: str) -> None:
        self.stdout = stdout


if __name__ == "__main__":
    unittest.main()
