# Exact Fable whole-campaign post audit

Source-only preparation. This helper launches no engine and changes no original
output. The root coordinator runs it only after both serial dataset campaign
parents have exited successfully and their owned process groups have closed.

## Inputs and launch

Fill `config-template.json`, `admission-template.json` and the two closure
templates with actual observed facts and immutable file pins. Templates contain
placeholders and are not execution-admitted. Root-owned source/input admission
must bind the exact 9f controller and host, b4da GraphFrames, path-adapted original
Fable script, actual client/modules, 16 workers, 30 GiB pools and unchanged
original inputs. Admission evidence is small metadata; the post audit itself
verifies original vertex file hashes before and after its complete domain read.
The edge/source/native before-and-after verification belongs to the pinned root
admission evidence; this helper does not scan edge payloads or binary payloads.

Run with the frozen Python 3.12 audit environment, not a native engine:

```
/tmp/sem-output-oracle-venv/bin/python -I -B -c 'import runpy,sys; sys.path.insert(0,sys.argv[1]); runpy.run_path(sys.argv[1]+"/post_audit.py",run_name="__main__")' /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-fable-exact-post01 --config /ABSOLUTE/actual-post-config.json
```

The output directory must be fresh and must not overlap protected source,
metadata, input or result paths. Each observed process group is checked again at
completion. Closure covers the two waited whole-campaign parents and their
process groups. The original script records no per-call Sail return-code proof;
this helper invents none.

## Physical and numerical scope

- Exactly 24 ordered original calls per dataset: WCC, PageRank, BFS, each two
  GF/Pecan/Pecan/GF blocks. All 36 original inline oracle records are required
  where the script emits them, together with original Pecan call metadata.
- Every physical Parquet file has exactly the declared raw names and types.
  Every output contains each original non-null signed vertex ID exactly once.
  There is no integer or floating cast that conceals a raw type difference.
- Six first GF `b0-p0` outputs are references prepared independently by the
  original engine calls. They receive full physical/domain checks, and WCC
  canonical-label checks, but no numeric self-comparison. The other 42 calls
  compare against those six references, including later GF calls.
- WCC labels are original signed component minima. Both partition directions
  and direct labels are compared. Canonical/partition functions come from
  source-pinned frozen `matched_compare.py` and its pinned dependencies.
- Directed BFS uses Cit source 5795784 and Graph500 source 798169. Pecan exports
  `id:int64,distance:double,hops:int64,parent:int64`; distance and parent are
  retained and schema checked only. Numerical comparison uses exact hops,
  adapting Pecan NULL and GF Int32 maximum to the same unreachable marker.
  It makes no predecessor or distance-value correctness claim.
- PageRank is finite non-null binary64 and compared with the inclusive exact
  binary64 absolute bound 1e-12. Subtraction boundary cases use source-pinned
  `matched_numeric.within_bound`. The original script's inline check is strict
  `< 1e-12`, and that declared oracle is also required in the records.

Every result file, including markers and hidden files, is initially SHA256
inventoried, copied to `raw/{dataset}/{cell}/result`, then the copy and SSD
original are each fully hashed once against that inventory. Raw data is kept
on both SSD and Apo. Physical/numeric failures still retain their raw copies;
failed receipts are never promoted or retried in the same output directory.
An admission/protocol failure stops qualification and leaves original outputs
untouched. No code here deletes originals.

## Reporting and gates

The primary summary preserves Fable's ratio of four engine medians, with the
original after-import Sail launch-through-exit timer. A separate field reports
the geometric mean of four adjacent pair ratios. Both are ratios on a shared
native host. No warmup or extra reference engine call is added to the campaign.

Production helpers are `post_models.py`, `post_io.py`, `post_readers.py`, and
`post_audit.py`. `freeze.json` pins them and the final source gate. Source-only
controls use tiny synthetic Parquet fixtures, mock process inventory, signed
canonical partitions, source-pinned binary64 arithmetic and retention mutation.
There are no native imports, engine executions or original payload reads in the
gates. Failed initial Ruff/type outcomes and all subsequent gates are preserved.
