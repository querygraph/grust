import tempfile
import unittest
from pathlib import Path

import adapt_exact as aid

SOURCE = """import pathlib
HOME = pathlib.Path.home()
W = HOME / "w"
SAIL = W / "target/sail"
GF = HOME / "gf"
DATA = HOME / "data"
def pecan(x):
    # Keep this function text, including whitespace, unchanged.
    return x + 1
def graphframes(x):
    return x * 2
def oracle(x):
    return x == 2
"""
PATHS = aid.PathGlobals(
    W=Path("/w"), SAIL=Path("/sail"), GF=Path("/gf"), DATA=Path("/data")
)


class Controls(unittest.TestCase):
    def test_four_values_and_function_bytes(self) -> None:
        result = aid.adapt(SOURCE, PATHS)
        self.assertEqual(aid.function_bodies(SOURCE), aid.function_bodies(result))
        self.assertEqual(aid.normalized_ast(SOURCE), aid.normalized_ast(result))
        for name in aid.GLOBALS:
            self.assertIn(
                f"{name} = pathlib.Path({str(getattr(PATHS, name))!r})", result
            )
        self.assertIn("HOME = pathlib.Path.home()", result)

    def test_arbitrary_function_edit_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "AST changed"):
            aid.require_parity(
                SOURCE, aid.adapt(SOURCE, PATHS).replace("x + 1", "x + 2")
            )

    def test_function_whitespace_edit_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "function source changed"):
            aid.require_parity(
                SOURCE,
                aid.adapt(SOURCE, PATHS).replace("return x + 1", "return  x + 1"),
            )

    def test_missing_global_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "exactly one"):
            aid.adapt(SOURCE.replace('DATA = HOME / "data"\n', ""), PATHS)

    def test_duplicate_global_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "ambiguous"):
            aid.adapt(SOURCE + '\nW = pathlib.Path("/other")\n', PATHS)

    def test_non_ascii_ast_byte_offsets(self) -> None:
        source = SOURCE.replace("HOME =", "# café\nHOME =")
        result = aid.adapt(source, PATHS)
        self.assertTrue(result.startswith("import pathlib\n# café\n"))
        aid.require_parity(source, result)

    def test_fresh_destinations_and_protected_overlap(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            run = aid.Run(
                dataset="cit-Patents",
                source=5795784,
                root=base / "ssd",
                out=base / "apo/records.json",
            )
            aid.require_fresh(run, (base / "inputs",))
            run.root.mkdir()
            with self.assertRaisesRegex(ValueError, "fresh"):
                aid.require_fresh(run, ())
            nested = aid.Run(
                dataset="cit-Patents",
                source=5795784,
                root=base / "inputs/new",
                out=run.out,
            )
            with self.assertRaisesRegex(ValueError, "protected"):
                aid.require_fresh(nested, (base / "inputs",))

    def test_dangling_symlink_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            root = base / "root"
            root.symlink_to(base / "absent")
            run = aid.Run(
                dataset="graph500-24",
                source=798169,
                root=root,
                out=base / "records.json",
            )
            with self.assertRaisesRegex(ValueError, "fresh"):
                aid.require_fresh(run, ())

    def test_pin_mutation_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "source.py"
            path.write_text(SOURCE)
            pin = aid.identity(path)
            path.write_text(SOURCE + "# changed\n")
            with self.assertRaisesRegex(ValueError, "file pin changed"):
                aid.require_pin(pin)


if __name__ == "__main__":
    unittest.main()
