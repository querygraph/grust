# Exact Fable native A2-local preparation

Source preparation only. No engine, native import probe, build, VM, or data
scan was run by this aid.

## Files and launch

The original is the root-preserved `original/A2-local/a2_local.py` from Grust
`3448256c2723d0a65c231a822aabe45a71f26561`, SHA256
`f4f510aea8098b54f0076bc97316a9525d00525ccb853932422796254372540d`.
`generated01/a2_local.py` changes only the values assigned to `W`, `SAIL`,
`GF`, and `DATA`. The adapter records matching normalized whole-module ASTs
and byte-exact bodies of `pecan`, `graphframes`, and `oracle`.

`generated01/launch-1-cit-Patents.json` and
`generated01/launch-2-graph500-24.json` contain the exact argv and environment
additions for root's whole-script owner. Each uses `--contrasts wcc pagerank
bfs --blocks 2 --workers 16 --no-snapshot`, with sources 5795784 and 798169.
There are no added warmups, server overrides, or `--no-repartition` flag.
The SSD roots are under
`/Users/alexy/src/grust-benchmark-runs/A5-native-fable-exact-run01`; records
are under the corresponding dataset in Apo `A5-native-fable-exact-run01`.
Create each records-file parent before launch; keep the SSD dataset root and
records file absent until the final freshness check.

Root should recheck this immediately before launching either recipe:

```text
/tmp/sem-output-oracle-venv/bin/python adapt_exact.py --config configuration.json --check-launch
```

This check reads only the sealed small source/metadata files and verifies the
adapted-script pin and recipe bindings. It does not launch anything or check
binary/Parquet payload hashes. After the first dataset has run, use the same
`require_fresh` and `require_pin` functions for only the remaining dataset;
the combined CLI check deliberately requires both destinations still fresh.
Root separately owns actual selected-client/binary/input admission, source
and helper pins before/after, serial locks, storage admission, and process
closure. The typed public records are `Config`, `Run`, `LaunchRecipe`,
`FilePin`, and `Receipt` in `adapt_exact.py`.

The isolated `-I -B -c` bootstrap inserts exactly
`W/examples/extensions/graph-algorithms/src`, then calls `runpy.run_path`
with the original argv. It imports no algorithm before the original script.
`W` alone would not select the frontend. `frontend-git-source-pins.json`
binds all 16 small Python source files to exact Sail Git objects; the original
server environment remains unchanged. Native Python is the optimized-build
venv (3.12.6); its prior client receipt records PySpark 4.0.1, Arrow 21.0.0,
pandas 3.0.6, and actual selected ABI origins.

## Source and execution boundary

Controller and compiled Sail are both
`9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3`; GF is
`b4da56dabe20bba8e29563e06acc5179b2113ce3`. The retained native build receipt
records optimized macOS x86_64 binaries, Rust 1.97.1, optimization level 3,
full LTO, one codegen unit, and stripped debug information. Binary identities
come from that receipt; this aid has not opened the binaries. Config metadata
pins also bind the prior complete original-domain/source-membership admissions
and original Parquet identities. BFS and PageRank use stored directed arcs;
official Graph500 undirected ground truth is a separate contract.

The unchanged Pecan timer starts after function-local imports, port selection,
and environment construction; it includes server/session setup, input plans,
the public call, full raw export, session stop, and server terminate/wait.
The separate `algorithm_seconds` field is unchanged. GF times its CLI
subprocess. All four public Pecan BFS fields are exported unchanged, unlike
the earlier A5 two-column export. Software workers are 16 and the greedy
pool is 30 GiB; these are not OS CPU/memory caps on the 128-GiB native host.

The script deletes `--root` at startup and persists `--out` only at successful
completion. Root must capture complete stdout/stderr and partial records,
retain failed outputs, wait for the whole-script PID, and prove absence of
its owned group and any owned servers. No retries or reuse of a failed root.
Script return 0 implies each GF CLI returned 0 and each Pecan server wait
returned, but the script does not record or assert the Sail server's return
code. Its inline records supply no per-call PID or independently observed
per-call process closure.

## Post-run report admission

Require 24 ordered records per dataset (48 total), each contrast's two
unchanged G/P/P/G blocks, and 18 inline oracle records per dataset. There are
six first-GF records without inline comparisons. Preserve original medians,
raw clocks, diagnostics, every log and every physical result file. Published
prose should use disclosed ratios on a shared host, without absolute-clock
claims. These observations are a separate protocol from the earlier d0 A5
campaign; no historical result is rewritten.

The original inline oracle reads complete pandas tables, compares output
indices, exact canonical WCC labels and BFS hops, and strict PR absolute
error `< 1e-12`. It does not establish the original vertex domain,
uniqueness, physical schemas, file closure, or all BFS distance/parent values.
Root's post audit must separately retain raw types/inventories and check full
original-domain coverage before any full-physical verdict. It can use the six
first GF outputs as separately closed per-dataset/per-algorithm references
and compare the other 42 outputs; all reference domains still require full
checks. BFS numeric parity is explicitly hops only. The frozen d0 matched
oracle has a two-field BFS schema and d0 source bindings, so it cannot be
applied unchanged to these 9f four-field exports. No official Graph500,
generic signed-WCC, predecessor, or independent PageRank-ground-truth claim
is made by this preparation.
