"""Adapt four path assignments; emit recipes without importing or running engines."""

import argparse
import ast
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

GLOBALS = ("W", "SAIL", "GF", "DATA")
BOOTSTRAP = (
    "import runpy,sys; sys.path.insert(0,sys.argv[1]); "
    "script=sys.argv[2]; sys.argv=sys.argv[2:]; "
    "runpy.run_path(script,run_name='__main__')"
)


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class FilePin(Model):
    path: Path
    bytes: int = Field(ge=0, le=2**30)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class PathGlobals(Model):
    W: Path
    SAIL: Path
    GF: Path
    DATA: Path

    @field_validator("W", "SAIL", "GF", "DATA")
    @classmethod
    def absolute(cls, value: Path) -> Path:
        if not value.is_absolute():
            raise ValueError("path globals must be absolute")
        return value


class Run(Model):
    dataset: Literal["cit-Patents", "graph500-24"]
    source: int
    root: Path
    out: Path


class Config(Model):
    original: FilePin
    globals: PathGlobals
    python: Path
    frontend_directory: Path
    output: Path
    protected_paths: tuple[Path, ...]
    metadata: dict[str, FilePin]
    frontend_files: dict[str, FilePin]
    runs: tuple[Run, Run]


class LaunchRecipe(Model):
    dataset: str
    source: int
    root: Path
    out: Path
    argv: tuple[str, ...]
    environment: dict[str, str]
    original: FilePin
    adapted: FilePin
    frontend_directory: Path
    expected_calls: Literal[24] = 24
    expected_oracle_records: Literal[18] = 18
    parent_owns_wait_and_group_closure: Literal[True] = True
    per_call_pid_or_server_returncode_recorded: Literal[False] = False


class Receipt(Model):
    observed_utc: str
    outcome: Literal["prepared_source_only"]
    original: FilePin
    adapted: FilePin
    configuration: FilePin
    normalized_ast_sha256: str
    exact_function_body_sha256: dict[str, str]
    metadata: dict[str, FilePin]
    frontend_files: dict[str, FilePin]
    recipes: tuple[LaunchRecipe, LaunchRecipe]
    engine_jobs_launched: Literal[False] = False


def identity(path: Path) -> FilePin:
    data = path.read_bytes()
    return FilePin(path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def require_pin(pin: FilePin) -> None:
    if identity(pin.path) != pin:
        raise ValueError(f"file pin changed: {pin.path}")


def assignments(tree: ast.Module) -> dict[str, ast.expr]:
    found: dict[str, ast.expr] = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        selected = set(names).intersection(GLOBALS)
        for name in selected:
            if len(node.targets) != 1 or name in found:
                raise ValueError(f"ambiguous assignment: {name}")
            found[name] = node.value
    if set(found) != set(GLOBALS):
        raise ValueError("exactly one assignment for each path global is required")
    return found


def normalized_ast(source: str) -> str:
    tree = ast.parse(source)
    assignments(tree)
    for node in tree.body:
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in GLOBALS
        ):
            node.value = ast.Constant(value="PATH_ADAPTER_ONLY")
    return ast.dump(tree, include_attributes=False)


def function_bodies(source: str) -> dict[str, str]:
    bodies: dict[str, str] = {}
    for node in ast.parse(source).body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            segment = ast.get_source_segment(source, node)
            if segment is None:
                raise ValueError("function source unavailable")
            bodies[node.name] = segment
    return bodies


def adapt(source: str, paths: PathGlobals) -> str:
    lines = source.encode("utf-8").splitlines(keepends=True)
    offsets = [0]
    for line in lines:
        offsets.append(offsets[-1] + len(line))
    replacements: list[tuple[int, int, bytes]] = []
    for name, value in assignments(ast.parse(source)).items():
        if value.end_lineno is None or value.end_col_offset is None:
            raise ValueError("AST value has no end location")
        begin = offsets[value.lineno - 1] + value.col_offset
        end = offsets[value.end_lineno - 1] + value.end_col_offset
        path = getattr(paths, name)
        replacements.append((begin, end, f"pathlib.Path({str(path)!r})".encode()))
    adapted = source.encode("utf-8")
    for begin, end, replacement in sorted(replacements, reverse=True):
        adapted = adapted[:begin] + replacement + adapted[end:]
    result = adapted.decode("utf-8")
    require_parity(source, result)
    return result


def require_parity(original: str, adapted: str) -> None:
    if normalized_ast(original) != normalized_ast(adapted):
        raise ValueError("AST changed outside the four global values")
    if function_bodies(original) != function_bodies(adapted):
        raise ValueError("function source changed")


def overlap(left: Path, right: Path) -> bool:
    a, b = left.resolve(), right.resolve()
    return a == b or a in b.parents or b in a.parents


def require_fresh(run: Run, protected: tuple[Path, ...]) -> None:
    for path in (run.root, run.out):
        if not path.is_absolute() or path.exists() or path.is_symlink():
            raise ValueError(f"launch destination must be fresh and absolute: {path}")
        if any(overlap(path, item) for item in protected):
            raise ValueError(
                f"launch destination overlaps protected source/input: {path}"
            )
    if overlap(run.root, run.out):
        raise ValueError("SSD result root and records output must be separate")


def recipe(config: Config, run: Run, adapted: FilePin) -> LaunchRecipe:
    require_fresh(run, config.protected_paths)
    expected_source = {"cit-Patents": 5795784, "graph500-24": 798169}[run.dataset]
    if run.source != expected_source:
        raise ValueError("BFS source differs from the declared exact protocol")
    return LaunchRecipe(
        dataset=run.dataset,
        source=run.source,
        root=run.root,
        out=run.out,
        argv=(
            str(config.python),
            "-I",
            "-B",
            "-c",
            BOOTSTRAP,
            str(config.frontend_directory),
            str(adapted.path),
            "--graph",
            run.dataset,
            "--contrasts",
            "wcc",
            "pagerank",
            "bfs",
            "--blocks",
            "2",
            "--workers",
            "16",
            "--source",
            str(run.source),
            "--no-snapshot",
            "--root",
            str(run.root),
            "--out",
            str(run.out),
        ),
        environment={
            "PYTHONDONTWRITEBYTECODE": "1",
            "DYLD_LIBRARY_PATH": "/Users/alexy/.asdf/installs/python/3.12.6/lib",
        },
        original=config.original,
        adapted=adapted,
        frontend_directory=config.frontend_directory,
    )


def prepare(configuration: Path) -> Receipt:
    config = Config.model_validate_json(configuration.read_bytes())
    for pin in (
        config.original,
        *config.metadata.values(),
        *config.frontend_files.values(),
    ):
        require_pin(pin)
    if set(r.dataset for r in config.runs) != {"cit-Patents", "graph500-24"}:
        raise ValueError("both datasets are required exactly once")
    if (
        config.frontend_directory
        != config.globals.W / "examples/extensions/graph-algorithms/src"
    ):
        raise ValueError("frontend source must come from the selected W checkout")
    for run in config.runs:
        require_fresh(run, config.protected_paths)
    if overlap(config.runs[0].root, config.runs[1].root) or overlap(
        config.runs[0].out, config.runs[1].out
    ):
        raise ValueError("dataset destinations overlap")
    source = config.original.path.read_text()
    result = adapt(source, config.globals)
    config.output.mkdir(parents=True, exist_ok=False)
    script = config.output / "a2_local.py"
    script.write_text(result)
    adapted = identity(script)
    receipt = Receipt(
        observed_utc=datetime.now(timezone.utc).isoformat(),
        outcome="prepared_source_only",
        original=config.original,
        adapted=adapted,
        configuration=identity(configuration),
        normalized_ast_sha256=hashlib.sha256(
            normalized_ast(source).encode()
        ).hexdigest(),
        exact_function_body_sha256={
            name: hashlib.sha256(body.encode()).hexdigest()
            for name, body in function_bodies(source).items()
        },
        metadata=config.metadata,
        frontend_files=config.frontend_files,
        recipes=(
            recipe(config, config.runs[0], adapted),
            recipe(config, config.runs[1], adapted),
        ),
    )
    for index, launch in enumerate(receipt.recipes):
        (config.output / f"launch-{index + 1}-{launch.dataset}.json").write_text(
            launch.model_dump_json(indent=2) + "\n"
        )
    for pin in (
        config.original,
        *config.metadata.values(),
        *config.frontend_files.values(),
    ):
        require_pin(pin)
    (config.output / "adapter-receipt.json").write_text(
        receipt.model_dump_json(indent=2) + "\n"
    )
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument(
        "--check-launch",
        action="store_true",
        help="recheck pins/fresh destinations; do not write or execute",
    )
    args = parser.parse_args()
    if args.check_launch:
        config = Config.model_validate_json(args.config.read_bytes())
        receipt = Receipt.model_validate_json(
            (config.output / "adapter-receipt.json").read_bytes()
        )
        if (
            receipt.configuration != identity(args.config)
            or receipt.original != config.original
            or receipt.metadata != config.metadata
            or receipt.frontend_files != config.frontend_files
            or receipt.adapted.path != config.output / "a2_local.py"
        ):
            raise ValueError("prepared source receipt/configuration binding differs")
        require_pin(receipt.adapted)
        require_parity(
            config.original.path.read_text(), receipt.adapted.path.read_text()
        )
        for pin in (
            config.original,
            *config.metadata.values(),
            *config.frontend_files.values(),
        ):
            require_pin(pin)
        for run in config.runs:
            require_fresh(run, config.protected_paths)
        expected = (
            recipe(config, config.runs[0], receipt.adapted),
            recipe(config, config.runs[1], receipt.adapted),
        )
        if receipt.recipes != expected:
            raise ValueError("prepared launch recipes differ from configuration")
        print(
            json.dumps(
                {
                    "outcome": "source_pins_and_fresh_paths_checked",
                    "engine_jobs_launched": False,
                }
            )
        )
    else:
        print(prepare(args.config).model_dump_json(indent=2))


if __name__ == "__main__":
    main()
