"""Deadline-bounded immutable physical input/output I/O, outside engine timers."""
from __future__ import annotations

import errno
import hashlib
import os
import stat
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import matched_models as models

CHUNK_BYTES = 2**20


class Mismatch(ValueError):
    """The declared physical vector/domain contract is violated."""


class TimedOut(TimeoutError):
    """A configured outside-engine audit deadline elapsed."""


@dataclass(frozen=True, slots=True)
class Deadline:
    started: float
    seconds: float

    def check(self) -> None:
        if time.monotonic() - self.started >= self.seconds:
            raise TimedOut("outside-engine graph oracle deadline elapsed")


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise Mismatch(message)


def safe_path(path: Path) -> None:
    require(path.is_absolute() and ".." not in path.parts, "absolute canonical path required")
    require(not any(p.is_symlink() for p in (path, *path.parents)), "path/ancestor symlink refused")


def pin(path: Path, deadline: Deadline) -> models.FilePin:
    deadline.check()
    safe_path(path)
    before = path.stat()
    require(stat.S_ISREG(before.st_mode), "regular file required: " + str(path))
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(CHUNK_BYTES):
            deadline.check()
            digest.update(chunk)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
            "file changed while hashing: " + str(path))
    return models.FilePin(path=path, bytes=after.st_size, sha256=digest.hexdigest())


def verify(expected: models.FilePin, deadline: Deadline) -> None:
    require(pin(expected.path, deadline) == expected, "immutable pin differs: " + str(expected.path))


def metadata(expected: models.FilePin, deadline: Deadline) -> bytes:
    require(expected.bytes <= 16 * CHUNK_BYTES, "metadata exceeds16MiB")
    verify(expected, deadline)
    deadline.check()
    value = expected.path.read_bytes()
    require(len(value) == expected.bytes and hashlib.sha256(value).hexdigest() == expected.sha256,
            "consumed metadata differs from pin")
    return value


def inventory(directory: Path, limits: models.Limits, deadline: Deadline) -> dict[str, models.FileIdentity]:
    safe_path(directory)
    require(directory.is_dir(), "regular raw output directory required")
    pending, entries, byte_count = [directory], 0, 0
    found: dict[str, models.FileIdentity] = {}
    while pending:
        deadline.check()
        with os.scandir(pending.pop()) as children:
            for entry in children:
                deadline.check()
                entries += 1
                require(entries <= limits.maximum_entries, "output entry limit exceeded")
                require(not entry.is_symlink(), "raw output symlink refused")
                path = Path(entry.path)
                if entry.is_dir(follow_symlinks=False):
                    pending.append(path)
                else:
                    require(entry.is_file(follow_symlinks=False), "raw special file refused")
                    require(len(found) < limits.maximum_files, "output file limit exceeded")
                    byte_count += entry.stat(follow_symlinks=False).st_size
                    require(byte_count <= limits.maximum_total_file_bytes, "output byte limit exceeded")
                    found[path.relative_to(directory).as_posix()] = pin(path, deadline).identity()
    return dict(sorted(found.items()))


def sync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        try:
            os.fsync(descriptor)
        except OSError as error:
            # macOS directory fsync may report EINVAL; file fsync remains mandatory.
            if error.errno != errno.EINVAL:
                raise
    finally:
        os.close(descriptor)


def save(path: Path, record: models.OracleReceipt) -> None:
    record.observed_utc = utc()
    temporary = path.with_suffix(".writing")
    with temporary.open("w") as stream:
        stream.write(record.model_dump_json(indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    sync_directory(path.parent)


def fresh(config: models.OracleConfig) -> None:
    safe_path(config.output)
    require(config.output.parent.is_dir() and not config.output.exists(), "fresh exclusive oracle output required")
    protected = [config.input_vertices.path, config.input_edges.path, config.graphframes_reference.directory, config.candidate.directory,
                 config.graphframes_reference.exit.producer_receipt.path, config.candidate.exit.producer_receipt.path]
    require(not any(p == config.output or p.is_relative_to(config.output) or config.output.is_relative_to(p)
                    for p in protected), "oracle output overlaps original/reference/result paths")
    config.output.mkdir()
    sync_directory(config.output.parent)
