"""Exact signed canonical WCC partitions and directed per-vertex BFS hops."""
from __future__ import annotations

import matched_io as io
import matched_models as models
import matched_readers as readers
import numpy as np


def canonical(ids: readers.I64, labels: readers.I64, deadline: io.Deadline) -> models.CanonicalResult:
    deadline.check()
    groups = readers.positions(ids, labels)
    minimum = np.full(len(ids), np.iinfo(np.int64).max, dtype=np.int64)
    used = np.zeros(len(ids), dtype=np.bool_)
    # Repeated group indices, including within a batch, must all participate.
    np.minimum.at(minimum, groups, ids)
    used[groups] = True
    deadline.check()
    return models.CanonicalResult(components=int(np.count_nonzero(used)),
                                  mismatches=int(np.count_nonzero(labels != minimum[groups])))


def conflicts(ids: readers.I64, group_labels: readers.I64, member_labels: readers.I64,
              deadline: io.Deadline) -> int:
    deadline.check()
    groups = readers.positions(ids, group_labels)
    minimum = np.full(len(ids), np.iinfo(np.int64).max, dtype=np.int64)
    maximum = np.full(len(ids), np.iinfo(np.int64).min, dtype=np.int64)
    used = np.zeros(len(ids), dtype=np.bool_)
    np.minimum.at(minimum, groups, member_labels)
    np.maximum.at(maximum, groups, member_labels)
    used[groups] = True
    deadline.check()
    return int(np.count_nonzero(used & (minimum != maximum)))


def compare(ids: readers.I64, actual: readers.I64, expected: readers.I64,
            config: models.OracleConfig, record: models.OracleReceipt, deadline: io.Deadline) -> None:
    mismatches = 0
    for start in range(0, len(ids), config.limits.batch_rows):
        deadline.check()
        stop = min(len(ids), start + config.limits.batch_rows)
        mismatches += int(np.count_nonzero(actual[start:stop] != expected[start:stop]))
        record.compared_rows += stop-start
    record.numeric_mismatches = mismatches
    if config.algorithm == "wcc":
        record.false_merge_groups = conflicts(ids, actual, expected, deadline)
        record.false_split_groups = conflicts(ids, expected, actual, deadline)
        record.membership_mismatches = mismatches
        io.require(record.false_merge_groups == record.false_split_groups == 0,
                   "WCC false merge or split in full partition comparison")
        record.full_partition_comparison_passed = True
    else:
        record.distance_mismatches = mismatches
        record.reachable_vertices = int(np.count_nonzero(actual >= 0))
        record.unreachable_vertices = len(ids) - record.reachable_vertices
        record.maximum_finite_hops = int(actual.max(initial=0))
        record.source = config.source
    io.require(record.compared_rows == len(ids) and mismatches == 0, "full exact per-vertex label/hop mismatch")
    record.full_numeric_comparison_passed = True
