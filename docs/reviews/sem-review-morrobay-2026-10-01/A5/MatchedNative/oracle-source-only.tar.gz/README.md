# Native matched physical output oracle

This source preparation compares complete physical results from a separately
exited graphframes-rs reference and a candidate. It launches no engines and
belongs outside the launch-to-exit timer. All eighteen bounded controls are
offline declared fixtures; they do not qualify a native engine or production run.

The production modules are `matched_models.py`, `matched_io.py`,
`matched_readers.py`, `matched_compare.py`, `matched_numeric.py`, and
`matched_oracle.py`. `freeze.json` binds their immutable bytes.

## Contracts

| Algorithm | Pecan raw output | Graphframes raw output | Full comparison |
| --- | --- | --- | --- |
| WCC | `id:int64, component:int64` | `id:int64, component:int64` | Exact canonical minimum original member, both directions of partition equivalence, every vertex |
| BFS | `id:int64, hops:int64` | `id:int64, dist_SOURCE:int32` | Every vertex's exact directed hop count; Pecan NULL and GF INT32_MAX are unreachable |
| PageRank | `id:int64, pagerank:double` | `id:int64, pagerank:double` | Every finite vertex score within the predeclared binary64 absolute bound 1e-12 |

Column order is retained and read by name; extra, duplicate, wrong or missing
fields refuse. No result file is cast, rewritten, normalized or removed. Complete
original signed int64 vertex coverage, uniqueness, non-null IDs, per-file footer
and physical row counts are mandatory. The ordinal representation allocates by
vertex count, so negative IDs and signed extremes do not create sparse arrays.

BFS uses stored `source -> target` arcs, Cit source 5795784 and Graph500 source
798169. This projection is `id,hops` and does not compare or export BFS distance
or predecessor. It does not qualify official Graph500 undirected BFS or
PageRank ground truth. WCC uses canonical labels; arbitrary representative
labels are outside this contract.

The graphframes reference preparation checks its full physical domain and WCC
canonical labels or BFS source zero, and records `reference_prepared` with zero
compared rows and no numerical comparison. A candidate requires a distinct raw
directory and records `passed_full_physical_matched` only after full comparison
and immutable closure. Agreement with this reference is not an independent
graph topology correctness proof.

## Parent interface

`matched_oracle.verify(config, configuration=FilePin)` returns `OracleReceipt`.
The CLI is `python matched_oracle.py --config /absolute/config.json`. With an
isolated interpreter, explicitly insert this helper directory before `runpy`;
direct `-I` execution excludes siblings.

`OracleConfig` records algorithm, dataset, exact original vertices and edges
FilePins, expected_rows, BFS-only source, graphframes_reference, candidate,
output, reference_preparation_only and limits. Both `ResultDataset` values keep
the frozen native PageRank `ExitObservation`/`ExitProof` shape. Parent proofs
bind natural returncode 0, waited child and owned group absence, complete raw
inventory, child configuration and child receipt. Both child configurations
must match algorithm, dataset, original paths and applicable algorithm contract;
both raw receipts must match that configuration and exact output projection.

Positive candidate acceptance requires outcome `passed_full_physical_matched`,
finished_utc, error/traceback null, integrity_errors empty,
own_identity_closure_passed, full_physical_domain_passed,
full_numeric_comparison_passed, equal complete expected/reference/candidate/
unique_candidate/compared counts, and zero numeric_mismatches. WCC additionally
requires canonical_labels_passed/full_partition_comparison_passed and zero
canonical/membership/merge/split mismatches. BFS requires zero distance
mismatches and the declared source. Parent independently proves final process
ownership and complete physical retention; those are not promoted by the oracle.

## Retention and bounds

Original inputs, raw outputs including sidecars, parent/child metadata and all
six loaded helper modules are hashed before and after checking. Complete raw
inventories are compared again at closure. A late mutation downgrades a pass.
Fresh exclusive output directories prevent retry or overwrite. Work and closure
deadlines are separate, errors and partial counts are retained durably.

The admission model is `128*V + 256*batch_rows + 2*max_rowgroup_bytes + 512 MiB`.
It models simultaneously live ordinal vectors, bounded Arrow batches, WCC
scatter work and library allowance. This is a modeled bound, not observed RSS
or an OS memory cap. Native host observations belong to the supervisor.

Run the eighteen declared controls with `python -m unittest -v
test_matched_oracle` in this directory. Ruff and strict mypy include all seven
Python files. Production execution, retained full inputs, reference generation,
timers and native qualification remain root-owned.
