# Source contracts and limitations

Pecan controller is d0e4e422afdea967126ae7b9506e04c9f1812b97. The optimized
native Sail runtime is 9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3; these are
separate pins, and their Rust build parity is an independently retained root
admission. Graphframes-rs is b4da56dabe20bba8e29563e06acc5179b2113ce3.
The benchmark runtime/measurement helpers are frozen at
6ae2e43a903c2cee02da170465c922c72b76198e.

Exact d0 Pecan `algorithms.py` and `pagerank_pregel_delta.py` are byte identical
to controller 0d1ef2ca3; the source audit binds exact Git objects rather than
the dirty common checkout. Dynamic PageRank initializes rank and delta to reset
probability .15, sends on the first step, then sends when delta exceeds .01,
uses damping .85, caps at ten rounds and normalizes its final scores. No dangling
redistribution, ordinary Grust PageRank or official undirected archive contract
is substituted. The predeclared PageRank comparison functions are copied
losslessly from the frozen native oracle; their source segments are bound in
`source-audit.json`.

Pecan BFS expands the active frontier over the stored directed adjacency and
left joins the final state against all original vertices. Its public output
has `id,distance,hops,parent`; this campaign exports the explicit `id,hops`
projection for comparison with graphframes-rs's full `id,dist_SOURCE` output.
Pecan unreachable hop counts remain NULL. Graphframes uses Int32 zero at the
source and INT32_MAX for unreachable vertices; its default traversal follows
the stored forward arcs. No `--to-landmarks` or `--symmetrize` is permitted by
the parent command contract. Original edge column names require explicit
`--src-col-name source --dst-col-name target` in its CLI.

The Fable A2-local source is a historical protocol lead: it uses Cit source
5795784, Graph500 source 798169 and exports all four Pecan BFS fields, while its
oracle compares hops. This campaign deliberately projects the two compared
logical fields. Its timer does not reproduce that four-field export boundary.
The historical Fable graphframes pin is ba2fdd8, not this campaign's b4da pin.

Graph500's official archive declares directed=false and BFS source 2592222.
Stored Parquet direction and source 798169 are a separate contract. Vertex/edge
counts or matching names alone do not certify archive topology equivalence.
No official archive, Sem execution class, full signed-graph conformance,
independent correctness reference, or generic PageRank stopping parity is
qualified by this source preparation.
