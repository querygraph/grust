"""Typed native graph physical output and parent-observed waited-exit contracts."""
from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Digest = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]
Count = Annotated[int, Field(strict=True, ge=0)]
Positive = Annotated[int, Field(strict=True, gt=0)]
Engine = Literal["pecan", "graphframes"]
Outcome = Literal["checking", "passed_full_physical_matched", "reference_prepared", "mismatch", "error", "timeout", "interrupted"]
ABSOLUTE_BOUND = 1e-12
Algorithm = Literal["wcc", "bfs", "pagerank"]
CIT_ROWS = 3_774_768
GRAPH_ROWS = 8_870_942
GRAPH_VERTEX_SHA = "f186f0fac502106454ceae29a57c7f350ae60699b5a5087b3001cfd054983428"
CIT_EDGE_SHA = "70bcba17b5a7762ef5a0c3d16c1dc37a352461b83e338f550ae897d844f0268f"
GRAPH_EDGE_SHA = "da4f324e619c97d68190c0eba4e2f9e59ebcd492d84c3e1bafe7624fdc7e2453"
CIT_VERTEX_SHA = "0969ea9ede0969e18e76a2c70191ed7ccecaecb9f1da6d954093dbefbc8958aa"


class Record(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False, strict=True)


def absolute_path(path: Path) -> Path:
    if not path.is_absolute() or ".." in path.parts:
        raise ValueError("absolute canonical file path required")
    return path


def exact_true(value: object) -> object:
    if value is not True:
        raise ValueError("exact observed true flag required")
    return value


def exact_zero(value: object) -> object:
    if type(value) is not int or value != 0:
        raise ValueError("exact observed integer returncode0 required")
    return value


class FileIdentity(Record):
    bytes: Count
    sha256: Digest


class FilePin(FileIdentity):
    path: Path

    _absolute = field_validator("path")(absolute_path)

    def identity(self) -> FileIdentity:
        return FileIdentity(bytes=self.bytes, sha256=self.sha256)


def relative_names(files: dict[str, FileIdentity]) -> dict[str, FileIdentity]:
    if not files or any(not name or Path(name).is_absolute() or ".." in Path(name).parts
                        or Path(name).as_posix() != name for name in files):
        raise ValueError("nonempty canonical relative file inventory required")
    return files


class ExitProof(Record):
    """Parent writes after wait and independently observed owned group closure.

    For graphframes, server_group_absent refers to its native CLI runtime group;
    no separate Sail server is implied. Final parent retention remains separate.
    """

    engine: Engine
    run_id: str = Field(min_length=1, strict=True)
    child_pid: Positive
    returncode: Literal[0]
    wait_completed: Literal[True]
    child_group_absent: Literal[True]
    server_group_absent: Literal[True]
    raw_directory: Path
    raw_files: dict[str, FileIdentity]
    child_receipt: FilePin
    configuration: FilePin
    observed_utc: str = Field(min_length=1, strict=True)

    _absolute = field_validator("raw_directory")(absolute_path)
    _names = field_validator("raw_files")(relative_names)
    _flags = field_validator("wait_completed", "child_group_absent", "server_group_absent", mode="before")(exact_true)
    _returncode = field_validator("returncode", mode="before")(exact_zero)


class ExitObservation(Record):
    engine: Engine
    run_id: str = Field(min_length=1, strict=True)
    child_pid: Positive
    returncode: Literal[0]
    wait_completed: Literal[True]
    producer_receipt: FilePin
    _flag = field_validator("wait_completed", mode="before")(exact_true)
    _returncode = field_validator("returncode", mode="before")(exact_zero)


class ResultDataset(Record):
    engine: Engine
    directory: Path
    files: dict[str, FileIdentity]
    exit: ExitObservation

    _absolute = field_validator("directory")(absolute_path)
    _names = field_validator("files")(relative_names)

    @model_validator(mode="after")
    def engine_matches(self) -> Self:
        if self.engine != self.exit.engine:
            raise ValueError("result/exit engine differs")
        return self


class Limits(Record):
    batch_rows: int = Field(default=65536, strict=True, gt=0, le=262144)
    maximum_files: int = Field(default=512, strict=True, gt=0, le=512)
    maximum_entries: int = Field(default=8192, strict=True, gt=0, le=8192)
    maximum_row_group_bytes: Positive = 256 * 2**20
    maximum_total_file_bytes: Positive = 4 * 2**30
    memory_budget_bytes: Positive = 4 * 2**30
    timeout_seconds: float = Field(default=1800.0, gt=0, le=14400)
    closure_timeout_seconds: float = Field(default=300.0, gt=0, le=3600)


class OracleConfig(Record):
    algorithm: Algorithm
    dataset: Literal["cit-Patents", "graph500-24", "tiny"]
    expected_rows: Positive
    input_vertices: FilePin
    input_edges: FilePin
    source: int | None = Field(default=None, strict=True, ge=-(2**63), lt=2**63)
    directed: Literal[True] = True
    canonical_labels: Literal[True] = True
    graphframes_reference: ResultDataset
    candidate: ResultDataset
    output: Path
    reference_preparation_only: bool = Field(default=False, strict=True)
    limits: Limits = Field(default_factory=Limits)

    _absolute = field_validator("output")(absolute_path)
    _fixed_flags = field_validator("directed", "canonical_labels", mode="before")(exact_true)

    @model_validator(mode="after")
    def contract(self) -> Self:
        if self.dataset == "cit-Patents" and (self.expected_rows, self.input_vertices.bytes,
                                             self.input_vertices.sha256) != (CIT_ROWS, 3_861_941, CIT_VERTEX_SHA):
            raise ValueError("exact retained Cit-Patents vertex domain required")
        if self.dataset == "cit-Patents" and (self.input_edges.bytes, self.input_edges.sha256) != (70_037_384, CIT_EDGE_SHA):
            raise ValueError("exact retained Cit-Patents edges required")
        if self.dataset == "graph500-24" and (self.expected_rows, self.input_vertices.bytes,
                                             self.input_vertices.sha256, self.input_edges.bytes,
                                             self.input_edges.sha256) != (GRAPH_ROWS, 9_119_859, GRAPH_VERTEX_SHA,
                                                                        837_233_354, GRAPH_EDGE_SHA):
            raise ValueError("exact retained Graph500-24 originals required")
        if (self.algorithm == "bfs") != (self.source is not None):
            raise ValueError("only BFS requires a configured source")
        if (self.algorithm == "bfs" and self.dataset != "tiny"
                and self.source != (5_795_784 if self.dataset == "cit-Patents" else 798_169)):
            raise ValueError("exact native campaign BFS source required")
        if self.dataset == "tiny" and self.expected_rows > 1024:
            raise ValueError("tiny control exceeds1024vertices")
        if self.graphframes_reference.engine != "graphframes":
            raise ValueError("physical reference must be graphframes")
        same = self.graphframes_reference == self.candidate
        if self.reference_preparation_only != same:
            raise ValueError("self-reference only qualifies reference preparation")
        if not same and (self.graphframes_reference.directory == self.candidate.directory
                         or self.graphframes_reference.directory.is_relative_to(self.candidate.directory)
                         or self.candidate.directory.is_relative_to(self.graphframes_reference.directory)):
            raise ValueError("comparison requires disjoint physical reference/candidate directories")
        return self


class PhysicalField(Record):
    name: str
    arrow_type: str
    nullable: bool


class CanonicalResult(Record):
    components: Count
    mismatches: Count


class PhysicalFile(Record):
    file: str
    fields: tuple[PhysicalField, ...]
    footer_rows: Count
    maximum_row_group_bytes: Count


class NumericWitness(Record):
    vertex_id: int
    actual_hex: str
    reference_hex: str
    absolute_error_hex: str


class OracleReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    config: OracleConfig
    algorithm: Algorithm
    started_utc: str
    observed_utc: str
    finished_utc: str | None = None
    outcome: Outcome = "checking"
    error: str | None = None
    traceback: str | None = None
    absolute_bound: float = ABSOLUTE_BOUND
    absolute_bound_hex: str = ABSOLUTE_BOUND.hex()
    expected_domain_rows: Count = 0
    reference_rows: Count = 0
    candidate_rows: Count = 0
    compared_rows: Count = 0
    unique_candidate_rows: Count = 0
    numeric_mismatches: Count = 0
    membership_mismatches: Count = 0
    distance_mismatches: Count = 0
    false_merge_groups: Count = 0
    false_split_groups: Count = 0
    canonical_mismatches: Count = 0
    components: Count | None = None
    reachable_vertices: Count | None = None
    unreachable_vertices: Count | None = None
    maximum_finite_hops: Count | None = None
    source: int | None = None
    full_partition_comparison_passed: bool = False
    canonical_labels_passed: bool = False
    adapters: dict[str, str] = Field(default_factory=dict)
    max_absolute_error: float | None = None
    max_absolute_error_hex: str | None = None
    max_relative_error: float | None = None
    max_relative_error_hex: str | None = None
    witnesses: list[NumericWitness] = Field(default_factory=list)
    physical_schemas: dict[str, list[PhysicalFile]] = Field(default_factory=dict)
    identity_before: dict[str, FilePin] = Field(default_factory=dict)
    identity_after: dict[str, FilePin] = Field(default_factory=dict)
    exit_proofs: dict[str, ExitProof] = Field(default_factory=dict)
    integrity_errors: list[str] = Field(default_factory=list)
    own_identity_closure_passed: bool = False
    full_physical_domain_passed: bool = False
    full_numeric_comparison_passed: bool = False
    independent_parent_retention_qualified: Literal[False] = False
    performance_comparison: Literal[False] = False
    scope: str = "Full physical original-domain and declared canonical WCC/directed BFS/dynamic PageRank comparison after parent-observed natural child exits; final parent retention/ownership and generic semantics qualification remain separate."
