"""Read exact physical outputs by named field, preserving raw schemas and identities."""
from __future__ import annotations

from pathlib import Path
from typing import cast

import matched_io as io
import matched_models as models
import numpy as np
import numpy.typing as npt
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

I64 = npt.NDArray[np.int64]
F64 = npt.NDArray[np.float64]
Vector = I64 | F64


def fields(config: models.OracleConfig, engine: models.Engine | None) -> dict[str, pa.DataType]:
    if engine is None:
        return {"id": pa.int64()}
    if config.algorithm == "wcc":
        return {"id": pa.int64(), "component": pa.int64()}
    if config.algorithm == "pagerank":
        return {"id": pa.int64(), "pagerank": pa.float64()}
    return {"id": pa.int64(), "hops": pa.int64()} if engine == "pecan" else {
        "id": pa.int64(), f"dist_{config.source}": pa.int32()}


def physical(path: Path, name: str, expected: dict[str, pa.DataType], config: models.OracleConfig,
             deadline: io.Deadline) -> models.PhysicalFile:
    deadline.check()
    with pq.ParquetFile(path) as parquet:
        schema = parquet.schema_arrow
        raw_fields = tuple(models.PhysicalField(name=f.name, arrow_type=str(f.type), nullable=f.nullable) for f in schema)
        groups = [sum(parquet.metadata.row_group(i).column(j).total_uncompressed_size
                      for j in range(parquet.metadata.row_group(i).num_columns))
                  for i in range(parquet.metadata.num_row_groups)]
        maximum = max(groups, default=0)
        io.require(maximum <= config.limits.maximum_row_group_bytes, "uncompressed rowgroup exceeds admission")
        io.require(len(schema.names) == len(expected) and len(set(schema.names)) == len(expected)
                   and set(schema.names) == set(expected), "physical field names differ: " + name)
        io.require(all(schema.field(key).type == kind for key, kind in expected.items()),
                   "physical types differ: " + name)
        return models.PhysicalFile(file=name, fields=raw_fields, footer_rows=parquet.metadata.num_rows,
                                   maximum_row_group_bytes=maximum)


def positions(ids: I64, keys: I64) -> npt.NDArray[np.intp]:
    ordinals = np.searchsorted(ids, keys)
    present = ordinals < len(ids)
    matched = np.zeros(len(keys), dtype=np.bool_)
    matched[present] = ids[ordinals[present]] == keys[present]
    io.require(bool(np.all(matched)), "raw ID/label outside complete original vertex domain")
    return ordinals


def domain(config: models.OracleConfig, record: models.OracleReceipt, deadline: io.Deadline) -> I64:
    descriptor = physical(config.input_vertices.path, config.input_vertices.path.name, fields(config, None), config, deadline)
    record.physical_schemas["input"] = [descriptor]
    io.require(descriptor.footer_rows == config.expected_rows, "input footer differs from expected completeV")
    ids: I64 = np.empty(config.expected_rows, dtype=np.int64)
    count = 0
    with pq.ParquetFile(config.input_vertices.path) as parquet:
        for batch in parquet.iter_batches(batch_size=config.limits.batch_rows, use_threads=False):
            deadline.check()
            column = batch.column(batch.schema.get_field_index("id"))
            io.require(column.null_count == 0, "null input vertex")
            values = cast(I64, column.to_numpy(zero_copy_only=False))
            io.require(count + len(values) <= len(ids), "input exceeds expected vertex count")
            ids[count:count+len(values)] = values
            count += len(values)
    io.require(count == config.expected_rows, "input physical/footer count differs")
    ids.sort()
    io.require(bool(np.all(ids[1:] > ids[:-1])), "duplicate original vertex ID")
    if config.source is not None:
        positions(ids, np.array([config.source], dtype=np.int64))
    record.expected_domain_rows = count
    ids.setflags(write=False)
    return ids


def adapt(column: pa.Array[pa.Scalar[pa.DataType]], dataset: models.ResultDataset, config: models.OracleConfig) -> Vector:
    if config.algorithm == "pagerank":
        io.require(column.null_count == 0, "null raw PageRank")
        scores = cast(F64, column.to_numpy(zero_copy_only=False))
        io.require(bool(np.all(np.isfinite(scores))), "nonfinite raw DOUBLE rank")
        return scores
    if config.algorithm == "wcc":
        io.require(column.null_count == 0, "null raw WCC label")
        return cast(I64, column.to_numpy(zero_copy_only=False))
    if dataset.engine == "pecan":
        # This adapter changes only in-memory comparison representation, never raw output.
        nulls = column.is_null().to_numpy(zero_copy_only=False)
        filled = cast("pa.Array[pa.Scalar[pa.DataType]]", pc.fill_null(column, pa.scalar(-1, type=pa.int64())))
        hops = cast(I64, filled.to_numpy(zero_copy_only=False))
        io.require(bool(np.all(nulls | ((hops >= 0) & (hops < 2**31 - 1)))),
                   "Pecan BFS finite hops must be nonnegative and below GF sentinel")
        return hops
    io.require(column.null_count == 0, "null GF BFS hop")
    hops = column.to_numpy(zero_copy_only=False).astype(np.int64)
    io.require(bool(np.all(hops >= 0)), "negative GF BFS hop")
    hops[hops == 2**31 - 1] = -1
    return hops


def values(dataset: models.ResultDataset, role: str, ids: I64, config: models.OracleConfig,
           record: models.OracleReceipt, deadline: io.Deadline) -> Vector:
    io.require(io.inventory(dataset.directory, config.limits, deadline) == dataset.files,
               "complete raw inventory differs: " + role)
    for name, identity in dataset.files.items():
        record.identity_before[role+"/raw/"+name] = models.FilePin(path=dataset.directory/name, **identity.model_dump())
    names = [name for name in dataset.files if name.endswith(".parquet")]
    io.require(bool(names), "no physical result Parquet: " + role)
    expected = fields(config, dataset.engine)
    descriptors = [physical(dataset.directory/name, name, expected, config, deadline) for name in names]
    record.physical_schemas[role] = descriptors
    io.require(sum(p.footer_rows for p in descriptors) == len(ids), "raw footer cardinality differs: " + role)
    seen = np.zeros(len(ids), dtype=np.bool_)
    result: Vector
    if config.algorithm == "pagerank":
        result = np.empty(len(ids), dtype=np.float64)
    else:
        result = np.empty(len(ids), dtype=np.int64)
    count = 0
    value_name = next(name for name in expected if name != "id")
    for descriptor in descriptors:
        file_rows = 0
        with pq.ParquetFile(dataset.directory/descriptor.file) as parquet:
            for batch in parquet.iter_batches(batch_size=config.limits.batch_rows, use_threads=False):
                deadline.check()
                key_column = batch.column(batch.schema.get_field_index("id"))
                io.require(key_column.null_count == 0, "null raw vertex ID")
                keys = cast(I64, key_column.to_numpy(zero_copy_only=False))
                ordinals = positions(ids, keys)
                unique = np.unique(ordinals)
                io.require(len(unique) == len(ordinals) and not bool(np.any(seen[unique])),
                           "duplicate raw ID inside/across batches/files: " + role)
                seen[ordinals] = True
                result[ordinals] = adapt(batch.column(batch.schema.get_field_index(value_name)), dataset, config)
                count += len(keys)
                file_rows += len(keys)
                if role == "reference":
                    record.reference_rows = count
                else:
                    record.candidate_rows = count
        io.require(file_rows == descriptor.footer_rows, "physical/footer rows differ: " + role)
    io.require(count == len(ids) and bool(np.all(seen)), "missing raw vertex: " + role)
    if config.algorithm == "bfs":
        io.require(config.source is not None, "BFS source missing")
        source = positions(ids, np.array([config.source], dtype=np.int64))[0]
        io.require(int(result[source]) == 0 and int(np.count_nonzero(result == 0)) == 1,
                   "BFS source must be the only zero-hop vertex")
        record.adapters[role] = "Pecan BIGINT hops: NULL -> -1" if dataset.engine == "pecan" else (
            f"GF Int32 dist_{config.source}: INT32_MAX -> -1; all other values losslessly widened")
    result.setflags(write=False)
    return result
