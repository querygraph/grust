"""Complete physical WCC/BFS/PageRank outputs versus a separately exited GF reference."""
from __future__ import annotations

import argparse
import sys
import time
import traceback
from pathlib import Path
from typing import cast

import matched_compare as exact
import matched_io as io
import matched_models as models
import matched_numeric as numeric
import matched_readers as readers
import pydantic

JSON = pydantic.TypeAdapter(dict[str, pydantic.JsonValue])
CONTROLLER = "d0e4e422afdea967126ae7b9506e04c9f1812b97"
RUNTIME = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
GF = "b4da56dabe20bba8e29563e06acc5179b2113ce3"


def admit_exit(dataset: models.ResultDataset, role: str, config: models.OracleConfig,
               record: models.OracleReceipt, deadline: io.Deadline) -> None:
    observed = dataset.exit
    proof = models.ExitProof.model_validate_json(io.metadata(observed.producer_receipt, deadline))
    io.require((proof.engine, proof.run_id, proof.child_pid, proof.returncode, proof.wait_completed) ==
               (observed.engine, observed.run_id, observed.child_pid, observed.returncode, observed.wait_completed),
               "parent waited-exit binding differs: " + role)
    io.require(proof.raw_directory == dataset.directory and proof.raw_files == dataset.files,
               "parent exited proof raw output binding differs: " + role)
    raw_config = JSON.validate_json(io.metadata(proof.configuration, deadline))
    io.require(raw_config.get("algorithm") == config.algorithm and raw_config.get("dataset") == config.dataset
               and raw_config.get("engine") == dataset.engine
               and raw_config.get("vertices") == str(config.input_vertices.path)
               and raw_config.get("edges") == str(config.input_edges.path), "producer algorithm/originals differ")
    if config.algorithm == "bfs":
        io.require(type(raw_config.get("source")) is int and raw_config.get("source") == config.source
                   and raw_config.get("directed") is True, "BFS producer source/direction differs")
    if config.algorithm == "wcc":
        io.require(raw_config.get("canonical_labels") is True, "WCC producer canonical contract differs")
    raw_child = JSON.validate_json(io.metadata(proof.child_receipt, deadline))
    io.require(raw_child.get("config") == raw_config and raw_child.get("outcome") == "passed"
               and raw_child.get("cleanup_errors") == [] and raw_child.get("error") is None,
               "actual child execution/cleanup differs")
    projection = ["id", next(name for name in readers.fields(config, dataset.engine) if name != "id")]
    io.require(raw_child.get("output_projection") == projection, "actual raw projection differs")
    if config.algorithm == "pagerank":
        io.require(raw_config.get("method") == "pregel_delta" and raw_config.get("reset_probability") == 0.15
                   and raw_config.get("tolerance") == 0.01 and raw_config.get("max_iterations") == 10
                   and raw_config.get("normalize") is True and raw_config.get("vote_to_halt") is False,
                   "dynamic PageRank producer contract differs")
    if config.dataset != "tiny":
        io.require(raw_child.get("declared_controller_pin") == CONTROLLER
                   and raw_child.get("declared_runtime_pin") == (RUNTIME if dataset.engine == "pecan" else GF)
                   and raw_child.get("declared_harness_pin") == "6ae2e43a903c2cee02da170465c922c72b76198e",
                   "actual child source declaration differs")
    record.exit_proofs[role] = proof
    for name, pin in {"exit-proof": observed.producer_receipt, "child-receipt": proof.child_receipt,
                      "configuration": proof.configuration}.items():
        record.identity_before[role+"/"+name] = pin


def outcome(error: BaseException) -> models.Outcome:
    if isinstance(error, io.TimedOut):
        return "timeout"
    if isinstance(error, (KeyboardInterrupt, SystemExit)):
        return "interrupted"
    return "mismatch" if isinstance(error, io.Mismatch) else "error"


def verify(config: models.OracleConfig, *, configuration: models.FilePin | None = None) -> models.OracleReceipt:
    started = time.monotonic()
    deadline = io.Deadline(started, config.limits.timeout_seconds)
    io.fresh(config)
    record = models.OracleReceipt(config=config, algorithm=config.algorithm, started_utc=io.utc(), observed_utc=io.utc())
    path = config.output/"receipt.json"
    io.save(path, record)
    try:
        modeled = (config.expected_rows * 128 + config.limits.batch_rows * 256
                   + 2 * config.limits.maximum_row_group_bytes + 512 * 2**20)
        io.require(modeled <= config.limits.memory_budget_bytes, "conservative ordinal/rowgroup/library memory admission refused")
        sources = (Path(__file__).resolve(), Path(models.__file__).resolve(), Path(io.__file__).resolve(),
                   Path(readers.__file__).resolve(), Path(exact.__file__).resolve(), Path(numeric.__file__).resolve())
        for source in sources:
            record.identity_before["helper/"+source.name] = io.pin(source, deadline)
        if configuration is not None:
            io.verify(configuration, deadline)
            record.identity_before["oracle-configuration"] = configuration
        for name, pin in (("input-vertices", config.input_vertices), ("input-edges", config.input_edges)):
            io.verify(pin, deadline)
            record.identity_before[name] = pin
        admit_exit(config.graphframes_reference, "reference", config, record, deadline)
        admit_exit(config.candidate, "candidate", config, record, deadline)
        ids = readers.domain(config, record, deadline)
        reference = readers.values(config.graphframes_reference, "reference", ids, config, record, deadline)
        candidate = readers.values(config.candidate, "candidate", ids, config, record, deadline)
        record.unique_candidate_rows = len(ids)
        record.full_physical_domain_passed = True
        if config.algorithm == "wcc":
            ref_canonical = exact.canonical(ids, cast(readers.I64, reference), deadline)
            candidate_canonical = exact.canonical(ids, cast(readers.I64, candidate), deadline)
            record.canonical_mismatches = ref_canonical.mismatches + candidate_canonical.mismatches
            record.components = candidate_canonical.components
            io.require(record.canonical_mismatches == 0, "WCC label is not the minimum original member")
            record.canonical_labels_passed = True
        if config.reference_preparation_only:
            record.outcome = "reference_prepared"
        else:
            if config.algorithm == "pagerank":
                numeric.compare(ids, cast(readers.F64, candidate), cast(readers.F64, reference), record, config, deadline)
            else:
                exact.compare(ids, cast(readers.I64, candidate), cast(readers.I64, reference), config, record, deadline)
            record.outcome = "passed_full_physical_matched"
    except BaseException as error:  # noqa: BLE001 - retain utility failure; never owns engines.
        record.outcome = outcome(error)
        record.error, record.traceback = repr(error), traceback.format_exc()
    finally:
        closure = io.Deadline(time.monotonic(), config.limits.closure_timeout_seconds)
        for role, dataset in (("reference", config.graphframes_reference), ("candidate", config.candidate)):
            try:
                io.require(io.inventory(dataset.directory, config.limits, closure) == dataset.files,
                           "complete raw inventory changed at closure: " + role)
            except BaseException as error:  # noqa: BLE001 - preserve all closure failures.
                record.integrity_errors.append(role+": "+repr(error))
        for key, expected in record.identity_before.items():
            try:
                actual = io.pin(expected.path, closure)
                record.identity_after[key] = actual
                io.require(actual == expected, "immutable closure differs: "+key)
            except BaseException as error:  # noqa: BLE001 - preserve all closure failures.
                record.integrity_errors.append(key+": "+repr(error))
        record.own_identity_closure_passed = not record.integrity_errors and record.identity_before == record.identity_after
        if not record.own_identity_closure_passed and record.outcome in ("passed_full_physical_matched", "reference_prepared"):
            record.outcome, record.error = "error", "immutable source/input/reference/raw closure failed"
        record.finished_utc = io.utc()
        io.save(path, record)
    return record


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    configuration = io.pin(args.config.resolve(), io.Deadline(time.monotonic(), 300))
    config = models.OracleConfig.model_validate_json(io.metadata(configuration, io.Deadline(time.monotonic(), 300)))
    result = verify(config, configuration=configuration)
    return 0 if result.outcome in ("passed_full_physical_matched", "reference_prepared") else 1


if __name__ == "__main__":
    sys.exit(main())
