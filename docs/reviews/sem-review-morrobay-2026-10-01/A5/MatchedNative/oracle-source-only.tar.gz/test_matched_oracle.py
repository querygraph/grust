"""Bounded declared tiny physical files and mocked mutation; no native engine work."""
from __future__ import annotations

import json
import tempfile
import time
import unittest
from pathlib import Path
from typing import cast
from unittest import mock

import matched_io as io
import matched_models as models
import matched_numeric as numeric
import matched_oracle as oracle
import matched_readers as readers
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

IDS = [-(2**63), -7694170072594669674, -1, 0, 1, 2, 2**53+1, 2**63-1]
LABELS = [IDS[0], IDS[1], -1, 0, 1, 1, IDS[6], IDS[7]]
HOPS: list[int | None] = [None, None, None, None, 0, 1, None, None]


class Controls(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name).resolve()
        self.counter = 0
        self.vertices = self.root / "vertices.parquet"
        self.edges = self.root / "edges.parquet"
        pq.write_table(pa.table({"id": pa.array(IDS, type=pa.int64())}), self.vertices)
        pq.write_table(pa.table({"source": pa.array([1, 0, 1], type=pa.int64()),
                                 "target": pa.array([2, 0, 2], type=pa.int64())}), self.edges)

    def deadline(self) -> io.Deadline:
        return io.Deadline(time.monotonic(), 30)

    def pin(self, path: Path) -> models.FilePin:
        return io.pin(path, self.deadline())

    def result(self, engine: models.Engine, algorithm: models.Algorithm, values: list[int | float | None], *,
               ids: list[int | None] | None = None, kind: pa.DataType | None = None,
               extra: bool = False) -> models.ResultDataset:
        self.counter += 1
        run = self.root / f"{engine}-{self.counter}"
        run.mkdir()
        directory = run / "result"
        directory.mkdir()
        source = 1 if algorithm == "bfs" else None
        name = {"wcc": "component", "pagerank": "pagerank", "bfs": "hops" if engine == "pecan" else "dist_1"}[algorithm]
        physical_type = kind or (pa.float64() if algorithm == "pagerank" else
                                pa.int32() if algorithm == "bfs" and engine == "graphframes" else pa.int64())
        raw = [2**31-1 if value is None else value for value in values] if algorithm == "bfs" and engine == "graphframes" else values
        columns = {name: pa.array(raw, type=physical_type), "id": pa.array(IDS if ids is None else ids, type=pa.int64())}
        if extra:
            columns["unexpected"] = pa.array([0]*len(values), type=pa.int64())
        pq.write_table(pa.table(columns), directory / "part.parquet", row_group_size=3)
        config = {"algorithm": algorithm, "dataset": "tiny", "engine": engine, "vertices": str(self.vertices), "edges": str(self.edges),
                  "source": source, "directed": True, "canonical_labels": True, "method": "pregel_delta",
                  "reset_probability": 0.15, "tolerance": 0.01, "max_iterations": 10,
                  "normalize": True, "vote_to_halt": False}
        configuration = run / "child-config.json"
        configuration.write_text(json.dumps(config))
        child = run / "engine-receipt.json"
        child.write_text(json.dumps({"config": config, "outcome": "passed", "cleanup_errors": [], "error": None,
                                     "output_projection": ["id", name]}))
        files = io.inventory(directory, models.Limits(), self.deadline())
        proof = models.ExitProof(engine=engine, run_id=run.name, child_pid=100+self.counter,
            returncode=0, wait_completed=True, child_group_absent=True, server_group_absent=True,
            raw_directory=directory, raw_files=files, child_receipt=self.pin(child),
            configuration=self.pin(configuration), observed_utc=io.utc())
        path = run / "engine-exited.json"
        path.write_text(proof.model_dump_json())
        return models.ResultDataset(engine=engine, directory=directory, files=files,
            exit=models.ExitObservation(engine=engine, run_id=run.name, child_pid=proof.child_pid,
                returncode=0, wait_completed=True, producer_receipt=self.pin(path)))

    def config(self, algorithm: models.Algorithm, expected: list[int | float | None],
               actual: list[int | float | None] | None = None, *, ids: list[int | None] | None = None,
               kind: pa.DataType | None = None, extra: bool = False,
               preparation: bool = False) -> models.OracleConfig:
        reference = self.result("graphframes", algorithm, expected)
        candidate = reference if preparation else self.result("pecan", algorithm, expected if actual is None else actual,
                                                              ids=ids, kind=kind, extra=extra)
        return models.OracleConfig(algorithm=algorithm, dataset="tiny", expected_rows=len(IDS),
            input_vertices=self.pin(self.vertices), input_edges=self.pin(self.edges), source=1 if algorithm == "bfs" else None,
            graphframes_reference=reference, candidate=candidate, output=self.root / f"oracle-{self.counter}",
            reference_preparation_only=preparation, limits=models.Limits(batch_rows=3))

    def test_signed_extremes_loops_duplicates_isolate_canonical_wcc(self) -> None:
        result = oracle.verify(self.config("wcc", cast(list[int | float | None], LABELS)))
        self.assertEqual(result.outcome, "passed_full_physical_matched")
        self.assertEqual(result.components, 7)
        self.assertTrue(result.canonical_labels_passed and result.full_partition_comparison_passed)
        self.assertTrue(result.own_identity_closure_passed)

    def test_wcc_false_merge_split_both_directions(self) -> None:
        for failure in ("merge", "split"):
            actual = LABELS.copy()
            if failure == "merge":
                actual[4:6] = [0, 0]
            else:
                actual[5] = 2
            with self.subTest(failure=failure):
                result = oracle.verify(self.config("wcc", cast(list[int | float | None], LABELS), cast(list[int | float | None], actual)))
                self.assertEqual(result.outcome, "mismatch")
                self.assertGreater(result.numeric_mismatches, 0)
                self.assertGreater(result.false_merge_groups if failure == "merge" else result.false_split_groups, 0)
                self.assertFalse(result.full_partition_comparison_passed)

    def test_wcc_noncanonical_and_nonmember_refuse(self) -> None:
        for label in (2, 3):
            actual = LABELS.copy()
            actual[4:6] = [label, label]
            result = oracle.verify(self.config("wcc", cast(list[int | float | None], LABELS), cast(list[int | float | None], actual)))
            self.assertEqual(result.outcome, "mismatch")
            self.assertFalse(result.canonical_labels_passed)

    def test_bfs_raw_named_field_order_null_sentinel(self) -> None:
        result = oracle.verify(self.config("bfs", cast(list[int | float | None], HOPS)))
        self.assertEqual(result.outcome, "passed_full_physical_matched")
        self.assertEqual((result.reachable_vertices, result.unreachable_vertices, result.maximum_finite_hops), (2, 6, 1))
        self.assertEqual([field.name for field in result.physical_schemas["reference"][0].fields], ["dist_1", "id"])
        self.assertEqual(result.compared_rows, 8)

    def test_bfs_wrong_direction_or_hop_refuses(self) -> None:
        actual = HOPS.copy()
        actual[5] = None
        result = oracle.verify(self.config("bfs", cast(list[int | float | None], HOPS), cast(list[int | float | None], actual)))
        self.assertEqual(result.outcome, "mismatch")
        self.assertEqual(result.distance_mismatches, 1)

    def test_bfs_source_and_unreachable_adapter_refuse(self) -> None:
        for bad, position in ((1, 4), (0, 5), (-1, 0), (2**31-1, 0)):
            actual = HOPS.copy()
            actual[position] = bad
            result = oracle.verify(self.config("bfs", cast(list[int | float | None], HOPS), cast(list[int | float | None], actual)))
            self.assertEqual(result.outcome, "mismatch")

    def test_missing_source_refuses_outside_timer(self) -> None:
        config = self.config("bfs", cast(list[int | float | None], HOPS)).model_copy(update={"source": 3})
        result = oracle.verify(config)
        self.assertEqual(result.outcome, "mismatch")
        self.assertFalse(result.full_physical_domain_passed)

    def test_duplicate_omit_outside_and_null_id_refuse(self) -> None:
        for ids, values in ((IDS[:-1], LABELS[:-1]), (IDS[:-1]+[IDS[0]], LABELS),
                            (IDS[:-1]+[4], LABELS), (IDS[:-1]+[None], LABELS)):
            config = self.config("wcc", cast(list[int | float | None], LABELS),
                                 cast(list[int | float | None], values), ids=cast(list[int | None], ids))
            result = oracle.verify(config)
            self.assertEqual(result.outcome, "mismatch")
            self.assertFalse(result.full_physical_domain_passed)

    def test_extra_wrong_physical_types_refuse(self) -> None:
        for kind, extra in ((pa.int32(), False), (None, True)):
            result = oracle.verify(self.config("wcc", cast(list[int | float | None], LABELS), kind=kind, extra=extra)) if extra else (
                oracle.verify(self.config("bfs", cast(list[int | float | None], HOPS), kind=kind)))
            self.assertEqual(result.outcome, "mismatch")

    def test_duplicate_physical_field_refuses(self) -> None:
        config = self.config("wcc", cast(list[int | float | None], LABELS))
        path = self.root / "duplicate-fields.parquet"
        pq.write_table(pa.Table.from_arrays([pa.array(IDS), pa.array(IDS)], names=["id", "id"]), path)
        with self.assertRaises(ValueError):
            readers.physical(path, path.name, {"id": pa.int64(), "component": pa.int64()}, config, self.deadline())

    def test_proof_missing_false_uncertain_refuses(self) -> None:
        config = self.config("wcc", cast(list[int | float | None], LABELS))
        proof = json.loads(config.candidate.exit.producer_receipt.path.read_bytes())
        for field in ("wait_completed", "child_group_absent", "server_group_absent"):
            broken = {**proof, field: False}
            with self.subTest(field=field), self.assertRaises(ValueError):
                models.ExitProof.model_validate_json(json.dumps(broken))

    def test_raw_identity_proof_config_binding_refuses(self) -> None:
        config = self.config("wcc", cast(list[int | float | None], LABELS))
        pin = config.candidate.exit.producer_receipt
        bad_pin = pin.model_copy(update={"sha256": "0"*64})
        bad = config.candidate.model_copy(update={"exit": config.candidate.exit.model_copy(update={"producer_receipt": bad_pin})})
        result = oracle.verify(config.model_copy(update={"candidate": bad}))
        self.assertEqual(result.outcome, "mismatch")

    def test_cross_dataset_producer_refuses_both_roles(self) -> None:
        for role in ("graphframes_reference", "candidate"):
            config = self.config("wcc", cast(list[int | float | None], LABELS))
            dataset = getattr(config, role)
            proof = models.ExitProof.model_validate_json(dataset.exit.producer_receipt.path.read_bytes())
            raw_config = json.loads(proof.configuration.path.read_bytes())
            raw_config["dataset"] = "graph500-24"
            proof.configuration.path.write_text(json.dumps(raw_config))
            child = json.loads(proof.child_receipt.path.read_bytes())
            child["config"] = raw_config
            proof.child_receipt.path.write_text(json.dumps(child))
            proof = proof.model_copy(update={"configuration": self.pin(proof.configuration.path),
                                            "child_receipt": self.pin(proof.child_receipt.path)})
            dataset.exit.producer_receipt.path.write_text(proof.model_dump_json())
            updated = dataset.model_copy(update={"exit": dataset.exit.model_copy(update={
                "producer_receipt": self.pin(dataset.exit.producer_receipt.path)})})
            result = oracle.verify(config.model_copy(update={role: updated}))
            self.assertEqual(result.outcome, "mismatch")
            self.assertFalse(result.full_physical_domain_passed)

    def test_reference_preparation_is_not_comparison(self) -> None:
        for algorithm, values in (("wcc", LABELS), ("bfs", HOPS), ("pagerank", [0.125]*8)):
            config = self.config(cast(models.Algorithm, algorithm), cast(list[int | float | None], values), preparation=True)
            result = oracle.verify(config)
            self.assertEqual(result.outcome, "reference_prepared")
            self.assertEqual(result.compared_rows, 0)
            self.assertFalse(result.full_numeric_comparison_passed)
            self.assertTrue(result.full_physical_domain_passed)

    def test_pr_frozen_exact_rational_bound_and_full_domain(self) -> None:
        self.assertTrue(numeric.within_bound(1e-12, 0.0))
        self.assertFalse(numeric.within_bound(float(np.nextafter(1e-12, np.inf)), 0.0))
        result = oracle.verify(self.config("pagerank", [0.125]*8, [0.125+1e-14]*8))
        self.assertEqual(result.outcome, "passed_full_physical_matched")
        self.assertEqual(result.compared_rows, 8)
        bad = oracle.verify(self.config("pagerank", [0.125]*8, [0.25]*8))
        self.assertEqual(bad.outcome, "mismatch")
        self.assertEqual(bad.numeric_mismatches, 8)

    def test_pr_nonfinite_physical_rank_refuses(self) -> None:
        result = oracle.verify(self.config("pagerank", [0.125]*8, [float("nan")]*8))
        self.assertEqual(result.outcome, "mismatch")

    def test_late_mutation_downgrades_pass_and_retains_receipt(self) -> None:
        config = self.config("wcc", cast(list[int | float | None], LABELS))
        original = io.inventory
        calls = 0

        def inventory(path: Path, limits: models.Limits, deadline: io.Deadline) -> dict[str, models.FileIdentity]:
            nonlocal calls
            calls += 1
            if calls == 3:
                with (config.candidate.directory / "part.parquet").open("ab") as stream:
                    stream.write(b"mutation")
            return original(path, limits, deadline)

        with mock.patch.object(io, "inventory", side_effect=inventory):
            result = oracle.verify(config)
        self.assertEqual(result.outcome, "error")
        self.assertFalse(result.own_identity_closure_passed)
        self.assertTrue(result.integrity_errors)
        self.assertTrue((config.output / "receipt.json").is_file())

    def test_timeout_memory_admission_and_fresh_destination(self) -> None:
        for limits, outcome in ((models.Limits(timeout_seconds=1e-9), "timeout"),
                                (models.Limits(memory_budget_bytes=1), "mismatch")):
            config = self.config("wcc", cast(list[int | float | None], LABELS)).model_copy(update={"limits": limits})
            result = oracle.verify(config)
            self.assertEqual(result.outcome, outcome)
            with self.assertRaisesRegex(ValueError, "fresh exclusive"):
                oracle.verify(config)


if __name__ == "__main__":
    unittest.main()
