"""Unchanged presealed binary64 absolute PageRank comparison from the frozen oracle."""
from __future__ import annotations

import math

import matched_io as io
import matched_models as models
import numpy as np
import numpy.typing as npt

I64 = npt.NDArray[np.int64]
F64 = npt.NDArray[np.float64]

def within_bound(actual: float, expected: float) -> bool:
    """Exact binary64 difference versus the fixed binary64 1e-12 bound."""
    a, ad = actual.as_integer_ratio()
    b, bd = expected.as_integer_ratio()
    t, td = models.ABSOLUTE_BOUND.as_integer_ratio()
    return abs(a*bd-b*ad)*td <= t*ad*bd

def compare(ids: I64, actual: F64, expected: F64, record: models.OracleReceipt,
            config: models.OracleConfig, deadline: io.Deadline) -> None:
    max_abs, max_rel = 0.0, 0.0
    bound = models.ABSOLUTE_BOUND
    lower, upper = np.nextafter(bound, -np.inf), np.nextafter(bound, np.inf)
    for start in range(0, len(ids), config.limits.batch_rows):
        deadline.check()
        stop = min(len(ids), start+config.limits.batch_rows)
        a, e = actual[start:stop], expected[start:stop]
        with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
            difference = np.abs(a-e)
            relative = np.where(e == 0, np.where(a == 0, 0.0, np.inf), difference/np.abs(e))
        failed = difference > bound
        # Correct only subtraction-rounding edge cases, retaining vector throughput.
        for offset in np.flatnonzero((difference >= lower) & (difference <= upper)):
            deadline.check()
            failed[offset] = not within_bound(float(a[offset]), float(e[offset]))
        record.numeric_mismatches += int(np.count_nonzero(failed))
        max_abs = max(max_abs, float(difference.max(initial=0)))
        max_rel = max(max_rel, float(relative.max(initial=0)))
        for offset in np.flatnonzero(failed)[:max(0, 16-len(record.witnesses))]:
            record.witnesses.append(models.NumericWitness(vertex_id=int(ids[start+offset]),
                actual_hex=float(a[offset]).hex(), reference_hex=float(e[offset]).hex(),
                absolute_error_hex=float(difference[offset]).hex()))
        record.compared_rows += stop-start
    record.max_absolute_error = max_abs if math.isfinite(max_abs) else None
    record.max_absolute_error_hex = max_abs.hex()
    record.max_relative_error = max_rel if math.isfinite(max_rel) else None
    record.max_relative_error_hex = max_rel.hex()
    io.require(record.compared_rows == len(ids) and record.numeric_mismatches == 0,
               "full per-vertex PageRank absolute bound exceeded")
    record.full_numeric_comparison_passed = True
