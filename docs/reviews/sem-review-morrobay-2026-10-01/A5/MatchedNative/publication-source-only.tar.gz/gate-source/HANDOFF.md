# Exact detached matched-native publication gate

Run gate.py with --plan, --worktree, --mode candidate|committed and a fresh external --receipt. Use isolated Python with explicit sys.path containing this source directory and the frozen A5-native-matched-report01 directory. The plan seals all published artifact bytes, exact detached revision/tree/parent, original generation configuration, own append, preserved planned protocol and helper source identities. The gate reads bounded small metadata and its safe physical archive only; it starts no engine or build and opens no Parquet, native binary or retired VM archive.

Frozen report qualification and all70 outcomes/6 four-pair contrasts/2 single-pair snapshot contrasts are rechecked against original metadata. This checks the published representation of the completed independent root audit; it does not repeat the graph oracle.
