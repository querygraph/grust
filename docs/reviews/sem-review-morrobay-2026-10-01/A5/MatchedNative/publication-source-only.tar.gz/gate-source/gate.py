"""Gate exact detached native matched documentation using sealed small evidence."""

from __future__ import annotations

import argparse
import datetime
import io as byte_io
import re
import stat
import subprocess
import tarfile
import traceback
from pathlib import Path
from typing import Literal

import matched_report_io as io
import matched_report_models as report_models
import matched_report_qualify as qualify
from pydantic import BaseModel, ConfigDict


class Revision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    head: str
    tree: str
    parent: str


class Plan(BaseModel):
    model_config = ConfigDict(extra="forbid")
    candidate: Revision
    committed: Revision | None = None
    files: dict[str, report_models.Identity]
    report_directory: str
    configuration: report_models.Pin
    coordination_append: str
    preserved_protocol: str
    report_sources: dict[str, report_models.Identity]
    gate_source: report_models.Pin


def same(actual: object, expected: object, message: str) -> None:
    io.require(type(actual) is type(expected) and actual == expected, message)


def read_artifact(path: Path) -> bytes:
    if io.permitted(path):
        return io.read(path)
    io.require(
        path.name
        in {
            "evidence.tar.gz",
            "oracle-source-only.tar.gz",
            "publication-source-only.tar.gz",
        },
        "unexpected nonmetadata artifact",
    )
    io.require(
        all(not p.is_symlink() for p in (path, *path.parents)), "symlink artifact"
    )
    info = path.stat()
    io.require(
        stat.S_ISREG(info.st_mode) and info.st_size <= 64 * 2**20,
        "oversized or nonregular metadata archive",
    )
    with path.open("rb") as stream:
        data = stream.read(64 * 2**20 + 1)
    io.require(
        len(data) == info.st_size and len(data) <= 64 * 2**20,
        "archive changed or exceeded bound",
    )
    return data


def utc() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=repo, text=True, timeout=30
    ).strip()


def state(repo: Path) -> Revision:
    detached = subprocess.run(
        ["git", "symbolic-ref", "-q", "HEAD"],
        cwd=repo,
        capture_output=True,
        text=True,
        timeout=30,
    )
    io.require(detached.returncode == 1, "detached worktree required")
    same(git(repo, "status", "--porcelain"), "", "clean detached tree required")
    return Revision(
        head=git(repo, "rev-parse", "HEAD"),
        tree=git(repo, "rev-parse", "HEAD^{tree}"),
        parent=git(repo, "rev-parse", "HEAD^"),
    )


def source_checks(plan: Plan) -> None:
    same(io.pin(Path(__file__)), plan.gate_source, "publication source changed")
    root = Path(str(qualify.__file__)).parent
    for module in (io, report_models, qualify):
        io.require(
            Path(str(module.__file__)).parent == root,
            "report imports changed directory",
        )
    for name, expected in plan.report_sources.items():
        io.relative(name)
        same(
            io.identity_bytes(io.read(root / name)),
            expected,
            "frozen report source differs",
        )


def text_checks(
    repo: Path, plan: Plan, revision: Revision, files: dict[str, bytes]
) -> None:
    coord = "codex-to-codex.md"
    original = subprocess.check_output(
        ["git", "show", revision.parent + ":" + coord], cwd=repo
    )
    same(
        files[coord],
        original + plan.coordination_append.encode(),
        "coordination is not exact own append",
    )
    previous = subprocess.check_output(
        [
            "git",
            "show",
            revision.parent
            + ":docs/reviews/sem-review-morrobay-2026-10-01/A5/NATIVE-MATCHED.md",
        ],
        cwd=repo,
    )
    same(
        files[plan.preserved_protocol],
        previous,
        "previous planned protocol not preserved exactly",
    )
    for name, data in files.items():
        if not name.endswith(".md"):
            continue
        io.require(
            not re.search(rb"^(<<<<<<<|=======|>>>>>>>)( |$)", data, re.MULTILINE),
            "conflict markers",
        )
        text = plan.coordination_append if name == coord else data.decode()
        for ref in re.findall(r"\]\(([^)]+)\)", text):
            target = ref.strip("<>").split("#", 1)[0]
            if not target or target.startswith(("https://", "http://")):
                continue
            path = (repo / name).parent / target
            io.require(
                not Path(target).is_absolute()
                and path.resolve().is_relative_to(repo.resolve())
                and path.is_file(),
                "missing or unsafe relative document link",
            )
    text = files[plan.report_directory + "/README.md"].decode().lower()
    for word in (
        "70",
        "shared",
        "four",
        "snapshot",
        "1e-12",
        "popen",
        "imports",
        "four fields",
        "d0e4e422a",
        "9f0aa7d2a",
        "software",
        "128",
        "undirected",
        "oracle",
    ):
        io.require(word in text, "required result boundary absent: " + word)


def outer_inventory(
    data: bytes, expected: set[str]
) -> dict[str, report_models.Identity]:
    io.require(
        len(data) <= 64 * 2**20 and len(expected) <= 8192,
        "outer metadata archive bound",
    )
    found: dict[str, report_models.Identity] = {}
    total = 0
    with tarfile.open(fileobj=byte_io.BytesIO(data), mode="r:gz") as archive:
        for member in archive:
            name = io.relative(member.name)
            timestamp_headers = set(member.pax_headers) <= {"mtime"} and all(
                len(value) <= 128
                and re.fullmatch(r"-?[0-9]+(?:\.[0-9]+)?", value) is not None
                for value in member.pax_headers.values()
            )
            io.require(
                member.isfile()
                and timestamp_headers
                and 0 <= member.size <= 64 * 2**20,
                "unsafe or oversized outer archive member",
            )
            io.require(
                name in expected and name not in found,
                "unexpected or duplicate outer member",
            )
            io.require(
                not any(
                    name.startswith(n + "/") or n.startswith(name + "/") for n in found
                ),
                "outer archive path shadow conflict",
            )
            total += member.size
            io.require(total <= 512 * 2**20, "outer metadata expanded byte bound")
            stream = archive.extractfile(member)
            io.require(stream is not None, "missing outer regular member stream")
            if stream is None:
                raise ValueError("missing outer member stream")
            with stream:
                payload = stream.read(member.size + 1)
            io.require(len(payload) == member.size, "outer member size mismatch")
            found[name] = io.identity_bytes(payload)
    same(set(found), expected, "outer archive exact member set differs")
    return found


def artifacts(plan: Plan, files: dict[str, bytes]) -> report_models.Json:
    prefix = plan.report_directory + "/"
    report = report_models.JSON.validate_json(files[prefix + "report.json"])
    verification = report_models.JSON.validate_json(
        files[prefix + "archive-verification.json"]
    )
    generation = report_models.JSON.validate_json(
        files[prefix + "generation-receipt.json"]
    )
    config_data = files[prefix + "generation-configuration.json"]
    same(
        io.identity_bytes(config_data),
        io.identity_bytes(io.verify(plan.configuration)),
        "original generation configuration differs",
    )
    config = report_models.Configuration.model_validate_json(config_data)
    same(
        generation.get("outcome"),
        "passed_metadata_only_matched_report_generation",
        "report generation failed",
    )
    same(
        generation.get("configuration"),
        plan.configuration.model_dump(mode="json"),
        "generation configuration pin",
    )
    same(
        generation.get("metadata_inputs_before_after_equal"),
        True,
        "metadata not closed",
    )
    same(generation.get("errors"), [], "generation has errors")
    same(
        verification.get("outcome"),
        "passed_complete_physical_metadata_archive",
        "archive verification failed",
    )
    io.require(
        all(io.permitted(Path(name)) for name in config.files),
        "nonmetadata configured archive input",
    )
    expected_members = set(config.files) | {
        "report.json",
        "README.md",
        "INPUTS.json",
        "oracle-source-only.tar.gz",
    }
    archive = files[prefix + "evidence.tar.gz"]
    archive_identity = io.identity_bytes(archive).model_dump()
    same(verification.get("archive"), archive_identity, "archive identity differs")
    same(generation.get("archive"), archive_identity, "generation archive differs")
    inventory = {
        name: pin.model_dump()
        for name, pin in outer_inventory(archive, expected_members).items()
    }
    same(
        verification.get("files"),
        inventory,
        "complete physical archive inventory differs",
    )
    oracle = files[prefix + "oracle-source-only.tar.gz"]
    oracle_inventory = {
        name: pin.model_dump() for name, pin in io.archive_inventory(oracle).items()
    }
    same(
        verification.get("oracle_source_archive_members"),
        oracle_inventory,
        "oracle source archive differs",
    )
    expected_members = set(config.files) | {
        "report.json",
        "README.md",
        "INPUTS.json",
        "oracle-source-only.tar.gz",
    }
    same(
        set(inventory),
        expected_members,
        "physical package has unexpected or omitted members",
    )
    originals = report_models.JSON.validate_json(files[prefix + "INPUTS.json"])
    same(
        originals,
        {name: pin.model_dump(mode="json") for name, pin in config.files.items()},
        "portable original pin map",
    )
    for name, pin in config.files.items():
        same(
            inventory[name],
            pin.model_dump(exclude={"path"}),
            "archived original bytes differ: " + name,
        )
    for name in (
        "report.json",
        "README.md",
        "INPUTS.json",
        "oracle-source-only.tar.gz",
    ):
        same(
            inventory[name],
            io.identity_bytes(files[prefix + name]).model_dump(),
            "outer/archive member differs",
        )
    declared_report = report_models.Pin.model_validate(generation.get("report"))
    same(
        declared_report.path,
        config.output / "report.json",
        "original generated report path",
    )
    same(
        declared_report.model_dump(exclude={"path"}),
        io.identity_bytes(files[prefix + "report.json"]).model_dump(),
        "original generated report bytes",
    )
    # The frozen qualifier rechecks complete original small metadata, never Parquet/binaries.
    recomputed = qualify.qualify(config)
    observed = report.pop("observed_utc", None)
    io.require(isinstance(observed, str), "generated UTC absent")
    same(
        report,
        recomputed,
        "published all-outcome report differs from frozen metadata qualification",
    )
    audit = io.load(config.audit.path)
    for name in (
        "all_owned_pid_and_group_absent",
        "shared_locks_absent",
        "source_input_client_closure",
    ):
        same(audit.get(name), True, "final independent audit closure absent")
    return {
        "contrasts": report["contrasts"],
        "snapshot_pairs": report["snapshot_pairs"],
        "archive_members": len(inventory),
        "qualified_cells": len(io.array(report["cells"], "cells")),
        "archive": archive_identity,
    }


def gate(
    repo: Path, plan: Plan, mode: Literal["candidate", "committed"]
) -> report_models.Json:
    expected = plan.candidate if mode == "candidate" else plan.committed
    io.require(expected is not None, "committed revision not admitted")
    before = state(repo)
    same(before, expected, "exact detached revision differs")
    source_checks(plan)
    same(
        set(git(repo, "diff", "--name-only", before.parent, before.head).splitlines()),
        set(plan.files),
        "changed path set",
    )
    prefix = "docs/reviews/sem-review-morrobay-2026-10-01/A5/"
    io.require(
        plan.report_directory == prefix + "MatchedNative", "report destination differs"
    )
    io.require(
        all(
            name == "codex-to-codex.md"
            or name in {prefix + "NATIVE-MATCHED.md", prefix + "NATIVE-MATCHED-PLAN.md"}
            or name.startswith(plan.report_directory + "/")
            for name in plan.files
        ),
        "publication scope exceeds result files",
    )
    files: dict[str, bytes] = {}
    for name, expected_file in plan.files.items():
        io.relative(name)
        data = read_artifact(repo / name)
        same(
            io.identity_bytes(data),
            expected_file,
            "exact publication file differs: " + name,
        )
        files[name] = data
    text_checks(repo, plan, before, files)
    result = artifacts(plan, files)
    for name, original in files.items():
        same(read_artifact(repo / name), original, "detached file changed during gate")
    source_checks(plan)
    same(state(repo), before, "detached revision changed during gate")
    return {
        "revision": before.model_dump(),
        "checks": result,
        "scope": "Exact detached result publication, all70 frozen small metadata checks and complete bounded metadata archive; no engine jobs, Parquet, binaries or retired VM archive opened.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--mode", choices=("candidate", "committed"), required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    io.require(not args.receipt.exists(), "fresh external gate receipt required")
    io.require(
        not args.receipt.resolve().is_relative_to(args.worktree.resolve()),
        "receipt must be outside detached tree",
    )
    original = io.read(args.plan)
    plan = Plan.model_validate_json(original)
    result: report_models.Json = {
        "started_utc": utc(),
        "outcome": "error",
        "mode": args.mode,
    }
    try:
        mode: Literal["candidate", "committed"] = (
            "candidate" if args.mode == "candidate" else "committed"
        )
        result.update(gate(args.worktree, plan, mode))
        same(io.read(args.plan), original, "publication plan changed")
        result["outcome"] = "passed_exact_detached_native_matched_publication"
    except (
        ValueError,
        OSError,
        TypeError,
        KeyError,
        subprocess.SubprocessError,
    ) as error:
        result.update(error=repr(error), traceback=traceback.format_exc())
    result.update(
        finished_utc=utc(),
        plan=io.identity_bytes(original).model_dump(),
        gate_source=plan.gate_source.model_dump(mode="json"),
    )
    io.write(args.receipt, result)
    print(result["outcome"])
    return (
        0
        if result["outcome"] == "passed_exact_detached_native_matched_publication"
        else 1
    )


if __name__ == "__main__":
    raise SystemExit(main())
