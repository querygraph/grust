"""Bounded metadata mocks and physical archive controls; no engines or graph payloads."""
from __future__ import annotations

import copy
import io as binary_io
import math
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import generate_report as generate
import matched_report_io as io
import matched_report_models as models
import matched_report_qualify as qualify
import pydantic


class CellControls(unittest.TestCase):
    def setUp(self) -> None:
        self.fixture = io.load(Path(__file__).parent / "test-metadata-fixture.json")
        self.config = models.Configuration.model_validate(self.fixture["configuration"])
        self.cell = models.Cell.model_validate(self.fixture["cell"])
        self.state = qualify.at(self.fixture, "state")
        self.audit = qualify.at(self.fixture, "audit")
        self.contents = qualify.at(self.fixture, "contents")

    def verify(self, pin: models.Pin) -> bytes:
        value = self.contents[str(pin.path)]
        if not isinstance(value, str):
            raise TypeError("mock metadata bytes missing")
        data = value.encode()
        io.equal(io.identity_bytes(data).model_dump(), pin.model_dump(exclude={"path"}), "mock pin changed")
        return data

    def verdict(self, configuration: models.Configuration | None = None) -> models.Json:
        with mock.patch.object(io, "verify", side_effect=self.verify):
            return qualify.qualify_cell(configuration or self.config, self.cell, self.state,
                                        self.audit, self.fixture["reference"])

    def test_declared_small_adapter_schema_passes(self) -> None:
        result = self.verdict()
        self.assertEqual(result["compared_rows"], models.DOMAINS[self.cell.dataset])
        self.assertEqual(result["numeric_mismatches"], 0)

    def test_false_closure_refuses(self) -> None:
        self.audit["full_output_retention_qualified"] = False
        with self.assertRaisesRegex(ValueError, "full_output_retention_qualified"):
            self.verdict()

    def test_other_reference_refuses(self) -> None:
        self.fixture["reference"] = {"engine": "pecan"}
        with self.assertRaisesRegex(ValueError, "another GF reference"):
            self.verdict()

    def test_removed_log_refuses(self) -> None:
        files = dict(self.config.files)
        del files["campaign/cells/" + self.cell.id + "/native-memory.jsonl"]
        with self.assertRaisesRegex(ValueError, "complete cell log"):
            self.verdict(self.config.model_copy(update={"files": files}))

    def test_changed_bytes_refuses(self) -> None:
        path = str(self.config.files["campaign/cells/" + self.cell.id + "/correctness.json"].path)
        self.contents[path] = str(self.contents[path]) + " "
        with self.assertRaisesRegex(ValueError, "mock pin changed"):
            self.verdict()

    def test_footer_extra_type_and_coverage_refuse(self) -> None:
        key = str(self.config.files["campaign/cells/" + self.cell.id + "/correctness.json"].path)
        oracle = models.JSON.validate_json(str(self.contents[key]))
        proof_key = str(self.config.files["campaign/cells/" + self.cell.id + "/engine-exited.json"].path)
        proof = models.JSON.validate_json(str(self.contents[proof_key]))
        for failure in ("type", "duplicate", "count"):
            broken = copy.deepcopy(oracle)
            schemas = io.array(qualify.at(broken, "physical_schemas")["candidate"], "schemas")
            schema = io.obj(schemas[0], "schema")
            if failure == "type":
                field = io.obj(io.array(schema["fields"], "fields")[0], "field")
                field["arrow_type"] = "double"
            elif failure == "duplicate":
                schemas.append(copy.deepcopy(schemas[0]))
            else:
                schema["footer_rows"] = 0
            with self.subTest(failure=failure), self.assertRaises(ValueError):
                qualify.physical_schemas(broken, proof, self.cell)


class CampaignControls(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        root = Path(self.directory.name).resolve()
        pins: dict[str, models.Pin] = {}
        for name in ("queue.json", "plan.json", "audit.json", "root_queue.py", "root-audit-source01.py"):
            path = root/name
            path.write_text("{}\n")
            pins[name] = io.pin(path)
        self.config = models.Configuration(campaign=root/"campaign", output=root/"report",
            queue=pins["queue.json"], plan=pins["plan.json"], audit=pins["audit.json"],
            files={"campaign/"+name: pin for name, pin in pins.items()})

    def cells(self) -> list[models.Cell]:
        return [models.Cell.model_validate({"id": f"cell-{index:02}", **value})
                for index, value in enumerate(models.expected_sequence())]

    def test_original_sequence(self) -> None:
        cells = self.cells()
        self.assertEqual(len(cells), 70)
        self.assertEqual(sum(c.kind == "reference" for c in cells), 6)
        self.assertEqual(sum(c.kind == "warmup" for c in cells), 12)
        self.assertEqual(sum(c.snapshot_inputs for c in cells), 2)
        self.assertEqual(qualify.planned_cells({"cells": [c.as_json() for c in cells]}), tuple(cells))
        for dataset in models.DOMAINS:
            for algorithm in ("wcc", "pagerank", "bfs"):
                main = [c for c in cells if c.dataset == dataset and c.algorithm == algorithm
                        and c.kind == "measured" and c.block in (0, 1)]
                self.assertEqual([c.engine for c in main], ["graphframes", "pecan", "pecan", "graphframes"]*2)

    def documents(self) -> tuple[models.Json, models.Json, models.Json, list[models.Json]]:
        report_cells: list[models.Json] = []
        states: list[pydantic.JsonValue] = []
        audits: list[pydantic.JsonValue] = []
        for index, cell in enumerate(self.cells()):
            states.append({"cell": cell.as_json(), "qualified": True})
            audits.append({k: v for k, v in cell.as_json().items()
                           if k in ("id", "dataset", "algorithm", "engine", "kind", "snapshot_inputs")})
            report_cells.append({**cell.as_json(), "launch_to_exit_seconds": float(index+2),
                                 "maximum_absolute_error": 0.0 if cell.algorithm == "pagerank" else None})
        references: models.Json = {d+"-"+a: {} for d in models.DOMAINS for a in ("wcc", "pagerank", "bfs")}
        queue: models.Json = {"cells": states, "references": references}
        plan = models.JSON.validate_python({"cells": [c.as_json() for c in self.cells()]})
        audit: models.Json = {"cells": audits, "contrasts": {}, "snapshot_pairs": {}}
        contrasts = qualify.at(audit, "contrasts")
        snapshots = qualify.at(audit, "snapshot_pairs")
        for dataset in models.DOMAINS:
            for algorithm in ("wcc", "pagerank", "bfs"):
                selected = [c for c in report_cells if c["dataset"] == dataset and c["algorithm"] == algorithm]
                measured = [c for c in selected if c["kind"] == "measured" and c["block"] in (0, 1)]
                # Independently use adjacent positions in the known eight measured cells.
                durations = [io.number(c["launch_to_exit_seconds"], "time") for c in measured]
                ratios = [durations[1]/durations[0], durations[2]/durations[3],
                          durations[5]/durations[4], durations[6]/durations[7]]
                contrasts[dataset+"-"+algorithm] = models.JSON.validate_python({"n_per_engine": 4,
                    "paired_ratios": ratios, "geometric_mean_ratio": math.exp(sum(math.log(v) for v in ratios)/4),
                    "maximum_absolute_error": 0.0 if algorithm == "pagerank" else None})
                if algorithm == "wcc":
                    pair = [c for c in selected if c["block"] == 2]
                    ratio = io.number(pair[1]["launch_to_exit_seconds"], "time") / io.number(
                        pair[0]["launch_to_exit_seconds"], "time")
                    snapshots[dataset+"-wcc"] = {"n_per_engine": 1,
                        "paired_ratios": [ratio], "geometric_mean_ratio": ratio, "maximum_absolute_error": None}
        return queue, plan, audit, report_cells

    def test_ratios_warmup_reference_and_snapshot_exclusion(self) -> None:
        queue, plan, audit, cells = self.documents()
        with mock.patch.object(qualify, "final_inputs", return_value=(queue, plan, audit)), \
                mock.patch.object(qualify, "qualify_cell", side_effect=cells):
            report = qualify.qualify(self.config)
        contrast = io.obj(qualify.at(report, "contrasts")["cit-Patents-wcc"], "contrast")
        self.assertEqual(contrast["n_per_engine"], 4)
        self.assertEqual(contrast["paired_ratios"], [6/5, 7/8, 10/9, 11/12])
        self.assertEqual(qualify.at(report, "snapshot_pairs")["cit-Patents-wcc"],
                         {"n_per_engine": 1, "paired_ratios": [14/13],
                          "geometric_mean_ratio": 14/13, "maximum_absolute_error": None})
        text = generate.readme(report)
        self.assertIn("All 70 outcomes", text)
        self.assertIn("Python bootstrap", text)
        self.assertNotIn(" s |", text)

    def test_wrong_ratio_missing_order_and_snapshot_refuse(self) -> None:
        for failure in ("ratio", "missing", "order", "snapshot", "references", "unqualified"):
            queue, plan, audit, cells = self.documents()
            if failure == "ratio":
                qualify.at(qualify.at(audit, "contrasts"), "cit-Patents-wcc")["paired_ratios"] = [1.0]*4
            elif failure == "missing":
                io.array(queue["cells"], "states").pop()
            elif failure == "order":
                planned = io.array(plan["cells"], "cells")
                planned[1], planned[2] = planned[2], planned[1]
            elif failure == "snapshot":
                qualify.at(qualify.at(audit, "snapshot_pairs"), "cit-Patents-wcc")["paired_ratios"] = [1.0]
            elif failure == "references":
                del qualify.at(queue, "references")["graph500-24-bfs"]
            else:
                io.obj(io.array(queue["cells"], "states")[0], "state")["qualified"] = False
            with self.subTest(failure=failure), \
                    mock.patch.object(qualify, "final_inputs", return_value=(queue, plan, audit)), \
                    mock.patch.object(qualify, "qualify_cell", side_effect=cells), self.assertRaises(ValueError):
                qualify.qualify(self.config)

    def test_unfinished_audit_or_queue_refuses(self) -> None:
        with mock.patch.object(io, "verify", return_value=b'{"outcome":"running"}'), \
                self.assertRaisesRegex(ValueError, "root audit not passed"):
            qualify.final_inputs(self.config)
        audit: models.Json = {"outcome": "passed_independent_native_matched_campaign_audit",
            "all_owned_pid_and_group_absent": True, "shared_locks_absent": True, "source_input_client_closure": True,
            "owned_processes_remaining": [], "matching_native_servers_remaining": [],
            "queue_pin": self.config.queue.model_dump(mode="json"), "plan_pin": self.config.plan.model_dump(mode="json")}
        with mock.patch.object(io, "verify", side_effect=[models.JSON.dump_json(audit), b'{"outcome":"running"}', b"{}"]), \
                self.assertRaisesRegex(ValueError, "queue not qualified"):
            qualify.final_inputs(self.config)

    def test_failure_is_durable_and_fresh(self) -> None:
        path = Path(self.directory.name).resolve()/"config.json"
        path.write_text(self.config.model_dump_json())
        with mock.patch.object(qualify, "qualify", side_effect=ValueError("closure witness false")):
            self.assertEqual(generate.run(path), 1)
        receipt = io.load(self.config.output/"generation-receipt.json")
        self.assertEqual(receipt["outcome"], "error")
        self.assertIn("closure witness false", str(receipt["errors"]))
        with self.assertRaisesRegex(ValueError, "existing report"):
            generate.run(path)


class ArchiveControls(unittest.TestCase):
    def tar(self, members: list[tuple[str, bytes, bytes]]) -> bytes:
        data = binary_io.BytesIO()
        with tarfile.open(fileobj=data, mode="w:gz", format=tarfile.USTAR_FORMAT) as archive:
            for name, value, kind in members:
                member = tarfile.TarInfo(name)
                member.type, member.size = kind, len(value)
                if kind == tarfile.SYMTYPE:
                    member.linkname = "victim.json"
                    member.size = 0
                archive.addfile(member, binary_io.BytesIO(value))
        return data.getvalue()

    def test_source_archive_safe_physical_bytes(self) -> None:
        data = self.tar([("src/helper.py", b"x=1\n", tarfile.REGTYPE)])
        self.assertEqual(io.archive_inventory(data)["src/helper.py"], io.identity_bytes(b"x=1\n"))

    def test_actual_standard_pax_mtime_only(self) -> None:
        for headers, passes in (({"mtime": "1790942235.490653"}, True),
                                ({"path": "redirect.py"}, False), ({"GNU.sparse.size": "100"}, False)):
            data = binary_io.BytesIO()
            with tarfile.open(fileobj=data, mode="w:gz", format=tarfile.PAX_FORMAT) as archive:
                member = tarfile.TarInfo("helper.py")
                member.size = 4
                member.pax_headers = headers
                archive.addfile(member, binary_io.BytesIO(b"x=1\n"))
            with self.subTest(headers=headers):
                if passes:
                    self.assertEqual(io.archive_inventory(data.getvalue())["helper.py"], io.identity_bytes(b"x=1\n"))
                else:
                    with self.assertRaises(ValueError):
                        io.archive_inventory(data.getvalue())

    def test_traversal_link_duplicate_shadow_payload_refuse(self) -> None:
        for members in [[("../bad.py", b"", tarfile.REGTYPE)], [("x.py", b"", tarfile.SYMTYPE)],
                        [("x.py", b"", tarfile.REGTYPE)] * 2,
                        [("x.py", b"", tarfile.REGTYPE), ("x.py/inner.py", b"", tarfile.REGTYPE)],
                        [("result.parquet", b"raw", tarfile.REGTYPE)]]:
            with self.subTest(members=members), self.assertRaises(ValueError):
                io.archive_inventory(self.tar(members))

    def test_parquet_and_binary_refused_before_open(self) -> None:
        for name in ("/no/result.parquet", "/no/sail", "/no/native.so", "/no/large.tar.zst"):
            with self.subTest(name=name), mock.patch.object(Path, "open") as opened, self.assertRaises(ValueError):
                io.read(Path(name))
            opened.assert_not_called()

    def test_symlink_refused(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            path = Path(root)
            (path / "target.json").write_text("{}")
            (path / "alias.json").symlink_to(path / "target.json")
            with self.assertRaisesRegex(ValueError, "symlink"):
                io.read(path / "alias.json")

    def test_complete_package_physical_inventory(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            payloads = {"metadata/a.json": b"{}\n", "logs/b.log": b"all lines\n"}
            result = io.pack(Path(root) / "evidence.tar.gz", payloads)
            self.assertEqual(set(result), set(payloads))
            self.assertEqual(result["logs/b.log"], io.identity_bytes(payloads["logs/b.log"]).model_dump())


if __name__ == "__main__":
    unittest.main()
