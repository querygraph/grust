"""Seal completed small native matched graph metadata for a separate report destination."""
from __future__ import annotations

import argparse
from pathlib import Path

import matched_report_io as io
import matched_report_models as models
import matched_report_qualify as qualify


def add(files: dict[str, models.Pin], name: str, path: Path,
        expected: models.Json | None = None) -> None:
    io.relative(name)
    io.require(name not in files, "duplicate report input name")
    actual = io.pin(path)
    if expected is not None:
        io.equal(actual.model_dump(exclude={"path"}),
                 {k: expected[k] for k in ("bytes", "sha256")}, "original declared metadata bytes differ")
    files[name] = actual


def tree(files: dict[str, models.Pin], prefix: str, root: Path) -> None:
    io.require(root.is_dir() and not root.is_symlink(), "missing or symlink source directory")
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError("symlink under source directory")
        if path.is_file() and io.permitted(path):
            add(files, prefix + "/" + path.relative_to(root).as_posix(), path)


def prepare(campaign: Path, output: Path) -> models.Configuration:
    # Refuse an unfinished/missing root audit before reading mutable queue data.
    audit_path = campaign / "root-audit01.json"
    audit = io.load(audit_path)
    io.equal(audit.get("outcome"), "passed_independent_native_matched_campaign_audit", "root audit not qualified")
    queue_pin = models.Pin.model_validate(audit.get("queue_pin"))
    plan_pin = models.Pin.model_validate(audit.get("plan_pin"))
    io.require(queue_pin.path == campaign / "queue.json" and plan_pin.path.parent == campaign,
               "audit campaign paths differ")
    plan = models.JSON.validate_json(io.verify(plan_pin))
    files: dict[str, models.Pin] = {}
    # This dedicated tree contains small metadata and raw outputs; only the metadata allowlist is opened.
    tree(files, "campaign", campaign)
    queue = models.JSON.validate_json(io.verify(queue_pin))
    for raw_state in io.array(queue.get("cells"), "closed campaign states"):
        state = io.obj(raw_state, "state")
        cell = io.obj(state.get("cell"), "cell")
        cid = str(cell["id"])
        proof = io.load(campaign/"cells"/cid/"engine-exited.json")
        for role in ("configuration", "child_receipt"):
            pin = models.Pin.model_validate(proof.get(role))
            add(files, "provenance/producer-pins/"+cid+"/"+role+".json", pin.path,
                pin.model_dump(mode="json"))
    for role in ("helper", "oracle"):
        source_directory = plan.get(role)
        io.require(isinstance(source_directory, str), "source directory path missing")
        tree(files, "provenance/" + role, Path(str(source_directory)))
    templates = qualify.at(plan, "templates")
    template: models.Json = {}
    for key, raw_pin in templates.items():
        template_pin = models.Pin.model_validate(raw_pin)
        add(files, "provenance/templates/"+key+".json", template_pin.path, template_pin.model_dump(mode="json"))
        current = models.JSON.validate_json(io.verify(template_pin))
        template = current
        for name in ("client", "build", "retirement", "input_admission", "source_admission", "support_manifest"):
            pin = models.Pin.model_validate(current.get(name))
            portable = "provenance/"+key+"/"+name+".json"
            add(files, portable, pin.path, pin.model_dump(mode="json"))
        input_admission = models.JSON.validate_json(io.verify(models.Pin.model_validate(current["input_admission"])))
        for index, raw in enumerate(io.array(input_admission.get("supporting_receipts"), "input source receipts")):
            pin = models.Pin.model_validate(raw)
            add(files, "provenance/"+key+"/input-provenance/"+str(index)+pin.path.suffix,
                pin.path, pin.model_dump(mode="json"))
    io.require(bool(template), "missing all template provenance")
    manifest = io.load(models.Pin.model_validate(template.get("support_manifest")).path)
    repo = Path(str(qualify.at(template, "engine")["repo"]))
    for name, raw in qualify.at(manifest, "source_pins").items():
        io.relative(name)
        add(files, "provenance/controller/"+name, repo/name, io.obj(raw, "source pin"))
    harness = Path(str(qualify.at(template, "engine")["harness_repo"]))/"examples/extensions/benchmarks"
    for name, raw in qualify.at(manifest, "frozen_harness_files").items():
        io.relative(name)
        add(files, "provenance/harness/"+name, harness/name, io.obj(raw, "harness pin"))
    # Build/retirement roots are not walked: their targets/venvs and retired VM archive are excluded.
    build_root = models.Pin.model_validate(template["build"]).path.parent
    for name in ("launch.json", "owner.log", "sail-build.log", "graphframes-build.log", "sem-native-optimized-build01.py"):
        add(files, "provenance/build/" + name, build_root / name)
    retired_root = models.Pin.model_validate(template["retirement"]).path.parent
    for name in ("launch.json", "owner.log", "stop.log", "delete.log", "sem-graph-vm-retirement01.py"):
        add(files, "provenance/retirement/" + name, retired_root / name)
    source_root = models.Pin.model_validate(template["source_admission"]).path.parent
    tree(files, "provenance/source-admission", source_root)
    for path in sorted(Path(__file__).parent.glob("*")):
        if path.is_file() and io.permitted(path):
            add(files, "report-generator/" + path.name, path)
    config = models.Configuration(campaign=campaign, output=output, queue=queue_pin, plan=plan_pin,
                                  audit=io.pin(audit_path), files=files)
    qualify.qualify(config)
    return config


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    io.require(not args.config.exists() and not args.output.exists(), "fresh config/output required")
    config = prepare(args.campaign, args.output)
    args.config.write_text(config.model_dump_json(indent=2) + "\n")
    print(config.model_dump_json(include={"queue", "plan", "audit"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
