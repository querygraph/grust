# Matched native report builder: source preparation

This factory is prepared for `A5-native-matched-run01`. It has not generated a
campaign verdict. It refuses until the complete queue and an independent final
root audit are available. The running campaign is not inspected, changed or
stopped by the factory preparation.

## Root execution after final audit

Use a Python environment with Pydantic. These tools import no native engine.
Direct `-I` script execution excludes sibling helpers; use an explicit isolated
bootstrap if isolation is wanted.

```sh
python prepare_report.py \
  --campaign /Volumes/Apo/graph-tests/results/sem-review-20261001/A5-native-matched-run01 \
  --output /tmp/sem-native-matched-report-generated01 \
  --config /tmp/sem-native-matched-report-config01.json
python generate_report.py --config /tmp/sem-native-matched-report-config01.json
```

Both configuration and output must be fresh. A failure is durable; there is no
retry, resume, overwrite, engine action or cleanup. Governing Grust AGENTS applies.

## Required final metadata

`root-audit01.json` must have outcome
`passed_independent_native_matched_campaign_audit`. It binds queue_pin,
plan_pin, source_pin, all_owned_pid_and_group_absent, shared_locks_absent,
source_input_client_closure, empty owned_processes_remaining and
matching_native_servers_remaining. The source pin must be in the sealed small
metadata inventory. The queue must be
`qualified_native_d0_WCC_PageRank_BFS_and_snapshot_pairs`, have 70 qualified
states, no errors or forced cancellation, finished UTC and unchanged plan/source
pins. The plan binds all six original templates and its immutable queue source.

Every audit cell uses the actual `root_audit.py` schema: id, dataset, algorithm,
kind, engine, snapshot_inputs, parent/child/server PIDs, workers, config_pin,
receipt_pin, retained_files, raw_result_files, retained_total_bytes,
source_client_identity_closure, full_output_retention_qualified,
full_physical_domain_passed, full_domain_rows, compared_rows, numeric_mismatches,
full_numeric_comparison_passed, reference_preparation_only and max errors.

Contrasts are keyed `dataset-algorithm` for all six combinations. Each has
`n_per_engine:4`, four adjacent `paired_ratios`, `geometric_mean_ratio` and
`maximum_absolute_error` (null for WCC/BFS). Snapshot pairs are keyed
`dataset-wcc`; each uses the same summary shape with `n_per_engine:1`, one ratio,
its geometric mean equal to that ratio, and null maximum absolute error.
The factory independently recomputes all ratios from the bound parent timer
metadata and refuses disagreement. It does not recompute a physical graph oracle.

The exact ordered 70-cell contract is six GF references, two warmups per
dataset/algorithm, two GF/Pecan/Pecan/GF blocks per combination and an additional
GF/Pecan snapshot-on WCC pair per dataset. Original plan IDs are retained; IDs
must be unique safe relative names. References and warmups never enter ratios.

## Portable package

The package preserves complete small campaign metadata and logs, parent and
oracle helpers, original source archives, all six templates, child source/config/
receipt and raw inventory bindings, build/client/retirement/input/source
admissions, pinned controller and frozen harness source files. Original child
configuration and child receipt pins in the engine-exited proof receive explicit
portable aliases, including the small SSD child receipt.

Metadata is allowlisted by suffix and bounded to 64 MiB per file and 512 MiB per
package. Raw Parquet, binaries and large archives are refused before opening.
An exact safe regular-file archive inventory and original before/after pins are
verified. Source archive decoding accepts only plain regular safe unique names
and harmless numeric mtime PAX metadata, with expanded-size and member limits.

Outputs are README.md, report.json, INPUTS.json, evidence.tar.gz,
oracle-source-only.tar.gz, archive-verification.json and generation-receipt.json.
`report.json` exposes all 70 cells, six `contrasts` and both `snapshot_pairs` at
full precision; raw clocks are retained in JSON. README reports shared-host
ratios only and states the source, projection, timer and software-budget limits.

## Preparation gates

Six Python files pass repository Ruff and strict mypy. Seventeen bounded
offline controls cover the 70-step protocol, ABBA/warmup/reference/snapshot
separation, summary mutation, missing outcomes/references, unqualified/unfinished
metadata, changed bytes, false closure, removed complete logs, physical-schema
and footer metadata refusal, fresh durable failure and safe archive rules.
The copied PR-shaped fixture is explicitly synthetic after adaptation. Tests
mock metadata pin reads and do not qualify d0, the native engines, inputs or
production physical output. No campaign report has been generated.
