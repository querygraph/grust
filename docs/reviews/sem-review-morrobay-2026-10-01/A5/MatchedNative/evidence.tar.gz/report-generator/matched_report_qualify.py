"""Bind final root metadata; physical graph/result checks belong to the independent audit."""
from __future__ import annotations

import math
from pathlib import Path

import matched_report_io as io
import matched_report_models as models
import pydantic

CONTROLLER = "d0e4e422afdea967126ae7b9506e04c9f1812b97"
RUNTIME = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
GRAPHFRAMES = "b4da56dabe20bba8e29563e06acc5179b2113ce3"


def at(record: models.Json, key: str) -> models.Json:
    return io.obj(record.get(key), key)


def same_pin(value: pydantic.JsonValue, pin: models.Pin, context: str) -> None:
    io.equal(value, pin.model_dump(mode="json"), context)


def lookup(config: models.Configuration, name: str) -> models.Json:
    io.require(name in config.files, "missing sealed report input: " + name)
    return models.JSON.validate_json(io.verify(config.files[name]))


def final_inputs(config: models.Configuration) -> tuple[models.Json, models.Json, models.Json]:
    audit = models.JSON.validate_json(io.verify(config.audit))
    io.equal(audit.get("outcome"), "passed_independent_native_matched_campaign_audit", "root audit not passed")
    io.true(audit, ("all_owned_pid_and_group_absent", "shared_locks_absent", "source_input_client_closure"))
    io.equal(audit.get("owned_processes_remaining"), [], "owned process remains")
    io.equal(audit.get("matching_native_servers_remaining"), [], "matching native server remains")
    same_pin(audit.get("queue_pin"), config.queue, "audit binds another queue")
    same_pin(audit.get("plan_pin"), config.plan, "audit binds another plan")
    queue = models.JSON.validate_json(io.verify(config.queue))
    plan = models.JSON.validate_json(io.verify(config.plan))
    io.equal(queue.get("outcome"), "qualified_native_d0_WCC_PageRank_BFS_and_snapshot_pairs", "queue not qualified")
    io.equal(queue.get("errors"), [], "queue errors retained")
    io.equal(queue.get("forced_parent_cancellation"), False, "queue forced cancellation")
    io.require(isinstance(queue.get("finished_utc"), str) and bool(queue["finished_utc"]), "unfinished queue")
    same_pin(queue.get("plan_before"), config.plan, "queue before plan differs")
    same_pin(queue.get("plan_after"), config.plan, "queue after plan differs")
    io.equal(queue.get("source_before"), queue.get("source_after"), "queue source changed")
    io.equal(queue.get("source_before"), plan.get("source"), "queue source differs from plan")
    same_pin(plan.get("source"), config.files["campaign/root_queue.py"], "root queue source not sealed")
    audit_source = models.Pin.model_validate(audit.get("source_pin"))
    io.require(audit_source in config.files.values(), "root audit source not sealed")
    io.verify(audit_source)
    io.equal(plan.get("root"), str(config.campaign), "plan root differs")
    templates = at(plan, "templates")
    expected_keys = {d+"-"+a for d in models.DOMAINS for a in ("wcc", "pagerank", "bfs")}
    io.require(set(templates) == expected_keys, "all six templates required")
    for key, pin in templates.items():
        same_pin(pin, config.files["provenance/templates/"+key+".json"], "template not sealed")
    return queue, plan, audit


def contract(engine: models.Json, cell: models.Cell) -> None:
    method, iterations = {"wcc": ("randomized", 100), "bfs": ("frontier", 1000),
                          "pagerank": ("pregel_delta", 10)}[cell.algorithm]
    expected_contract: models.Json = {"engine": cell.engine, "dataset": cell.dataset, "algorithm": cell.algorithm,
                          "method": method, "max_iterations": iterations,
                          "snapshot_inputs": cell.snapshot_inputs, "seed": 42,
                          "canonical_labels": True, "directed": True,
                          "partitions": 16, "native_quota": 268_435_456,
                          "mode": "local", "pool_bytes": 30 * 2**30}
    for key, expected in expected_contract.items():
        io.equal(engine.get(key), expected, "engine contract differs: " + key)
    if cell.algorithm == "bfs":
        io.equal(engine.get("source"), 5795784 if cell.dataset == "cit-Patents" else 798169,
                 "stored-arcs BFS source differs")
    if cell.algorithm == "pagerank":
        for key, expected in {"reset_probability": 0.15, "tolerance": 0.01,
                              "normalize": True, "vote_to_halt": False}.items():
            io.equal(engine.get(key), expected, "dynamic PageRank contract differs: "+key)


def physical_schemas(oracle: models.Json, proof: models.Json, cell: models.Cell) -> None:
    schemas = at(oracle, "physical_schemas")
    candidate = io.array(schemas.get("candidate"), "candidate schemas")
    files = at(proof, "raw_files")
    value = {"wcc": "component", "pagerank": "pagerank", "bfs": "hops" if cell.engine == "pecan"
             else "dist_"+str(5795784 if cell.dataset == "cit-Patents" else 798169)}[cell.algorithm]
    value_type = "double" if cell.algorithm == "pagerank" else "int32" if cell.algorithm == "bfs" and cell.engine == "graphframes" else "int64"
    names: set[str] = set()
    rows = 0
    for raw in candidate:
        schema = io.obj(raw, "physical schema")
        name = schema.get("file")
        io.require(isinstance(name, str) and name not in names and name in files, "physical footer file mismatch")
        if not isinstance(name, str):
            raise TypeError("physical schema name missing")
        names.add(name)
        fields = [io.obj(v, "field") for v in io.array(schema.get("fields"), "fields")]
        io.require(len(fields) == 2 and {f.get("name") for f in fields} == {"id", value}, "wrong field names")
        for field in fields:
            io.equal(field.get("arrow_type"), "int64" if field.get("name") == "id" else value_type, "raw type differs")
        count = schema.get("footer_rows")
        io.require(type(count) is int and io.number(count, "footer_rows") >= 0, "invalid footer count")
        rows += int(io.number(count, "footer_rows"))
    io.require(names == {n for n in files if n.endswith(".parquet")} and rows == models.DOMAINS[cell.dataset], "full footer coverage differs")


def qualify_cell(config: models.Configuration, cell: models.Cell, state: models.Json,
                 audit: models.Json, reference: pydantic.JsonValue) -> models.Json:
    cid = cell.id
    domain = models.DOMAINS[cell.dataset]
    prefix = "campaign/cells/" + cid + "/"
    cfg = lookup(config, prefix + "configuration.json")
    parent = lookup(config, prefix + "receipt.json")
    child = lookup(config, prefix + "raw-output/engine-receipt.json")
    oracle = lookup(config, prefix + "correctness.json")
    proof = lookup(config, prefix + "engine-exited.json")
    sampler = lookup(config, prefix + "sampler-receipt.json")
    retention = lookup(config, prefix + "retention-index.json")
    for name in ("child.log", "native-memory.jsonl"):
        io.require(prefix + name in config.files, "missing complete cell log: " + name)
    io.require("campaign/logs/" + cid + ".log" in config.files, "missing parent launch log")
    for name, raw_identity in retention.items():
        io.relative(name)
        if io.permitted(Path(name)):
            pin = config.files.get(prefix + "raw-output/" + name)
            io.require(pin is not None, "missing retained raw metadata/log: " + name)
            if pin is None:
                raise ValueError("missing metadata pin")
            io.equal(pin.model_dump(exclude={"path"}), raw_identity, "retained raw metadata identity differs")
    io.equal(lookup(config, prefix + "oracle/receipt.json"), oracle, "two oracle copies differ")
    io.equal(lookup(config, prefix + "child-config.json"), at(cfg, "engine"), "child config differs")
    io.equal(parent.get("config"), cfg, "parent config differs")
    io.equal(parent.get("child"), child, "parent child copy differs")
    io.equal(parent.get("correctness"), oracle, "parent correctness differs")
    io.equal(parent.get("sampler"), sampler, "sampler copy differs")
    io.equal(parent.get("retention_files"), retention, "retention index differs")
    expected = "reference_prepared" if cell.kind == "reference" else "passed_matched_native_diagnostic"
    for record in (parent, state):
        io.equal(record.get("outcome"), expected, "cell outcome not qualified")
        io.equal(record.get("returncode"), 0, "nonzero engine/parent exit")
    queue_config = config.files["campaign/configs/" + cid + ".json"]
    io.equal(models.JSON.validate_json(io.verify(queue_config)), cfg, "sealed queue/cell config copies differ")
    same_pin(state.get("configuration"), queue_config, "queue config pin differs")
    same_pin(state.get("receipt"), config.files[prefix + "receipt.json"], "queue receipt pin differs")
    same_pin(audit.get("config_pin"), queue_config, "audit config pin differs")
    same_pin(audit.get("receipt_pin"), config.files[prefix + "receipt.json"], "audit receipt pin differs")
    io.equal(state.get("launch_to_exit_seconds"), parent.get("launch_to_exit_seconds"), "queue timer differs")
    duration = io.number(parent.get("launch_to_exit_seconds"), "actual primary timer")
    io.require(math.isfinite(duration) and duration > 0, "invalid primary timer")
    io.true(parent, ("child_group_absent", "server_group_absent", "worker_processes_absent",
                     "matching_server_absent", "retention_verified", "locks_released"))
    io.true(audit, ("source_client_identity_closure", "full_output_retention_qualified", "full_physical_domain_passed"))
    io.equal(parent.get("errors"), [], "parent errors")
    io.equal(child.get("outcome"), "passed", "child not passed")
    io.equal(child.get("cleanup_errors"), [], "child cleanup error")
    io.equal(child.get("error"), None, "child error")
    io.equal(parent.get("before"), parent.get("after"), "identity closure changed")
    io.equal(parent.get("source_before"), parent.get("source_after"), "source closure changed")
    source = at(parent, "source_after")
    for key, expected_source in {"commit": CONTROLLER, "compiled_runtime": RUNTIME,
                                 "graphframes_commit": GRAPHFRAMES,
                                 "compiled_runtime_paths_parity": "empty diff"}.items():
        io.equal(source.get(key), expected_source, "source identity differs: " + key)
    engine = at(cfg, "engine")
    contract(engine, cell)
    io.equal(cfg.get("run_id"), cid, "run ID differs")
    io.equal(cfg.get("contrast_mode"), "local", "contrast mode differs")
    io.equal(cfg.get("reference_preparation_only"), cell.kind == "reference", "reference mode differs")
    if cell.kind != "reference":
        io.equal(cfg.get("reference"), reference, "candidate binds another GF reference")
    io.equal(lookup(config, prefix + "oracle-config.json"), at(oracle, "config"), "oracle config differs")
    same_pin(parent.get("engine_exited"), config.files[prefix + "engine-exited.json"], "parent exit proof pin differs")
    io.true(proof, ("wait_completed", "child_group_absent", "server_group_absent"))
    io.equal(proof.get("returncode"), 0, "producer nonzero return")
    io.equal(proof.get("run_id"), cid, "producer run ID differs")
    io.equal(proof.get("engine"), cell.engine, "producer engine differs")
    io.equal(proof.get("child_pid"), parent.get("child_pid"), "producer child differs")
    candidate = at(at(oracle, "config"), "candidate")
    same_pin(at(candidate, "exit").get("producer_receipt"), config.files[prefix + "engine-exited.json"], "oracle producer differs")
    io.equal(candidate.get("files"), proof.get("raw_files"), "oracle raw inventory differs")
    io.equal(candidate.get("directory"), proof.get("raw_directory"), "oracle raw directory differs")
    io.equal(audit.get("raw_result_files"), proof.get("raw_files"), "audit raw result inventory differs")
    io.equal(audit.get("retained_files"), retention, "audit retention inventory differs")
    raw = {n.removeprefix("result/"): value for n, value in retention.items() if n.startswith("result/")}
    io.equal(raw, proof.get("raw_files"), "retained result inventory differs")
    total = sum(int(io.number(io.obj(v, "file").get("bytes"), "file bytes")) for v in retention.values())
    io.equal(audit.get("retained_total_bytes"), total, "audit retained total differs")
    for key in ("child_pid", "server_pid"):
        io.equal(audit.get(key), parent.get(key), "audit ownership differs: " + key)
    io.equal(audit.get("parent_pid"), state.get("parent_pid"), "audit parent differs")
    io.equal(audit.get("workers"), sampler.get("owned_workers"), "audit workers differ")
    io.require(sampler.get("error") is None and sampler.get("thread_alive") is False
               and io.number(sampler.get("execution_samples"), "execution_samples") > 0, "sampler failed")
    io.true(oracle, ("own_identity_closure_passed", "full_physical_domain_passed"))
    io.equal(oracle.get("identity_before"), oracle.get("identity_after"), "oracle identity changed")
    io.equal(oracle.get("error"), None, "oracle error")
    io.equal(oracle.get("integrity_errors"), [], "oracle closure errors")
    for key in ("expected_domain_rows", "reference_rows", "candidate_rows", "unique_candidate_rows"):
        io.equal(oracle.get(key), domain, "full domain differs: " + key)
    for key in ("numeric_mismatches",):
        io.equal(oracle.get(key), 0, "numeric mismatch")
        io.equal(audit.get(key), 0, "audit numeric mismatch")
    reference_only = cell.kind == "reference"
    io.equal(oracle.get("outcome"), "reference_prepared" if reference_only else "passed_full_physical_matched", "oracle verdict differs")
    io.equal(oracle.get("absolute_bound"), 1e-12, "numerical envelope differs")
    io.equal(oracle.get("absolute_bound_hex"), "0x1.19799812dea11p-40", "numerical binary64 bound differs")
    for record in (oracle, audit):
        io.equal(record.get("compared_rows"), 0 if reference_only else domain, "comparison count differs")
        io.equal(record.get("full_numeric_comparison_passed"), not reference_only, "numeric self-comparison/unqualified output")
    if cell.algorithm == "wcc":
        io.true(oracle, ("canonical_labels_passed",))
        for key in ("canonical_mismatches", "membership_mismatches", "false_merge_groups", "false_split_groups"):
            io.equal(oracle.get(key), 0, "WCC mismatch: "+key)
        io.equal(oracle.get("full_partition_comparison_passed"), not reference_only,
                 "full WCC partition comparison differs")
    if cell.algorithm == "bfs":
        io.equal(oracle.get("distance_mismatches"), 0, "BFS mismatch")
        if not reference_only:
            io.equal(oracle.get("source"), engine.get("source"), "BFS oracle source differs")
            io.equal(io.number(oracle.get("reachable_vertices"), "reachable")
                     + io.number(oracle.get("unreachable_vertices"), "unreachable"), float(domain),
                     "BFS reachable coverage differs")
    io.equal(oracle.get("algorithm"), cell.algorithm, "oracle algorithm differs")
    oracle_cfg = at(oracle, "config")
    io.equal(oracle_cfg.get("dataset"), cell.dataset, "oracle dataset differs")
    io.equal(oracle_cfg.get("algorithm"), cell.algorithm, "oracle configuration algorithm differs")
    io.equal(oracle_cfg.get("input_vertices"), at(cfg, "originals").get("vertices"), "oracle original vertices differ")
    io.equal(oracle_cfg.get("input_edges"), at(cfg, "originals").get("edges"), "oracle original edges differ")
    io.equal(audit.get("reference_preparation_only"), reference_only, "audit reference mode differs")
    io.equal(audit.get("full_domain_rows"), domain, "audit domain differs")
    for key in ("max_absolute_error", "max_relative_error"):
        io.equal(audit.get(key), oracle.get(key), "audit numeric diagnostic differs")
    physical_schemas(oracle, proof, cell)
    return {**cell.as_json(), "outcome": expected, "launch_to_exit_seconds": duration,
            "configuration": config.files[prefix + "configuration.json"].model_dump(mode="json"),
            "receipt": config.files[prefix + "receipt.json"].model_dump(mode="json"),
            "full_domain_rows": domain, "compared_rows": 0 if reference_only else domain,
            "numeric_mismatches": 0, "maximum_absolute_error": oracle.get("max_absolute_error"),
            "maximum_relative_error": oracle.get("max_relative_error"), "retained_total_bytes": total,
            "components": oracle.get("components"), "reachable_vertices": oracle.get("reachable_vertices"),
            "unreachable_vertices": oracle.get("unreachable_vertices"), "maximum_finite_hops": oracle.get("maximum_finite_hops"),
            "sampled_rss_sum_bytes": sampler.get("max_sampled_rss_sum_bytes"),
            "observed_workers": sampler.get("owned_workers"), "full_output_retention_qualified": True}


def planned_cells(plan: models.Json) -> tuple[models.Cell, ...]:
    raw = io.array(plan.get("cells"), "plan cells")
    cells = tuple(models.Cell.model_validate(value) for value in raw)
    io.require(len(cells) == len({cell.id for cell in cells}) == 70, "exact seventy unique outcomes required")
    observed = [{k: v for k, v in cell.as_json().items() if k != "id"} for cell in cells]
    io.require(observed == models.expected_sequence(), "original reference/warmup/ABBA/snapshot order differs")
    return cells


def pairs(measured: list[models.Json], block: int) -> tuple[float, float]:
    selected = {int(io.number(c.get("position"), "position")): c for c in measured if c.get("block") == block}
    io.require(set(selected) == {0, 1, 2, 3}, "full ABBA block required")
    times = {p: io.number(c.get("launch_to_exit_seconds"), "timer") for p, c in selected.items()}
    return times[1]/times[0], times[2]/times[3]


def summaries(actual: list[models.Json], audit: models.Json) -> tuple[models.Json, models.Json]:
    contrasts: models.Json = {}
    snapshots: models.Json = {}
    claimed = at(audit, "contrasts")
    snapshot_claimed = at(audit, "snapshot_pairs")
    io.require(set(claimed) == {d+"-"+a for d in models.DOMAINS for a in ("wcc", "pagerank", "bfs")},
               "six root summary contrasts required")
    io.require(set(snapshot_claimed) == {d+"-wcc" for d in models.DOMAINS}, "both WCC snapshot pairs required")
    for dataset in models.DOMAINS:
        for algorithm in ("wcc", "pagerank", "bfs"):
            key = dataset+"-"+algorithm
            selected = [c for c in actual if c.get("dataset") == dataset and c.get("algorithm") == algorithm]
            measured = [c for c in selected if c.get("kind") == "measured" and c.get("block") in (0, 1)]
            io.require(len(measured) == 8, "four measured calls per engine required")
            ratios = [*pairs(measured, 0), *pairs(measured, 1)]
            mean = math.exp(sum(math.log(v) for v in ratios)/4)
            maximum = max(io.number(c.get("maximum_absolute_error"), "max PR error") for c in selected
                          if c.get("engine") == "pecan") if algorithm == "pagerank" else None
            summary: models.Json = models.JSON.validate_python({"n_per_engine": 4, "paired_ratios": ratios,
                                     "geometric_mean_ratio": mean, "maximum_absolute_error": maximum})
            io.equal(claimed.get(key), summary, "root paired summary differs: "+key)
            contrasts[key] = summary
            if algorithm == "wcc":
                snapshot = {int(io.number(c.get("position"), "position")): c for c in selected
                            if c.get("kind") == "measured" and c.get("block") == 2}
                io.require(set(snapshot) == {0, 1}, "one actual WCC snapshot pair required")
                ratio = io.number(snapshot[1].get("launch_to_exit_seconds"), "timer") / io.number(
                    snapshot[0].get("launch_to_exit_seconds"), "timer")
                single: models.Json = {"n_per_engine": 1, "paired_ratios": [ratio],
                                       "geometric_mean_ratio": ratio, "maximum_absolute_error": None}
                io.equal(snapshot_claimed.get(key), single, "root snapshot summary differs: "+key)
                snapshots[key] = single
    return contrasts, snapshots


def qualify(config: models.Configuration) -> models.Json:
    queue, plan, audit = final_inputs(config)
    cells = planned_cells(plan)
    states = io.array(queue.get("cells"), "queue cells")
    audits = io.array(audit.get("cells"), "audit cells")
    io.require(len(states) == len(audits) == 70, "all seventy finalized queue/audit outcomes required")
    references = at(queue, "references")
    io.require(set(references) == {d+"-"+a for d in models.DOMAINS for a in ("wcc", "pagerank", "bfs")},
               "six separate references required")
    actual: list[models.Json] = []
    for cell, s, a in zip(cells, states, audits, strict=True):
        state, audited = io.obj(s, "state"), io.obj(a, "cell audit")
        io.equal(state.get("cell"), cell.as_json(), "queue order differs")
        io.equal(state.get("qualified"), True, "queue cell is unqualified")
        for key in ("id", "dataset", "algorithm", "kind", "engine", "snapshot_inputs"):
            io.equal(audited.get(key), cell.as_json()[key], "audit cell order/binding differs: "+key)
        actual.append(qualify_cell(config, cell, state, audited, references[cell.dataset+"-"+cell.algorithm]))
    contrasts, snapshots = summaries(actual, audit)
    return models.JSON.validate_python({"schema_version": 1, "outcome": "qualified_native_matched_shared_host_report",
            "cells": actual, "contrasts": contrasts, "snapshot_pairs": snapshots,
            "independent_audit": config.audit.model_dump(mode="json"),
            "original_queue": config.queue.model_dump(mode="json"), "original_plan": config.plan.model_dump(mode="json"),
            "source": {"controller": CONTROLLER, "compiled_runtime": RUNTIME, "graphframes": GRAPHFRAMES,
                       "harness": "6ae2e43a903c2cee02da170465c922c72b76198e", "rust_paths_parity": "empty diff"},
            "scope": {"shared_host_ratios_only": True, "native_macos": True,
                      "snapshot_inputs_main": False, "snapshot_wcc_separate_single_pairs": True,
                      "os_resource_caps": False, "equal_cpu_envelope": False,
                      "pss_cgroups_steal_observed": False, "independent_topology_ground_truth": False,
                      "official_graph500_undirected_ground_truth_qualification": False,
                      "bfs_projection": ["id", "hops"],
                      "timing_boundary": "parent Popen through waited child exit including Python bootstrap/imports, lifecycle, full projected raw export and cleanup; oracle/retention afterward",
                      "fable_timer_boundary_reproduced": False, "absolute_pagerank_comparison_bound": 1e-12}})
