"""Bounded metadata inputs for a full native matched graph report."""
from __future__ import annotations

from pathlib import Path
from typing import Literal

import pydantic

Json = dict[str, pydantic.JsonValue]
JSON = pydantic.TypeAdapter(Json)
Dataset = Literal["cit-Patents", "graph500-24"]
Algorithm = Literal["wcc", "pagerank", "bfs"]
Engine = Literal["graphframes", "pecan"]
DOMAINS = {"cit-Patents": 3_774_768, "graph500-24": 8_870_942}


class Record(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="forbid", frozen=True, allow_inf_nan=False)


class Identity(Record):
    bytes: int = pydantic.Field(ge=0, le=64 * 2**20)
    sha256: str = pydantic.Field(pattern=r"^[0-9a-f]{64}$")


class Pin(Identity):
    path: Path

    @pydantic.model_validator(mode="after")
    def absolute(self) -> Pin:
        if not self.path.is_absolute() or ".." in self.path.parts:
            raise ValueError("metadata pin must have an absolute canonical path")
        return self


class Configuration(Record):
    campaign: Path
    output: Path
    queue: Pin
    plan: Pin
    audit: Pin
    files: dict[str, Pin]
    max_total_bytes: int = pydantic.Field(default=512 * 2**20, ge=1, le=2**30)

    @pydantic.model_validator(mode="after")
    def paths(self) -> Configuration:
        if not self.campaign.is_absolute() or not self.output.is_absolute():
            raise ValueError("campaign/output paths must be absolute")
        if self.output == self.campaign or self.campaign in self.output.parents:
            raise ValueError("report destination must be outside the original campaign")
        return self


class Cell(Record):
    id: str = pydantic.Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")
    dataset: Dataset
    algorithm: Algorithm
    snapshot_inputs: bool = pydantic.Field(default=False, strict=True)
    engine: Engine
    kind: Literal["reference", "warmup", "measured"]
    block: int | None = None
    position: int | None = None

    def as_json(self) -> Json:
        return JSON.validate_python(self.model_dump(mode="json"))


def expected_sequence() -> list[Json]:
    result: list[Json] = []
    for dataset in ("cit-Patents", "graph500-24"):
        for algorithm in ("wcc", "pagerank", "bfs"):
            def append(engine: str, kind: str, block: int | None = None,
                       position: int | None = None, snapshot: bool = False, *,
                       dataset: str = dataset, algorithm: str = algorithm) -> None:
                result.append({"dataset": dataset, "algorithm": algorithm, "engine": engine,
                               "kind": kind, "block": block, "position": position,
                               "snapshot_inputs": snapshot})
            append("graphframes", "reference")
            for engine in ("graphframes", "pecan"):
                append(engine, "warmup")
            for block in range(2):
                for position, engine in enumerate(("graphframes", "pecan", "pecan", "graphframes")):
                    append(engine, "measured", block, position)
            if algorithm == "wcc":
                append("graphframes", "measured", 2, 0)
                append("pecan", "measured", 2, 1, True)
    return result
