"""Generate a portable, independently bound native matched graph metadata report."""
from __future__ import annotations

import argparse
import datetime
import json
import traceback
from pathlib import Path

import matched_report_io as io
import matched_report_models as models
import matched_report_qualify as qualify


def utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def readme(report: models.Json) -> str:
    contrasts = qualify.at(report, "contrasts")
    snapshots = qualify.at(report, "snapshot_pairs")
    lines = ["# Native matched WCC, PageRank and BFS", "", "## Findings", "",
             ("All 70 outcomes qualified: six separate GraphFrames references, twelve warmups, "
             "48 measured calls in two ABBA blocks per dataset and algorithm, and four calls "
             "in two separate WCC snapshot pairs. References and warmups are excluded from ratios."), "",
             "| Dataset | Algorithm, inputs in place | Four adjacent Pecan / GraphFrames ratios | Geometric mean |",
             "| --- | --- | --- | ---: |"]
    for dataset in models.DOMAINS:
        for algorithm in ("wcc", "pagerank", "bfs"):
            summary = io.obj(contrasts[dataset+"-"+algorithm], "contrast")
            ratios = ", ".join(f"{io.number(v, 'ratio'):.6f}" for v in io.array(summary["paired_ratios"], "ratios"))
            lines.append(f"| {dataset} | {algorithm} | {ratios} | "
                         f"{io.number(summary['geometric_mean_ratio'], 'mean'):.6f} |")
    lines += ["", "| Dataset | Separate WCC pair, Pecan snapshot on | Pecan / GraphFrames ratio |",
              "| --- | --- | ---: |"]
    for dataset in models.DOMAINS:
        pair = io.obj(snapshots[dataset+"-wcc"], "snapshot pair")
        lines.append(f"| {dataset} | One adjacent pair | {io.number(pair['geometric_mean_ratio'], 'ratio'):.6f} |")
    lines += ["", ("These are ratios on shared Morrobay. Above one means Pecan's interval was longer "
              "in the adjacent pair. Each main contrast has four measured calls per engine; each "
              "separate snapshot contrast has one call per engine."), "", "## Full outputs and contracts", "",
              ("Every call covers every original vertex exactly once: 3,774,768 Cit vertices and "
              "8,870,942 Graph500 vertices. Raw schemas, complete retained inventories, zero mismatches, "
              "identity closure and independently observed process closure are retained."), "",
              ("WCC compares canonical minimum original labels and both directions of full partition "
              "equivalence. BFS compares exact hops along the stored source-to-target arcs, with Cit "
              "source 5795784 and Graph500 source 798169. Pecan exports only `id,hops`; GraphFrames "
              "exports its original `id,dist_SOURCE`. Pecan NULL and GraphFrames INT32_MAX are "
              "explicit unreachable adapters. Distance and predecessor fields are not exported or compared."), "",
              ("PageRank uses initial rank and delta .15, damping .85, first-step sends followed by "
              "delta > .01, ten fixed steps, no dangling redistribution, and final normalization. "
              "Pecan uses `pregel_delta` with voting disabled. Every score is compared to the separate "
              "GraphFrames reference at the predeclared absolute bound 1e-12. Reference preparation "
              "qualifies domain and physical values; it has no numerical self-comparison."), "",
              ("Agreement with the separately prepared GraphFrames outputs is the oracle contract. "
              "Stored directed BFS and PageRank do not qualify official Graph500 undirected ground "
              "truth or establish independent topology correctness."), "", "## Timing, source and resources", "",
              ("The primary timer is parent Popen through waited child exit, including Python bootstrap "
              "and imports, engine startup, reads, actions, the complete projected raw Parquet export "
              "and cleanup. Oracle and retention checks follow outside it. Fable's timer starts after "
              "imports and its BFS exports four fields; this timer and two-field BFS projection do "
              "not reproduce those boundaries."), "",
              ("Pecan controller `d0e4e422a`; optimized native Sail `9f0aa7d2a`; GraphFrames "
              "`b4da56dabe`; frozen runtime/measurement helpers `6ae2e43a9`. The controller and "
              "compiled runtime have an observed empty diff over Rust crates, Cargo manifests, "
              "lockfile and toolchain. Source, build, client and original input admissions are retained."), "",
              ("Both engines are local with 16 configured threads and a 30 GiB software pool; Pecan "
              "has 16 partitions. GraphFrames uses FairSpillPool and Pecan uses a greedy pool. "
              "Main comparisons read inputs in place; the separate WCC pairs enable Pecan snapshots. "
              "The physical macOS host has 128 GiB. These settings are not OS CPU, memory or swap "
              "caps. There is no PSS, cgroup or steal observation. Periodic process RSS is a sampled "
              "observation and may include shared pages."), "", "## Evidence", "",
              ("[report.json](report.json) retains all 70 outcomes and original timer values. "
              "[evidence.tar.gz](evidence.tar.gz) preserves exact small metadata, complete logs, "
              "helper sources and their source archives. [INPUTS.json](INPUTS.json) maps portable "
              "names to original paths and identities. [archive-verification.json](archive-verification.json) "
              "binds every physical archive member. Raw Parquet and binaries remain represented "
              "by root's independently checked inventories and are not embedded."), ""]
    return "\n".join(lines)


def run(config_path: Path) -> int:
    config_pin = io.pin(config_path)
    config = models.Configuration.model_validate_json(io.verify(config_pin))
    io.require(not config.output.exists(), "refusing existing report destination; no retry/resume")
    config.output.mkdir(parents=True, exist_ok=False)
    receipt: models.Json = {"started_utc": utc(), "outcome": "checking", "configuration": config_pin.model_dump(mode="json"),
                           "errors": [], "production_payloads_read": False, "runtime_jobs_launched": False}
    io.write(config.output / "generation-receipt.json", receipt)
    try:
        report = qualify.qualify(config)
        files: dict[str, bytes] = {}
        nested: models.Json = {}
        total = 0
        for name, pin in sorted(config.files.items()):
            io.relative(name)
            data = io.verify(pin)
            total += len(data)
            io.require(total <= config.max_total_bytes, "metadata package exceeds sealed byte bound")
            if pin.path.name == "source-only.tar.gz":
                nested[name] = {n: p.model_dump() for n, p in io.archive_inventory(data).items()}
            files[name] = data
        originals: models.Json = {n: p.model_dump(mode="json") for n, p in config.files.items()}
        report["observed_utc"] = utc()
        io.write(config.output / "report.json", report)
        (config.output / "README.md").write_text(readme(report))
        io.write(config.output / "INPUTS.json", originals)
        # Also preserve an exact portable oracle source subset beside any original archive.
        oracle_files = {n.removeprefix("provenance/oracle/"): data for n, data in files.items()
                        if n.startswith("provenance/oracle/") and not n.endswith(".tar.gz")}
        oracle_verified = io.pack(config.output / "oracle-source-only.tar.gz", oracle_files)
        files["oracle-source-only.tar.gz"] = (config.output / "oracle-source-only.tar.gz").read_bytes()
        for name in ("report.json", "README.md", "INPUTS.json"):
            files[name] = io.read(config.output / name)
        inventory = io.pack(config.output / "evidence.tar.gz", files)
        verification: models.Json = {"outcome": "passed_complete_physical_metadata_archive", "observed_utc": utc(),
                                    "files": inventory, "source_archives": nested,
                                    "oracle_source_archive_members": oracle_verified,
                                    "archive": io.identity_bytes((config.output / "evidence.tar.gz").read_bytes()).model_dump()}
        io.write(config.output / "archive-verification.json", verification)
        for pin in config.files.values():
            io.verify(pin)
        io.verify(config_pin)
        io.verify(config.queue)
        io.verify(config.plan)
        io.verify(config.audit)
        receipt.update(outcome="passed_metadata_only_matched_report_generation", finished_utc=utc(),
                       metadata_inputs_before_after_equal=True, file_count=len(files), total_metadata_bytes=total,
                       archive=verification["archive"], report=io.pin(config.output / "report.json").model_dump(mode="json"))
    except BaseException as error:  # noqa: BLE001 -- all failed packaging evidence remains durable.
        receipt.update(outcome="error", finished_utc=utc(), errors=[repr(error)], traceback=traceback.format_exc())
    io.write(config.output / "generation-receipt.json", receipt)
    print(json.dumps({k: receipt.get(k) for k in ("outcome", "file_count", "archive", "errors")}, allow_nan=False))
    return 0 if receipt["outcome"] == "passed_metadata_only_matched_report_generation" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    return run(parser.parse_args().config)


if __name__ == "__main__":
    raise SystemExit(main())
