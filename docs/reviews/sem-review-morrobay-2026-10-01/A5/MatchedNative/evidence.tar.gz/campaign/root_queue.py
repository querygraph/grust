"""Root-owned serial native matched graph contrasts with complete outcome preservation."""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import traceback
from pathlib import Path
from types import FrameType
from typing import Literal

import native_io as io
from matched_models import OracleReceipt
from native_models import (
    Algorithm,
    Config,
    Dataset,
    EngineExitedProof,
    ExitObservation,
    Pin,
    Receipt,
    Record,
    ResultDataset,
)
from pydantic import Field


class Cell(Record):
    id: str
    dataset: Dataset
    algorithm: Algorithm
    snapshot_inputs: bool = False
    engine: Literal["graphframes", "pecan"]
    kind: Literal["reference", "warmup", "measured"]
    block: int | None = None
    position: int | None = None


class State(Record):
    cell: Cell
    outcome: str = "pending"
    parent_pid: int | None = None
    returncode: int | None = None
    configuration: Pin | None = None
    receipt: Pin | None = None
    started_utc: str | None = None
    finished_utc: str | None = None
    launch_to_exit_seconds: float | None = None
    reason: str | None = None
    qualified: bool = False


class Plan(Record):
    root: Path
    helper: Path
    oracle: Path
    templates: dict[str, Pin]
    source: Pin
    graphframes_binary: Path
    pecan_binary: Path
    ssd_root: Path
    cells: list[Cell]


class Queue(Record):
    started_utc: str
    owner_pid: int
    plan_before: Pin
    source_before: Pin
    outcome: str = "running"
    finished_utc: str | None = None
    plan_after: Pin | None = None
    source_after: Pin | None = None
    references: dict[str, ResultDataset] = Field(default_factory=dict)
    cells: list[State] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    traceback: str | None = None
    forced_parent_cancellation: bool = False


BOOT = (
    "import runpy,sys; d,o=sys.argv[1:3]; sys.path[:0]=[d,o]; "
    'sys.argv=[d+"/supervise_native.py",*sys.argv[3:]]; '
    'runpy.run_path(sys.argv[0],run_name="__main__")'
)


def pinned(path: Path) -> Pin:
    return Pin(path=path, **io.identity(path).model_dump())


def absent(pid: int) -> bool:
    return all(row.pid != pid and row.pgid != pid for row, _ in io.processes())


def closed_reference(config: Config, receipt: Receipt) -> ResultDataset:
    if receipt.engine_exited is None:
        raise ValueError("closed reference needs actual pre-oracle exit proof")
    proof_pin = receipt.engine_exited
    io.verify(proof_pin)
    proof = EngineExitedProof.model_validate_json(proof_pin.path.read_bytes())
    io.require(
        proof.raw_directory == config.engine.output / "result"
        and proof.run_id == config.run_id
        and proof.engine == "graphframes",
        "reference producer binding differs",
    )
    io.require(
        io.inventory(proof.raw_directory) == proof.raw_files,
        "closed reference raw bytes differ",
    )
    return ResultDataset(
        engine="graphframes",
        directory=proof.raw_directory,
        files=proof.raw_files,
        exit=ExitObservation(
            engine="graphframes",
            run_id=proof.run_id,
            child_pid=proof.child_pid,
            returncode=0,
            wait_completed=True,
            producer_receipt=proof_pin,
        ),
    )


def seal_config(
    plan: Plan, template: Config, cell: Cell, reference: ResultDataset | None
) -> Config:
    raw = template.model_dump(mode="json")
    output = plan.root / "cells" / cell.id
    raw.update(
        output=str(output),
        retention=str(output / "raw-output"),
        run_id=cell.id,
        contrast_mode="local",
        reference_preparation_only=cell.kind == "reference",
        reference=reference.model_dump(mode="json") if reference else None,
    )
    engine = template.engine.model_dump(mode="json")
    engine.update(
        engine=cell.engine,
        mode="local",
        snapshot_inputs=cell.snapshot_inputs,
        output=str(plan.ssd_root / cell.id),
        binary=str(
            plan.pecan_binary if cell.engine == "pecan" else plan.graphframes_binary
        ),
        pool_bytes=30 * 2**30,
    )
    raw["engine"] = engine
    return Config.model_validate_json(io.JSON_OBJECT.dump_json(raw))


def validate_plan(plan: Plan) -> None:
    expected_keys = {
        dataset + "-" + algorithm
        for dataset in ("cit-Patents", "graph500-24")
        for algorithm in ("wcc", "pagerank", "bfs")
    }
    io.require(set(plan.templates) == expected_keys, "all six exact templates required")
    io.require(
        len(plan.cells) == 70 and len({cell.id for cell in plan.cells}) == 70,
        "exact unique seventy-cell campaign required",
    )
    expected: list[tuple[str, str, str, str, int | None, int | None, bool]] = []
    for dataset in ("cit-Patents", "graph500-24"):
        for algorithm in ("wcc", "pagerank", "bfs"):
            expected.append(
                (dataset, algorithm, "graphframes", "reference", None, None, False)
            )
            expected.extend(
                (dataset, algorithm, engine, "warmup", None, None, False)
                for engine in ("graphframes", "pecan")
            )
            for block in range(2):
                expected.extend(
                    (dataset, algorithm, engine, "measured", block, position, False)
                    for position, engine in enumerate(
                        ("graphframes", "pecan", "pecan", "graphframes")
                    )
                )
            if algorithm == "wcc":
                expected.extend(
                    (
                        dataset,
                        algorithm,
                        engine,
                        "measured",
                        2,
                        position,
                        engine == "pecan",
                    )
                    for position, engine in enumerate(("graphframes", "pecan"))
                )
    observed = [
        (
            c.dataset,
            c.algorithm,
            c.engine,
            c.kind,
            c.block,
            c.position,
            c.snapshot_inputs,
        )
        for c in plan.cells
    ]
    io.require(
        observed == expected,
        "reference/warmup/ABBA/snapshot call order or arguments changed",
    )


def interrupted(signum: int, _frame: FrameType | None) -> None:
    raise InterruptedError(f"root queue signal {signum}")


def execute(plan_path: Path) -> int:
    plan = Plan.model_validate_json(plan_path.read_bytes())
    io.verify(plan.source)
    io.require(
        Path(__file__).resolve() == plan.source.path.resolve(),
        "actual root queue source origin mismatch",
    )
    validate_plan(plan)
    templates = {
        key: Config.model_validate_json(pin.path.read_bytes())
        for key, pin in plan.templates.items()
    }
    for key, pin in plan.templates.items():
        io.verify(pin)
        template = templates[key]
        io.require(
            key == template.engine.dataset + "-" + template.engine.algorithm,
            "template dataset/algorithm key mismatch",
        )
    io.require(
        all(
            not (plan.root / n).exists()
            for n in ("queue.json", "cells", "configs", "logs")
        ),
        "refusing existing queue artifacts",
    )
    for name in ("configs", "logs"):
        (plan.root / name).mkdir(parents=True, exist_ok=False)
    queue = Queue(
        started_utc=io.utc(),
        owner_pid=os.getpid(),
        plan_before=pinned(plan_path),
        source_before=pinned(Path(__file__)),
        cells=[State(cell=c) for c in plan.cells],
    )
    path = plan.root / "queue.json"
    io.write(path, queue, fresh=True)
    active: subprocess.Popen[bytes] | None = None
    active_config: Config | None = None
    try:
        for state in queue.cells:
            io.verify(plan.source)
            key = state.cell.dataset + "-" + state.cell.algorithm
            io.verify(plan.templates[key])
            template = templates[key]
            io.verify(queue.plan_before)
            io.require(
                all(not lock.exists() for lock in template.locks),
                "shared graph locks occupied",
            )
            config = seal_config(plan, template, state.cell, queue.references.get(key))
            active_config = config
            config_path = plan.root / "configs" / (state.cell.id + ".json")
            io.write(config_path, config, fresh=True)
            state.configuration = pinned(config_path)
            state.started_utc = io.utc()
            state.outcome = "running"
            io.write(path, queue)
            with (plan.root / "logs" / (state.cell.id + ".log")).open("xb") as log:
                active = subprocess.Popen(
                    [
                        str(config.python),
                        "-I",
                        "-B",
                        "-c",
                        BOOT,
                        str(plan.helper),
                        str(plan.oracle),
                        "--config",
                        str(config_path),
                    ],
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    env=io.environment(config.library_path),
                    start_new_session=True,
                )
                state.parent_pid = active.pid
                io.write(path, queue)
                state.returncode = active.wait(
                    timeout=config.engine_seconds
                    + config.oracle_seconds
                    + 2 * config.closure_seconds
                    + 600
                )
            receipt_path = config.output / "receipt.json"
            state.receipt = pinned(receipt_path)
            receipt = Receipt.model_validate_json(receipt_path.read_bytes())
            io.require(
                receipt.config == config,
                "parent receipt configuration differs from frozen call",
            )
            state.outcome = receipt.outcome
            state.finished_utc = io.utc()
            state.launch_to_exit_seconds = receipt.launch_to_exit_seconds
            io.write(path, queue)
            wanted = (
                "reference_prepared"
                if state.cell.kind == "reference"
                else "passed_matched_native_diagnostic"
            )
            io.require(
                state.returncode == 0
                and receipt.outcome == wanted
                and not receipt.errors,
                "parent did not qualify this cell",
            )
            io.require(
                absent(active.pid)
                and receipt.child_group_absent
                and receipt.server_group_absent
                and receipt.worker_processes_absent
                and receipt.matching_server_absent,
                "owned parent/engine/worker closure uncertain",
            )
            io.require(
                receipt.retention_verified
                and receipt.locks_released
                and receipt.before == receipt.after
                and receipt.source_before == receipt.source_after,
                "final cell integrity/retention failed",
            )
            if receipt.correctness is None:
                raise ValueError("missing full physical oracle")
            oracle = OracleReceipt.model_validate_json(
                io.JSON_OBJECT.dump_json(receipt.correctness)
            )
            io.require(
                oracle.own_identity_closure_passed
                and oracle.full_physical_domain_passed
                and oracle.expected_domain_rows
                == oracle.unique_candidate_rows
                == config.expected_vertex_rows,
                "full original vertex domain oracle failed",
            )
            if state.cell.kind == "reference":
                io.require(
                    not oracle.full_numeric_comparison_passed
                    and oracle.compared_rows == 0,
                    "reference preparation cannot be a numerical self-comparison",
                )
                queue.references[key] = closed_reference(config, receipt)
            else:
                io.require(
                    oracle.full_numeric_comparison_passed
                    and oracle.compared_rows == config.expected_vertex_rows
                    and oracle.numeric_mismatches == 0,
                    "full per-vertex numeric oracle failed",
                )
            io.verify(state.configuration)
            io.verify(state.receipt)
            state.qualified = True
            io.write(path, queue)
            active = None
            active_config = None
        queue.plan_after = pinned(plan_path)
        queue.source_after = pinned(Path(__file__))
        io.require(
            queue.plan_before == queue.plan_after
            and queue.source_before == queue.source_after,
            "queue source/plan closure changed",
        )
        io.require(
            all(state.qualified for state in queue.cells)
            and len(queue.references) == 6,
            "every planned call and all six references must qualify",
        )
        queue.outcome = "qualified_native_d0_WCC_PageRank_BFS_and_snapshot_pairs"
    except BaseException as error:  # noqa: BLE001 -- interruptions must preserve all skipped outcomes.
        queue.outcome = "error"
        queue.errors.append(repr(error))
        queue.traceback = traceback.format_exc()
        for state in queue.cells:
            if state.outcome == "pending":
                state.outcome = "skipped"
                state.reason = "prior cell or root queue was unqualified; no retry"
            elif state.outcome == "running":
                state.outcome = "error"
                state.reason = repr(error)
    finally:
        if active is not None and active.poll() is None:
            queue.forced_parent_cancellation = True
            queue.outcome = "error"
            queue.errors.append(
                "root forced cancellation of live parent; no qualification"
            )
            try:
                os.killpg(active.pid, signal.SIGTERM)
                active.wait(
                    timeout=(active_config.closure_seconds if active_config else 300)
                    + 60
                )
            except BaseException as error:  # noqa: BLE001 -- cancellation failures remain unqualified.
                queue.errors.append("parent cancellation: " + repr(error))
                try:
                    os.killpg(active.pid, signal.SIGKILL)
                    active.wait(timeout=10)
                except BaseException as final_error:  # noqa: BLE001 -- preserve final owned cleanup uncertainty.
                    queue.errors.append(
                        "parent final cancellation: " + repr(final_error)
                    )
        queue.finished_utc = io.utc()
        io.write(path, queue)
    return 0 if queue.outcome.startswith("qualified_") else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True, type=Path)
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, interrupted)
    return execute(parser.parse_args().plan)


if __name__ == "__main__":
    raise SystemExit(main())
