"""Offline controls for serialized native campaign order and snapshot policy."""

from __future__ import annotations

import unittest
from pathlib import Path
from typing import Literal, cast

from native_models import Pin
from root_queue import Cell, Plan, validate_plan


def plan() -> Plan:
    pin = Pin(path=Path("/tmp/dummy"), bytes=0, sha256="0" * 64)
    cells: list[Cell] = []
    for dataset in ("cit-Patents", "graph500-24"):
        for algorithm in ("wcc", "pagerank", "bfs"):
            rows: list[tuple[str, str, int | None, int | None, bool]] = [
                ("graphframes", "reference", None, None, False),
                ("graphframes", "warmup", None, None, False),
                ("pecan", "warmup", None, None, False),
            ]
            for block in range(2):
                rows.extend(
                    (engine, "measured", block, position, False)
                    for position, engine in enumerate(
                        ("graphframes", "pecan", "pecan", "graphframes")
                    )
                )
            if algorithm == "wcc":
                rows.extend(
                    (engine, "measured", 2, position, engine == "pecan")
                    for position, engine in enumerate(("graphframes", "pecan"))
                )
            cells.extend(
                Cell(
                    id=f"{dataset}-{algorithm}-{index}",
                    dataset=dataset,
                    algorithm=algorithm,
                    engine=cast(Literal["graphframes", "pecan"], engine),
                    kind=cast(Literal["reference", "warmup", "measured"], kind),
                    block=block,
                    position=position,
                    snapshot_inputs=snapshot,
                )
                for index, (engine, kind, block, position, snapshot) in enumerate(rows)
            )
    return Plan(
        root=Path("/tmp/run"),
        helper=Path("/tmp/helper"),
        oracle=Path("/tmp/oracle"),
        templates={
            d + "-" + a: pin
            for d in ("cit-Patents", "graph500-24")
            for a in ("wcc", "pagerank", "bfs")
        },
        source=pin,
        graphframes_binary=Path("/tmp/gf"),
        pecan_binary=Path("/tmp/sail"),
        ssd_root=Path("/tmp/ssd"),
        cells=cells,
    )


class OrderControls(unittest.TestCase):
    def test_all_six_references_and_seventy_calls(self) -> None:
        validate_plan(plan())

    def test_missing_measured_call_refused(self) -> None:
        value = plan()
        value.cells.pop()
        with self.assertRaises(ValueError):
            validate_plan(value)

    def test_duplicate_run_identity_refused(self) -> None:
        value = plan()
        value.cells[-1] = value.cells[0]
        with self.assertRaises(ValueError):
            validate_plan(value)

    def test_reference_cannot_follow_warmup(self) -> None:
        value = plan()
        value.cells[0], value.cells[1] = value.cells[1], value.cells[0]
        with self.assertRaises(ValueError):
            validate_plan(value)

    def test_snapshot_on_graphframes_refused(self) -> None:
        value = plan()
        value.cells[11].snapshot_inputs = True
        with self.assertRaises(ValueError):
            validate_plan(value)

    def test_snapshot_in_primary_abba_refused(self) -> None:
        value = plan()
        value.cells[4].snapshot_inputs = True
        with self.assertRaises(ValueError):
            validate_plan(value)

    def test_missing_dataset_template_refused(self) -> None:
        value = plan()
        value.templates.pop("graph500-24-bfs")
        with self.assertRaises(ValueError):
            validate_plan(value)

    def test_paired_block_position_change_refused(self) -> None:
        value = plan()
        value.cells[3].position = 3
        with self.assertRaises(ValueError):
            validate_plan(value)


if __name__ == "__main__":
    unittest.main()
