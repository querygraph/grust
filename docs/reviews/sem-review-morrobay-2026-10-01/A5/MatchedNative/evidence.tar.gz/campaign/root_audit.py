"""Independent root audit of closed native matched graph files, identities, and ownership."""

from __future__ import annotations

import math
from pathlib import Path
from typing import cast

import native_io as io
from matched_models import OracleReceipt
from native_models import EngineExitedProof, Identity, Pin, Process, Receipt, Record
from pydantic import JsonValue

BASE = Path("/Volumes/Apo/graph-tests/results/sem-review-20261001")
ROOT = BASE / "A5-native-matched-run01"


class CellAudit(Record):
    id: str
    kind: str
    dataset: str
    algorithm: str
    snapshot_inputs: bool
    engine: str
    parent_pid: int
    child_pid: int
    server_pid: int
    workers: list[Process]
    config_pin: Pin
    receipt_pin: Pin
    retained_files: dict[str, Identity]
    raw_result_files: dict[str, Identity]
    retained_total_bytes: int
    source_client_identity_closure: bool = True
    full_output_retention_qualified: bool = True
    full_domain_rows: int
    compared_rows: int
    numeric_mismatches: int
    full_numeric_comparison_passed: bool
    reference_preparation_only: bool
    max_absolute_error: float | None
    max_relative_error: float | None
    full_physical_domain_passed: bool = True


class Contrast(Record):
    n_per_engine: int = 4
    paired_ratios: list[float]
    geometric_mean_ratio: float
    maximum_absolute_error: float | None


class Audit(Record):
    observed_utc: str
    outcome: str = "passed_independent_native_matched_campaign_audit"
    queue_pin: Pin
    plan_pin: Pin
    source_pin: Pin
    all_owned_pid_and_group_absent: bool = True
    shared_locks_absent: bool = True
    owned_processes_remaining: list[str]
    matching_native_servers_remaining: list[str]
    source_input_client_closure: bool = True
    current_pins: dict[str, Identity]
    cells: list[CellAudit]
    contrasts: dict[str, Contrast]
    snapshot_pairs: dict[str, Contrast]
    total_retained_files: int
    total_retained_bytes: int
    scope: str = "Independent complete SSD/Apo file hashes, immutable source/client/input pins and current owned PID/group closure; prior full physical per-vertex oracle receipts are bound, no new algorithm rerun."


def obj(value: JsonValue) -> dict[str, JsonValue]:
    if not isinstance(value, dict):
        raise TypeError("required metadata object missing")
    return value


def rows(value: JsonValue) -> list[JsonValue]:
    if not isinstance(value, list):
        raise TypeError("required metadata rows missing")
    return value


def pin(path: Path) -> Pin:
    return Pin(path=path, **io.identity(path).model_dump())


def main() -> int:
    queue_path, plan_path = ROOT / "queue.json", ROOT / "plan.json"
    queue_pin, plan_pin = pin(queue_path), pin(plan_path)
    queue, plan = io.load(queue_path), io.load(plan_path)
    io.require(
        queue.get("outcome")
        == "qualified_native_d0_WCC_PageRank_BFS_and_snapshot_pairs"
        and queue.get("errors") == []
        and queue.get("forced_parent_cancellation") is False
        and bool(queue.get("finished_utc")),
        "all70 actual calls must close before independent audit",
    )
    io.require(
        queue.get("plan_before")
        == queue.get("plan_after")
        == plan_pin.model_dump(mode="json")
        and queue.get("source_before") == queue.get("source_after"),
        "queue source/plan closure changed",
    )
    queue_source = Pin.model_validate(plan.get("source"))
    io.verify(queue_source)
    io.require(
        queue.get("source_before")
        == queue.get("source_after")
        == queue_source.model_dump(mode="json"),
        "current queue source pin closure differs",
    )
    actual, planned = rows(queue.get("cells")), rows(plan.get("cells"))
    io.require(len(actual) == len(planned) == 70, "complete70-call protocol required")
    owned = {cast(int, queue["owner_pid"])}
    owned.update([cast(int, io.load(ROOT / "launch01.json")["pid"])])
    pins: dict[str, Identity] = {}
    audited: list[CellAudit] = []
    durations: dict[str, float] = {}
    binaries: set[Path] = set()
    for raw, intended in zip(actual, planned, strict=True):
        state = obj(raw)
        cell = obj(state.get("cell"))
        io.require(cell == intended, "actual cell differs from fixed ordered protocol")
        config_pin = Pin.model_validate(state.get("configuration"))
        receipt_pin = Pin.model_validate(state.get("receipt"))
        io.verify(config_pin)
        io.verify(receipt_pin)
        receipt = Receipt.model_validate_json(receipt_pin.path.read_bytes())
        reference = cell["kind"] == "reference"
        from_config = io.load(config_pin.path)
        io.require(
            receipt.config.model_dump(mode="json") == from_config,
            "actual parent/config pin binding differs",
        )
        wanted = (
            "reference_prepared" if reference else "passed_matched_native_diagnostic"
        )
        io.require(
            state.get("returncode") == receipt.returncode == 0
            and state.get("outcome") == receipt.outcome == wanted
            and not receipt.errors
            and bool(receipt.finished_utc),
            "actual parent did not qualify",
        )
        io.require(
            all(
                (
                    receipt.child_group_absent,
                    receipt.server_group_absent,
                    receipt.worker_processes_absent,
                    receipt.matching_server_absent,
                    receipt.locks_released,
                    receipt.retention_verified,
                )
            ),
            "parent ownership/retention release failed",
        )
        io.require(
            receipt.before == receipt.after
            and receipt.source_before == receipt.source_after,
            "parent source/input identity closure failed",
        )
        if receipt.client_before is None or receipt.client_after is None:
            raise ValueError("actual client probes missing")
        io.same_client(receipt.client_before, receipt.client_after)
        io.require(
            not receipt.client_after.extensions,
            "unexpected installed extension entrypoints",
        )
        io.require(
            receipt.source_after["commit"] == "d0e4e422afdea967126ae7b9506e04c9f1812b97"
            and receipt.source_after["compiled_runtime"]
            == "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
            and receipt.source_after["compiled_runtime_paths_parity"] == "empty diff"
            and receipt.source_after["graphframes_commit"]
            == "b4da56dabe20bba8e29563e06acc5179b2113ce3",
            "actual source pins differ",
        )
        io.require(
            state.get("qualified") is True,
            "root late audit must also qualify this call",
        )
        io.require(
            receipt.config.engine.dataset == cell["dataset"]
            and receipt.config.engine.algorithm == cell["algorithm"]
            and receipt.config.engine.snapshot_inputs is cell["snapshot_inputs"]
            and receipt.config.run_id == cell["id"]
            and receipt.config.reference_preparation_only is reference,
            "actual invocation contract differs",
        )
        io.require(
            receipt.correctness is not None and receipt.engine_exited is not None,
            "oracle/exit proof missing",
        )
        oracle = OracleReceipt.model_validate_json(
            io.JSON_OBJECT.dump_json(cast(dict[str, JsonValue], receipt.correctness))
        )
        io.require(
            oracle.own_identity_closure_passed
            and oracle.full_physical_domain_passed
            and oracle.expected_domain_rows
            == oracle.reference_rows
            == oracle.candidate_rows
            == oracle.unique_candidate_rows
            == receipt.config.expected_vertex_rows,
            "full physical domain failed",
        )
        io.require(
            oracle.full_numeric_comparison_passed is (not reference)
            and oracle.compared_rows
            == (0 if reference else receipt.config.expected_vertex_rows)
            and oracle.numeric_mismatches == 0
            and oracle.absolute_bound == 1e-12,
            "numeric qualification differs",
        )
        if cell["algorithm"] == "wcc" and not reference:
            io.require(
                oracle.full_partition_comparison_passed
                and oracle.canonical_labels_passed
                and oracle.membership_mismatches
                == oracle.canonical_mismatches
                == oracle.false_merge_groups
                == oracle.false_split_groups
                == 0,
                "full canonical WCC partition failed",
            )
        if cell["algorithm"] == "bfs" and not reference:
            io.require(
                oracle.distance_mismatches == 0
                and oracle.source == receipt.config.engine.source
                and oracle.reachable_vertices is not None
                and oracle.reachable_vertices >= 1,
                "full directed hop/source qualification failed",
            )
        proof_pin = cast(Pin, receipt.engine_exited)
        io.verify(proof_pin)
        proof = EngineExitedProof.model_validate_json(proof_pin.path.read_bytes())
        io.require(
            proof.run_id == cell["id"]
            and proof.child_pid == receipt.child_pid
            and proof.raw_directory == receipt.config.engine.output / "result",
            "producer exit proof differs",
        )
        io.require(
            oracle.config.candidate.exit.producer_receipt.model_dump(mode="json")
            == proof_pin.model_dump(mode="json"),
            "oracle candidate does not bind actual immutable exit proof",
        )
        ssd = io.inventory(receipt.config.engine.output)
        retained = io.inventory(receipt.config.retention)
        io.require(
            ssd == retained == receipt.retention_files,
            "complete actual SSD/Apo retained bytes differ",
        )
        result = io.inventory(proof.raw_directory)
        io.require(
            result == proof.raw_files,
            "complete actual raw result differs from sealed proof",
        )
        io.require(
            {
                n.removeprefix("result/"): p
                for n, p in retained.items()
                if n.startswith("result/")
            }
            == result,
            "complete retained raw result inventory differs",
        )
        parent_pid = cast(int, state["parent_pid"])
        child_pid, server_pid = (
            cast(int, receipt.child_pid),
            cast(int, receipt.server_pid),
        )
        owned.update({parent_pid, child_pid, server_pid})
        owned.update(p.pid for p in receipt.sampler.owned_workers)
        owned.update(
            p.pgid
            for p in [*receipt.sampler.owned_servers, *receipt.sampler.owned_workers]
        )
        io.require(
            not receipt.sampler.owned_workers and receipt.config.engine.mode == "local",
            "unexpected process cluster in local campaign",
        )
        binaries.add(receipt.config.engine.binary)
        for name, identity in receipt.after.items():
            io.require(
                name not in pins or pins[name] == identity,
                "immutable pin differed between cells",
            )
            pins[name] = identity
        for origin in receipt.client_after.modules.values():
            pins[str(origin.path)] = Identity(bytes=origin.bytes, sha256=origin.sha256)
        for abi in (receipt.client_after.executable, receipt.client_after.libpython):
            observed = Identity(bytes=abi.bytes, sha256=abi.sha256)
            io.require(
                str(abi.path) not in pins or pins[str(abi.path)] == observed,
                "client executable/library ABI identity differed between cells",
            )
            pins[str(abi.path)] = observed
        duration = receipt.launch_to_exit_seconds
        io.require(
            duration is not None and math.isfinite(duration) and duration > 0,
            "actual measured boundary missing",
        )
        durations[cast(str, cell["id"])] = cast(float, duration)
        audited.append(
            CellAudit(
                id=cast(str, cell["id"]),
                kind=cast(str, cell["kind"]),
                dataset=cast(str, cell["dataset"]),
                algorithm=cast(str, cell["algorithm"]),
                snapshot_inputs=cast(bool, cell["snapshot_inputs"]),
                engine=cast(str, cell["engine"]),
                parent_pid=parent_pid,
                child_pid=child_pid,
                server_pid=server_pid,
                workers=receipt.sampler.owned_workers,
                config_pin=config_pin,
                receipt_pin=receipt_pin,
                retained_files=retained,
                raw_result_files=result,
                retained_total_bytes=sum(p.bytes for p in retained.values()),
                full_domain_rows=oracle.unique_candidate_rows,
                compared_rows=oracle.compared_rows,
                numeric_mismatches=oracle.numeric_mismatches,
                full_numeric_comparison_passed=oracle.full_numeric_comparison_passed,
                reference_preparation_only=reference,
                max_absolute_error=oracle.max_absolute_error,
                max_relative_error=oracle.max_relative_error,
            )
        )
    current = {
        name: io.verify(Pin(path=Path(name), **identity.model_dump()))
        for name, identity in pins.items()
    }
    table = io.processes()
    remaining = [
        f"{p.pid} {p.ppid} {p.pgid}"
        for p, _ in table
        if p.pid in owned or p.pgid in owned
    ]
    matching = [
        f"{p.pid} {p.pgid}"
        for p, text in table
        if any(io.matching_server(text, b) for b in binaries)
    ]
    io.require(
        not remaining and not matching,
        "current owned process or matching native server remains",
    )
    io.require(
        all(not (BASE / n).exists() for n in ["gate.lock", "serial-queue.lock"]),
        "shared locks remain",
    )
    contrasts: dict[str, Contrast] = {}
    snapshot_pairs: dict[str, Contrast] = {}
    for dataset in ("cit-Patents", "graph500-24"):
        for algorithm in ("wcc", "pagerank", "bfs"):
            selected = [
                obj(obj(state).get("cell"))
                for state in actual
                if obj(obj(state).get("cell")).get("dataset") == dataset
                and obj(obj(state).get("cell")).get("algorithm") == algorithm
                and obj(obj(state).get("cell")).get("kind") == "measured"
            ]
            pairs = []
            for block in (0, 1):
                blockcells = sorted(
                    (c for c in selected if c.get("block") == block),
                    key=lambda c: cast(int, c["position"]),
                )
                io.require(
                    [c["engine"] for c in blockcells]
                    == ["graphframes", "pecan", "pecan", "graphframes"],
                    "actual paired ABBA order changed",
                )
                pairs.extend(
                    [
                        durations[cast(str, blockcells[1]["id"])]
                        / durations[cast(str, blockcells[0]["id"])],
                        durations[cast(str, blockcells[2]["id"])]
                        / durations[cast(str, blockcells[3]["id"])],
                    ]
                )
            maximum = max(
                (
                    c.max_absolute_error
                    for c in audited
                    if c.dataset == dataset
                    and c.algorithm == algorithm
                    and c.engine == "pecan"
                    and c.max_absolute_error is not None
                ),
                default=None,
            )
            contrasts[dataset + "-" + algorithm] = Contrast(
                paired_ratios=pairs,
                geometric_mean_ratio=math.exp(sum(math.log(x) for x in pairs) / 4),
                maximum_absolute_error=maximum,
            )
            if algorithm == "wcc":
                pair = sorted(
                    (c for c in selected if c.get("block") == 2),
                    key=lambda c: cast(int, c["position"]),
                )
                io.require(
                    [c["engine"] for c in pair] == ["graphframes", "pecan"]
                    and pair[1]["snapshot_inputs"] is True,
                    "actual single snapshot contrast changed",
                )
                ratio = (
                    durations[cast(str, pair[1]["id"])]
                    / durations[cast(str, pair[0]["id"])]
                )
                snapshot_pairs[dataset + "-wcc"] = Contrast(
                    n_per_engine=1,
                    paired_ratios=[ratio],
                    geometric_mean_ratio=ratio,
                    maximum_absolute_error=None,
                )
    io.verify(queue_pin)
    io.verify(plan_pin)
    audit = Audit(
        observed_utc=io.utc(),
        queue_pin=queue_pin,
        plan_pin=plan_pin,
        source_pin=pin(Path(__file__)),
        owned_processes_remaining=remaining,
        matching_native_servers_remaining=matching,
        current_pins=current,
        cells=audited,
        contrasts=contrasts,
        snapshot_pairs=snapshot_pairs,
        total_retained_files=sum(len(c.retained_files) for c in audited),
        total_retained_bytes=sum(c.retained_total_bytes for c in audited),
    )
    io.write(ROOT / "root-audit01.json", audit, fresh=True)
    print(
        audit.model_dump_json(
            include={
                "outcome",
                "contrasts",
                "snapshot_pairs",
                "total_retained_files",
                "total_retained_bytes",
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
