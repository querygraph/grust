"""Native local WCC/BFS/PageRank child; full raw export and owned cleanup.

Configured software pools/threads are not OS limits. The outside-timer parent
checks the full physical output against a retained graphframes reference.
"""
from __future__ import annotations

import argparse
import contextlib
import json
import os
import signal
import sys
import time
import traceback
from collections.abc import Callable, Iterator, Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType
from typing import Any, Literal, cast

import measurement
import native_models
import runtime
import shutdown as group_shutdown
from native_models import EngineConfig
from pydantic import BaseModel, ConfigDict, Field
from pyspark.sql import DataFrame
from pyspark.sql.connect.client.retries import DefaultPolicy
from pyspark.sql.connect.session import SparkSession
from pyspark_pecan import algorithms
from pyspark_pecan.lifecycle import GraphResult
from pyspark_pecan.staging import StagingRun
from pyspark_pecan.types import IterationEvent

GIB = 2**30
ALGORITHM_DEADLINE_SECONDS = 1200
CLEANUP_DEADLINE_SECONDS = 30
Outcome = Literal["running", "passed", "error", "timeout", "interrupted", "nonconverged", "cleanup_error"]


class Record(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class CleanupError(Record):
    operation: str
    error: str


@dataclass(slots=True)
class CleanupSink:
    """Typed adapter for the frozen runtime's append-only cleanup interface."""

    records: list[CleanupError] = field(default_factory=list)

    def append(self, value: Mapping[str, str]) -> None:
        self.records.append(CleanupError(operation=value["operation"], error=value["error"]))


class PhaseRecord(Record):
    name: str
    status: Literal["start", "end", "error"]
    recorded_utc: str
    elapsed_seconds: float
    duration_seconds: float | None = None
    error: str | None = None


class ObservedEvent(Record):
    elapsed_seconds: float
    event: IterationEvent


class RoundRecord(Record):
    iteration: int
    duration_seconds: float


class OutputField(Record):
    name: str
    type: str
    nullable: bool


class ResultMetadata(Record):
    algorithm: str
    method: str | None
    seed: int | None
    iterations: int
    converged: bool | None


class CgroupSnapshot(Record):
    model_config = ConfigDict(extra="ignore")
    memory_current: str | None = Field(alias="memory.current")
    memory_peak: str | None = Field(alias="memory.peak")
    memory_max: str | None = Field(alias="memory.max")
    memory_swap_max: str | None = Field(alias="memory.swap.max")
    memory_events: str | None = Field(alias="memory.events")
    memory_stat: str | None = Field(alias="memory.stat")
    cpu_max: str | None = Field(alias="cpu.max")
    cpu_stat: str | None = Field(alias="cpu.stat")
    cpuset_cpus_effective: str | None = Field(alias="cpuset.cpus.effective")


class ModuleOrigins(Record):
    native_models: str
    algorithms: str
    runtime: str
    measurement: str
    shutdown: str
    python_executable: str
    python_version: str


class ErrorRecord(Record):
    type: str
    message: str
    traceback: str


class EngineReceipt(Record):
    schema_version: Literal[1] = 1
    verdict_scope: Literal["engine execution and cleanup only; oracle outside child"] = (
        "engine execution and cleanup only; oracle outside child")
    config: EngineConfig
    started_utc: str
    finished_utc: str | None = None
    outcome: Outcome = "running"
    declared_controller_pin: str = "d0e4e422afdea967126ae7b9506e04c9f1812b97"
    declared_runtime_pin: str = "9f0aa7d2a50f1258544d37c05dd19b3ff3d915b3"
    runtime_pin_scope: str = "compiled native Sail source; runtime.py helper source is declared_harness_pin"
    declared_harness_pin: str = "6ae2e43a903c2cee02da170465c922c72b76198e"
    declared_native_pin: str | None = None
    native_package_scope: str = "not applicable: Pecan builtin SQL/GraphUtils; root requires zero installed pysail.extensions entry points"
    execution_class: Literal["native-macOS"] = "native-macOS"
    identity_guard_scope: str = "root native preflight must verify hashes/pins; child records and checks import locations"
    measurement_scope: str = "Linux cgroups, PSS and guest steal are unavailable on native macOS; no container 16CPU/32GiB/noSwap envelope is claimed. Local threads16/pool30GiB, partitions16, are software settings only."
    origins: ModuleOrigins | None = None
    shutdown: list[group_shutdown.ShutdownRecord] = Field(default_factory=list)
    driver_pid: int | None = None
    inherited_library_path: str | None = None
    phases: list[PhaseRecord] = Field(default_factory=list)
    events: list[ObservedEvent] = Field(default_factory=list)
    rounds: list[RoundRecord] = Field(default_factory=list)
    incomplete_rounds: list[int] = Field(default_factory=list)
    result: ResultMetadata | None = None
    output_schema: list[OutputField] = Field(default_factory=list)
    output_projection: list[str] = Field(default_factory=list)
    timing_scope: str = "phase offsets begin after config parsing; root native launcher times complete process launch through exit"
    snapshots_in_engine_boundary: bool = True
    pecan_snapshot_inputs: bool
    snapshot_timing_hook: str = "delegates the original _snapshot once, without extra actions"
    algorithm_contract: str
    output_scope: str = "full declared raw scalar export; BFS is id/hops only, parent/distance are not exported"
    max_iterations: int
    threads_per_process: Literal[16] = 16
    worker_count: int
    worker_task_slots: Literal[64] = 64
    potential_pool_total_bytes: int = 30 * GIB
    pool_type: Literal["greedy"] = "greedy"
    logging: Literal["warn"] = "warn"
    plan_capture: Literal[False] = False
    repartition_checkpoints: Literal[True] = True
    rpc_max_retries: Literal[1] = 1
    algorithm_deadline_seconds: int = ALGORITHM_DEADLINE_SECONDS
    cleanup_deadline_seconds: int = CLEANUP_DEADLINE_SECONDS
    before: CgroupSnapshot | None = None
    after: CgroupSnapshot | None = None
    guest_steal_fraction: float | None = None
    cleanup_errors: list[CleanupError] = Field(default_factory=list)
    staging_payload_after_shutdown: list[str] = Field(default_factory=list)
    error: ErrorRecord | None = None


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_receipt(path: Path, receipt: EngineReceipt) -> None:
    temporary = path.with_suffix(".json.tmp")
    with temporary.open("w") as stream:
        stream.write(receipt.model_dump_json(indent=2, by_alias=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def append_record(path: Path, record: Record) -> None:
    with path.open("a") as stream:
        stream.write(record.model_dump_json(exclude_none=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


@dataclass(slots=True)
class Journal:
    receipt: EngineReceipt
    start: float

    def persist(self) -> None:
        atomic_receipt(self.receipt.config.output / "engine-receipt.json", self.receipt)

    @contextlib.contextmanager
    def phase(self, name: str) -> Iterator[None]:
        began = time.perf_counter()
        self.mark(PhaseRecord(name=name, status="start", recorded_utc=utc(), elapsed_seconds=began - self.start))
        try:
            yield
        except BaseException as error:
            self.mark(PhaseRecord(name=name, status="error", recorded_utc=utc(),
                                 elapsed_seconds=time.perf_counter() - self.start,
                                 duration_seconds=time.perf_counter() - began, error=repr(error)))
            raise
        else:
            self.mark(PhaseRecord(name=name, status="end", recorded_utc=utc(),
                                 elapsed_seconds=time.perf_counter() - self.start,
                                 duration_seconds=time.perf_counter() - began))

    def mark(self, event: PhaseRecord) -> None:
        self.receipt.phases.append(event)
        append_record(self.receipt.config.output / "phases.jsonl", event)
        self.persist()

    def observe(self, event: IterationEvent) -> None:
        row = ObservedEvent(elapsed_seconds=time.perf_counter() - self.start, event=event)
        self.receipt.events.append(row)
        append_record(self.receipt.config.output / "events.jsonl", row)


@contextlib.contextmanager
def snapshot_phase(journal: Journal) -> Iterator[None]:
    original = algorithms._snapshot

    def measured(run: StagingRun, vertices: DataFrame, edges: DataFrame,
                 edge_columns: tuple[str, ...] = ("src", "dst"), *,
                 count_vertices: bool = True,
                 snapshot: bool = True) -> tuple[DataFrame, DataFrame, int | None]:
        with journal.phase("input_snapshot"):
            return cast(tuple[DataFrame, DataFrame, int | None],
                        original(run, vertices, edges, edge_columns, count_vertices=count_vertices, snapshot=snapshot))

    algorithms._snapshot = measured
    try:
        yield
    finally:
        algorithms._snapshot = original


def interrupted(signum: int, _frame: FrameType | None) -> None:
    if signum == signal.SIGALRM:
        raise TimeoutError("engine or cleanup phase deadline")
    raise InterruptedError(f"engine interrupted by signal {signum}")


def cleanup(journal: Journal, sink: CleanupSink, name: str, action: Callable[[], Any]) -> None:
    attempted = False
    try:
        signal.alarm(CLEANUP_DEADLINE_SECONDS)
        with journal.phase(name):
            attempted = True
            action()
    except BaseException as error:  # noqa: BLE001 — interruption must not skip owned cleanup.
        sink.records.append(CleanupError(operation=name, error=repr(error)))
        if not attempted:
            # A failed diagnostic write must not prevent owned-resource cleanup.
            try:
                signal.alarm(CLEANUP_DEADLINE_SECONDS)
                action()
            except BaseException as fallback_error:  # noqa: BLE001 — retain fallback cleanup failures.
                sink.records.append(CleanupError(operation=name + "_after_journal_error", error=repr(fallback_error)))
    finally:
        signal.alarm(0)


def execute(config: EngineConfig, journal: Journal, sink: CleanupSink) -> None:
    receipt = journal.receipt
    # These Linux observations are unsupported for the naked macOS class.
    # Leave actual receipt fields None, rather than emulate a cgroup or steal.
    receipt.before = None
    server = runtime.server(config.binary, config.output, config.mode, config.partitions, 16,
                            config.native_quota, sink, worker_task_slots=64,
                            sail_pool_bytes=config.pool_bytes, http2_keepalive_timeout=120)
    spark: SparkSession | None = None
    handle: GraphResult | None = None
    entered = False
    try:
        with journal.phase("server_startup"):
            endpoint_and_pid = server.__enter__()
            entered = True
            endpoint, receipt.driver_pid = endpoint_and_pid
        with journal.phase("session_startup"):
            spark = SparkSession.builder.remote(endpoint).create()
            spark.client.set_retry_policies([DefaultPolicy(max_retries=1, initial_backoff=100,
                                                          max_backoff=100, jitter=0)])
            if spark.sql("SELECT 1 AS ready").first().ready != 1:
                raise RuntimeError("server readiness failed")
        with journal.phase("input_handles"):
            vertices = spark.read.parquet(config.vertices.as_uri())
            edges = spark.read.parquet(config.edges.as_uri()).selectExpr("source AS src", "target AS dst")
        graph = algorithms.GraphAlgorithms(spark, observer=journal.observe, record_plans=False,
                                           repartition_checkpoints=True, snapshot_inputs=config.snapshot_inputs)
        with journal.phase("public_algorithm"), snapshot_phase(journal):
            if config.algorithm == "wcc":
                handle = graph.wcc(vertices, edges, method="randomized", seed=config.seed,
                                   canonical_labels=config.canonical_labels,
                                   max_iterations=config.max_iterations, partitions=config.partitions)
            elif config.algorithm == "bfs":
                handle = graph.bfs(vertices, edges, source=config.source, method="frontier",
                                   directed=True, max_iterations=config.max_iterations, partitions=config.partitions)
            else:
                handle = graph.pagerank(vertices, edges, method="pregel_delta",
                                        reset_probability=config.reset_probability, tolerance=config.tolerance,
                                        max_iterations=config.max_iterations, normalize=config.normalize,
                                        vote_to_halt=config.vote_to_halt, partitions=config.partitions)
        receipt.result = ResultMetadata(algorithm=handle.algorithm, method=handle.method, seed=handle.seed,
                                        iterations=handle.iterations, converged=handle.converged)
        if config.algorithm == "pagerank":
            if handle.iterations != 10 or handle.converged is not None:
                raise RuntimeError("fixed-budget PageRank must return exactly 10 steps/converged None")
        elif handle.converged is not True or not 0 <= handle.iterations <= config.max_iterations:
            raise RuntimeError("WCC/BFS must converge within the declared iteration cap")
        with journal.phase("result_export"):
            receipt.output_projection = {"wcc": ["id", "component"], "bfs": ["id", "hops"],
                                         "pagerank": ["id", "pagerank"]}[config.algorithm]
            frame = handle.frame.select(*receipt.output_projection)
            receipt.output_schema = [OutputField(name=f.name, type=f.dataType.simpleString(), nullable=f.nullable)
                                     for f in frame.schema.fields]
            frame.write.mode("error").parquet((config.output / "result").as_uri())
    finally:
        active_error = sys.exc_info()
        if handle is not None:
            cleanup(journal, sink, "result_close", handle.close)
        if spark is not None:
            cleanup(journal, sink, "session_stop", spark.stop)
        if entered:
            cleanup(journal, sink, "server_shutdown", lambda: server.__exit__(*active_error))
        receipt.after = None
        receipt.guest_steal_fraction = None


def summarize_rounds(receipt: EngineReceipt) -> None:
    starts: dict[int, float] = {}
    for row in receipt.events:
        event = row.event
        if event.kind == "iteration_start":
            if event.iteration in starts:
                raise RuntimeError("duplicate iteration start")
            starts[event.iteration] = row.elapsed_seconds
        elif event.kind == "iteration_end":
            if event.iteration not in starts:
                raise RuntimeError("iteration end without start")
            receipt.rounds.append(RoundRecord(iteration=event.iteration,
                                              duration_seconds=row.elapsed_seconds - starts.pop(event.iteration)))
    receipt.incomplete_rounds = sorted(starts)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    config = EngineConfig.model_validate_json(parser.parse_args().config.read_text())
    if sys.platform != "darwin":
        raise RuntimeError("native algorithm child requires naked macOS execution")
    config.output.mkdir(parents=True, exist_ok=True)
    for name in ("engine-receipt.json", "engine-receipt.json.tmp", "phases.jsonl", "events.jsonl", "result", "staging"):
        if (config.output / name).exists() or (config.output / name).is_symlink():
            raise FileExistsError(f"refusing existing engine evidence: {name}")
    for name in ("phases.jsonl", "events.jsonl"):
        (config.output / name).touch(exist_ok=False)
    receipt = EngineReceipt(config=config, started_utc=utc(), max_iterations=config.max_iterations,
                            algorithm_contract={"wcc": "weak components/randomized seed42/canonical signedmin/cap100",
                                                "bfs": "stored src->dst directed/frontier/source shared/cap1000/hops only",
                                                "pagerank": "directed dynamic Pregel delta/reset.15/tol.01/10 fixedsteps/normalizeTrue/no vote/no dangling"}[config.algorithm],
                            worker_count=0 if config.mode == "local" else 2,
                            inherited_library_path=os.environ.get("DYLD_LIBRARY_PATH"),
                            pecan_snapshot_inputs=config.snapshot_inputs,
                            snapshots_in_engine_boundary=config.snapshot_inputs)
    journal, sink = Journal(receipt, time.perf_counter()), CleanupSink()
    journal.persist()
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM):
        signal.signal(signum, interrupted)
    os.environ.update(SAIL_BENCHMARK_RUST_LOG="warn", SPARK_CONNECT_MODE_ENABLED="1",
                      PYTHONDONTWRITEBYTECODE="1", SAIL_CLUSTER__TASK_STREAM_CREATION_TIMEOUT_SECS="900",
                      SAIL_CLUSTER__WORKER_MAX_IDLE_TIME_SECS="86400")
    try:
        receipt.origins = ModuleOrigins(native_models=str(Path(native_models.__file__).resolve()), algorithms=str(Path(algorithms.__file__).resolve()),
                                       runtime=str(Path(runtime.__file__).resolve()),
                                       measurement=str(Path(measurement.__file__).resolve()),
                                       shutdown=str(Path(group_shutdown.__file__).resolve()),
                                       python_executable=sys.executable, python_version=sys.version)
        if Path(receipt.origins.shutdown) != (Path(__file__).parent / "shutdown.py").resolve():
            raise RuntimeError("shutdown adapter import origin mismatch")
        expected_algorithms = config.repo / "examples/extensions/graph-algorithms/src/pyspark_pecan/algorithms.py"
        if Path(receipt.origins.algorithms) != expected_algorithms.resolve():
            raise RuntimeError("Pecan import does not come from configured source")
        expected_benchmarks = config.harness_repo / "examples/extensions/benchmarks"
        if (Path(receipt.origins.runtime) != (expected_benchmarks / "runtime.py").resolve()
                or Path(receipt.origins.measurement) != (expected_benchmarks / "measurement.py").resolve()):
            raise RuntimeError("benchmark helper import does not come from configured frozen harness")
        signal.alarm(ALGORITHM_DEADLINE_SECONDS)
        with group_shutdown.observe(receipt.shutdown):
            execute(config, journal, sink)
        if receipt.result is None:
            raise RuntimeError("missing exported algorithm metadata")
    except BaseException as error:  # noqa: BLE001 — cancellation and timeout are recorded outcomes.
        receipt.outcome = ("nonconverged" if isinstance(error, algorithms.ConvergenceError)
                           else "timeout" if isinstance(error, TimeoutError)
                           else "interrupted" if isinstance(error, (InterruptedError, KeyboardInterrupt)) else "error")
        receipt.error = ErrorRecord(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        try:
            summarize_rounds(receipt)
            staging = config.output / "staging"
            receipt.staging_payload_after_shutdown = [str(p.relative_to(staging)) for p in staging.rglob("*")
                                                      if p.is_symlink() or not p.is_dir()]
            if receipt.outcome == "running":
                receipt.outcome = ("cleanup_error" if any(r.sigkill_escalated or r.outcome != "closed" for r in receipt.shutdown) or not receipt.shutdown or sink.records or receipt.staging_payload_after_shutdown
                                   or receipt.incomplete_rounds else "passed")
        except BaseException as error:  # noqa: BLE001 — final observation cannot mask owned cleanup.
            sink.records.append(CleanupError(operation="final_observation", error=repr(error)))
            if receipt.outcome == "running":
                receipt.outcome = "cleanup_error"
        receipt.cleanup_errors = sink.records
        receipt.finished_utc = utc()
        journal.persist()
    print(json.dumps({"outcome": receipt.outcome, "receipt": str(config.output / "engine-receipt.json")}), flush=True)
    return 0 if receipt.outcome == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
