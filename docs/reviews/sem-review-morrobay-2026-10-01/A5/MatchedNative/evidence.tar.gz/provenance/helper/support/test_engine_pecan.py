"""Offline generalized native adapter controls; no engine/server/controller/native imports."""
from __future__ import annotations

import ast
import contextlib
import copy
import json
import unittest
from collections.abc import Callable, Iterator, Sequence
from pathlib import Path
from typing import Any, cast

from native_models import EngineConfig
from pydantic import ValidationError

SUPPORT = Path(__file__).parent
OLD = Path('/Volumes/Apo/graph-tests/results/sem-review-20261001/B7-native-preparation01/support/engine_pecan.py')
SOURCE = SUPPORT / 'engine_pecan.py'
CONTROLLER = Path('/Volumes/Apo/graph-tests/workspaces/sem-review-20261001/a5-matched-d0e4e422a/examples/extensions/graph-algorithms/src/pyspark_pecan/algorithms.py')


def function(tree: ast.Module, name: str) -> ast.FunctionDef:
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


def compile_nodes(nodes: Sequence[ast.stmt], namespace: dict[str, Any]) -> None:
    module = ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',
        names=[ast.alias(name='annotations')], level=0), *copy.deepcopy(nodes)], type_ignores=[]))
    exec(compile(module, '<owned-PR-adapter-control>', 'exec'), namespace)  # noqa: S102


class Journal:
    def __init__(self) -> None:
        self.phases: list[str] = []

    @contextlib.contextmanager
    def phase(self, name: str) -> Iterator[None]:
        self.phases.append(name)
        yield


def snapshot_hook(original: Callable[..., Any]) -> tuple[type[Any], Callable[[Journal], contextlib.AbstractContextManager[None]]]:
    class Algorithms:
        _snapshot = staticmethod(original)

    namespace: dict[str, Any] = {'algorithms': Algorithms, 'Journal': Journal,
        'StagingRun': object, 'DataFrame': object, 'Iterator': Iterator,
        'contextlib': contextlib, 'cast': cast}
    compile_nodes([function(ast.parse(SOURCE.read_text()), 'snapshot_phase')], namespace)
    return Algorithms, cast(Callable[[Journal], contextlib.AbstractContextManager[None]], namespace['snapshot_phase'])


class Controls(unittest.TestCase):
    def test_real_config_snapshot_bypass_and_pools(self) -> None:
        model = EngineConfig
        base: dict[str, object] = {'repo': '/controller', 'harness_repo': '/harness', 'output': '/fresh-output',
            'vertices': '/inputs/v.parquet', 'edges': '/inputs/e.parquet', 'binary': '/sail',
            'mode': 'local', 'engine':'pecan','dataset':'cit-Patents','algorithm': 'pagerank','method':'pregel_delta',
            'max_iterations':10,'source': 5795784, 'partitions': 16,
            'pool_bytes': 30 * 2**30, 'native_quota': 256 * 2**20}
        for flag in [False]:
            value = model.model_validate_json(json.dumps(base | {'snapshot_inputs': flag}))
            self.assertIs(value.model_dump()['snapshot_inputs'], flag)
        for invalid_flag in [True, 0, 1, 'true', 'false', None]:
            with self.subTest(flag=invalid_flag), self.assertRaises(ValidationError):
                model.model_validate_json(json.dumps(base | {'snapshot_inputs': invalid_flag}))
        with self.assertRaises(ValidationError):
            model.model_validate_json(json.dumps(base))

    def test_actual_hook_delegates_once_for_both_flags_and_count_modes(self) -> None:
        calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
        result = (object(), object(), None)

        def original(*args: object, **kwargs: object) -> tuple[object, object, None]:
            calls.append((args, kwargs))
            return result

        algorithms, hook = snapshot_hook(original)
        run, vertices, edges = object(), object(), object()
        journal = Journal()
        with hook(journal):
            for flag, count in [(True, True), (False, True), (False, False), (True, False)]:
                self.assertIs(algorithms._snapshot(run, vertices, edges, ('src', 'dst'),
                    count_vertices=count, snapshot=flag), result)
        self.assertEqual(calls, [((run, vertices, edges, ('src', 'dst')),
            {'count_vertices': count, 'snapshot': flag}) for flag, count in
            [(True, True), (False, True), (False, False), (True, False)]])
        self.assertEqual(journal.phases, ['input_snapshot'] * 4)
        self.assertIs(algorithms._snapshot, original)

    def test_original_error_propagates_and_hook_restores(self) -> None:
        error = RuntimeError('original snapshot failure')
        calls: list[bool] = []

        def original(*_args: object, count_vertices: bool = True, snapshot: bool = True) -> None:
            calls.append(snapshot)
            raise error

        algorithms, hook = snapshot_hook(original)
        with self.assertRaises(RuntimeError) as caught, hook(Journal()):
            algorithms._snapshot(object(), object(), object(), count_vertices=False, snapshot=False)
        self.assertIs(caught.exception, error)
        self.assertEqual(calls, [False])
        self.assertIs(algorithms._snapshot, original)

    def test_hook_matches_exact_d0_keyword_surface(self) -> None:
        current = function(ast.parse(CONTROLLER.read_text()), '_snapshot')
        adapter = function(ast.parse(SOURCE.read_text()), 'snapshot_phase')
        wrapper = next(n for n in adapter.body if isinstance(n, ast.FunctionDef) and n.name == 'measured')
        self.assertEqual([n.arg for n in current.args.kwonlyargs], ['count_vertices', 'snapshot'])
        self.assertEqual([n.arg for n in wrapper.args.kwonlyargs], ['count_vertices', 'snapshot'])

    def test_fixed_pagerank_call_has_no_input_validation_actions(self) -> None:
        tree = ast.parse(SOURCE.read_text())
        execute = function(tree, 'execute')
        graph = next(n for n in ast.walk(execute) if isinstance(n, ast.Call)
            and isinstance(n.func, ast.Attribute) and n.func.attr == 'GraphAlgorithms')
        kwargs = {k.arg: ast.unparse(k.value) for k in graph.keywords}
        self.assertEqual(kwargs['snapshot_inputs'], 'config.snapshot_inputs')
        self.assertEqual(kwargs['repartition_checkpoints'], 'True')
        self.assertEqual(kwargs['record_plans'], 'False')
        names = {n.attr for n in ast.walk(execute) if isinstance(n, ast.Attribute)}
        self.assertNotIn('count', names)
        self.assertNotIn('distinct', names)
        source = SOURCE.read_text()
        self.assertNotIn('profile_component_count', source)
        self.assertNotIn('profile_wcc', source)
        self.assertNotIn('measurement.cgroup_snapshot', source)
        self.assertIn('pecan_snapshot_inputs=config.snapshot_inputs', source)
        self.assertIn('frame.write.mode("error").parquet', source)
        call = next(n for n in ast.walk(execute) if isinstance(n, ast.Call)
                    and isinstance(n.func, ast.Attribute) and n.func.attr == 'pagerank')
        kwargs = {k.arg: ast.unparse(k.value) for k in call.keywords}
        self.assertEqual(kwargs, {'method':"'pregel_delta'",'reset_probability':'config.reset_probability',
            'tolerance':'config.tolerance','max_iterations':'config.max_iterations','normalize':'config.normalize',
            'vote_to_halt':'config.vote_to_halt','partitions':'config.partitions'})
        self.assertIn('handle.iterations != 10 or handle.converged is not None', source)

    def test_owned_cleanup_and_round_journal_remain_identical(self) -> None:
        old, new = ast.parse(OLD.read_text()), ast.parse(SOURCE.read_text())
        for name in ['cleanup', 'interrupted', 'summarize_rounds', 'atomic_receipt', 'append_record']:
            self.assertEqual(ast.dump(function(old, name)), ast.dump(function(new, name)))
        old_execute, new_execute = function(old, 'execute'), function(new, 'execute')
        old_finally = next(n for n in old_execute.body if isinstance(n, ast.Try)).finalbody
        new_finally = next(n for n in new_execute.body if isinstance(n, ast.Try)).finalbody
        self.assertEqual([ast.dump(n) for n in old_finally], [ast.dump(n) for n in new_finally])


if __name__ == '__main__':
    unittest.main()
