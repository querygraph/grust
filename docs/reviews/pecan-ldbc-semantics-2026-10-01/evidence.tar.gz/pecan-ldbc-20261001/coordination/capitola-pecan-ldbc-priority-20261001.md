# Alexy's requested priority: LDBC Graphalytics correctness first

Observed/request recorded UTC: 2026-10-01T18:34:50Z

To Astra / Capitola graph coordinator, explicitly requested by Alexy in the Morrobay graph conversation:

Please run the official LDBC Graphalytics `test-*` graphs FIRST, before further performance or scale experiments, to verify Pecan's LDBC semantics. Download the current test archives from https://ldbcouncil.org/benchmarks/graphalytics/datasets/ (test-graphs download script). The archives contain graph properties and reference results, including WCC components, PageRank values and SSSP distances. Use those references and parameters, not only our own synthetic oracle. Include directed/undirected input semantics, PageRank damping/iteration/dangling-node behavior and official validation tolerance, weighted SSSP source/direction/unreachable semantics, isolates, exact vertex coverage and WCC representative conventions. Retain actual outputs, input/reference hashes, source/runtime pins and every outcome. Separate API semantics mismatches from transport/runtime errors; do not loosen a reference to get a pass. Existing Grust AGENTS.md governs; for Sail changes read the actual checkout AGENTS.md and nested instructions. Reports and plans belong in Grust.

The frozen typed Pecan sequence on Morrobay is COMPLETE: all 14 cells passed, source 6ae2e43a903c2cee02da170465c922c72b76198e, runtime 56194b170155301ba91077f0ba3df31fe2c78b6b. Results are pushed to querygraph/grust branch work/morrobay-pecan-typed-results at 6d1d7093a9f39de70fcd0706347daf2a977a3bb8. No new benchmark is running here.

Please ACK with execution ownership, pinned source and the planned semantic matrix. Reply to /tmp/capitola-pecan-ldbc-ack-20261001.md on Morrobay or queue a message to the existing Morrobay graph thread 01a0efb4-9d6b-7843-a56a-32dc7b43266f, session name Review VM and publishing options. Do not target the eigen thread.
