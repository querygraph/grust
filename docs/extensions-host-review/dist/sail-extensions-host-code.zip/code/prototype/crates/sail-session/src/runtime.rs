use std::sync::Arc;

mod memory;
use datafusion::execution::DiskManager;
use datafusion::execution::cache::cache_manager::{
    CacheManagerConfig, FileMetadataCache, FileStatisticsCache, ListFilesCache,
};
use datafusion::execution::disk_manager::{DiskManagerBuilder, DiskManagerMode};
use datafusion::execution::runtime_env::{RuntimeEnv, RuntimeEnvBuilder};
use datafusion_common::Result;
use log::debug;
pub use memory::MemoryResourceDomain;
use sail_cache::file_listing_cache::MokaFileListingCache;
use sail_cache::file_metadata_cache::MokaFileMetadataCache;
use sail_cache::file_statistics_cache::MokaFileStatisticsCache;
use sail_common::config::{AppConfig, CacheType};
use sail_common::runtime::RuntimeHandle;
use sail_object_store::DynamicObjectStoreRegistry;

pub struct RuntimeEnvFactory {
    config: Arc<AppConfig>,
    runtime: RuntimeHandle,
    global_file_listing_cache: Option<Arc<ListFilesCache>>,
    global_file_statistics_cache: Option<Arc<FileStatisticsCache>>,
    global_file_metadata_cache: Option<Arc<MokaFileMetadataCache>>,
}

impl RuntimeEnvFactory {
    pub fn new(config: Arc<AppConfig>, runtime: RuntimeHandle) -> Self {
        Self {
            config,
            runtime,
            global_file_listing_cache: None,
            global_file_statistics_cache: None,
            global_file_metadata_cache: None,
        }
    }

    pub fn create<M>(
        &mut self,
        domain: Option<&MemoryResourceDomain>,
        mutator: M,
    ) -> Result<Arc<RuntimeEnv>>
    where
        M: FnOnce(RuntimeEnvBuilder) -> Result<RuntimeEnvBuilder>,
    {
        let registry = DynamicObjectStoreRegistry::new(self.runtime.clone());
        let cache_config = CacheManagerConfig::default()
            .with_file_statistics_cache(self.create_file_statistics_cache())
            .with_list_files_cache(self.create_file_listing_cache())
            .with_file_metadata_cache(Some(self.create_file_metadata_cache()));
        let cache_config = match &self.config.parquet.file_statistics_cache.r#type {
            CacheType::None => cache_config.with_file_statistics_cache_limit(0),
            CacheType::Global | CacheType::Session => cache_config,
        };
        let cache_config = match &self.config.execution.file_listing_cache.r#type {
            CacheType::None => cache_config.with_list_files_cache_limit(0),
            CacheType::Global | CacheType::Session => cache_config,
        };
        let cache_config = match &self.config.parquet.file_metadata_cache.r#type {
            CacheType::None => cache_config.with_metadata_cache_limit(0),
            CacheType::Global | CacheType::Session => cache_config,
        };
        let builder = RuntimeEnvBuilder::default()
            .with_object_store_registry(Arc::new(registry))
            .with_cache_manager(cache_config)
            .with_memory_pool(domain.map_or_else(
                || memory::new_pool(&self.config.runtime.memory_pool),
                MemoryResourceDomain::pool,
            ))
            .with_disk_manager_builder(self.create_disk_manager_builder());
        let builder = mutator(builder)?;
        Ok(Arc::new(builder.build()?))
    }

    fn create_disk_manager_builder(&self) -> DiskManagerBuilder {
        let max_size = self.config.runtime.temporary_files.max_size;
        let paths = self.config.runtime.temporary_files.paths.as_slice();

        let mut builder = DiskManager::builder();
        builder.set_max_temp_directory_size(max_size as u64);
        if max_size == 0 {
            builder.set_mode(DiskManagerMode::Disabled);
        } else if paths.is_empty() {
            builder.set_mode(DiskManagerMode::OsTmpDirectory);
        } else {
            let paths = paths.iter().map(|x| x.into()).collect();
            builder.set_mode(DiskManagerMode::Directories(paths));
        }
        builder
    }

    fn create_file_statistics_cache(&mut self) -> Option<Arc<FileStatisticsCache>> {
        let ttl = self.config.parquet.file_statistics_cache.ttl;
        let max_entries = self.config.parquet.file_statistics_cache.max_entries;
        match &self.config.parquet.file_statistics_cache.r#type {
            CacheType::None => {
                debug!("Not using file statistics cache");
                None
            }
            CacheType::Global => {
                debug!("Using global file statistics cache");
                Some(
                    self.global_file_statistics_cache
                        .get_or_insert_with(|| {
                            Arc::new(MokaFileStatisticsCache::new(ttl, max_entries))
                                as Arc<FileStatisticsCache>
                        })
                        .clone(),
                )
            }
            CacheType::Session => {
                debug!("Using session file statistics cache");
                Some(Arc::new(MokaFileStatisticsCache::new(ttl, max_entries)))
            }
        }
    }

    fn create_file_listing_cache(&mut self) -> Option<Arc<ListFilesCache>> {
        let ttl = self.config.execution.file_listing_cache.ttl;
        let max_entries = self.config.execution.file_listing_cache.max_entries;
        match &self.config.execution.file_listing_cache.r#type {
            CacheType::None => {
                debug!("Not using file listing cache");
                None
            }
            CacheType::Global => {
                debug!("Using global file listing cache");
                Some(
                    self.global_file_listing_cache
                        .get_or_insert_with(|| {
                            Arc::new(MokaFileListingCache::new(ttl, max_entries))
                                as Arc<ListFilesCache>
                        })
                        .clone(),
                )
            }
            CacheType::Session => {
                debug!("Using session file listing cache");
                Some(Arc::new(MokaFileListingCache::new(ttl, max_entries)))
            }
        }
    }

    fn create_file_metadata_cache(&mut self) -> Arc<FileMetadataCache> {
        let ttl = self.config.parquet.file_metadata_cache.ttl;
        let size_limit = self.config.parquet.file_metadata_cache.size_limit;
        match self.config.parquet.file_metadata_cache.r#type {
            CacheType::None => {
                debug!("Not using file metadata cache");
                Arc::new(MokaFileMetadataCache::new(ttl, Some(0)))
            }
            CacheType::Global => {
                debug!("Using global file metadata cache");
                self.global_file_metadata_cache
                    .get_or_insert_with(|| Arc::new(MokaFileMetadataCache::new(ttl, size_limit)))
                    .clone()
            }
            CacheType::Session => {
                debug!("Using session file metadata cache");
                Arc::new(MokaFileMetadataCache::new(ttl, size_limit))
            }
        }
    }
}
