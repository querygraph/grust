import datetime, hashlib, json, os, pathlib, shutil, subprocess, time
root = pathlib.Path('/Users/alexy/src/grust-arrow-pipeline')
os.chdir(root)
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert source.startswith('100822f')
receipt = pathlib.Path('/tmp/grust-cypher-path-runs') / datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
receipt.mkdir(parents=True, exist_ok=False)
binary = receipt / 'cypher_paths'
shutil.copy2(root / 'benchmarks/arrow-pipelines/target/release/cypher_paths', binary)
(receipt / 'driver.py').write_bytes(pathlib.Path(__file__).read_bytes())
state = {'source': source, 'binary': str(binary), 'sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'host': subprocess.check_output(['uname', '-a'], text=True).strip(), 'runs': [], 'complete': False}
print('RECEIPT', receipt, flush=True)
for hops in [2, 3]:
    for nodes in [0, 1, 2, 3, 17, 10000, 100000]:
        stem = f'h{hops}-n{nodes}'
        command = ['/usr/bin/time', '-l', str(binary), str(nodes), '3', str(hops)]
        start = time.monotonic()
        with (receipt / f'{stem}.jsonl').open('w') as out, (receipt / f'{stem}.stderr').open('w') as err:
            code = subprocess.run(command, stdout=out, stderr=err).returncode
        records = [json.loads(line) for line in (receipt / f'{stem}.jsonl').read_text().splitlines()]
        trials = [r for r in records if r.get('event') == 'trial']
        configs = [r for r in records if r.get('event') == 'configuration']
        passed = code == 0 and len(trials) == 6 and all(r['status'] == 'pass' for r in trials) and len(configs) == 1 and configs[0]['source'] == source and configs[0]['hops'] == hops and configs[0]['nodes'] == nodes
        state['runs'].append({'hops': hops, 'nodes': nodes, 'command': command, 'exit_code': code, 'seconds': time.monotonic() - start, 'passed': passed})
        (receipt / 'status.json').write_text(json.dumps(state, indent=2) + '\n')
        print('DONE', hops, nodes, code, passed, flush=True)
state['complete'] = True
state['all_passed'] = all(run['passed'] for run in state['runs'])
(receipt / 'status.json').write_text(json.dumps(state, indent=2) + '\n')
raise SystemExit(0 if state['all_passed'] else 1)
